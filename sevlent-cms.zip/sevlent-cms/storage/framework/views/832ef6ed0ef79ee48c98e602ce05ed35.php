

<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 overflow-hidden">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-10">
        <!-- Dots Pattern -->
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0); background-size: 40px 40px;"></div>

        <!-- Graph Lines -->
        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 1200 400" preserveAspectRatio="xMidYMid slice">
            <defs>
                <linearGradient id="blogLineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                    <stop offset="50%" style="stop-color:rgba(255,255,255,0.3);stop-opacity:1" />
                    <stop offset="100%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                </linearGradient>
            </defs>

            <!-- Horizontal lines -->
            <line x1="0" y1="50" x2="1200" y2="50" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="0" y1="150" x2="1200" y2="150" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="0" y1="250" x2="1200" y2="250" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="0" y1="350" x2="1200" y2="350" stroke="url(#blogLineGradient)" stroke-width="1"/>

            <!-- Vertical lines -->
            <line x1="200" y1="0" x2="200" y2="400" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="400" y1="0" x2="400" y2="400" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="600" y1="0" x2="600" y2="400" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="800" y1="0" x2="800" y2="400" stroke="url(#blogLineGradient)" stroke-width="1"/>
            <line x1="1000" y1="0" x2="1000" y2="400" stroke="url(#blogLineGradient)" stroke-width="1"/>
        </svg>
    </div>

    <!-- Floating Elements -->
    <div class="absolute inset-0">
        <!-- Floating dots -->
        <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute bottom-24 left-1/4 w-2 h-2 bg-white rounded-full opacity-25 animate-pulse" style="animation-delay: 2s;"></div>
        <div class="absolute bottom-32 right-1/3 w-5 h-5 bg-white rounded-full opacity-15 animate-pulse" style="animation-delay: 0.5s;"></div>

        <!-- Geometric shapes -->
        <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
        <div class="absolute bottom-16 left-16 w-8 h-8 border border-white rounded-full opacity-20"></div>
    </div>

    <!-- Overlay gradient -->
    <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>

    <!-- Content -->
    <div class="relative pt-32 pb-20">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-heading-xl md:text-heading-2xl lg:text-heading-3xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                Our Blog
            </h1>
            <p class="text-body-lg md:text-body-xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed drop-shadow">
                Stay updated with the latest insights, trends, and news from our team of experts.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#latest-posts" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-blue-600 bg-white hover:bg-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                    Explore Articles
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                    </svg>
                </a>
                <a href="<?php echo e(route('contact.index')); ?>" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-base font-semibold rounded-lg text-white hover:bg-white/10 hover:border-white transition-all duration-300">
                    Get In Touch
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Blog Content -->
<div id="latest-posts" class="bg-gray-50 py-16 -mt-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Categories Filter -->
        <?php if($categories->count() > 0): ?>
        <div class="mb-12">
            <div class="flex flex-wrap justify-center gap-4">
                <a href="<?php echo e(route('blogs.index')); ?>"
                   class="px-6 py-3 rounded-full text-sm font-medium <?php echo e(request('category') ? 'bg-gray-200 text-gray-700' : 'bg-blue-600 text-white'); ?> hover:bg-blue-700 hover:text-white transition-colors">
                    All Posts
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('blogs.index', ['category' => $category->slug])); ?>"
                   class="px-6 py-3 rounded-full text-sm font-medium <?php echo e(request('category') === $category->slug ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'); ?> hover:bg-blue-700 hover:text-white transition-colors">
                    <?php echo e($category->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Blog Posts Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
                <div class="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                    <?php if($blog->image): ?>
                        <?php if($blog->image->file_type === 'video'): ?>
                        <video class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" controls muted>
                            <source src="<?php echo e($blog->image->url); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                        <?php else: ?>
                        <img src="<?php echo e($blog->image->url); ?>"
                             alt="<?php echo e($blog->image->alt_text ?: $blog->title); ?>"
                             class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                        <?php endif; ?>
                        <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <?php else: ?>
                    <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
                        <div class="text-center">
                            <svg class="mx-auto h-16 w-16 text-gray-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                            <p class="text-xs text-gray-500 font-medium">No Media</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="p-8">
                    <?php if($blog->category): ?>
                    <span class="inline-block px-3 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full mb-4 uppercase tracking-wide">
                        <?php echo e($blog->category->name); ?>

                    </span>
                    <?php endif; ?>

                    <h2 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors leading-tight">
                        <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>" class="hover:text-blue-600 transition-colors">
                            <?php echo e($blog->title); ?>

                        </a>
                    </h2>

                    <p class="text-gray-600 mb-6 line-clamp-3 leading-relaxed">
                        <?php echo e(Str::limit(strip_tags($blog->excerpt ?: $blog->content), 150)); ?>

                    </p>

                    <div class="flex items-center justify-between text-sm text-gray-500 mb-6">
                        <div class="flex items-center">
                            <?php if($blog->author): ?>
                            <span class="font-medium">By <?php echo e($blog->author->name); ?></span>
                            <?php endif; ?>
                        </div>
                        <time datetime="<?php echo e($blog->published_at->format('Y-m-d')); ?>" class="font-medium">
                            <?php echo e($blog->published_at->format('M j, Y')); ?>

                        </time>
                    </div>

                    <div class="pt-4 border-t border-gray-100">
                        <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"
                           class="inline-flex items-center text-blue-600 hover:text-blue-800 font-semibold group-hover:gap-2 transition-all duration-300">
                            Read More
                            <svg class="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-center py-16">
                <div class="max-w-md mx-auto">
                    <svg class="mx-auto h-16 w-16 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">No blog posts available</h3>
                    <p class="text-gray-600 mb-6">Check back later for our latest articles and insights.</p>
                    <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition-colors">
                        Back to Home
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($blogs->hasPages()): ?>
        <div class="mt-12">
            <?php echo e($blogs->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/blogs/index.blade.php ENDPATH**/ ?>