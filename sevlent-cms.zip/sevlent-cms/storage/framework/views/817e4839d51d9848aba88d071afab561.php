

<?php
    $seoable = $page;
?>

<?php $__env->startSection('content'); ?>


<?php if($page->banner && !$page->sections->where('type', 'hero')->count()): ?>
    <section>
        <?php if($page->banner->file_type === 'video'): ?>
        <video controls class="w-full">
            <source src="<?php echo e($page->banner->url); ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <?php else: ?>
        <img src="<?php echo e($page->banner->url); ?>" alt="<?php echo e($page->title); ?>" class="w-full">
        <?php endif; ?>
    </section>
<?php endif; ?>


<?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if ($__env->exists('frontend.sections.' . $section->type, ['section' => $section])) echo $__env->make('frontend.sections.' . $section->type, ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/page.blade.php ENDPATH**/ ?>