

<?php
    $seoable = $service;
?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section with Content -->
<?php
    $backgroundMedia = $service->icon;
?>
<div class="relative overflow-hidden min-h-screen flex flex-col">
    
    <?php if (isset($component)) { $__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.background','data' => ['backgroundMedia' => $backgroundMedia,'backgroundVideoOverlay' => 'bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent','pattern' => 'dots','patternOpacity' => '0.1','floatingElements' => 'true','gradient' => 'hero-dark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('background'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['backgroundMedia' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($backgroundMedia),'backgroundVideoOverlay' => 'bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent','pattern' => 'dots','patternOpacity' => '0.1','floatingElements' => 'true','gradient' => 'hero-dark']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7)): ?>
<?php $attributes = $__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7; ?>
<?php unset($__attributesOriginala9a1d47caf0e21037a9fa995be1a1fc7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7)): ?>
<?php $component = $__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7; ?>
<?php unset($__componentOriginala9a1d47caf0e21037a9fa995be1a1fc7); ?>
<?php endif; ?>

    <!-- Content -->
    <div class="relative z-10 flex-1 flex flex-col justify-between pt-28 pb-24">

        <!-- Hero Content -->
        <div class="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-12 items-center">
                <!-- Left Content -->
                <div class="flex flex-col justify-start">
                    <?php if($service->category): ?>
                    <div class="inline-flex items-center gap-2 mb-6 w-fit">
                        <span class="px-4 py-2 text-xs font-bold uppercase tracking-widest bg-white/20 backdrop-blur text-white rounded-full border border-white/30">
                            <?php echo e($service->category->name); ?>

                        </span>
                    </div>
                    <?php endif; ?>

                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                        <?php echo e($service->name); ?>

                    </h1>

                    <?php if($service->short_description): ?>
                    <p class="text-lg md:text-xl text-white/90 mb-8 leading-relaxed drop-shadow">
                        <?php echo e($service->short_description); ?>

                    </p>
                    <?php endif; ?>

                    <?php if($service->pricing_info && isset($service->pricing_info['amount'])): ?>
                    <div class="bg-white/10 backdrop-blur-md border border-white/30 rounded-lg p-6 shadow-lg mb-8">
                        <p class="text-xs uppercase tracking-wider text-white/70 mb-2 font-semibold">
                            <?php if(isset($service->pricing_info['label'])): ?>
                                <?php echo e($service->pricing_info['label']); ?>

                            <?php else: ?>
                                Starting Price
                            <?php endif; ?>
                        </p>
                        <div class="flex items-baseline gap-2 mb-2">
                            <span class="text-4xl font-bold text-white"><?php echo e($service->pricing_info['amount']); ?></span>
                        </div>
                        <?php if(isset($service->pricing_info['description'])): ?>
                        <p class="text-sm text-white/80"><?php echo e($service->pricing_info['description']); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="flex flex-col sm:flex-row gap-4 pt-4">
                        <a href="#contact" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-blue-600 bg-white hover:bg-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                            Get Started
                            <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                            </svg>
                        </a>
                        <a href="<?php echo e(route('services.index')); ?>" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-base font-semibold rounded-lg text-white hover:bg-white/10 hover:border-white transition-all duration-300">
                            View All Services
                        </a>
                    </div>
                </div>

                <!-- Right Media -->
                <?php if($service->icon): ?>
                <div class="flex justify-center lg:justify-end">
                    <div class="relative group">
                        <!-- Glow effect -->
                        <div class="absolute inset-0 bg-gradient-to-t from-blue-600 via-transparent to-transparent blur-2xl opacity-50 group-hover:opacity-75 transition-opacity duration-300"></div>

                        <!-- Media container -->
                            <div class="bg-gradient-to-br from-white/5 to-white/10 rounded-2xl p-6 sm:p-8 border border-white/30">
                                <?php if($service->icon->file_type === 'video'): ?>
                                <video class="w-full h-48 sm:h-56 md:h-64 lg:h-72 xl:h-80 object-cover drop-shadow-2xl rounded-lg" controls muted>
                                    <source src="<?php echo e($service->icon->url); ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                                <?php else: ?>
                                <img src="<?php echo e($service->icon->url); ?>"
                                     alt="<?php echo e($service->name); ?>"
                                     class="w-full h-48 sm:h-56 md:h-64 lg:h-72 xl:h-80 object-cover drop-shadow-2xl rounded-lg">
                                <?php endif; ?>
                            </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Breadcrumbs fallback for small screens -->
<div class="bg-white border-b border-gray-100 lg:hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="flex items-center space-x-2 text-sm">
                <li>
                    <a href="<?php echo e(route('home')); ?>" class="text-gray-400 hover:text-blue-600 transition-colors">
                        <svg class="flex-shrink-0 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-5 5a1 1 0 001.414 1.414L9 3.414V15a1 1 0 102 0V3.414l3.293 3.293a1 1 0 001.414-1.414l-5-5z"/>
                        </svg>
                    </a>
                </li>
                <li class="text-gray-300">/</li>
                <li>
                    <a href="<?php echo e(route('services.index')); ?>" class="text-gray-500 hover:text-blue-600 transition-colors">Services</a>
                </li>
                <li class="text-gray-300">/</li>
                <li class="text-gray-700 font-medium"><?php echo e($service->name); ?></li>
            </ol>
        </nav>
    </div>
</div>

<!-- Service Content Blocks -->
<?php if($service->content_blocks && count($service->content_blocks) > 0): ?>
<div class="bg-white py-24">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="space-y-8">
            <?php $__currentLoopData = $service->content_blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($block['type'] === 'heading'): ?>
                    <div class="<?php if($index > 0): ?> pt-12 border-t border-gradient from-transparent via-gray-200 to-transparent <?php endif; ?>">
                        <h2 class="text-2xl md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-blue-600 mb-6 leading-tight">
                            <?php echo e($block['content']); ?>

                        </h2>
                    </div>
                <?php elseif($block['type'] === 'paragraph'): ?>
                    <div class="group">
                        <p class="text-lg text-gray-700 leading-relaxed font-light hover:text-gray-900 transition-colors duration-300">
                            <?php echo e($block['content']); ?>

                        </p>
                    </div>
                <?php elseif($block['type'] === 'image' && isset($block['image'])): ?>
                    <div class="my-16">
                        <div class="relative group overflow-hidden rounded-2xl shadow-xl border border-gray-100 hover:shadow-2xl transition-all duration-500">
                            <div class="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-indigo-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                            <img src="/storage/<?php echo e($block['image']); ?>" 
                                 alt="<?php echo e($block['content'] ?? 'Service image'); ?>"
                                 class="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500">
                        </div>
                        <?php if(isset($block['content']) && $block['content']): ?>
                            <p class="mt-6 text-center text-gray-600 italic text-sm font-light"><?php echo e($block['content']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Service Features -->
<?php if($service->features && count($service->features) > 0): ?>
<div class="relative py-24 bg-gradient-to-b from-white via-blue-50/30 to-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="mb-16 text-center">
            <h2 class="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-blue-600 mb-4 leading-tight">Key Features & Benefits</h2>
            <p class="text-lg md:text-xl text-gray-600 font-light">Everything you need to succeed with this service</p>
        </div>
        
        <div class="grid md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $service->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group flex items-start gap-4 bg-white p-8 rounded-xl border border-gray-100 hover:border-blue-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-blue-50/30 transition-all duration-300">
                <div class="flex-shrink-0 mt-0.5">
                    <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-blue-100 to-indigo-100 group-hover:from-blue-200 group-hover:to-indigo-200 transition-colors duration-300 flex-shrink-0">
                        <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                </div>
                <div class="flex-1">
                    <p class="text-base font-semibold text-gray-900 group-hover:text-gray-900 transition-colors"><?php echo e($feature); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Related Services -->
<?php if($relatedServices->count() > 0): ?>
<div class="bg-gradient-to-b from-gray-50 to-white py-24">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-blue-600 mb-4 leading-tight">Related Services</h2>
            <p class="text-lg text-gray-600 font-light">Explore other solutions that complement and enhance this service</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $relatedServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('services.show', $relatedService->slug)); ?>" class="group">
                <div class="h-full bg-white rounded-2xl overflow-hidden border border-gray-100 hover:border-blue-300 hover:shadow-2xl transition-all duration-300 flex flex-col hover:-translate-y-2">
                    <div class="p-8 flex-grow flex flex-col">
                        <h3 class="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                            <?php echo e($relatedService->name); ?>

                        </h3>

                        <p class="text-gray-600 text-sm mb-6 flex-grow leading-relaxed">
                            <?php echo e(Str::limit($relatedService->short_description ?? 'Discover this service', 100)); ?>

                        </p>

                        <div class="inline-flex items-center text-blue-600 font-semibold group-hover:gap-2 transition-all duration-300">
                            Learn More
                            <svg class="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Contact CTA -->
<div id="contact" class="relative bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 py-24 overflow-hidden">
    <!-- Decorative animated elements -->
    <div class="absolute inset-0 overflow-hidden pointer-events-none">
        <div class="absolute -top-40 -right-40 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl"></div>
        <div class="absolute -bottom-20 -left-40 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl"></div>
        <div class="absolute top-1/2 right-1/3 w-64 h-64 bg-blue-300 opacity-5 rounded-full blur-3xl"></div>
    </div>

    <div class="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-lg">Ready to Get Started?</h2>
        <p class="text-xl md:text-2xl text-white mb-12 max-w-2xl mx-auto leading-relaxed font-light drop-shadow">
            Contact us today to discuss how we can help bring your project to life. Our expert team is ready to assist you.
        </p>
        <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/contact" class="inline-flex items-center justify-center px-8 py-4 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-all duration-300 shadow-xl hover:shadow-2xl hover:-translate-y-1 group">
                Contact Us Now
                <svg class="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
            <a href="<?php echo e(route('services.index')); ?>" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-white font-semibold rounded-lg hover:bg-white/10 hover:border-white transition-all duration-300 backdrop-blur-sm">
                Browse All Services
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/services/show.blade.php ENDPATH**/ ?>