

<?php $__env->startSection('title', $project->title); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="bg-gradient-to-r from-blue-500 to-purple-600 h-32 lg:h-40 relative overflow-hidden">
    <!-- Dots Pattern -->
    <div class="absolute inset-0 opacity-20">
        <svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <pattern id="projectDots" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="10" cy="10" r="1" fill="white"/>
                </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#projectDots)"/>
        </svg>
    </div>
</section>

<!-- Breadcrumbs -->
<div class="bg-gray-100 py-4">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="flex items-center space-x-4">
                <li>
                    <a href="<?php echo e(route('home')); ?>" class="text-gray-400 hover:text-gray-500">
                        <svg class="flex-shrink-0 h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-5 5a1 1 0 001.414 1.414L9 3.414V15a1 1 0 102 0V3.414l3.293 3.293a1 1 0 001.414-1.414l-5-5z"/>
                        </svg>
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="flex-shrink-0 h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <a href="<?php echo e(route('projects.index')); ?>" class="ml-4 text-sm font-medium text-gray-500 hover:text-gray-700">Projects</a>
                    </div>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="flex-shrink-0 h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <span class="ml-4 text-sm font-medium text-gray-500"><?php echo e($project->title); ?></span>
                    </div>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Project Header -->
<div class="bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
            <div>
                <h1 class="text-4xl font-bold text-gray-900 mb-4"><?php echo e($project->title); ?></h1>

                <?php if($project->description): ?>
                <p class="text-l text-gray-600 mb-8"><?php echo e($project->description); ?></p>
                <?php endif; ?>

                <?php if($project->technologies): ?>
                <div class="mb-6">
                    <h3 class="text-sm font-medium text-gray-900 mb-2">Technologies Used</h3>
                    <div class="flex flex-wrap gap-2">
                        <?php $__currentLoopData = is_array($project->technologies) ? $project->technologies : explode(',', $project->technologies); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full"><?php echo e(trim($tech)); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="flex flex-col sm:flex-row gap-4">
                    <?php if($project->project_url): ?>
                    <a href="<?php echo e($project->project_url); ?>" target="_blank" class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        <svg class="mr-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                        </svg>
                        View Live Project
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('projects.index')); ?>" class="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        View All Projects
                    </a>
                </div>
            </div>

            <?php if($project->media && $project->media->count() > 0): ?>
            <div class="mt-10 lg:mt-0">
                <div class="relative">
                    <img src="<?php echo e(asset('storage/' . $project->media->first()->file_path)); ?>"
                         alt="<?php echo e($project->title); ?>"
                         class="w-full rounded-lg shadow-lg">
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Project Gallery -->
<?php if($project->media && $project->media->count() > 0): ?>
<div class="bg-gray-100 py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-900 mb-4">Project Gallery</h2>
        </div>

        <div class="overflow-x-auto pb-4">
            <div class="flex space-x-6 min-w-max">
                <?php $__currentLoopData = $project->media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg overflow-hidden shadow-md flex-shrink-0 w-[28rem]">
                    <?php if(strpos($media->mime_type, 'image') === 0): ?>
                    <img src="<?php echo e(asset('storage/' . $media->file_path)); ?>"
                         alt="<?php echo e($media->file_name); ?>"
                         class="w-full h-72 object-cover">
                    <?php else: ?>
                    <div class="h-72 bg-gray-200 flex items-center justify-center">
                        <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Project Content -->
<div class="bg-white py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-gray-50 rounded-lg p-6 md:p-12">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Project Details</h2>
            
            <?php if($project->description): ?>
                <div class="text-lg text-gray-700 mb-8 leading-relaxed">
                    <?php echo e($project->description); ?>

                </div>
            <?php endif; ?>

            <?php if($project->content_blocks && count($project->content_blocks) > 0): ?>
                <div class="space-y-6">
                    <?php $__currentLoopData = $project->content_blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($block['type'] === 'heading'): ?>
                            <h3 class="text-2xl font-bold text-gray-900 mt-8 mb-4"><?php echo e($block['content']); ?></h3>

                        <?php elseif($block['type'] === 'paragraph'): ?>
                            <div class="prose prose-lg max-w-none text-gray-700 leading-relaxed">
                                <?php
                                    // Process simple markdown formatting
                                    $content = $block['content'];
                                    // Bold: **text**
                                    $content = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $content);
                                    // Italic: *text*
                                    $content = preg_replace('/\*(.*?)\*/', '<em>$1</em>', $content);
                                    // Convert newlines to paragraphs
                                    $content = nl2br($content);
                                ?>
                                <?php echo $content; ?>

                            </div>

                        <?php elseif($block['type'] === 'image'): ?>
                            <figure class="my-8">
                                <?php if(isset($block['image']) && $block['image']): ?>
                                    <img src="<?php echo e(asset('storage/' . $block['image'])); ?>"
                                         alt="<?php echo e($block['content'] ?? 'Project image'); ?>"
                                         class="max-w-full mx-auto rounded-lg shadow-lg">
                                <?php endif; ?>
                                <?php if(!empty($block['content'])): ?>
                                    <figcaption class="mt-3 text-center text-sm text-gray-600 italic">
                                        <?php echo e($block['content']); ?>

                                    </figcaption>
                                <?php endif; ?>
                            </figure>

                        <?php elseif($block['type'] === 'list'): ?>
                            <ul class="list-disc list-inside space-y-2 text-gray-700 ml-4">
                                <?php $__currentLoopData = explode("\n", $block['content']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(trim($item)): ?>
                                        <li class="leading-relaxed"><?php echo e(trim($item)); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        <?php elseif($block['type'] === 'link'): ?>
                            <?php
                                $parts = explode('|', $block['content']);
                                $linkText = $parts[0] ?? 'Link';
                                $linkUrl = $parts[1] ?? '#';
                            ?>
                            <div class="my-4">
                                <a href="<?php echo e($linkUrl); ?>"
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   class="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition-all duration-200">
                                    <?php echo e($linkText); ?>

                                    <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                    </svg>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php elseif($project->description): ?>
                <div class="prose prose-lg max-w-none">
                    <?php echo $project->description; ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Related Projects -->
<?php if($relatedProjects->count() > 0): ?>
<div class="bg-gradient-to-b from-gray-50 to-white py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Related Projects</h2>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">Discover more projects from our portfolio</p>
            <div class="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mt-6 rounded-full"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $relatedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-gray-100 group">
                <div class="p-6">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                        <a href="<?php echo e(route('projects.show', $relatedProject->slug)); ?>" class="block">
                            <?php echo e($relatedProject->title); ?>

                        </a>
                    </h3>

                    <p class="text-gray-600 mb-4 line-clamp-3 leading-relaxed">
                        <?php echo e(Str::limit(strip_tags($relatedProject->description), 120)); ?>

                    </p>

                    <?php if($relatedProject->technologies): ?>
                    <div class="mb-4">
                        <div class="flex flex-wrap gap-1">
                            <?php $__currentLoopData = is_array($relatedProject->technologies) ? $relatedProject->technologies : explode(',', $relatedProject->technologies); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="px-3 py-1 text-xs bg-blue-100 text-blue-700 rounded-full font-medium"><?php echo e(trim($tech)); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center text-sm text-gray-500">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                            </svg>
                            <time datetime="<?php echo e($relatedProject->created_at->format('Y-m-d')); ?>">
                                <?php echo e($relatedProject->created_at->format('M j, Y')); ?>

                            </time>
                        </div>
                        <a href="<?php echo e(route('projects.show', $relatedProject->slug)); ?>"
                           class="inline-flex items-center px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 hover:text-gray-900 font-medium rounded-md shadow-sm hover:shadow-md transform hover:-translate-y-0.5 transition-all duration-200 group border border-gray-200 hover:border-gray-300">
                            <span>View Project</span>
                            <svg class="w-4 h-4 ml-2 group-hover:translate-x-0.5 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Contact CTA -->
<div class="bg-blue-600 py-16">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-3xl font-bold text-white mb-4">Ready to Start Your Project?</h2>
        <p class="text-xl text-white mb-8">
            Let's discuss how we can bring your ideas to life with our expertise.
        </p>
        <a href="/contact" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-gray-50">
            Get In Touch
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/projects/show.blade.php ENDPATH**/ ?>