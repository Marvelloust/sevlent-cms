<!-- Topbar -->
<header class="fixed top-0 left-0 right-0 z-40 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 shadow-lg transition-all duration-300 ease-in-out" :class="sidebarCollapsed ? 'md:left-16' : 'md:left-64'" style="backdrop-filter: blur(10px);">
    <div class="px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <!-- Mobile menu button -->
            <div class="flex items-center md:hidden">
                <button @click="sidebarOpen = !sidebarOpen" type="button" class="text-white/90 hover:text-white hover:bg-white/10 focus:outline-none focus:text-white p-2 rounded-lg transition-all duration-200" aria-controls="sidebar" :aria-expanded="sidebarOpen">
                    <span class="sr-only">Open sidebar</span>
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path x-show="!sidebarOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        <path x-show="sidebarOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

            <!-- Breadcrumb -->
            <div class="flex items-center">
                <button @click="sidebarCollapsed = !sidebarCollapsed" class="hidden md:block mr-4 text-white/90 hover:text-white hover:bg-white/10 p-2 rounded-lg transition-all duration-200">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path x-show="!sidebarCollapsed" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                        <path x-show="sidebarCollapsed" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                </button>
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                        <i class="fas fa-tachometer-alt text-white text-sm"></i>
                    </div>
                    <div>
                        <h2 class="text-lg font-bold text-white"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h2>
                        <p class="text-xs text-white hidden sm:block">Admin Panel</p>
                    </div>
                </div>
            </div>

            <!-- Right side -->
            <div class="flex items-center space-x-3">
                <!-- Search -->
                <div class="hidden md:block relative">
                    <input type="text" placeholder="Search..." class="w-64 pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/30 focus:bg-white/20 transition-all duration-200 text-sm">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center">
                        <svg class="h-4 w-4 text-white/70" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                </div>

                <!-- Dark Mode Toggle -->
                <button @click="darkMode = !darkMode" 
                        class="inline-flex items-center justify-center h-9 w-9 p-2 text-white/90 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200" 
                        title="Toggle dark mode">
                    <span class="sr-only">Toggle dark mode</span>
                    <svg x-show="!darkMode" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                    </svg>
                    <svg x-show="darkMode" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                </button>

                <!-- Notifications -->
                <div class="relative" x-data="{ 
                    open: false,
                    notifications: [],
                    unreadCount: 0,
                    loading: false,
                    async fetchNotifications() {
                        if (this.loading) return;
                        this.loading = true;
                        try {
                            const response = await fetch('<?php echo e(route('admin.notifications.recent')); ?>');
                            const data = await response.json();
                            this.notifications = data.notifications;
                            this.unreadCount = data.unread_count;
                        } catch (error) {
                            console.error('Failed to fetch notifications:', error);
                        } finally {
                            this.loading = false;
                        }
                    },
                    async markAsRead(id) {
                        try {
                            await fetch(`/admin/notifications/${id}/mark-as-read`, {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                                    'Content-Type': 'application/json',
                                }
                            });
                            await this.fetchNotifications();
                        } catch (error) {
                            console.error('Failed to mark notification as read:', error);
                        }
                    },
                    async markAllAsRead() {
                        try {
                            await fetch('<?php echo e(route('admin.notifications.mark-all-as-read')); ?>', {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                                    'Content-Type': 'application/json',
                                }
                            });
                            await this.fetchNotifications();
                        } catch (error) {
                            console.error('Failed to mark all notifications as read:', error);
                        }
                    }
                }" x-init="fetchNotifications(); setInterval(() => fetchNotifications(), 60000)">
                    <button @click="open = !open; if(open) fetchNotifications()" class="inline-flex items-center justify-center h-9 w-9 p-2 text-white/90 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 relative">
                        <span class="sr-only">View notifications</span>
                        <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        <span x-show="unreadCount > 0" x-text="unreadCount" class="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white font-bold"></span>
                    </button>

                    <!-- Notifications Dropdown -->
                    <div x-show="open" @click.away="open = false" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 z-10 mt-2 w-96 origin-top-right bg-white dark:bg-gray-800 rounded-xl shadow-xl ring-1 ring-black ring-opacity-5 dark:ring-gray-700 focus:outline-none transition-colors duration-200" role="menu">
                        <!-- Header -->
                        <div class="px-4 py-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                            <h3 class="text-sm font-semibold text-gray-900 dark:text-white">Notifications</h3>
                            <div class="flex items-center space-x-2">
                                <button x-show="unreadCount > 0" @click="markAllAsRead()" class="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium">
                                    Mark all read
                                </button>
                                <a href="<?php echo e(route('admin.notifications.index')); ?>" class="text-xs text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 font-medium">
                                    View all
                                </a>
                            </div>
                        </div>

                        <!-- Notifications List -->
                        <div class="max-h-96 overflow-y-auto">
                            <template x-if="loading">
                                <div class="p-4 text-center text-gray-500 dark:text-gray-400">
                                    <i class="fas fa-spinner fa-spin mr-2"></i>
                                    Loading...
                                </div>
                            </template>

                            <template x-if="!loading && notifications.length === 0">
                                <div class="p-8 text-center">
                                    <i class="fas fa-bell-slash text-4xl text-gray-300 dark:text-gray-600 mb-2"></i>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">No notifications</p>
                                </div>
                            </template>

                            <template x-if="!loading && notifications.length > 0">
                                <div>
                                    <template x-for="notification in notifications" :key="notification.id">
                                        <div class="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors" :class="notification.is_read ? 'opacity-60' : ''">
                                            <div class="p-4">
                                                <div class="flex items-start space-x-3">
                                                    <!-- Icon -->
                                                    <div class="flex-shrink-0">
                                                        <div :class="notification.color_class" class="rounded-full p-2">
                                                            <i :class="notification.icon_class" class="text-white text-sm"></i>
                                                        </div>
                                                    </div>

                                                    <!-- Content -->
                                                    <div class="flex-1 min-w-0">
                                                        <p class="text-sm font-medium text-gray-900 dark:text-white" x-text="notification.title"></p>
                                                        <p class="text-xs text-gray-600 dark:text-gray-400 mt-1" x-text="notification.message"></p>
                                                        <div class="flex items-center justify-between mt-2">
                                                            <p class="text-xs text-gray-500 dark:text-gray-400" x-text="notification.created_at_human"></p>
                                                            <div class="flex items-center space-x-2">
                                                                <template x-if="notification.link">
                                                                    <a :href="notification.link" class="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300">View</a>
                                                                </template>
                                                                <template x-if="!notification.is_read">
                                                                    <button @click="markAsRead(notification.id)" class="text-xs text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300">
                                                                        <i class="fas fa-check"></i>
                                                                    </button>
                                                                </template>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>

                        <!-- Footer -->
                        <div class="px-4 py-3 border-t border-gray-200 dark:border-gray-700 text-center">
                            <a href="<?php echo e(route('admin.notifications.index')); ?>" class="text-sm text-blue-600 hover:text-blue-800 font-medium">
                                View All Notifications
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Profile dropdown -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center space-x-3 text-sm rounded-lg focus:outline-none focus:ring-2 focus:ring-white/30 hover:bg-white/10 p-2 transition-all duration-200" id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                        <img class="h-8 w-8 rounded-lg border-2 border-white/30" src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(auth()->user()->name)); ?>&color=FFFFFF&background=6366F1" alt="">
                        <div class="hidden md:block text-left">
                            <div class="font-semibold text-white"><?php echo e(auth()->user()->name); ?></div>
                            <div class="text-xs text-white">Administrator</div>
                        </div>
                        <svg class="hidden md:block h-4 w-4 text-white/70" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </button>

                    <div x-show="open" @click.away="open = false" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 z-10 mt-2 w-56 origin-top-right bg-white dark:bg-gray-800 rounded-xl shadow-xl ring-1 ring-black ring-opacity-5 dark:ring-gray-700 focus:outline-none transition-colors duration-200" role="menu" aria-orientation="vertical" aria-labelledby="user-menu-button" tabindex="-1">
                        <div class="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                            <p class="text-sm font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->name); ?></p>
                            <p class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(auth()->user()->email); ?></p>
                        </div>
                        <div class="py-1">
                            <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white transition-colors duration-150" role="menuitem" tabindex="-1">
                                <i class="fas fa-user mr-3 text-gray-400 dark:text-gray-500"></i>
                                Your Profile
                            </a>
                            <a href="<?php echo e(route('admin.settings.index')); ?>" class="flex items-center px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white transition-colors duration-150" role="menuitem" tabindex="-1">
                                <i class="fas fa-cog mr-3 text-gray-400 dark:text-gray-500"></i>
                                Settings
                            </a>
                        </div>
                        <div class="border-t border-gray-200 dark:border-gray-700 py-1">
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="block">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-700 dark:hover:text-red-300 transition-colors duration-150" role="menuitem" tabindex="-1">
                                    <i class="fas fa-sign-out-alt mr-3"></i>
                                    Sign out
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/layouts/topbar.blade.php ENDPATH**/ ?>