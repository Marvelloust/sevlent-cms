

<?php $__env->startSection('title', 'FAQs Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r  from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-question-circle mr-3"></i>FAQs Management
                    </h1>
                    <p class="text-white">Create and manage frequently asked questions</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.faqs.create')); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-green-600 font-semibold rounded-lg shadow-md hover:bg-green-50 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Add New FAQ
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <i class="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active FAQs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($activeFaqs); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-gray-500">
            <div class="flex items-center">
                <div class="p-3 bg-gray-100 dark:bg-gray-600 rounded-full">
                    <i class="fas fa-pause-circle text-gray-600 dark:text-gray-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Inactive FAQs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($inactiveFaqs); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <i class="fas fa-question-circle text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total FAQs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($totalFaqs); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQs Table -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Filters Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <form method="GET" action="<?php echo e(route('admin.faqs.index')); ?>" class="space-y-3">
                <!-- All Filters in One Line -->
                <div class="flex flex-wrap gap-3">
                    <!-- Search -->
                    <div class="w-80">
                        <label for="search" class="sr-only">Search FAQs</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                                   class="block w-full bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 pl-10 pr-4 py-2 text-sm"
                                   placeholder="Search FAQs...">
                        </div>
                    </div>

                    <!-- Status Filter -->
                    <div class="w-36">
                        <label for="status" class="sr-only">Filter by status</label>
                        <select name="status" id="status"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('status') === 'all' || !request('status') ? 'selected' : ''); ?>>All Status</option>
                            <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                    <!-- Icon Filter -->
                    <div class="w-36">
                        <label for="icon" class="sr-only">Filter by icon</label>
                        <select name="icon" id="icon"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('icon') === 'all' || !request('icon') ? 'selected' : ''); ?>>All Icons</option>
                            <option value="clock" <?php echo e(request('icon') === 'clock' ? 'selected' : ''); ?>>Clock</option>
                            <option value="settings" <?php echo e(request('icon') === 'settings' ? 'selected' : ''); ?>>Settings</option>
                            <option value="lightbulb" <?php echo e(request('icon') === 'lightbulb' ? 'selected' : ''); ?>>Lightbulb</option>
                            <option value="check" <?php echo e(request('icon') === 'check' ? 'selected' : ''); ?>>Check</option>
                            <option value="calendar" <?php echo e(request('icon') === 'calendar' ? 'selected' : ''); ?>>Calendar</option>
                        </select>
                    </div>

                    <!-- Color Filter -->
                    <div class="w-36">
                        <label for="color" class="sr-only">Filter by color</label>
                        <select name="color" id="color"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('color') === 'all' || !request('color') ? 'selected' : ''); ?>>All Colors</option>
                            <option value="blue" <?php echo e(request('color') === 'blue' ? 'selected' : ''); ?>>Blue</option>
                            <option value="purple" <?php echo e(request('color') === 'purple' ? 'selected' : ''); ?>>Purple</option>
                            <option value="indigo" <?php echo e(request('color') === 'indigo' ? 'selected' : ''); ?>>Indigo</option>
                            <option value="green" <?php echo e(request('color') === 'green' ? 'selected' : ''); ?>>Green</option>
                            <option value="orange" <?php echo e(request('color') === 'orange' ? 'selected' : ''); ?>>Orange</option>
                        </select>
                    </div>

                    <!-- Sort Options -->
                    <div class="w-48">
                        <label for="sort_by" class="sr-only">Sort by</label>
                        <select name="sort_by" id="sort_by"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="order" <?php echo e(request('sort_by') === 'order' || !request('sort_by') ? 'selected' : ''); ?>>Order</option>
                            <option value="question" <?php echo e(request('sort_by') === 'question' ? 'selected' : ''); ?>>Question</option>
                            <option value="icon" <?php echo e(request('sort_by') === 'icon' ? 'selected' : ''); ?>>Icon</option>
                            <option value="color" <?php echo e(request('sort_by') === 'color' ? 'selected' : ''); ?>>Color</option>
                            <option value="is_active" <?php echo e(request('sort_by') === 'is_active' ? 'selected' : ''); ?>>Status</option>
                            <option value="created_at" <?php echo e(request('sort_by') === 'created_at' ? 'selected' : ''); ?>>Created Date</option>
                            <option value="updated_at" <?php echo e(request('sort_by') === 'updated_at' ? 'selected' : ''); ?>>Updated Date</option>
                        </select>
                    </div>

                    <!-- Sort Direction -->
                    <div class="w-32">
                        <label for="sort_direction" class="sr-only">Sort direction</label>
                        <select name="sort_direction" id="sort_direction"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="asc" <?php echo e(request('sort_direction') === 'asc' || !request('sort_direction') ? 'selected' : ''); ?>>Ascending</option>
                            <option value="desc" <?php echo e(request('sort_direction') === 'desc' ? 'selected' : ''); ?>>Descending</option>
                        </select>
                    </div>
                </div>

                <!-- Buttons on Second Line -->
                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.faqs.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-times mr-2"></i>Clear
                    </a>
                </div>
            </form>
        </div>

        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600"></i>All FAQs
                    <?php if(request('search') || request('status') !== 'all' && request('status') || request('icon') !== 'all' && request('icon') || request('color') !== 'all' && request('color')): ?>
                        <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                            (<?php echo e($faqs->total()); ?> result<?php echo e($faqs->total() !== 1 ? 's' : ''); ?>)
                        </span>
                    <?php endif; ?>
                </h3>
                <?php if(request('search') || request('status') !== 'all' && request('status') || request('icon') !== 'all' && request('icon') || request('color') !== 'all' && request('color')): ?>
                    <div class="mt-2 sm:mt-0 flex flex-wrap gap-2">
                        <?php if(request('search')): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                                Search: "<?php echo e(request('search')); ?>"
                                <a href="<?php echo e(request()->fullUrlWithQuery(['search' => null])); ?>" class="ml-1 text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('status') && request('status') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300">
                                Status: <?php echo e(ucfirst(request('status'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => null])); ?>" class="ml-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('icon') && request('icon') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300">
                                Icon: <?php echo e(ucfirst(request('icon'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['icon' => null])); ?>" class="ml-1 text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('color') && request('color') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300">
                                Color: <?php echo e(ucfirst(request('color'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['color' => null])); ?>" class="ml-1 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50 dark:bg-gray-900">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-sort mr-2"></i>Order & Question
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-palette mr-2"></i>Icon & Color
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-info-circle mr-2"></i>Status
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Created
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-10 h-10">
                                        <div class="w-10 h-10 rounded-full bg-gradient-to-r from-green-500 to-teal-500 flex items-center justify-center">
                                            <span class="text-sm font-bold text-white"><?php echo e($faq->order); ?></span>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900 dark:text-white line-clamp-2"><?php echo e($faq->question); ?></div>
                                        <div class="text-sm text-gray-600 dark:text-gray-400 line-clamp-1"><?php echo e(Str::limit($faq->answer, 60)); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center space-x-3">
                                    <div class="flex items-center">
                                        <?php
                                            $iconColor = match($faq->color) {
                                                'blue', 'indigo' => setting('primary_color', '#3b82f6'),
                                                'purple' => setting('secondary_color', '#8b5cf6'),
                                                'green' => setting('accent_color', '#10b981'),
                                                default => setting('primary_color', '#3b82f6'),
                                            };
                                        ?>
                                        <i class="fas fa-<?php echo e($faq->icon); ?> text-lg" style="color: <?php echo e($iconColor); ?>"></i>
                                        <span class="ml-2 text-sm font-medium text-gray-900 dark:text-white"><?php echo e(ucfirst($faq->icon)); ?></span>
                                    </div>
                                    <div class="w-4 h-4 rounded-full border-2 border-gray-300 dark:border-gray-600" style="background-color: <?php echo e($iconColor); ?>"></div>
                                    <span class="text-sm text-gray-600 dark:text-gray-400"><?php echo e(ucfirst($faq->color)); ?></span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($faq->is_active ? 'bg-green-100 dark:bg-green-300 text-green-800 dark:text-green-300 border border-green-200 dark:border-green-700' : 'bg-gray-100 dark:bg-gray-300 text-gray-800 dark:text-gray-300 border border-gray-200 dark:border-gray-600'); ?>">
                                    <i class="fas <?php echo e($faq->is_active ? 'fa-check-circle' : 'fa-pause-circle'); ?> mr-1"></i>
                                    <?php echo e($faq->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                                <?php echo e($faq->created_at->format('M d, Y')); ?>

                                <div class="text-xs text-gray-400 dark:text-gray-500"><?php echo e($faq->created_at->format('H:i')); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.faqs.edit', $faq)); ?>" class="inline-flex items-center px-3 py-1 bg-blue-100 dark:bg-blue-300 text-yellow-100 dark:text-yellow-100 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors duration-150">
                                        <i class="fas fa-edit mr-1"></i>Edit
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.faqs.destroy', $faq)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="inline-flex items-center px-3 py-1 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-md hover:bg-red-200 dark:hover:bg-red-800 transition-colors duration-150" onclick="showDeleteConfirmation('Are you sure you want to delete this FAQ? This action cannot be undone.', () => { this.closest('form').submit(); })">
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <i class="fas fa-question-circle text-gray-300 dark:text-gray-600 text-4xl mb-4"></i>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No FAQs found</h3>
                                    <p class="text-gray-500 dark:text-gray-400 mb-4">
                                        <?php if(request('search') || request('status') !== 'all' && request('status') || request('icon') !== 'all' && request('icon') || request('color') !== 'all' && request('color')): ?>
                                            No FAQs match your current filters. Try adjusting your search criteria.
                                        <?php else: ?>
                                            No FAQs have been created yet. Create your first FAQ to get started.
                                        <?php endif; ?>
                                    </p>
                                    <?php if(!request('search') && (!request('status') || request('status') === 'all') && (!request('icon') || request('icon') === 'all') && (!request('color') || request('color') === 'all')): ?>
                                        <a href="<?php echo e(route('admin.faqs.create')); ?>" class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-150">
                                            <i class="fas fa-plus mr-2"></i>Add New FAQ
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.faqs.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-150">
                                            <i class="fas fa-times mr-2"></i>Clear Filters
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if($faqs->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            Showing <span class="font-medium"><?php echo e($faqs->firstItem()); ?></span> to
                            <span class="font-medium"><?php echo e($faqs->lastItem()); ?></span> of
                            <span class="font-medium"><?php echo e($faqs->total()); ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-1">
                        
                        <?php if($faqs->onFirstPage()): ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-l-lg">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($faqs->previousPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-l-lg hover:bg-gray-50 dark:hover:bg-gray-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </a>
                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $faqs->getUrlRange(1, $faqs->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $faqs->currentPage()): ?>
                                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 cursor-default">
                                    <?php echo e($page); ?>

                                </span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                    <?php echo e($page); ?>

                                </a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($faqs->hasMorePages()): ?>
                            <a href="<?php echo e($faqs->nextPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-r-lg hover:bg-gray-50 dark:hover:bg-gray-700 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-r-lg">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50" id="success-message">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('success-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50" id="error-message">
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-2"></i>
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('error-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/faqs/index.blade.php ENDPATH**/ ?>