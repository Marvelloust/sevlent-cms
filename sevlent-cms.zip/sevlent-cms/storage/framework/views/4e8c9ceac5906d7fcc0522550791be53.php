

<?php
    $fieldName = $fieldName ?? 'media_ids';
    $selectedMedia = $selectedMedia ?? collect();
    $label = $label ?? 'Select Media';
    $help = $help ?? '';
    $required = $required ?? false;
    $allowedTypes = $allowedTypes ?? ['image'];
    $previewSize = $previewSize ?? 'w-24 h-24';
?>

<div class="multiple-media-picker" data-field="<?php echo e($fieldName); ?>" data-allowed-types="<?php echo e(json_encode($allowedTypes)); ?>">
    <label for="<?php echo e($fieldName); ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
        <?php echo e($label); ?>

        <?php if($required): ?>
            <span class="text-red-500">*</span>
        <?php endif; ?>
    </label>

    <?php if($help): ?>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e($help); ?></p>
    <?php endif; ?>

    <!-- Selected media display -->
    <div id="<?php echo e($fieldName); ?>-container" class="mt-2 space-y-6">
        <!-- Current selected media with enhanced grid -->
        <div id="<?php echo e($fieldName); ?>-selected" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <?php $__currentLoopData = $selectedMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative group <?php echo e($previewSize); ?> rounded-xl overflow-hidden bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200" data-media-id="<?php echo e($media->id); ?>">
                    <!-- Gradient overlay for hover effect -->
                    <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10"></div>

                    <?php if($media->file_type === 'image'): ?>
                        <img src="<?php echo e($media->url); ?>" alt="<?php echo e($media->alt_text); ?>" class="w-full h-full object-cover transition-transform duration-200 group-hover:scale-110">
                    <?php elseif($media->file_type === 'video'): ?>
                        <video class="w-full h-full object-cover" muted>
                            <source src="<?php echo e($media->url); ?>" type="<?php echo e($media->mime_type); ?>">
                        </video>
                        <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                            <div class="bg-white/90 rounded-full p-2">
                                <svg class="w-4 h-4 text-gray-800 dark:text-white" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M8 5v14l11-7z"/>
                                </svg>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="w-full h-full bg-gradient-to-br from-gray-100 to-slate-200 flex items-center justify-center">
                            <svg class="w-8 h-8 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                        </div>
                    <?php endif; ?>

                    <!-- Enhanced remove button -->
                    <button type="button" onclick="removeMultipleMedia('<?php echo e($fieldName); ?>', <?php echo e($media->id); ?>)"
                            class="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 transform scale-75 group-hover:scale-100 shadow-lg z-20">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>

                    <!-- File type indicator -->
                    <div class="absolute top-2 left-2 z-20">
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-black/60 text-white backdrop-blur-sm">
                            <?php if($media->file_type === 'image'): ?>
                                <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                            <?php elseif($media->file_type === 'video'): ?>
                                <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                                </svg>
                            <?php else: ?>
                                <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                </svg>
                            <?php endif; ?>
                            <?php echo e(ucfirst(substr($media->file_type, 0, 3))); ?>

                        </span>
                    </div>

                    <!-- Hidden input for this media -->
                    <input type="hidden" name="<?php echo e($fieldName); ?>[]" value="<?php echo e($media->id); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Enhanced add media button with modern gradient design -->
        <div class="relative mt-6 group cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-800 dark:via-gray-800 dark:to-gray-800 border-2 border-dashed border-blue-300 dark:border-blue-700 hover:border-blue-500 dark:hover:border-blue-500 transition-all duration-300 hover:shadow-2xl"
             onclick="document.querySelector('button[onclick*=\"openMultipleMediaSelector\"]').click()">
            <!-- Animated background gradient -->
            <div class="absolute inset-0 bg-gradient-to-r from-blue-400/10 via-indigo-400/10 to-purple-400/10 dark:from-blue-600/20 dark:via-indigo-600/20 dark:to-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            
            <div class="relative text-center py-16 px-6">
                <!-- Icon with pulse animation -->
                <div class="mx-auto w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 dark:from-blue-600 dark:to-indigo-700 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                    <svg class="w-10 h-10 text-white animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                </div>
                
                <div class="space-y-4">
                    <h3 class="text-xl font-bold text-gray-900 dark:text-white">Add Project Images</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-400 max-w-md mx-auto leading-relaxed"><?php echo e($help ?? 'Select multiple images from the media library to showcase your project'); ?></p>
                    
                    <button type="button" onclick="openMultipleMediaSelector('<?php echo e($fieldName); ?>')"
                            class="inline-flex items-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-2xl hover:shadow-blue-500/50 dark:hover:shadow-blue-900/50 transform hover:-translate-y-1 hover:scale-105 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800">
                        <svg class="-ml-1 mr-3 h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                        </svg>
                        <span class="tracking-wide">Browse Media Library</span>
                    </button>
                    
                    <!-- Feature highlights -->
                    <div class="flex items-center justify-center gap-6 mt-6 text-xs text-gray-500 dark:text-gray-400">
                        <div class="flex items-center gap-1.5">
                            <svg class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            <span>Multiple Upload</span>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <svg class="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                            </svg>
                            <span>Drag & Drop</span>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <svg class="w-4 h-4 text-purple-500" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
                            </svg>
                            <span>Instant Preview</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function openMultipleMediaSelector(fieldName) {
    const allowedTypes = document.querySelector(`[data-field="${fieldName}"]`).dataset.allowedTypes;
    const url = `<?php echo e(route('admin.media.selector')); ?>?types=${encodeURIComponent(JSON.stringify(allowedTypes))}&multiple=true`;

    const selectorWindow = window.open(url, 'mediaSelector', 'width=1200,height=800,scrollbars=yes,resizable=yes');

    // Store field name for callback
    window.currentMediaField = fieldName;
    window.fieldId = fieldName; // Set fieldId for selector compatibility

    // Listen for media selection messages
    const messageHandler = function(event) {
        console.log('Received message:', event.data);
        if (event.origin !== window.location.origin) {
            console.log('Ignoring message from different origin:', event.origin);
            return;
        }
        
        if (event.data.type === 'MEDIA_SELECTED_MULTIPLE') {
            addMultipleMediaSelections(fieldName, event.data.media);
            selectorWindow.close();
            window.removeEventListener('message', messageHandler);
        }
    };
    window.addEventListener('message', messageHandler);

    // Clean up listener when window closes
    selectorWindow.onbeforeunload = function() {
        window.removeEventListener('message', messageHandler);
    };
}

function addMultipleMediaSelections(fieldName, mediaArray) {
    const container = document.getElementById(`${fieldName}-selected`);

    mediaArray.forEach(media => {
        // Check if already selected
        if (document.querySelector(`[data-media-id="${media.id}"]`)) {
            return; // Skip if already selected
        }

        // Create media preview element
        const mediaElement = createMediaElement(fieldName, media);
        container.appendChild(mediaElement);
    });
}

function createMediaElement(fieldName, media) {
    const element = document.createElement('div');
    element.className = 'relative group w-24 h-24 rounded-xl overflow-hidden bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200';
    element.setAttribute('data-media-id', media.id);

    let mediaContent = '';
    let fileTypeIcon = '';

    if (media.type === 'image') {
        mediaContent = `<img src="${media.url}" alt="${media.alt_text}" class="w-full h-full object-cover transition-transform duration-200 group-hover:scale-110">`;
        fileTypeIcon = `<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
        </svg>`;
    } else if (media.type === 'video') {
        mediaContent = `<video class="w-full h-full object-cover" muted><source src="${media.url}" type="${media.mime_type}"></video>
        <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <div class="bg-white/90 rounded-full p-2">
                <svg class="w-4 h-4 text-gray-800 dark:text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                </svg>
            </div>
        </div>`;
        fileTypeIcon = `<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
        </svg>`;
    } else {
        mediaContent = `<div class="w-full h-full bg-gradient-to-br from-gray-100 to-slate-200 flex items-center justify-center">
            <svg class="w-8 h-8 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
        </div>`;
        fileTypeIcon = `<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
        </svg>`;
    }

    element.innerHTML = `
        <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10"></div>
        ${mediaContent}
        <button type="button" onclick="removeMultipleMedia('${fieldName}', ${media.id})"
                class="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 transform scale-75 group-hover:scale-100 shadow-lg z-20">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
        <div class="absolute top-2 left-2 z-20">
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-black/60 text-white backdrop-blur-sm">
                ${fileTypeIcon}
                ${media.type.charAt(0).toUpperCase() + media.type.slice(1, 4)}
            </span>
        </div>
        <input type="hidden" name="${fieldName}[]" value="${media.id}">
    `;

    return element;
}

function removeMultipleMedia(fieldName, mediaId) {
    const element = document.querySelector(`[data-media-id="${mediaId}"]`);
    if (element) {
        element.remove();
    }
}
</script><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/media/multiple-picker.blade.php ENDPATH**/ ?>