<!-- Modern Team Section -->
<section class="py-24 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
    <!-- Background Elements -->
    <div class="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))] -z-10"></div>
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Header with CTA Button -->
        <div class="grid lg:grid-cols-2 gap-12 items-center mb-16" data-aos="fade-up">
            <!-- Left Side: Heading and Subheading -->
            <div class="space-y-6">
                <!-- Badge -->
                <?php if(!empty($section->data['section_label'])): ?>
                <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full">
                    <span class="text-sm font-semibold text-blue-700"><?php echo e($section->data['section_label']); ?></span>
                </div>
                <?php endif; ?>

                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    <span class="bg-clip-text text-transparent bg-gradient-to-r from-gray-900 via-purple-900 to-gray-900">
                        <?php echo e($section->title); ?>

                    </span>
                </h2>

                <?php if(!empty($section->data['subheadline'])): ?>
                    <div class="text-body-lg md:text-body-xl text-gray-600">
                        <?php echo $section->data['subheadline']; ?>

                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Side: CTA Button -->
            <?php if(!empty($section->data['cta_button_text'])): ?>
            <div class="lg:text-right" data-aos="fade-up" data-aos-delay="100">
                <a href="<?php echo e($section->data['cta_button_url'] ?? '#'); ?>"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all duration-300 transform hover:scale-105">
                    <span><?php echo e($section->data['cta_button_text']); ?></span>
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Team Members Carousel -->
        <?php
            $members = $section->data['members'] ?? [];
            if (is_string($members)) {
                $members = json_decode($members, true);
            }

            // Randomly shuffle and select up to 6 members for display
            if ($members && is_array($members) && count($members) > 0) {
                shuffle($members);
                $members = array_slice($members, 0, 6);
            }
        ?>

        <?php if($members && is_array($members) && count($members) > 0): ?>
        <div class="relative mb-16">
            <!-- Carousel Container -->
            <div class="overflow-x-auto scrollbar-hide pb-4">
                <div class="flex space-x-6 px-4" style="width: max-content;">
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $gradients = [
                                'from-blue-500 to-indigo-600',
                                'from-purple-500 to-pink-600',
                                'from-green-500 to-emerald-600',
                                'from-orange-500 to-red-600',
                                'from-cyan-500 to-blue-600',
                                'from-pink-500 to-purple-600',
                            ];
                            $gradient = $gradients[$index % count($gradients)];
                        ?>

                        <div class="group relative bg-white rounded-2xl border border-gray-200 p-6 transition-all duration-300 hover:shadow-2xl hover:border-transparent hover:-translate-y-2 flex-shrink-0 w-80" data-aos="fade-up" data-aos-delay="<?php echo e($index * 100); ?>">
                            <!-- Gradient Border on Hover -->
                            <div class="absolute inset-0 bg-gradient-to-r <?php echo e($gradient); ?> rounded-2xl opacity-0 group-hover:opacity-5 transition-opacity duration-300 -z-10"></div>

                            <!-- Avatar -->
                            <div class="relative mb-6 text-center">
                                <?php if(!empty($member['image'])): ?>
                                    <img src="/storage/<?php echo e($member['image']); ?>" alt="<?php echo e($member['name'] ?? 'Team Member'); ?>" class="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white shadow-lg ring-2 ring-gray-100 group-hover:ring-purple-200 transition-all duration-300">
                                <?php else: ?>
                                    <div class="w-24 h-24 bg-gradient-to-r <?php echo e($gradient); ?> rounded-full mx-auto flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                                        <?php echo e(substr($member['name'] ?? 'T', 0, 1)); ?>

                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Member Info -->
                            <div class="text-center space-y-3 mb-6">
                                <h3 class="text-heading-sm font-bold text-gray-900"><?php echo e($member['name'] ?? 'Team Member'); ?></h3>
                                <p class="text-sm font-semibold text-purple-600"><?php echo e($member['position'] ?? 'Position'); ?></p>
                                <?php if(!empty($member['bio'])): ?>
                                    <p class="text-sm text-gray-600 leading-relaxed line-clamp-3"><?php echo e($member['bio']); ?></p>
                                <?php endif; ?>
                            </div>

                            <!-- Social Links -->
                            <?php
                                $socialLinks = [];
                                if (!empty($member['linkedin'])) $socialLinks['linkedin'] = $member['linkedin'];
                                if (!empty($member['twitter'])) $socialLinks['twitter'] = $member['twitter'];
                                if (!empty($member['github'])) $socialLinks['github'] = $member['github'];
                                if (!empty($member['dribbble'])) $socialLinks['dribbble'] = $member['dribbble'];
                            ?>
                            <?php if(!empty($socialLinks)): ?>
                            <div class="flex justify-center space-x-3 pt-4 border-t border-gray-100">
                                <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($url): ?>
                                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener noreferrer"
                                           class="w-10 h-10 bg-gray-100 hover:bg-gradient-to-r <?php echo e($gradient); ?> rounded-full flex items-center justify-center text-gray-600 hover:text-white transition-all duration-300 transform hover:scale-110"
                                           title="<?php echo e(ucfirst($platform)); ?>">
                                            <?php switch($platform):
                                                case ('linkedin'): ?>
                                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                                                    </svg>
                                                    <?php break; ?>
                                                <?php case ('twitter'): ?>
                                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                                                    </svg>
                                                    <?php break; ?>
                                                <?php case ('github'): ?>
                                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                                                    </svg>
                                                    <?php break; ?>
                                                <?php case ('dribbble'): ?>
                                                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M12 0C5.374 0 0 5.373 0 12c0 6.628 5.374 12 12 12s12-5.372 12-12S18.626 0 12 0zm9.885 11.441c-2.575-.422-4.943-.445-7.103-.073-.244-.563-.497-1.125-.767-1.68 2.31-1 4.165-2.358 5.548-4.082 1.35 1.594 2.197 3.619 2.322 5.835zm-3.842-7.282c-1.205 1.554-2.868 2.783-4.986 3.68-1.016-1.861-2.178-3.676-3.488-5.438.779-.197 1.591-.314 2.431-.314 2.275 0 4.368.779 6.043 2.072zm-10.516-.993c1.331 1.742 2.511 3.538 3.537 5.381-2.43.715-5.331 1.082-8.684 1.105.692-2.835 2.601-5.193 5.147-6.486zm-5.44 8.834l.013-.256c3.849-.005 7.169-.448 9.95-1.322.233.475.456.952.67 1.432-3.38 1.057-6.165 3.222-8.337 6.48-1.432-1.719-2.296-3.927-2.296-6.334zm3.829 7.81c1.969-3.088 4.482-5.098 7.598-6.027.928 2.42 1.609 4.91 2.043 7.46-3.349 1.291-6.953.666-9.641-1.433zm11.586.43c-.438-2.353-1.08-4.653-1.92-6.897 1.876-.265 3.94-.196 6.199.196-.437 2.786-2.028 5.192-4.279 6.701z"/>
                                                    </svg>
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Scroll Indicators -->
            <div class="flex justify-center space-x-2 mt-6">
                <div class="flex space-x-2">
                    <?php for($i = 0; $i < count($members); $i++): ?>
                    <button class="w-2 h-2 rounded-full bg-gray-300 transition-all duration-300 hover:bg-gray-400 team-indicator" data-slide="<?php echo e($i); ?>"></button>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Scrollbar Hide CSS -->
<style>
    .scrollbar-hide::-webkit-scrollbar {
        display: none;
    }
    .scrollbar-hide {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
    .line-clamp-3 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
</style><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/team.blade.php ENDPATH**/ ?>