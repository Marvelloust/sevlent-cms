<?php
    $bgColors = [
        'white' => 'bg-white',
        'gray' => 'bg-gray-50',
        'blue' => 'bg-blue-50',
        'gradient' => 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    ];
    $bgClass = $bgColors[$section->data['background_color'] ?? 'white'] ?? 'bg-white';
?>

<!-- Modern Content Section -->
<section class="py-24 <?php echo e($bgClass); ?> relative overflow-hidden">
    <!-- Background Decorations -->
    <?php if($bgClass === 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'): ?>
        <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-indigo-100/40 rounded-full blur-3xl -z-10"></div>
        <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100/40 to-pink-100/40 rounded-full blur-3xl -z-10"></div>
    <?php endif; ?>

    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <!-- Header Section -->
        <div class="text-center mb-16" data-aos="fade-up">
            <?php if(!empty($section->data['section_badge'])): ?>
                <div class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold bg-white/80 backdrop-blur-sm text-gray-800 border border-gray-200/50 shadow-sm mb-6">
                    <span class="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mr-2"></span>
                    <?php echo e($section->data['section_badge']); ?>

                </div>
            <?php endif; ?>

            <?php if(!empty($section->data['headline'])): ?>
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight mb-6">
                    <?php echo e($section->data['headline']); ?>

                </h2>
            <?php endif; ?>

            <?php if(!empty($section->data['subheadline'])): ?>
                <p class="text-body-lg md:text-body-xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-8">
                    <?php echo e($section->data['subheadline']); ?>

                </p>
            <?php endif; ?>

            <?php if(!empty($section->title) && empty($section->data['headline'])): ?>
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight mb-8">
                    <?php echo e($section->title); ?>

                </h2>
            <?php endif; ?>
        </div>

        <!-- Main Content -->
        <?php if(!empty($section->content)): ?>
            <div class="mb-16" data-aos="fade-up" data-aos-delay="200">
                <div class="bg-white/70 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-xl border border-white/20">
                    <div class="prose prose-xl prose-gray max-w-none">
                        <div class="text-body-lg md:text-body-xl text-gray-700 leading-relaxed">
                            <?php echo $section->content; ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Content Blocks -->
        <?php if(!empty($section->data['content_blocks']) && is_array($section->data['content_blocks'])): ?>
            <div class="space-y-12" data-aos="fade-up" data-aos-delay="300">
                <?php $__currentLoopData = $section->data['content_blocks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($block['type']) && isset($block['content'])): ?>
                        <?php if($block['type'] === 'heading'): ?>
                            <div class="text-center" data-aos="fade-up" data-aos-delay="<?php echo e(400 + ($index * 100)); ?>">
                                <h3 class="text-heading-lg md:text-heading-xl font-bold text-gray-900 mb-6 relative">
                                    <?php echo e($block['content']); ?>

                                    <div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                                </h3>
                            </div>
                        <?php elseif($block['type'] === 'paragraph'): ?>
                            <div class="bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-white/30" data-aos="fade-up" data-aos-delay="<?php echo e(400 + ($index * 100)); ?>">
                                <p class="text-body-lg md:text-body-xl text-gray-700 leading-relaxed text-center max-w-4xl mx-auto">
                                    <?php echo e($block['content']); ?>

                                </p>
                            </div>
                        <?php elseif($block['type'] === 'list'): ?>
                            <?php
                                // Handle both string and array content
                                if (is_array($block['content'])) {
                                    $items = array_filter(array_map('trim', $block['content']));
                                } else {
                                    $items = explode("\n", $block['content']);
                                    $items = array_filter(array_map('trim', $items));
                                }
                            ?>
                            <?php if(count($items) > 0): ?>
                                <div class="bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-white/30" data-aos="fade-up" data-aos-delay="<?php echo e(400 + ($index * 100)); ?>">
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex items-start group">
                                                <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mr-4 mt-1 group-hover:scale-110 transition-transform duration-200">
                                                    <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                    </svg>
                                                </div>
                                                <span class="text-gray-700 text-lg leading-relaxed group-hover:text-gray-900 transition-colors duration-200"><?php echo e($item); ?></span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php elseif($block['type'] === 'image'): ?>
                            <div class="text-center" data-aos="fade-up" data-aos-delay="<?php echo e(400 + ($index * 100)); ?>">
                                <?php if($block['content']): ?>
                                    <div class="relative inline-block">
                                        <div class="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-3xl blur-xl transform scale-110"></div>
                                        <img src="/storage/<?php echo e($block['content']); ?>"
                                             alt="<?php echo e($block['alt'] ?? ''); ?>"
                                             class="relative w-full max-w-4xl h-auto rounded-3xl shadow-2xl border border-white/50">
                                        <?php if(isset($block['caption']) && !empty($block['caption'])): ?>
                                            <p class="text-center text-gray-600 mt-6 text-lg italic bg-white/50 backdrop-blur-sm rounded-xl py-3 px-6 inline-block">
                                                <?php echo e($block['caption']); ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/content.blade.php ENDPATH**/ ?>