

<?php
    $menuName = $menu ?? 'main';
    $navClass = $class ?? 'navigation';
    $maxDepth = $depth ?? 2;
    $isScrolled = $scrolled ?? false;

    // Find menu by name or ID
    if (is_numeric($menuName)) {
        $menu = \App\Models\Menu::find($menuName);
    } else {
        $menu = \App\Models\Menu::where('name', $menuName)->first();
    }

    if (!$menu) {
        return;
    }

    $menuItems = $menu->topLevelItems()->active()->get();
?>

<?php if($menuItems->count() > 0): ?>
<nav class="<?php echo e($navClass); ?>">
    <ul class="menu-items flex space-x-4">
        <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="menu-item <?php echo e($item->css_class); ?>">
            <a href="<?php echo e($item->url); ?>"
               target="<?php echo e($item->target); ?>"
               class="menu-link px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo e($isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'); ?> <?php echo e($item->css_class); ?>">
                <?php if($item->icon): ?>
                    <i class="<?php echo e($item->icon); ?> mr-2"></i>
                <?php endif; ?>
                <?php echo e($item->title); ?>

            </a>

            
            <?php if($item->children->count() > 0 && $item->depth < $maxDepth): ?>
            <ul class="submenu absolute hidden bg-white shadow-lg rounded-md mt-2 py-2 min-w-48">
                <?php echo $__env->make('components.navigation-submenu', ['items' => $item->children, 'maxDepth' => $maxDepth, 'currentDepth' => $item->depth + 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </ul>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<?php endif; ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/components/navigation.blade.php ENDPATH**/ ?>