

<?php $__env->startSection('title', 'Page Sections - ' . $page->title); ?>
<?php $__env->startSection('page-title', 'Manage Page Sections'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-puzzle-piece mr-3"></i>Page Sections Management
                    </h1>
                    <p class="text-white">Manage and customize sections for "<?php echo e($page->title); ?>"</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-blue-600 font-semibold rounded-lg shadow-md hover:bg-gray-100 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-edit mr-2"></i>
                        Edit Page
                    </a>
                    <button type="button" id="addSectionBtn" class="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Add Section
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <i class="fas fa-check-circle text-green-600 dark:text-green-200 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->where('is_active', true)->count()); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-gray-500">
            <div class="flex items-center">
                <div class="p-3 bg-gray-100 dark:bg-gray-700 rounded-full">
                    <i class="fas fa-pause-circle text-gray-600 dark:text-gray-300 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Inactive Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->where('is_active', false)->count()); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <i class="fas fa-puzzle-piece text-blue-600 dark:text-blue-200 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->count()); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sections List -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600"></i>All Sections
                    <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                        (<?php echo e($page->sections->count()); ?> section<?php echo e($page->sections->count() !== 1 ? 's' : ''); ?>)
                    </span>
                </h3>
                <div class="mt-2 sm:mt-0 text-sm text-gray-600">
                    <i class="fas fa-arrows-alt mr-1"></i>Drag and drop to reorder sections
                </div>
            </div>
        </div>

        <div class="px-6 py-4">
            <div id="sectionsContainer" class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="section-item bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-200 overflow-hidden" data-section-id="<?php echo e($section->id); ?>">
                        <div class="px-4 sm:px-6 py-4 sm:py-5">
                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                                <div class="flex items-center space-x-3 sm:space-x-4">
                                    <div class="drag-handle cursor-move text-gray-400 hover:text-blue-600 transition-colors duration-200 p-2 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 flex-shrink-0">
                                        <i class="fas fa-grip-vertical text-lg"></i>
                                    </div>
                                    <div class="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                                        <i class="fas fa-puzzle-piece text-white text-xs sm:text-sm"></i>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <h3 class="text-base sm:text-lg font-semibold text-gray-900 dark:text-white mb-1 truncate"><?php echo e($section->title); ?></h3>
                                        <p class="text-sm text-gray-600 dark:text-gray-400 mb-1 sm:mb-2"><?php echo e($sectionTypes[$section->type]['name'] ?? ucfirst($section->type)); ?></p>
                                        <div class="flex flex-wrap items-center gap-2 sm:gap-4 text-xs text-gray-500 dark:text-gray-400">
                                            <span class="flex items-center"><i class="fas fa-hashtag mr-1"></i>ID: <?php echo e($section->id); ?></span>
                                            <span class="flex items-center"><i class="fas fa-sort mr-1"></i>Order: <?php echo e($section->order_index); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                                    <span class="inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-semibold self-start sm:self-center <?php echo e($section->is_active ? 'bg-green-100 text-green-800 border border-green-200 dark:bg-green-800 dark:text-green-100 dark:border-green-700' : 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300 border border-gray-200 dark:border-gray-700'); ?>">
                                        <i class="fas <?php echo e($section->is_active ? 'fa-check-circle' : 'fa-pause-circle'); ?> mr-1"></i>
                                        <?php echo e($section->is_active ? 'Active' : 'Inactive'); ?>

                                    </span>
                                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                                        <button type="button" class="edit-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-blue-100 dark:bg-blue-200 text-blue-700 dark:text-blue-200 rounded-lg hover:bg-green-200 dark:hover:bg-blue-800 transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas fa-edit mr-2 h-4 w-4 flex-shrink-0"></i>Edit
                                        </button>
                                        <button type="button" class="toggle-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 <?php echo e($section->is_active ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200 dark:bg-yellow-800 dark:text-yellow-100 dark:hover:bg-yellow-700' : 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-800 dark:text-green-100 dark:hover:bg-green-700'); ?> rounded-lg transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas <?php echo e($section->is_active ? 'fa-pause' : 'fa-play'); ?> mr-2 h-4 w-4 flex-shrink-0"></i>
                                            <?php echo e($section->is_active ? 'Disable' : 'Enable'); ?>

                                        </button>
                                        <button type="button" class="delete-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-red-100 dark:bg-red-800 text-red-700 dark:text-red-100 rounded-lg hover:bg-red-200 dark:hover:bg-red-700 transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas fa-trash mr-2 h-4 w-4 flex-shrink-0"></i>Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-16">
                        <div class="mx-auto w-24 h-24 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 rounded-full flex items-center justify-center mb-6">
                            <i class="fas fa-puzzle-piece text-blue-600 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No sections yet</h3>
                        <p class="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">Get started by creating your first page section. Sections help you build dynamic, modular content for your pages.</p>
                        <button type="button" id="addFirstSectionBtn" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg shadow-md hover:from-blue-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105">
                            <i class="fas fa-plus mr-2"></i>Create Your First Section
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Section Modal -->
<div id="sectionModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 dark:bg-gray-900 dark:bg-opacity-75 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-4 mx-auto p-4 sm:p-5 border border-gray-200 dark:border-gray-700 w-11/12 max-w-5xl shadow-2xl rounded-xl bg-white dark:bg-gray-800 max-h-[95vh] overflow-y-auto">
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-t-xl px-4 sm:px-6 py-3 sm:py-4">
            <div class="flex items-center justify-between">
                <h3 class="text-lg sm:text-xl font-bold text-white" id="modalTitle">Add Section</h3>
                <button type="button" id="closeModalBtn" class="text-blue-200 hover:text-white transition-colors duration-200 p-2 rounded-lg hover:bg-white/10 dark:hover:bg-white/10 flex-shrink-0">
                    <i class="fas fa-times text-lg sm:text-xl"></i>
                </button>
            </div>
        </div>

        <div class="p-4 sm:p-6">
            <form id="sectionForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="sectionId" name="section_id">
                <input type="hidden" id="orderIndex" name="order_index" value="0">

                <div class="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 mb-6">
                    <div>
                        <label for="sectionType" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                            <i class="fas fa-cubes mr-2 text-blue-600"></i>Section Type
                        </label>
                        <select id="sectionType" name="type" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200">
                            <?php $__currentLoopData = $sectionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>"><?php echo e($config['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="sectionTitle" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                            <i class="fas fa-heading mr-2 text-blue-600"></i>Section Title
                        </label>
                        <input type="text" id="sectionTitle" name="title" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200" placeholder="Enter section title">
                    </div>
                </div>

                <div class="mb-6">
                    <label for="sectionContent" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                        <i class="fas fa-align-left mr-2 text-blue-600"></i>Content
                    </label>
                    <textarea id="sectionContent" name="content" rows="4" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200" placeholder="Enter section content"></textarea>
                </div>

                <!-- Dynamic Fields Container -->
                <div id="dynamicFields" class="mb-6 space-y-4 sm:space-y-6 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
                    <!-- Fields will be dynamically added here based on section type -->
                </div>

                <div class="flex flex-col sm:flex-row sm:items-center p-3 sm:p-4 bg-blue-50 dark:bg-blue-900/10 rounded-lg border border-blue-200 dark:border-blue-700 mb-6 gap-2 sm:gap-0">
                    <div class="flex items-center">
                        <input type="checkbox" id="isActive" name="is_active" value="1" checked class="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 rounded transition-colors duration-200">
                        <label for="isActive" class="ml-3 block text-sm font-medium text-gray-900 dark:text-white">
                            <i class="fas fa-toggle-on mr-2 text-blue-600"></i>Active Section
                        </label>
                    </div>
                    <span class="text-sm text-gray-600 dark:text-gray-400 sm:ml-2">(Visible on the page)</span>
                </div>

                <div class="flex flex-col sm:flex-row justify-end gap-3 sm:gap-0 sm:space-x-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <button type="button" id="cancelBtn" class="inline-flex items-center justify-center px-4 sm:px-6 py-2 sm:py-3 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-all duration-200 transform hover:scale-105 leading-tight order-2 sm:order-1">
                        <i class="fas fa-times mr-2 h-4 w-4 flex-shrink-0"></i>Cancel
                    </button>
                    <button type="submit" class="inline-flex items-center justify-center px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-600 dark:to-purple-700 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 dark:hover:from-blue-700 dark:hover:to-purple-700 transition-all duration-200 transform hover:scale-105 leading-tight order-1 sm:order-2">
                        <i class="fas fa-save mr-2 h-4 w-4 flex-shrink-0"></i>Save Section
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentSectionId = null;
    let sortable = null;
    let currentMediaField = null;

    // Initialize sortable
    function initSortable() {
        const container = document.getElementById('sectionsContainer');
        if (!container) return;
        
        if (sortable) {
            sortable.destroy();
        }
        sortable = new Sortable(container, {
            handle: '.drag-handle',
            animation: 150,
            onEnd: function(evt) {
                updateSectionOrder();
            }
        });
    }

    // Update section order
    function updateSectionOrder() {
        const sections = [];
        document.querySelectorAll('.section-item').forEach((item, index) => {
            sections.push({
                id: parseInt(item.dataset.sectionId),
                order_index: index
            });
        });

        fetch(`/admin/pages/<?php echo e($page->id); ?>/sections/reorder`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ sections })
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                console.error('Failed to reorder sections');
            }
        })
        .catch(error => {
            console.error('Error reordering sections:', error);
        });
    }

    function openModal(title, sectionId = null) {
        const modal = document.getElementById('sectionModal');
        if (!modal) return;
        
        document.getElementById('modalTitle').textContent = title;
        modal.classList.remove('hidden');
        currentSectionId = sectionId;

        if (sectionId) {
            // Edit mode - load section data
            fetch(`/admin/pages/<?php echo e($page->id); ?>/sections/${sectionId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        populateForm(data.section);
                    }
                });
        } else {
            // Add mode - reset form
            resetForm();
        }
    }

    function closeModal() {
        const modal = document.getElementById('sectionModal');
        if (modal) {
            modal.classList.add('hidden');
        }
        resetForm();
    }

    function resetForm() {
        const form = document.getElementById('sectionForm');
        if (form) form.reset();
        
        const sectionIdInput = document.getElementById('sectionId');
        if (sectionIdInput) sectionIdInput.value = '';
        
        const orderIndexInput = document.getElementById('orderIndex');
        if (orderIndexInput) orderIndexInput.value = document.querySelectorAll('.section-item').length;
        
        const dynamicFields = document.getElementById('dynamicFields');
        if (dynamicFields) dynamicFields.innerHTML = '';
        
        currentSectionId = null;
    }

    function populateForm(section) {
        const sectionIdInput = document.getElementById('sectionId');
        if (sectionIdInput) sectionIdInput.value = section.id;
        
        const sectionTypeSelect = document.getElementById('sectionType');
        if (sectionTypeSelect) sectionTypeSelect.value = section.type;
        
        const sectionTitleInput = document.getElementById('sectionTitle');
        if (sectionTitleInput) sectionTitleInput.value = section.title;
        
        const sectionContentTextarea = document.getElementById('sectionContent');
        if (sectionContentTextarea) sectionContentTextarea.value = section.content || '';
        
        const orderIndexInput = document.getElementById('orderIndex');
        if (orderIndexInput) orderIndexInput.value = section.order_index;
        
        const isActiveCheckbox = document.getElementById('isActive');
        if (isActiveCheckbox) isActiveCheckbox.checked = section.is_active;

        // Load dynamic fields
        loadDynamicFields(section.type, section.data || {});
    }

    // Dynamic fields
    function loadDynamicFields(sectionType, data = {}) {
        const fieldsContainer = document.getElementById('dynamicFields');
        if (!fieldsContainer) return;
        
        fieldsContainer.innerHTML = '';

        const sectionConfig = <?php echo json_encode($sectionTypes, 15, 512) ?>[sectionType];
        if (!sectionConfig || !sectionConfig.fields) return;

        Object.entries(sectionConfig.fields).forEach(([fieldKey, fieldConfig]) => {
            const fieldDiv = document.createElement('div');
            fieldDiv.className = 'field-group';

            const label = document.createElement('label');
            label.className = 'block text-sm font-medium text-gray-700 dark:text-gray-300';
            label.textContent = fieldConfig.label || fieldKey.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            fieldDiv.appendChild(label);

            let input;
            switch (fieldConfig.type) {
                case 'textarea':
                    input = document.createElement('textarea');
                    input.rows = 3;
                    input.className = 'mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm';
                    break;
                case 'select':
                    input = document.createElement('select');
                    input.className = 'mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm';
                    if (fieldConfig.options) {
                        Object.entries(fieldConfig.options).forEach(([value, label]) => {
                            const option = document.createElement('option');
                            option.value = value;
                            option.textContent = label;
                            input.appendChild(option);
                        });
                    }
                    break;
                case 'media':
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    input.innerHTML = `
                        <div class="media-picker-field" data-field="${fieldKey}" data-allowed-types='["image"]'>
                            <input type="hidden" name="${fieldKey}" id="${fieldKey}" value="${data[fieldKey] || ''}">
                            <div id="${fieldKey}-preview" class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 ${data[fieldKey + '_media'] ? 'border-solid border-blue-300 bg-blue-50 dark:bg-gray-900 dark:border-blue-600' : ''}">
                                ${data[fieldKey + '_media'] ? `
                                    <div class="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                                            <div class="w-16 h-16 sm:w-20 sm:h-20 flex-shrink-0 mx-auto sm:mx-0 overflow-hidden rounded-lg bg-white dark:bg-gray-900">
                                            <img src="${data[fieldKey + '_media'].url}" class="w-full h-full object-cover rounded-lg border border-gray-200 dark:border-gray-700" style="max-width: 100%; height: auto;">
                                        </div>
                                        <div class="flex-1 text-center sm:text-left">
                                            <h4 class="text-sm font-medium text-gray-900 dark:text-white truncate">${data[fieldKey + '_media'].name}</h4>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">Image</p>
                                        </div>
                                        <div class="flex flex-row sm:flex-col space-x-2 sm:space-x-0 sm:space-y-2 justify-center sm:justify-start">
                                            <button type="button" onclick="openMediaSelector('${fieldKey}')" class="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">Change</button>
                                            <button type="button" onclick="removeMedia('${fieldKey}')" class="inline-flex items-center px-3 py-1 border border-red-300 dark:border-red-600 shadow-sm text-xs font-medium rounded text-red-700 dark:text-red-100 bg-white dark:bg-gray-800 hover:bg-red-50 dark:hover:bg-red-700">Remove</button>
                                        </div>
                                    </div>
                                ` : `
                                    <div class="text-center">
                                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                        </svg>
                                        <div class="mt-4">
                                            <button type="button" onclick="openMediaSelector('${fieldKey}')" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 dark:hover:bg-blue-800">
                                                <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                                </svg>
                                                Select Image
                                            </button>
                                        </div>
                                    </div>
                                `}
                            </div>
                        </div>
                    `;
                    break;
                case 'stats':
                    // For stats_json field, the data is stored as 'stats' in the database
                    let dataKey = fieldKey === 'stats_json' ? 'stats' : fieldKey;
                    let statsArray = data[dataKey] || [];
                    if (!Array.isArray(statsArray)) {
                        statsArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    let statsHtml = `<div id="${fieldKey}Container" class="space-y-4 sm:space-y-3">`;
                    statsArray.forEach((stat, index) => {
                        statsHtml += `
                            <div class="flex flex-col sm:flex-row gap-4 sm:gap-3 p-4 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
                                <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Number/Value</label>
                                        <input type="text" name="${fieldKey}[${index}][number]" value="${stat.number || stat.value || ''}" placeholder="e.g., 500+" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                    </div>
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Label</label>
                                        <input type="text" name="${fieldKey}[${index}][label]" value="${stat.label || ''}" placeholder="e.g., Projects Completed" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                    </div>
                                </div>
                                <div class="flex justify-end sm:justify-start mt-3 sm:mt-0">
                                    <button type="button" onclick="removeStat('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                </div>
                            </div>
                        `;
                    });
                    statsHtml += `</div>`;
                    statsHtml += `<button type="button" onclick="addStat('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Statistic</button>`;
                    
                    input.innerHTML = statsHtml;
                    break;
                    
                case 'features':
                    let featuresArray = data[fieldKey] || [];
                    if (!Array.isArray(featuresArray)) {
                        featuresArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    // Check if this is the approach section - use simple features like services
                    const sectionType = document.getElementById('sectionType').value;
                    if (sectionType === 'approach') {
                        // Simple features like services
                        let featuresHtml = `<div id="${fieldKey}Container" class="space-y-3">`;
                        featuresArray.forEach((feature, index) => {
                            const featureText = typeof feature === 'string' ? feature : (feature.title || '');
                            featuresHtml += `
                                <div class="flex gap-2">
                                    <input type="text" name="${fieldKey}[]" value="${featureText.replace(/"/g, '&quot;')}" class="flex-1 bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter process step">
                                    <button type="button" onclick="this.parentElement.remove()" class="px-3 py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                </div>
                            `;
                        });
                        featuresHtml += `</div>`;
                        featuresHtml += `<button type="button" onclick="addSimpleFeature('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Step</button>`;
                        
                        input.innerHTML = featuresHtml;
                    } else {
                        // Title/description features
                        let featuresHtml = `<div id="${fieldKey}Container" class="space-y-4 sm:space-y-3">`;
                        featuresArray.forEach((feature, index) => {
                            featuresHtml += `
                                <div class="flex flex-col sm:flex-row gap-4 sm:gap-3 p-4 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
                                    <div class="flex-1 space-y-4 sm:space-y-3">
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Feature Title</label>
                                            <input type="text" name="${fieldKey}[${index}][title]" value="${feature.title || ''}" placeholder="e.g., Expert Team" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Feature Description</label>
                                            <input type="text" name="${fieldKey}[${index}][description]" value="${feature.description || ''}" placeholder="e.g., Certified professionals" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                    </div>
                                    <div class="flex justify-end sm:justify-start mt-3 sm:mt-0">
                                        <button type="button" onclick="removeFeature('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                    </div>
                                </div>
                            `;
                        });
                        featuresHtml += `</div>`;
                        featuresHtml += `<button type="button" onclick="addFeature('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Feature</button>`;
                        
                        input.innerHTML = featuresHtml;
                    }
                    break;
                    
                case 'services':
                    let servicesArray = data[fieldKey] || [];
                    if (!Array.isArray(servicesArray)) {
                        servicesArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    let servicesHtml = `<div id="${fieldKey}Container" class="space-y-4 sm:space-y-3">`;
                    servicesArray.forEach((service, index) => {
                        servicesHtml += `
                            <div class="flex flex-col sm:flex-row gap-4 sm:gap-3 p-4 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">
                                <div class="flex-1 space-y-4 sm:space-y-3">
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Service Title</label>
                                        <input type="text" name="${fieldKey}[${index}][title]" value="${service.title || ''}" placeholder="e.g., Web Development" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                    </div>
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Service Description</label>
                                        <textarea name="${fieldKey}[${index}][description]" rows="3 sm:rows-2" placeholder="e.g., Professional web development services" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">${service.description || ''}</textarea>
                                    </div>
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Button Text</label>
                                            <input type="text" name="${fieldKey}[${index}][button_text]" value="${service.button_text || ''}" placeholder="e.g., Learn More" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Button URL</label>
                                            <input type="text" name="${fieldKey}[${index}][url]" value="${service.url || ''}" placeholder="e.g., /services/web" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                    </div>
                                </div>
                                <div class="flex justify-end sm:justify-start mt-3 sm:mt-0">
                                    <button type="button" onclick="removeService('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                </div>
                            </div>
                        `;
                    });
                    servicesHtml += `</div>`;
                    servicesHtml += `<button type="button" onclick="addService('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Service</button>`;
                    
                    input.innerHTML = servicesHtml;
                    break;
                    
                case 'testimonials':
                    let testimonialsArray = data[fieldKey] || [];
                    if (!Array.isArray(testimonialsArray)) {
                        testimonialsArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    let testimonialsHtml = `<div id="${fieldKey}Container" class="space-y-4 sm:space-y-3">`;
                    testimonialsArray.forEach((testimonial, index) => {
                        testimonialsHtml += `
                            <div class="flex flex-col sm:flex-row gap-4 sm:gap-3 p-4 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">
                                <div class="flex-1 space-y-4 sm:space-y-3">
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Client Name</label>
                                        <input type="text" name="${fieldKey}[${index}][name]" value="${testimonial.name || ''}" placeholder="e.g., John Doe" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                    </div>
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Position</label>
                                            <input type="text" name="${fieldKey}[${index}][position]" value="${testimonial.position || ''}" placeholder="e.g., CEO" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                        <div>
                                            <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Company</label>
                                            <input type="text" name="${fieldKey}[${index}][company]" value="${testimonial.company || ''}" placeholder="e.g., TechStart Inc." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Rating (1-5)</label>
                                        <input type="number" name="${fieldKey}[${index}][rating]" value="${testimonial.rating || 5}" min="1" max="5" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                    </div>
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-2 sm:mb-1">Testimonial Content</label>
                                        <textarea name="${fieldKey}[${index}][content]" rows="4 sm:rows-3" placeholder="e.g., Working with this company was amazing..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">${testimonial.content || ''}</textarea>
                                    </div>
                                </div>
                                <div class="flex justify-end sm:justify-start mt-3 sm:mt-0">
                                    <button type="button" onclick="removeTestimonial('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                </div>
                            </div>
                        `;
                    });
                    testimonialsHtml += `</div>`;
                    testimonialsHtml += `<button type="button" onclick="addTestimonial('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Testimonial</button>`;
                    
                    input.innerHTML = testimonialsHtml;
                    break;
                    
                case 'content_blocks':
                    let blocksArray = data[fieldKey] || [];
                    if (!Array.isArray(blocksArray)) {
                        blocksArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    let blocksHtml = `<div id="${fieldKey}Container" class="space-y-4 sm:space-y-3">`;
                    blocksArray.forEach((block, index) => {
                        blocksHtml += `
                            <div class="flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
                                <div class="flex-1 space-y-4 sm:space-y-3">
                                    <div>
                                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Block Type</label>
                                        <select name="${fieldKey}[${index}][type]" onchange="handleBlockTypeChange(this, '${fieldKey}', ${index})" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                            <option value="heading" ${block.type === 'heading' ? 'selected' : ''}>Heading</option>
                                            <option value="paragraph" ${block.type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
                                            <option value="list" ${block.type === 'list' ? 'selected' : ''}>Bullet List</option>
                                            <option value="image" ${block.type === 'image' ? 'selected' : ''}>Image</option>
                                        </select>
                                    </div>
                                    <div id="${fieldKey}_${index}_content_container">
                                        ${block.type === 'image' ? `
                                            <div>
                                                <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
                                                <div class="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-3">
                                                    <input type="hidden" name="${fieldKey}[${index}][content]" value="${block.content || ''}" id="${fieldKey}_${index}_image_input">
                                                    <div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0 mx-auto sm:mx-0">
                                                        ${(() => {
                                                            const content = block.content;
                                                            if (content && typeof content === 'string' && content !== 'undefined' && content !== 'null' && content.trim() !== '') {
                                                                return `<img src="/storage/${content}" alt="Selected image" class="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded border border-gray-200 dark:border-gray-700">`;
                                                            } else {
                                                                return '<div class="w-16 h-16 sm:w-20 sm:h-20 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';
                                                            }
                                                        })()}
                                                    </div>
                                                    <div class="flex flex-col sm:flex-row gap-2">
                                                        <button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-4 py-2 sm:px-3 sm:py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
                                                        ${(() => {
                                                            const content = block.content;
                                                            if (content && typeof content === 'string' && content !== 'undefined' && content !== 'null' && content.trim() !== '') {
                                                                return `<button type="button" onclick="removeContentBlockImage('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-4 py-2 sm:px-3 sm:py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">Remove</button>`;
                                                            } else {
                                                                return '';
                                                            }
                                                        })()}
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Alt Text (Optional)</label>
                                                <input type="text" name="${fieldKey}[${index}][alt]" value="${block.alt || ''}" placeholder="Describe the image for accessibility" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                            </div>
                                            <div>
                                                <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Caption (Optional)</label>
                                                <input type="text" name="${fieldKey}[${index}][caption]" value="${block.caption || ''}" placeholder="Image caption" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                                            </div>
                                        ` : `
                                            <div>
                                                <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Content</label>
                                                <textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="Enter your content here..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">${block.content || ''}</textarea>
                                            </div>
                                        `}
                                    </div>
                                </div>
                                <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                                    <button type="button" onclick="removeContentBlock('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                                </div>
                            </div>
                        `;
                    });
                    blocksHtml += `</div>`;
                    blocksHtml += `<button type="button" onclick="addContentBlock('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Content Block</button>`;
                    
                    input.innerHTML = blocksHtml;
                    break;
                    
                case 'team_members':
                    let teamArray = data[fieldKey] || [];
                    if (!Array.isArray(teamArray)) {
                        teamArray = [];
                    }
                    
                    input = document.createElement('div');
                    input.className = 'mt-1';
                    
                    let teamHtml = `<div id="${fieldKey}Container" class="space-y-3">`;
                    teamArray.forEach((member, index) => {
                        teamHtml += `
                            <div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">
                                <div class="flex-1 space-y-3">
                                    <div>
                                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Photo</label>
                                        <div class="flex items-center gap-3">
                                            <input type="hidden" name="${fieldKey}[${index}][image]" value="${member.image || ''}" id="${fieldKey}_${index}_image_input">
                                            <div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0">
                                                ${(() => {
                                                    const image = member.image;
                                                        if (image && typeof image === 'string' && image !== 'undefined' && image !== 'null' && image.trim() !== '') {
                                                        return `<img src="/storage/${image}" alt="Team member photo" class="w-20 h-20 object-cover rounded border border-gray-200 dark:border-gray-700">`;
                                                    } else {
                                                        return '<div class="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-700 flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>';
                                                    }
                                                })()}
                                            </div>
                                            <button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Photo</button>
                                            ${(() => {
                                                const image = member.image;
                                                if (image && typeof image === 'string' && image !== 'undefined' && image !== 'null' && image.trim() !== '') {
                                                    return `<button type="button" onclick="removeTeamMemberImage('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">Remove</button>`;
                                                } else {
                                                    return '';
                                                }
                                            })()}
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-3">
                                        <div>
                                            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Name</label>
                                            <input type="text" name="${fieldKey}[${index}][name]" value="${member.name || ''}" placeholder="e.g., John Doe" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                        </div>
                                        <div>
                                            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>
                                            <input type="text" name="${fieldKey}[${index}][position]" value="${member.position || ''}" placeholder="e.g., CEO" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                        </div>
                                    </div>
                                    <div>
                                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Bio</label>
                                        <textarea name="${fieldKey}[${index}][bio]" rows="2" placeholder="e.g., Experienced leader..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">${member.bio || ''}</textarea>
                                    </div>
                                    <div class="space-y-2">
                                        <label class="block text-xs font-medium text-gray-600">Social Links</label>
                                        <div class="grid grid-cols-2 gap-3">
                                            <div>
                                                <input type="text" name="${fieldKey}[${index}][linkedin]" value="${member.linkedin || ''}" placeholder="LinkedIn URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                            </div>
                                            <div>
                                                <input type="text" name="${fieldKey}[${index}][twitter]" value="${member.twitter || ''}" placeholder="Twitter URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                            </div>
                                            <div>
                                                <input type="text" name="${fieldKey}[${index}][github]" value="${member.github || ''}" placeholder="GitHub URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                            </div>
                                            <div>
                                                <input type="text" name="${fieldKey}[${index}][dribbble]" value="${member.dribbble || ''}" placeholder="Dribbble URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" onclick="removeTeamMember('${fieldKey}', this)" class="mt-auto px-3 py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
                            </div>
                        `;
                    });
                    teamHtml += `</div>`;
                    teamHtml += `<button type="button" onclick="addTeamMember('${fieldKey}')" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Team Member</button>`;
                    
                    input.innerHTML = teamHtml;
                    break;
                case 'text':
                    input = document.createElement('input');
                    input.type = 'text';
                    input.className = 'mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm';
                    break;
                default:
                    input = document.createElement('input');
                    input.type = 'text';
                    input.className = 'mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm';
            }

            if (input && input.tagName !== 'DIV') {
                input.name = fieldKey;
                input.id = fieldKey;
                input.value = data[fieldKey] || (fieldConfig.default || '');
                if (fieldConfig.placeholder) input.placeholder = fieldConfig.placeholder;
            }

            fieldDiv.appendChild(input);
            fieldsContainer.appendChild(fieldDiv);
        });
    }

    // Media picker functions (copied from media picker component)
    function openMediaSelector(fieldName, previewId = null) {
        const allowedTypes = ['image']; // Default to images
        const url = `/admin/media-selector?type=${allowedTypes[0]}&fieldId=${encodeURIComponent(fieldName)}`;

        const selectorWindow = window.open(url, 'mediaSelector', 'width=1200,height=800,scrollbars=yes,resizable=yes');

        // Store preview ID for callback (fieldId will come from the message)
        if (!window.mediaPreviewMap) {
            window.mediaPreviewMap = {};
        }
        window.mediaPreviewMap[fieldName] = previewId;
    }

    // Global message listener for media selection
    if (!window.mediaSelectionListenerAttached) {
        window.mediaSelectionListenerAttached = true;
        window.addEventListener('message', function(event) {
            // console.log('Received message:', event.data);
            if (event.origin !== window.location.origin) {
                console.log('Ignoring message from different origin:', event.origin);
                return;
            }
            
            if (event.data.type === 'MEDIA_SELECTED') {
                const media = event.data.media;
                const fieldId = event.data.fieldId;
                const previewId = window.mediaPreviewMap ? window.mediaPreviewMap[fieldId] : null;
                
                // console.log('Processing media selection for fieldId:', fieldId, 'with previewId:', previewId);
                
                if (previewId) {
                    updateContentBlockImage(media, fieldId, previewId);
                } else {
                    updateMediaSelection(media, fieldId);
                }
            }
        });
    }

    function updateContentBlockImage(media, fieldName, previewId) {
        // Update hidden input with media path
        const input = document.getElementById(fieldName);
        if (input) {
            // Use file_path if available, otherwise extract from URL
            const filePath = media.file_path || (media.url ? media.url.replace('/storage/', '') : '');
            input.value = filePath;
        }

        // Update preview
        const previewDiv = document.getElementById(previewId);
        if (previewDiv) {
            previewDiv.innerHTML = `<img src="${media.url}" alt="Selected image" class="w-20 h-20 object-cover rounded border">`;
        }
    }

    function removeContentBlockImage(fieldName, previewId) {
        // Clear hidden input
        const input = document.getElementById(fieldName);
        if (input) input.value = '';

        // Reset preview
        const previewDiv = document.getElementById(previewId);
        if (previewDiv) {
            previewDiv.innerHTML = '<div class="w-20 h-20 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';
        }
    }

    function updateMediaSelection(media, fieldId) {
        if (!fieldId) return;
        
        // Update hidden input
        const input = document.getElementById(fieldId);
        if (input) input.value = media.id;

        // Update preview
        const previewDiv = document.getElementById(`${fieldId}-preview`);
        if (!previewDiv) return;
        
        previewDiv.className = 'border-2 border-solid border-blue-300 rounded-lg p-4 bg-blue-50';

        let mediaIcon = '';
        if (media.type === 'image') {
            mediaIcon = `<img src="${media.url}" alt="${media.name}" class="w-full h-full object-cover rounded-lg border">`;
        }

        previewDiv.innerHTML = `
            <div class="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
                <div class="w-16 h-16 sm:w-20 sm:h-20 flex-shrink-0 mx-auto sm:mx-0">
                    ${mediaIcon}
                </div>
                <div class="flex-1 text-center sm:text-left">
                    <h4 class="text-sm font-medium text-gray-900 dark:text-white truncate">${media.name}</h4>
                    <p class="text-sm text-gray-500 dark:text-gray-400">${media.type.charAt(0).toUpperCase() + media.type.slice(1)}</p>
                </div>
                <div class="flex flex-row sm:flex-col space-x-2 sm:space-x-0 sm:space-y-2 justify-center sm:justify-start">
                    <button type="button" onclick="openMediaSelector('${fieldId}')" class="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700">Change</button>
                    <button type="button" onclick="removeMedia('${fieldId}')" class="inline-flex items-center px-3 py-1 border border-red-300 shadow-sm text-xs font-medium rounded text-red-700 bg-white dark:bg-gray-800 hover:bg-red-50">Remove</button>
                </div>
            </div>
        `;
    }

    function removeMedia(fieldName) {
        // Clear hidden input
        const input = document.getElementById(fieldName);
        if (input) input.value = '';

        // Reset preview
        const previewDiv = document.getElementById(`${fieldName}-preview`);
        if (!previewDiv) return;
        
        previewDiv.className = 'border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4';
        previewDiv.innerHTML = `
            <div class="text-center">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                <div class="mt-4">
                    <button type="button" onclick="openMediaSelector('${fieldName}')" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                        </svg>
                        Select Image
                    </button>
                </div>
            </div>
        `;
    }

    // Event listeners
    document.getElementById('addSectionBtn')?.addEventListener('click', () => openModal('Add Section'));
    document.getElementById('addFirstSectionBtn')?.addEventListener('click', () => openModal('Add Section'));
    document.getElementById('closeModalBtn')?.addEventListener('click', closeModal);
    document.getElementById('cancelBtn')?.addEventListener('click', closeModal);

    // Edit section buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('edit-section-btn')) {
            const sectionId = e.target.dataset.sectionId;
            openModal('Edit Section', sectionId);
        }
    });

    // Toggle section buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('toggle-section-btn')) {
            const sectionId = e.target.dataset.sectionId;
            const button = e.target;
            const isCurrentlyActive = button.textContent.trim().includes('Disable');

            const action = isCurrentlyActive ? 'disable' : 'enable';
            const title = `Confirm ${action.charAt(0).toUpperCase() + action.slice(1)}`;
            const message = `Are you sure you want to ${action} this section? ${isCurrentlyActive ? 'It will no longer be visible on the page.' : 'It will become visible on the page again.'}`;

            showToggleConfirmation(title, message, isCurrentlyActive, () => toggleSection(sectionId, button));
        }
    });

    // Toggle section function
    function toggleSection(sectionId, button) {
        fetch(`/admin/pages/<?php echo e($page->id); ?>/sections/${sectionId}/toggle`, {
            method: 'PATCH',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const statusSpan = button.closest('.section-item').querySelector('span');
                if (data.section.is_active) {
                    statusSpan.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800';
                    statusSpan.textContent = 'Active';
                    button.innerHTML = '<i class="fas fa-pause mr-2"></i>Disable';
                    button.className = button.className.replace('bg-green-100 text-green-700 hover:bg-green-200', 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200');
                } else {
                    statusSpan.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-800 text-gray-800';
                    statusSpan.textContent = 'Inactive';
                    button.innerHTML = '<i class="fas fa-play mr-2"></i>Enable';
                    button.className = button.className.replace('bg-yellow-100 text-yellow-700 hover:bg-yellow-200', 'bg-green-100 text-green-700 hover:bg-green-200');
                }
            }
        });
    }

    // Delete section buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('delete-section-btn')) {
            const sectionId = e.target.dataset.sectionId;
            showDeleteConfirmation('Are you sure you want to delete this section? This action cannot be undone.', () => { deleteSection(sectionId); });
        }
    });

    // Delete section function
    function deleteSection(sectionId) {
        fetch(`/admin/pages/<?php echo e($page->id); ?>/sections/${sectionId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector(`[data-section-id="${sectionId}"]`).remove();
                location.reload(); // Reload to update stats
            }
        });
    }

    // Section type change
    document.getElementById('sectionType')?.addEventListener('change', function() {
        loadDynamicFields(this.value);
    });

    // Form submission
    document.getElementById('sectionForm')?.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const url = currentSectionId
            ? `/admin/pages/<?php echo e($page->id); ?>/sections/${currentSectionId}`
            : `/admin/pages/<?php echo e($page->id); ?>/sections`;
        const method = currentSectionId ? 'PUT' : 'POST';

        // Add CSRF token and method for Laravel
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        if (method === 'PUT') {
            formData.append('_method', 'PUT');
        }

        fetch(url, {
            method: 'POST', // Always use POST, Laravel will handle _method
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                // If response is not ok, try to get the error message
                return response.text().then(text => {
                    throw new Error(`HTTP ${response.status}: ${text}`);
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                closeModal();
                location.reload(); // Simple reload for now
            } else {
                console.error('Validation errors:', data.errors);
                alert('Validation failed. Check the console for details.');
            }
        })
        .catch(error => {
            console.error('Error saving section:', error);
            alert('An error occurred while saving the section. Check the console for details.');
        });
    });

    // Initialize sortable on page load
    initSortable();

    // Helper function to escape HTML
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    // Stats management functions
    window.addStat = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const statDiv = document.createElement('div');
        statDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        statDiv.innerHTML = `
            <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Number/Value</label>
                    <input type="text" name="${fieldKey}[${index}][number]" placeholder="e.g., 500+" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Label</label>
                    <input type="text" name="${fieldKey}[${index}][label]" placeholder="e.g., Projects Completed" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeStat('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
            </div>
        `;
        container.appendChild(statDiv);
    };

    window.removeStat = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    // Features management functions
    window.addFeature = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const featureDiv = document.createElement('div');
        featureDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        featureDiv.innerHTML = `
            <div class="flex-1 space-y-4 sm:space-y-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Title</label>
                    <input type="text" name="${fieldKey}[${index}][title]" placeholder="e.g., Expert Team" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Description</label>
                    <input type="text" name="${fieldKey}[${index}][description]" placeholder="e.g., Certified professionals" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeFeature('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
            </div>
        `;
        container.appendChild(featureDiv);
    };

    window.removeFeature = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    // Simple features management functions (for approach section)
    window.addSimpleFeature = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        
        const featureDiv = document.createElement('div');
        featureDiv.className = 'flex gap-2';
        featureDiv.innerHTML = `
            <input type="text" name="${fieldKey}[]" class="flex-1 bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter process step">
            <button type="button" onclick="this.parentElement.remove()" class="px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;
        container.appendChild(featureDiv);
    };

    // Services management functions
    window.addService = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const serviceDiv = document.createElement('div');
        serviceDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        serviceDiv.innerHTML = `
            <div class="flex-1 space-y-4 sm:space-y-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Title</label>
                    <input type="text" name="${fieldKey}[${index}][title]" placeholder="e.g., Web Development" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Description</label>
                    <textarea name="${fieldKey}[${index}][description]" rows="2" placeholder="e.g., Professional web development services" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border"></textarea>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button Text</label>
                        <input type="text" name="${fieldKey}[${index}][button_text]" placeholder="e.g., Learn More" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button URL</label>
                        <input type="text" name="${fieldKey}[${index}][url]" placeholder="e.g., /services/web" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeService('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
            </div>
        `;
        container.appendChild(serviceDiv);
    };

    window.removeService = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input, textarea').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    // Testimonials management functions
    window.addTestimonial = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const testimonialDiv = document.createElement('div');
        testimonialDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        testimonialDiv.innerHTML = `
            <div class="flex-1 space-y-4 sm:space-y-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Client Name</label>
                    <input type="text" name="${fieldKey}[${index}][name]" placeholder="e.g., John Doe" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>
                        <input type="text" name="${fieldKey}[${index}][position]" placeholder="e.g., CEO" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Company</label>
                        <input type="text" name="${fieldKey}[${index}][company]" placeholder="e.g., TechStart Inc." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Rating (1-5)</label>
                    <input type="number" name="${fieldKey}[${index}][rating]" value="5" min="1" max="5" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Testimonial Content</label>
                    <textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="e.g., Working with this company was amazing..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border"></textarea>
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeTestimonial('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
            </div>
        `;
        container.appendChild(testimonialDiv);
    };

    window.removeTestimonial = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input, textarea').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    // Team members management functions
    window.addTeamMember = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const memberDiv = document.createElement('div');
        memberDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        memberDiv.innerHTML = `
            <div class="flex-1 space-y-4 sm:space-y-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Photo</label>
                    <div class="flex items-center gap-4 sm:gap-3">
                        <input type="hidden" name="${fieldKey}[${index}][image]" value="" id="${fieldKey}_${index}_image_input">
                        <div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0">
                            <div class="w-20 h-20 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>
                        </div>
                        <button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-4 py-2 sm:px-3 sm:py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Photo</button>
                    </div>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Name</label>
                        <input type="text" name="${fieldKey}[${index}][name]" placeholder="e.g., John Doe" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>
                        <input type="text" name="${fieldKey}[${index}][position]" placeholder="e.g., CEO" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                    </div>
                </div>
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Bio</label>
                    <textarea name="${fieldKey}[${index}][bio]" rows="2" placeholder="e.g., Experienced leader..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border"></textarea>
                </div>
                <div class="space-y-2">
                    <label class="block text-sm sm:text-xs font-medium text-gray-600">Social Links</label>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-3">
                        <div>
                            <input type="text" name="${fieldKey}[${index}][linkedin]" placeholder="LinkedIn URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][twitter]" placeholder="Twitter URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][github]" placeholder="GitHub URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][dribbble]" placeholder="Dribbble URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeTeamMember('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
            </div>
        `;
        container.appendChild(memberDiv);
    };

    window.removeTeamMember = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input, textarea').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    window.removeTeamMemberImage = function(fieldKey, index) {
        const input = document.getElementById(`${fieldKey}_${index}_image_input`);
        const preview = document.getElementById(`${fieldKey}_${index}_image_preview`);
        
        input.value = '';
        preview.innerHTML = '<div class="w-20 h-20 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>';
    };

    // Handle content block type changes
    window.handleBlockTypeChange = function(selectElement, fieldKey, index) {
        const container = document.getElementById(`${fieldKey}_${index}_content_container`);
        const selectedType = selectElement.value;
        
        if (selectedType === 'image') {
            container.innerHTML = `
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
                    <div class="flex items-center gap-3">
                        <input type="hidden" name="${fieldKey}[${index}][content]" value="" id="${fieldKey}_${index}_image_input">
                        <div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0">
                            <div class="w-20 h-20 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>
                        </div>
                        <button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Alt Text (Optional)</label>
                    <input type="text" name="${fieldKey}[${index}][alt]" placeholder="Describe the image for accessibility" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Caption (Optional)</label>
                    <input type="text" name="${fieldKey}[${index}][caption]" placeholder="Image caption" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
            `;
        } else {
            container.innerHTML = `
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Content</label>
                    <textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="Enter your content here..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border"></textarea>
                </div>
            `;
        }
    };

    // Content blocks management functions
    window.addContentBlock = function(fieldKey) {
        const container = document.getElementById(`${fieldKey}Container`);
        const index = container.children.length;
        
        const blockDiv = document.createElement('div');
        blockDiv.className = 'flex flex-col sm:flex-row gap-4 sm:gap-3 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700';
        blockDiv.innerHTML = `
            <div class="flex-1 space-y-4 sm:space-y-3">
                <div>
                    <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Block Type</label>
                    <select name="${fieldKey}[${index}][type]" onchange="handleBlockTypeChange(this, '${fieldKey}', ${index})" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border">
                        <option value="heading">Heading</option>
                        <option value="paragraph" selected>Paragraph</option>
                        <option value="list">Bullet List</option>
                        <option value="image">Image</option>
                    </select>
                </div>
                <div id="${fieldKey}_${index}_content_container">
                    <div>
                        <label class="block text-sm sm:text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Content</label>
                        <textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="Enter your content here..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-base sm:text-sm py-3 px-4 sm:py-2 sm:px-3 border"></textarea>
                    </div>
                </div>
            </div>
            <div class="flex justify-end sm:justify-start mt-2 sm:mt-0">
                <button type="button" onclick="removeContentBlock('${fieldKey}', this)" class="px-4 py-2 sm:px-3 sm:py-2 border border-red-300 dark:border-red-600 text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20">Remove</button>
            </div>
        `;
        container.appendChild(blockDiv);
    };

    window.removeContentBlock = function(fieldKey, btn) {
        btn.closest('.flex.gap-3').remove();
        // Re-index remaining items
        const container = document.getElementById(`${fieldKey}Container`);
        Array.from(container.children).forEach((item, index) => {
            item.querySelectorAll('input, textarea, select').forEach(input => {
                const name = input.getAttribute('name');
                input.setAttribute('name', name.replace(/\[\d+\]/, `[${index}]`));
            });
        });
    };

    // Make functions globally available
    window.openMediaSelector = openMediaSelector;
    window.updateMediaSelection = updateMediaSelection;
    window.removeMedia = removeMedia;
    window.updateContentBlockImage = updateContentBlockImage;
    window.removeContentBlockImage = removeContentBlockImage;
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/pages/sections.blade.php ENDPATH**/ ?>