

<?php $__env->startSection('title', 'View Application'); ?>
<?php $__env->startSection('page-title', 'View Job Application'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold
                            <?php if($jobApplication->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php elseif($jobApplication->status === 'reviewed'): ?> bg-blue-100 text-blue-800
                            <?php elseif($jobApplication->status === 'shortlisted'): ?> bg-green-100 text-green-800
                            <?php elseif($jobApplication->status === 'rejected'): ?> bg-red-100 text-red-800
                            <?php elseif($jobApplication->status === 'hired'): ?> bg-purple-100 text-purple-800
                            <?php else: ?> bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white <?php endif; ?>">
                            <i class="fas fa-<?php echo e($jobApplication->status === 'pending' ? 'clock' : ($jobApplication->status === 'reviewed' ? 'eye' : ($jobApplication->status === 'shortlisted' ? 'star' : ($jobApplication->status === 'rejected' ? 'times' : ($jobApplication->status === 'hired' ? 'check-circle' : 'question-circle'))))); ?> mr-1"></i>
                            <?php echo e(ucfirst($jobApplication->status)); ?>

                        </span>
                        <?php if($jobApplication->career): ?>
                        <span class="ml-3 text-sm font-medium" style="color: #e9d5ff;">
                            <i class="fas fa-briefcase mr-1"></i>
                            Applied for: <?php echo e($jobApplication->career->job_title); ?>

                        </span>
                        <?php endif; ?>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2"><?php echo e($jobApplication->name); ?></h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #e9d5ff;">
                        <span>
                            <i class="fas fa-envelope mr-2"></i><?php echo e($jobApplication->email); ?>

                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Applied <?php echo e($jobApplication->created_at->format('M d, Y')); ?>

                        </span>
                        <span>
                            <i class="fas fa-clock mr-2"></i><?php echo e($jobApplication->created_at->diffForHumans()); ?>

                        </span>
                        <?php if($jobApplication->phone): ?>
                        <span>
                            <i class="fas fa-phone mr-2"></i><?php echo e($jobApplication->phone); ?>

                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="mailto:<?php echo e($jobApplication->email); ?>" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-envelope mr-2"></i>Email
                    </a>
                    <a href="<?php echo e(route('admin.job-applications.index')); ?>" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
    <div class="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
        <i class="fas fa-check-circle mr-2"></i><?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Applicant Information -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-user mr-2 text-purple-600"></i>Applicant Information
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <dl class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Full Name</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->name); ?></p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email Address</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">
                                <a href="mailto:<?php echo e($jobApplication->email); ?>" class="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"><?php echo e($jobApplication->email); ?></a>
                            </p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Phone Number</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->phone ?? 'Not provided'); ?></p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">LinkedIn Profile</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">
                                <?php if($jobApplication->linkedin): ?>
                                    <a href="<?php echo e($jobApplication->linkedin); ?>" target="_blank" class="text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"><?php echo e($jobApplication->linkedin); ?></a>
                                <?php else: ?>
                                    Not provided
                                <?php endif; ?>
                            </p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Position Applied For</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->career->job_title); ?></p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Application Date</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->created_at->format('M d, Y \a\t g:i A')); ?></p>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Resume Download -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-file-pdf mr-2 text-red-600"></i>Resume & Documents
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">Resume Document</p>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Click to download and view the applicant's resume</p>
                        </div>
                        <a href="<?php echo e(asset('storage/' . $jobApplication->resume_path)); ?>" target="_blank" class="inline-flex items-center px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors duration-200">
                            <i class="fas fa-download mr-2"></i>Download Resume
                        </a>
                    </div>
                </div>
            </div>

            <!-- Cover Letter -->
            <?php if($jobApplication->cover_letter): ?>
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-file-alt mr-2 text-blue-600"></i>Cover Letter
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="prose prose-sm max-w-none dark:prose-invert prose-p:text-gray-700 dark:text-gray-300">
                        <?php echo nl2br(e($jobApplication->cover_letter)); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Application Status -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-tasks mr-2 text-green-600"></i>Application Status
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <form method="POST" action="<?php echo e(route('admin.job-applications.update', $jobApplication)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-4">
                            <label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Current Status</label>
                            <select name="status" id="status" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500">
                                <option value="pending" <?php echo e($jobApplication->status === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="reviewed" <?php echo e($jobApplication->status === 'reviewed' ? 'selected' : ''); ?>>Reviewed</option>
                                <option value="shortlisted" <?php echo e($jobApplication->status === 'shortlisted' ? 'selected' : ''); ?>>Shortlisted</option>
                                <option value="rejected" <?php echo e($jobApplication->status === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                <option value="hired" <?php echo e($jobApplication->status === 'hired' ? 'selected' : ''); ?>>Hired</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label for="notes" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Internal Notes</label>
                            <textarea name="notes" id="notes" rows="4" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500" placeholder="Add notes about this application..."><?php echo e($jobApplication->notes); ?></textarea>
                        </div>

                        <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors duration-200">
                            Update Status
                        </button>
                    </form>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-bolt mr-2 text-yellow-600"></i>Quick Actions
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <a href="mailto:<?php echo e($jobApplication->email); ?>" class="block px-4 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200">
                            <i class="fas fa-envelope mr-3"></i>Send Email
                        </a>
                    </div>
                    <div class="px-6 py-4">
                        <form method="POST" action="<?php echo e(route('admin.job-applications.destroy', $jobApplication)); ?>" onsubmit="return confirm('Are you sure you want to delete this application? This action cannot be undone.');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="w-full text-left px-4 py-3 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors duration-200">
                                <i class="fas fa-trash mr-3"></i>Delete Application
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Application Timeline -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-history mr-2 text-indigo-600"></i>Timeline
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Applied</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->created_at->format('M d, Y \a\t g:i A')); ?></p>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($jobApplication->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($jobApplication->updated_at->format('M d, Y \a\t g:i A')); ?></p>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($jobApplication->updated_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/job-applications/show.blade.php ENDPATH**/ ?>