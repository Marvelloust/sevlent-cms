

<?php $__env->startSection('title', 'Careers'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 overflow-hidden">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-10">
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0); background-size: 40px 40px;"></div>
        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 1200 400" preserveAspectRatio="xMidYMid slice">
            <defs>
                <linearGradient id="careerLineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                    <stop offset="50%" style="stop-color:rgba(255,255,255,0.3);stop-opacity:1" />
                    <stop offset="100%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                </linearGradient>
            </defs>
            <line x1="0" y1="50" x2="1200" y2="50" stroke="url(#careerLineGradient)" stroke-width="1"/>
            <line x1="0" y1="150" x2="1200" y2="150" stroke="url(#careerLineGradient)" stroke-width="1"/>
            <line x1="0" y1="250" x2="1200" y2="250" stroke="url(#careerLineGradient)" stroke-width="1"/>
            <line x1="200" y1="0" x2="200" y2="400" stroke="url(#careerLineGradient)" stroke-width="1"/>
            <line x1="600" y1="0" x2="600" y2="400" stroke="url(#careerLineGradient)" stroke-width="1"/>
            <line x1="1000" y1="0" x2="1000" y2="400" stroke="url(#careerLineGradient)" stroke-width="1"/>
        </svg>
    </div>

    <!-- Floating Elements -->
    <div class="absolute inset-0">
        <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
    </div>

    <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>

    <div class="relative pt-32 pb-20">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                Join Our Team
            </h1>
            <p class="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed drop-shadow">
                We're always looking for talented individuals to join our growing team. Explore our current opportunities and be part of something amazing.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#opportunities" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-blue-600 bg-white hover:bg-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                    Browse Opportunities
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                    </svg>
                </a>
                <a href="<?php echo e(route('contact.index')); ?>" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-base font-semibold rounded-lg text-white hover:bg-white/10 hover:border-white transition-all duration-300">
                    Get In Touch
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Careers Content -->
<div id="opportunities" class="bg-gray-50 py-16 -mt-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <!-- Careers List -->
        <div class="space-y-6">
            <?php $__empty_1 = true; $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 transform">
                <div class="p-6">
                    <div class="flex items-start justify-between">
                        <div class="flex-1">
<h2 class="text-2xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                        <a href="<?php echo e(route('careers.show', $career->slug)); ?>">
                                    <?php echo e($career->job_title); ?>

                                </a>
                            </h2>

                            <div class="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                                <?php if($career->location): ?>
                                <div class="flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    </svg>
                                    <?php echo e($career->location); ?>

                                </div>
                                <?php endif; ?>

                                <?php if($career->employment_type): ?>
                                <div class="flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                    </svg>
                                    <?php echo e($career->employment_type); ?>

                                </div>
                                <?php endif; ?>

                                <div class="flex items-center">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 4v10a2 2 0 002 2h4a2 2 0 002-2V11M9 11h6"/>
                                    </svg>
                                    <span class="text-sm font-medium text-green-600">Posted <?php echo e($career->created_at->diffForHumans()); ?></span>
                                </div>
                            </div>

                            <p class="text-gray-600 mb-6 line-clamp-3">
                                <?php echo e(Str::limit(strip_tags(is_string($career->job_description) ? nl2br(e($career->job_description)) : $career->job_description), 200)); ?>

                            </p>

                            <div class="flex items-center justify-between mt-4 flex-wrap gap-4">
                                <a href="<?php echo e(route('careers.show', $career->slug)); ?>"
                                   class="inline-flex items-center text-blue-600 hover:text-blue-800 font-semibold group/link">
                                    View Details
                                    <svg class="ml-2 w-4 h-4 group-hover/link:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                    </svg>
                                </a>

                                <?php if($career->application_deadline): ?>
                                <div class="text-sm font-medium text-orange-600 bg-orange-50 px-4 py-2 rounded-full">
                                    Apply by <?php echo e($career->application_deadline->format('M j, Y')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center py-16">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m8 0V8a2 2 0 01-2 2H8a2 2 0 01-2-2V6m8 0H8"/>
                </svg>
                <h3 class="mt-4 text-lg font-semibold text-gray-900">No positions available</h3>
                <p class="mt-1 text-gray-500">Check back later for new opportunities.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($careers->hasPages()): ?>
        <div class="mt-16">
            <div class="flex justify-center">
                <?php echo e($careers->links()); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Why Join Us Section -->
<div class="bg-white py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-900 mb-4">Why Join Us?</h2>
            <p class="text-lg text-gray-600">We're more than just a workplace – we're a community</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="text-center">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Growth Opportunities</h3>
                <p class="text-gray-600">Continuous learning and career development opportunities for all team members.</p>
            </div>

            <div class="text-center">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Collaborative Culture</h3>
                <p class="text-gray-600">Work with talented professionals in a supportive and inclusive environment.</p>
            </div>

            <div class="text-center">
                <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                    </svg>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">Innovation Focus</h3>
                <p class="text-gray-600">Be part of cutting-edge projects that push the boundaries of technology.</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/careers/index.blade.php ENDPATH**/ ?>