<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'pattern' => 'dots',
    'patternOpacity' => '0.1',
    'patternColor' => 'white',
    'patternSize' => '40',
    'gradient' => null,
    'overlay' => null,
    'floatingElements' => false,
    'backgroundMedia' => null,
    'backgroundVideoOverlay' => 'bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'pattern' => 'dots',
    'patternOpacity' => '0.1',
    'patternColor' => 'white',
    'patternSize' => '40',
    'gradient' => null,
    'overlay' => null,
    'floatingElements' => false,
    'backgroundMedia' => null,
    'backgroundVideoOverlay' => 'bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>


<?php if($backgroundMedia): ?>
    <?php
        $media = is_object($backgroundMedia) ? $backgroundMedia : \App\Models\Media::find($backgroundMedia);
        $isVideo = $media && $media->file_type === 'video';
    ?>

    <?php if($isVideo && $media): ?>
    <video class="absolute inset-0 w-full h-full object-cover" autoplay muted loop playsinline>
        <source src="<?php echo e($media->url); ?>" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="absolute inset-0 <?php echo e($backgroundVideoOverlay); ?>"></div>
    <?php elseif($media): ?>
    <div class="absolute inset-0" style="background-image: url('<?php echo e($media->url); ?>'); background-size: cover; background-position: center; background-attachment: fixed;"></div>
    <?php endif; ?>
<?php endif; ?>

<div class="absolute inset-0">
    
    <?php if($pattern && $pattern !== 'none'): ?>
        <?php if (isset($component)) { $__componentOriginalec63867a1ee5523d25431b203b076150 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec63867a1ee5523d25431b203b076150 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.background-pattern','data' => ['type' => $pattern,'opacity' => $patternOpacity,'color' => $patternColor,'size' => $patternSize]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('background-pattern'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pattern),'opacity' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patternOpacity),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patternColor),'size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($patternSize)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec63867a1ee5523d25431b203b076150)): ?>
<?php $attributes = $__attributesOriginalec63867a1ee5523d25431b203b076150; ?>
<?php unset($__attributesOriginalec63867a1ee5523d25431b203b076150); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec63867a1ee5523d25431b203b076150)): ?>
<?php $component = $__componentOriginalec63867a1ee5523d25431b203b076150; ?>
<?php unset($__componentOriginalec63867a1ee5523d25431b203b076150); ?>
<?php endif; ?>
    <?php endif; ?>

    
    <?php if($gradient): ?>
        <?php
            $gradients = [
                'hero-dark' => 'bg-gradient-to-t from-black/40 via-black/10 to-transparent',
                'hero-light' => 'bg-gradient-to-t from-white/20 via-white/5 to-transparent',
                'section-blue' => 'bg-gradient-to-br from-blue-600/10 via-purple-600/5 to-indigo-700/10',
                'section-warm' => 'bg-gradient-to-br from-orange-500/10 via-red-500/5 to-pink-500/10',
                'section-cool' => 'bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-indigo-500/10',
                'fade-top' => 'bg-gradient-to-t from-white via-white/50 to-transparent',
                'fade-bottom' => 'bg-gradient-to-b from-transparent via-white/50 to-white',
                'fade-both' => 'bg-gradient-to-b from-white/80 via-transparent to-white/80'
            ];
        ?>
        <div class="absolute inset-0 <?php echo e($gradients[$gradient] ?? $gradient); ?>"></div>
    <?php endif; ?>

    
    <?php if($overlay): ?>
        <div class="absolute inset-0 <?php echo e($overlay); ?>"></div>
    <?php endif; ?>

    
    <?php if($floatingElements): ?>
        <div class="absolute inset-0">
            
            <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
            <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
            <div class="absolute bottom-24 left-1/4 w-2 h-2 bg-white rounded-full opacity-25 animate-pulse" style="animation-delay: 2s;"></div>
            <div class="absolute bottom-32 right-1/3 w-5 h-5 bg-white rounded-full opacity-15 animate-pulse" style="animation-delay: 0.5s;"></div>

            
            <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
            <div class="absolute bottom-16 left-16 w-8 h-8 border border-white rounded-full opacity-20"></div>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/components/background.blade.php ENDPATH**/ ?>