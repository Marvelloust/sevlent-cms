

<?php
    $seoable = $seoable ?? null;
    $seo = $seoable ? $seoable->seo : null;

    // Get global settings
    $settings = \App\Models\Setting::pluck('value', 'key')->toArray();

    // Determine meta title
    $metaTitle = $seo?->meta_title ??
                 ($seoable ? ($seoable->title ?? $seoable->name ?? '') : '') ??
                 $settings['default_meta_title'] ??
                 config('app.name');

    // Determine meta description
    $metaDescription = $seo?->meta_description ??
                      ($seoable ? ($seoable->short_description ?? $seoable->excerpt ?? '') : '') ??
                      $settings['default_meta_description'] ??
                      'Welcome to ' . config('app.name');

    // Determine canonical URL
    $canonicalUrl = $seo?->canonical_url ?? url()->current();

    // Open Graph data
    $ogTitle = $seo?->og_title ?? $metaTitle;
    $ogDescription = $seo?->og_description ?? $metaDescription;
    $ogImage = $seo?->ogImage ? $seo->ogImage->url : null;
    $ogUrl = $canonicalUrl;

    // Keywords
    $keywords = $seo?->meta_keywords ?? '';
?>


<meta name="description" content="<?php echo e(Str::limit($metaDescription, 160)); ?>">
<?php if($keywords): ?>
    <meta name="keywords" content="<?php echo e($keywords); ?>">
<?php endif; ?>
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo e($canonicalUrl); ?>">


<meta property="og:title" content="<?php echo e(Str::limit($ogTitle, 60)); ?>">
<meta property="og:description" content="<?php echo e(Str::limit($ogDescription, 160)); ?>">
<meta property="og:url" content="<?php echo e($ogUrl); ?>">
<meta property="og:type" content="website">
<?php if($ogImage): ?>
    <meta property="og:image" content="<?php echo e(asset($ogImage)); ?>">
    <meta property="og:image:alt" content="<?php echo e($seoable ? ($seoable->title ?? $seoable->name ?? $ogTitle) : $ogTitle); ?>">
<?php endif; ?>


<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e(Str::limit($ogTitle, 60)); ?>">
<meta name="twitter:description" content="<?php echo e(Str::limit($ogDescription, 160)); ?>">
<?php if($ogImage): ?>
    <meta name="twitter:image" content="<?php echo e(asset($ogImage)); ?>">
<?php endif; ?>


<title><?php echo e($metaTitle); ?></title><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/components/seo-meta.blade.php ENDPATH**/ ?>