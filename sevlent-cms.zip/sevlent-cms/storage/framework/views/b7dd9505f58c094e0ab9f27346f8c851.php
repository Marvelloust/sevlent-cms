

<?php $__env->startSection('title', 'Blogs'); ?>
<?php $__env->startSection('page-title', 'Manage Blogs'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-blog mr-3"></i>Blog Management
                    </h1>
                    <p class="text-white">Create and manage your blog posts</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.blogs.create')); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-green-600 font-semibold rounded-lg shadow-md hover:bg-green-50 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Create New Blog
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 rounded-full">
                    <i class="fas fa-check-circle text-green-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Published Blogs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($publishedBlogs); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 bg-yellow-100 rounded-full">
                    <i class="fas fa-edit text-yellow-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Draft Blogs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($draftBlogs); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 rounded-full">
                    <i class="fas fa-blog text-blue-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Blogs</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($totalBlogs); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Blogs Table -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Filters Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <form method="GET" action="<?php echo e(route('admin.blogs.index')); ?>" class="space-y-3">
                <!-- All Filters in One Line -->
                <div class="flex flex-wrap gap-3">
                    <!-- Search -->
                    <div class="w-80">
                        <label for="search" class="sr-only">Search blogs</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400 dark:text-gray-500"></i>
                            </div>
                            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                                   class="block w-full pl-10 pr-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search blogs by title, content, or author...">
                        </div>
                    </div>

                    <!-- Status Filter -->
                    <div class="w-40">
                        <label for="status" class="sr-only">Filter by status</label>
                        <select name="status" id="status"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('status') === 'all' || !request('status') ? 'selected' : ''); ?>>All Status</option>
                            <option value="published" <?php echo e(request('status') === 'published' ? 'selected' : ''); ?>>Published</option>
                            <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Draft</option>
                        </select>
                    </div>

                    <!-- Category Filter -->
                    <div class="w-48">
                        <label for="category" class="sr-only">Filter by category</label>
                        <select name="category" id="category"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('category') === 'all' || !request('category') ? 'selected' : ''); ?>>All Categories</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Sort Options -->
                    <div class="w-48">
                        <label for="sort_by" class="sr-only">Sort by</label>
                        <select name="sort_by" id="sort_by"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="created_at" <?php echo e(request('sort_by') === 'created_at' || !request('sort_by') ? 'selected' : ''); ?>>Created Date</option>
                            <option value="title" <?php echo e(request('sort_by') === 'title' ? 'selected' : ''); ?>>Title</option>
                            <option value="slug" <?php echo e(request('sort_by') === 'slug' ? 'selected' : ''); ?>>Slug</option>
                            <option value="status" <?php echo e(request('sort_by') === 'status' ? 'selected' : ''); ?>>Status</option>
                            <option value="published_at" <?php echo e(request('sort_by') === 'published_at' ? 'selected' : ''); ?>>Published Date</option>
                            <option value="updated_at" <?php echo e(request('sort_by') === 'updated_at' ? 'selected' : ''); ?>>Updated Date</option>
                        </select>
                    </div>

                    <!-- Sort Direction -->
                    <div class="w-32">
                        <label for="sort_direction" class="sr-only">Sort direction</label>
                        <select name="sort_direction" id="sort_direction"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="desc" <?php echo e(request('sort_direction') === 'desc' || !request('sort_direction') ? 'selected' : ''); ?>>Descending</option>
                            <option value="asc" <?php echo e(request('sort_direction') === 'asc' ? 'selected' : ''); ?>>Ascending</option>
                        </select>
                    </div>
                </div>

                <!-- Buttons on Second Line -->
                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.blogs.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-times mr-2"></i>Clear
                    </a>
                </div>
            </form>
        </div>

        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600 dark:text-gray-400"></i>All Blogs
                    <?php if(request('search') || request('status') !== 'all' && request('status') || request('category') !== 'all' && request('category')): ?>
                        <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                            (<?php echo e($blogs->total()); ?> result<?php echo e($blogs->total() !== 1 ? 's' : ''); ?>)
                        </span>
                    <?php endif; ?>
                </h3>
                <?php if(request('search') || request('status') !== 'all' && request('status') || request('category') !== 'all' && request('category')): ?>
                    <div class="mt-2 sm:mt-0 flex flex-wrap gap-2">
                        <?php if(request('search')): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                Search: "<?php echo e(request('search')); ?>"
                                <a href="<?php echo e(request()->fullUrlWithQuery(['search' => null])); ?>" class="ml-1 text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('status') && request('status') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200">
                                Status: <?php echo e(ucfirst(request('status'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => null])); ?>" class="ml-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('category') && request('category') !== 'all'): ?>
                            <?php
                                $selectedCategory = $categories->find(request('category'));
                            ?>
                            <?php if($selectedCategory): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                                    Category: <?php echo e($selectedCategory->name); ?>

                                    <a href="<?php echo e(request()->fullUrlWithQuery(['category' => null])); ?>" class="ml-1 text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-300">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50 dark:bg-gray-900">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-heading mr-2"></i>Title & Image
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-tags mr-2"></i>Categories
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-info-circle mr-2"></i>Status
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Published
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <?php if($blog->image): ?>
                                        <div class="flex-shrink-0 w-12 h-12">
                                            <img class="w-12 h-12 rounded-lg object-cover border border-gray-200" src="<?php echo e(asset('storage/' . $blog->image->file_path)); ?>" alt="<?php echo e($blog->title); ?>">
                                        </div>
                                    <?php else: ?>
                                        <div class="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-image text-white text-sm"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900 dark:text-white"><?php echo e($blog->title); ?></div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($blog->slug); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($blog->categories->count() > 0): ?>
                                    <div class="flex flex-wrap gap-1">
                                        <?php $__currentLoopData = $blog->categories->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-200 text-green-800 dark:text-green-200">
                                                <?php echo e($category->name); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($blog->categories->count() > 2): ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-200 text-gray-800 dark:text-white">
                                                +<?php echo e($blog->categories->count() - 2); ?> more
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">No categories</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($blog->status === 'published' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-yellow-100 text-yellow-800 border border-yellow-200'); ?>">
                                    <i class="fas <?php echo e($blog->status === 'published' ? 'fa-check-circle' : 'fa-clock'); ?> mr-1"></i>
                                    <?php echo e(ucfirst($blog->status)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                                <?php echo e($blog->published_at ? $blog->published_at->format('M d, Y') : 'Not published'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.blogs.show', $blog)); ?>" class="inline-flex items-center px-3 py-1 bg-blue-100 dark:bg-blue-200 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors duration-150">
                                        <i class="fas fa-eye mr-1"></i>View
                                    </a>
                                    <a href="<?php echo e(route('admin.blogs.edit', $blog)); ?>" class="inline-flex items-center px-3 py-1 bg-indigo-100 dark:bg-indigo-200 text-indigo-700 dark:text-indigo-300 rounded-md hover:bg-indigo-200 dark:hover:bg-indigo-800 transition-colors duration-150">
                                        <i class="fas fa-edit mr-1"></i>Edit
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.blogs.destroy', $blog)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="inline-flex items-center px-3 py-1 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-md hover:bg-red-200 dark:hover:bg-red-800 transition-colors duration-150" onclick="showDeleteConfirmation('Are you sure you want to delete this blog post?', () => { this.closest('form').submit(); })">
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <i class="fas fa-blog text-gray-300 dark:text-gray-600 text-4xl mb-4"></i>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No blog posts found</h3>
                                    <p class="text-gray-500 dark:text-gray-400 mb-4">
                                        <?php if(request('search') || request('status') !== 'all' && request('status') || request('category') !== 'all' && request('category')): ?>
                                            No blogs match your current filters. Try adjusting your search criteria.
                                        <?php else: ?>
                                            Get started by creating your first blog post.
                                        <?php endif; ?>
                                    </p>
                                    <?php if(!request('search') && (!request('status') || request('status') === 'all') && (!request('category') || request('category') === 'all')): ?>
                                        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-150">
                                            <i class="fas fa-plus mr-2"></i>Create Your First Blog Post
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-150">
                                            <i class="fas fa-times mr-2"></i>Clear Filters
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if($blogs->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            Showing <span class="font-medium"><?php echo e($blogs->firstItem()); ?></span> to
                            <span class="font-medium"><?php echo e($blogs->lastItem()); ?></span> of
                            <span class="font-medium"><?php echo e($blogs->total()); ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-1">
                        
                        <?php if($blogs->onFirstPage()): ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-l-lg">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($blogs->previousPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-l-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </a>
                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $blogs->getUrlRange(1, $blogs->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $blogs->currentPage()): ?>
                                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 cursor-default">
                                    <?php echo e($page); ?>

                                </span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                    <?php echo e($page); ?>

                                </a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($blogs->hasMorePages()): ?>
                            <a href="<?php echo e($blogs->nextPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-r-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-r-lg">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>