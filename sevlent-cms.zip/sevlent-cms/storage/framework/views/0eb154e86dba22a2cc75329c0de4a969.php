

<?php
    $menuName = $menu ?? 'main';
    $navClass = $class ?? 'mobile-navigation';

    // Find menu by name or ID
    if (is_numeric($menuName)) {
        $menu = \App\Models\Menu::find($menuName);
    } else {
        $menu = \App\Models\Menu::where('name', $menuName)->first();
    }

    if (!$menu) {
        return;
    }

    $menuItems = $menu->topLevelItems()->active()->get();
?>

<?php if($menuItems->count() > 0): ?>
<div class="<?php echo e($navClass); ?>">
    <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e($item->url); ?>"
       target="<?php echo e($item->target); ?>"
       class="block pl-3 pr-4 py-2 border-l-4 text-base font-medium <?php echo e(request()->url() === $item->url ? 'border-blue-500 text-blue-700 bg-blue-50' : 'border-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300'); ?> <?php echo e($item->css_class); ?>">
        <?php if($item->icon): ?>
            <i class="<?php echo e($item->icon); ?> mr-2"></i>
        <?php endif; ?>
        <?php echo e($item->title); ?>

    </a>

    
    <?php if($item->children->count() > 0): ?>
        <?php echo $__env->make('components.navigation-mobile-submenu', ['items' => $item->children], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/components/navigation-mobile.blade.php ENDPATH**/ ?>