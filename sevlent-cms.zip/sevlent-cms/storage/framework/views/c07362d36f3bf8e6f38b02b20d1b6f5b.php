

<?php $__env->startSection('title', 'Homepage Builder'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-home mr-3"></i>Homepage Builder
                    </h1>
                    <p class="text-white">Manage and customize your homepage sections. Drag and drop to reorder.</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <button type="button" id="addSectionBtn" class="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Add Section
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <i class="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->where('is_active', true)->count()); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-gray-500">
            <div class="flex items-center">
                <div class="p-3 bg-gray-100 dark:bg-gray-800 rounded-full">
                    <i class="fas fa-pause-circle text-gray-600 dark:text-gray-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Inactive Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->where('is_active', false)->count()); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <i class="fas fa-layer-group text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Sections</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($page->sections->count()); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sections List -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600 dark:text-gray-400"></i>All Sections
                    <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                        (<?php echo e($page->sections->count()); ?> section<?php echo e($page->sections->count() !== 1 ? 's' : ''); ?>)
                    </span>
                </h3>
                <div class="mt-2 sm:mt-0 text-sm text-gray-600 dark:text-gray-400">
                    <i class="fas fa-arrows-alt mr-1"></i>Drag and drop to reorder sections
                </div>
            </div>
        </div>

        <div class="px-6 py-4">
            <div id="sectionsContainer" class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="section-item bg-gradient-to-r from-white to-gray-50 dark:from-gray-800 dark:to-gray-900 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-200 overflow-hidden" data-section-id="<?php echo e($section->id); ?>">
                        <div class="px-4 sm:px-6 py-4 sm:py-5">
                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                                <div class="flex items-center space-x-3 sm:space-x-4">
                                    <div class="drag-handle cursor-move text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-200 p-2 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900 flex-shrink-0">
                                        <i class="fas fa-grip-vertical text-lg"></i>
                                    </div>
                                    <div class="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                                        <i class="fas fa-layer-group text-white text-xs sm:text-sm"></i>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <h3 class="text-base sm:text-lg font-semibold text-gray-900 dark:text-white mb-1 truncate"><?php echo e($section->title); ?></h3>
                                        <p class="text-sm text-gray-600 dark:text-gray-400 mb-1 sm:mb-2"><?php echo e($sectionTypes[$section->type]['name'] ?? ucfirst($section->type)); ?></p>
                                        <div class="flex flex-wrap items-center gap-2 sm:gap-4 text-xs text-gray-500 dark:text-gray-400">
                                            <span class="flex items-center"><i class="fas fa-hashtag mr-1"></i>ID: <?php echo e($section->id); ?></span>
                                            <span class="flex items-center"><i class="fas fa-sort mr-1"></i>Order: <?php echo e($section->order_index); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                                    <span class="inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-semibold self-start sm:self-center <?php echo e($section->is_active ? 'bg-green-100 dark:bg-green-700 text-green-800 dark:text-green-300 border border-green-200 dark:border-green-700' : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-300 border border-gray-200 dark:border-gray-700'); ?>">
                                        <i class="fas <?php echo e($section->is_active ? 'fa-check-circle' : 'fa-pause-circle'); ?> mr-1"></i>
                                        <?php echo e($section->is_active ? 'Active' : 'Inactive'); ?>

                                    </span>
                                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                                        <button type="button" class="edit-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-blue-100 dark:bg-blue-400 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas fa-edit mr-2 h-4 w-4 flex-shrink-0"></i>Edit
                                        </button>
                                        <button type="button" class="toggle-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 <?php echo e($section->is_active ? 'bg-yellow-100 dark:bg-yellow-200 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-200 dark:hover:bg-yellow 300' : 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800'); ?> rounded-lg transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas <?php echo e($section->is_active ? 'fa-pause' : 'fa-play'); ?> mr-2 h-4 w-4 flex-shrink-0"></i>
                                            <?php echo e($section->is_active ? 'Disable' : 'Enable'); ?>

                                        </button>
                                        <button type="button" class="delete-section-btn inline-flex items-center justify-center px-3 sm:px-4 py-2 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300 rounded-lg hover:bg-red-200 dark:hover:bg-red-800 transition-colors duration-150 font-medium leading-tight text-sm" data-section-id="<?php echo e($section->id); ?>">
                                            <i class="fas fa-trash mr-2 h-4 w-4 flex-shrink-0"></i>Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-16">
                        <div class="mx-auto w-24 h-24 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 rounded-full flex items-center justify-center mb-6">
                            <i class="fas fa-layer-group text-blue-600 dark:text-blue-400 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No sections yet</h3>
                        <p class="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">Get started by creating your first homepage section. Sections help you build dynamic, modular content for your homepage.</p>
                        <button type="button" id="addFirstSectionBtn" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg shadow-md hover:from-blue-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105">
                            <i class="fas fa-plus mr-2"></i>Create Your First Section
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Section Modal -->
<div id="sectionModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 dark:bg-gray-900 dark:bg-opacity-75 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-4 mx-auto p-4 sm:p-5 border border-gray-300 dark:border-gray-600 w-11/12 max-w-5xl shadow-2xl rounded-xl bg-white dark:bg-gray-800 max-h-[95vh] overflow-y-auto">
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-t-xl px-4 sm:px-6 py-3 sm:py-4">
            <div class="flex items-center justify-between">
                <h3 class="text-lg sm:text-xl font-bold text-white" id="modalTitle">Add Section</h3>
                <button type="button" id="closeModalBtn" class="text-blue-200 hover:text-white transition-colors duration-200 p-2 rounded-lg hover:bg-white hover:bg-opacity-10 flex-shrink-0">
                    <i class="fas fa-times text-lg sm:text-xl"></i>
                </button>
            </div>
        </div>

        <div class="p-4 sm:p-6">
            <form id="sectionForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="sectionId" name="section_id">
                <input type="hidden" id="orderIndex" name="order_index" value="0">

                <div class="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 mb-6">
                    <div>
                        <label for="sectionType" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                            <i class="fas fa-cubes mr-2 text-blue-600"></i>Section Type
                        </label>
                        <select id="sectionType" name="type" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200" required>
                            <option value="">Select a section type</option>
                            <?php $__currentLoopData = $sectionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($type['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="sectionTitle" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                            <i class="fas fa-heading mr-2 text-blue-600"></i>Section Title
                        </label>
                        <input type="text" id="sectionTitle" name="title" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200" placeholder="Enter section title" required>
                    </div>
                </div>

                <div class="mb-6">
                    <label for="sectionContent" class="block text-sm font-semibold text-gray-900 dark:text-white mb-2">
                        <i class="fas fa-align-left mr-2 text-blue-600"></i>Content
                    </label>
                    <textarea id="sectionContent" name="content" rows="4" class="block w-full rounded-lg bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-3 px-4 border transition-colors duration-200" placeholder="Enter section content..."></textarea>
                </div>

                <!-- Dynamic Fields Container -->
                <div id="dynamicFields" class="mb-6 space-y-4 sm:space-y-6 p-3 sm:p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">
                    <!-- Section-specific fields will be loaded here -->
                </div>

                <div class="flex flex-col sm:flex-row sm:items-center p-3 sm:p-4 bg-blue-50 dark:bg-blue-900 rounded-lg border border-blue-200 dark:border-blue-700 mb-6 gap-2 sm:gap-0">
                    <div class="flex items-center">
                        <input type="checkbox" id="isActive" name="is_active" value="1" class="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 rounded transition-colors duration-200" checked>
                        <label for="isActive" class="ml-3 block text-sm font-medium text-gray-900 dark:text-white">
                            <i class="fas fa-toggle-on mr-2 text-blue-600"></i>Active Section
                        </label>
                    </div>
                    <span class="text-sm text-gray-600 dark:text-gray-400 sm:ml-2">(Visible on the page)</span>
                </div>

                <div class="flex flex-col sm:flex-row justify-end gap-3 sm:gap-0 sm:space-x-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <button type="button" id="cancelBtn" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                        <i class="fas fa-times mr-2 h-4 w-4 flex-shrink-0"></i>Cancel
                    </button>
                    <button type="submit" class="inline-flex items-center justify-center px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105 leading-tight order-1 sm:order-2">
                        <i class="fas fa-save mr-2 h-4 w-4 flex-shrink-0"></i><span id="submitBtnText">Create Section</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
// Media picker function moved to end of script to avoid duplicates
// See window.openMediaSelector definition below

// This function is defined later in the script - see window.addEventListener('message') handler below

function removeMedia(fieldName) {
    // Clear hidden input
    document.getElementById(fieldName).value = '';

    // Reset preview
    const previewDiv = document.getElementById(`${fieldName}-preview`);
    previewDiv.className = 'border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4';
    previewDiv.innerHTML = `
        <div class="text-center">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
            <div class="mt-4">
                <button type="button" onclick="openMediaSelector('${fieldName}')" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                    <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                    </svg>
                    Select Media
                </button>
            </div>
        </div>
    `;
}

document.addEventListener('DOMContentLoaded', function() {
    const sectionsContainer = document.getElementById('sectionsContainer');
    const modal = document.getElementById('sectionModal');
    const form = document.getElementById('sectionForm');
    const sectionTypeSelect = document.getElementById('sectionType');
    const dynamicFields = document.getElementById('dynamicFields');

    let sectionTypes = <?php echo json_encode($sectionTypes, 15, 512) ?> || {
        'hero': {
            'name': 'Hero Section',
            'description': 'Full-width hero section with headline, subheadline, and call-to-action buttons',
            'fields': {
                'section_title': {'type': 'text', 'label': 'Section Title (Badge)', 'required': false, 'placeholder': 'e.g., Professional Software Solutions'},
                'headline': {'type': 'text', 'label': 'Headline', 'required': true, 'placeholder': 'Enter your main headline'},
                'subheadline': {'type': 'textarea', 'label': 'Subheadline', 'required': false, 'placeholder': 'Enter your subheadline text'},
                'description': {'type': 'textarea', 'label': 'Description', 'required': false, 'placeholder': 'Enter section description'},
                'primary_button_text': {'type': 'text', 'label': 'Primary Button Text', 'required': false, 'placeholder': 'e.g., Get Started'},
                'primary_button_url': {'type': 'text', 'label': 'Primary Button URL', 'required': false, 'placeholder': 'e.g., /contact'},
                'secondary_button_text': {'type': 'text', 'label': 'Secondary Button Text', 'required': false, 'placeholder': 'e.g., Learn More'},
                'secondary_button_url': {'type': 'text', 'label': 'Secondary Button URL', 'required': false, 'placeholder': 'e.g., /about'},
                'background_image': {'type': 'media', 'label': 'Background Image', 'required': false},
                'stats_json': {'type': 'textarea', 'label': 'Stats (JSON format)', 'required': false, 'placeholder': '[{"number": "500+", "label": "Projects Delivered"}, {"number": "98%", "label": "Client Satisfaction"}]'}
            }
        },
        'about': {
            'name': 'About Section',
            'description': 'Two-column section with text content and optional image',
            'fields': {
                'image': {'type': 'media', 'label': 'Image', 'required': false}
            }
        },
        'services': {
            'name': 'Services Preview',
            'description': 'Display featured services in a grid layout',
            'fields': {}
        },
        'content': {
            'name': 'Content Section',
            'description': 'Simple content section with rich text editor',
            'fields': {}
        },
        'cta': {
            'name': 'Call to Action',
            'description': 'Centered call-to-action section with badge, headline, subheadline, button, and trust indicators',
            'fields': {
                'badge_text': {'type': 'text', 'label': 'Badge Text', 'required': false, 'placeholder': 'e.g., Let\'s Work Together'},
                'headline': {'type': 'text', 'label': 'Headline', 'required': true, 'placeholder': 'Enter your main headline'},
                'subheadline': {'type': 'textarea', 'label': 'Subheadline', 'required': false, 'placeholder': 'Enter your subheadline text'},
                'button_text': {'type': 'text', 'label': 'Button Text', 'required': false, 'placeholder': 'e.g., Get Free Consultation'},
                'button_url': {'type': 'text', 'label': 'Button URL', 'required': false, 'placeholder': 'e.g., /contact'},
                'trust_indicators': {'type': 'features', 'label': 'Trust Indicators', 'required': false, 'description': 'Add trust indicators like "Free Consultation", "Quick Response", etc.'}
            }
        },
        'testimonials': {
            'name': 'Testimonials',
            'description': 'Customer testimonials and reviews section with ratings and client information',
            'fields': {
                'section_label': {'type': 'text', 'label': 'Section Label', 'required': false, 'placeholder': 'e.g., Testimonials'},
                'headline': {'type': 'text', 'label': 'Headline', 'required': true, 'placeholder': 'What Our Clients Say'},
                'subheadline': {'type': 'textarea', 'label': 'Subheadline', 'required': false, 'placeholder': 'Hear from our satisfied clients'},
                'testimonials': {'type': 'testimonials', 'label': 'Testimonials', 'required': false, 'description': 'Add customer testimonials with ratings, names, positions, and content'},
                'cta_button_text': {'type': 'text', 'label': 'CTA Button Text', 'required': false, 'placeholder': 'Get in Touch'},
                'cta_button_url': {'type': 'text', 'label': 'CTA Button URL', 'required': false, 'placeholder': '/contact'}
            }
        }
    };
    // Initialize sortable
    if (typeof Sortable !== 'undefined') {
        const sortable = Sortable.create(sectionsContainer, {
            handle: '.drag-handle',
            animation: 150,
            onEnd: function(evt) {
                updateSectionOrder();
            }
        });
    } else {
        console.error('SortableJS not loaded');
    }

    // Add section buttons
    document.getElementById('addSectionBtn').addEventListener('click', () => openModal());
    document.getElementById('addFirstSectionBtn')?.addEventListener('click', () => openModal());

    // Modal controls
    document.getElementById('closeModalBtn').addEventListener('click', () => closeModal());
    document.getElementById('cancelBtn').addEventListener('click', () => closeModal());

    // Section type change
    sectionTypeSelect.addEventListener('change', function() {
        loadDynamicFields(this.value);
    });

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        saveSection();
    });

    // Edit buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('edit-section-btn') || e.target.closest('.edit-section-btn')) {
            const btn = e.target.classList.contains('edit-section-btn') ? e.target : e.target.closest('.edit-section-btn');
            const sectionId = btn.dataset.sectionId;
            editSection(sectionId);
        }

        if (e.target.classList.contains('toggle-section-btn') || e.target.closest('.toggle-section-btn')) {
            const btn = e.target.classList.contains('toggle-section-btn') ? e.target : e.target.closest('.toggle-section-btn');
            const sectionId = btn.dataset.sectionId;
            const isCurrentlyActive = btn.textContent.trim().includes('Disable');
            const action = isCurrentlyActive ? 'disable' : 'enable';
            const title = `Confirm ${action.charAt(0).toUpperCase() + action.slice(1)}`;
            const message = `Are you sure you want to ${action} this section? ${isCurrentlyActive ? 'It will no longer be visible on the page.' : 'It will become visible on the page again.'}`;
            
            showToggleConfirmation(title, message, isCurrentlyActive, () => toggleSection(sectionId, btn));
        }

        if (e.target.classList.contains('delete-section-btn') || e.target.closest('.delete-section-btn')) {
            const btn = e.target.classList.contains('delete-section-btn') ? e.target : e.target.closest('.delete-section-btn');
            const sectionId = btn.dataset.sectionId;
            showDeleteConfirmation('Are you sure you want to delete this section? This action cannot be undone.', () => { deleteSection(sectionId); });
        }
    });

    function openModal(section = null) {
        document.getElementById('sectionId').value = section ? section.id : '';
        document.getElementById('modalTitle').textContent = section ? 'Edit Section' : 'Add Section';
        document.getElementById('submitBtnText').textContent = section ? 'Update Section' : 'Create Section';

        if (section) {
            document.getElementById('sectionType').value = section.type;
            document.getElementById('sectionTitle').value = section.title;
            document.getElementById('sectionContent').value = section.content || '';
            document.getElementById('isActive').checked = section.is_active;
            document.getElementById('orderIndex').value = section.order_index;

            loadDynamicFields(section.type, section.data);
        } else {
            form.reset();
            document.getElementById('orderIndex').value = document.querySelectorAll('.section-item').length;
            loadDynamicFields(sectionTypeSelect.value);
        }

        modal.classList.remove('hidden');
    }

    function closeModal() {
        modal.classList.add('hidden');
        form.reset();
        dynamicFields.innerHTML = '';
    }

    function loadDynamicFields(type, data = {}) {
        if (!type || !sectionTypes[type]) {
            dynamicFields.innerHTML = '';
            return;
        }

        const fields = sectionTypes[type].fields || {};
        let html = '';

        // Helper function to escape HTML special characters
        function escapeHtml(text) {
            if (!text) return '';
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return String(text).replace(/[&<>"']/g, m => map[m]);
        }

        Object.keys(fields).forEach(fieldKey => {
            const field = fields[fieldKey];
            let value = data[fieldKey] || '';
            
            // If value is an object/array, convert to JSON string
            if (typeof value === 'object' && value !== null) {
                value = JSON.stringify(value);
            }
            
            const escapedValue = escapeHtml(value);

            html += '<div class="mt-6">';
            html += `<label class="block text-sm font-medium text-gray-700">${field.label}</label>`;

            switch (field.type) {
                case 'text':
                    html += `<input type="text" name="${fieldKey}" value="${escapedValue}" class="mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm" ${field.required ? 'required' : ''} placeholder="${field.placeholder || ''}">`;
                    break;
                case 'number':
                    html += `<input type="number" name="${fieldKey}" value="${escapedValue}" class="mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm" ${field.required ? 'required' : ''} placeholder="${field.placeholder || ''}">`;
                    break;
                case 'checkbox':
                    // For checkboxes, treat any truthy value as checked
                    const checked = (String(value) === '1' || String(value) === 'true' || value === true) ? 'checked' : '';
                    html += `<div class="mt-2"><label class="inline-flex items-center"><input type="checkbox" name="${fieldKey}" value="1" ${checked} class="rounded text-blue-600"> <span class="ml-2">${field.label}</span></label></div>`;
                    break;
                case 'textarea':
                    html += `<textarea name="${fieldKey}" rows="3" class="mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm" ${field.required ? 'required' : ''} placeholder="${field.placeholder || ''}">${escapedValue}</textarea>`;
                    break;
                case 'select':
                    html += `<select name="${fieldKey}" class="mt-1 block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm" ${field.required ? 'required' : ''}>`;
                    if (field.options) {
                        Object.entries(field.options).forEach(([optionValue, optionLabel]) => {
                            const selected = value === optionValue ? 'selected' : '';
                            html += `<option value="${optionValue}" ${selected}>${optionLabel}</option>`;
                        });
                    }
                    html += `</select>`;
                    break;
                case 'stats':
                    // Handle stats as repeatable fields
                    let statsArray = data['stats'] || [];
                    if (!Array.isArray(statsArray)) {
                        statsArray = [];
                    }
                    
                    html += `<div id="statsContainer" class="mt-2 space-y-4">`;
                    
                    // Render existing stats
                    statsArray.forEach((stat, index) => {
                        html += `<div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">`;
                        html += `<div class="flex-1 space-y-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Number/Value</label>`;
                        html += `<input type="text" name="stats[${index}][number]" value="${escapeHtml(stat.number || '')}" placeholder="e.g., 500+" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Label</label>`;
                        html += `<input type="text" name="stats[${index}][label]" value="${escapeHtml(stat.label || '')}" placeholder="e.g., Projects Delivered" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<button type="button" onclick="removeStat(${index})" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                    });
                    
                    html += `</div>`;
                    html += `<button type="button" onclick="addStat()" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Statistic</button>`;
                    break;
                case 'features':
                    // Handle features as repeatable fields
                    let featuresArray = data[fieldKey] || [];
                    if (!Array.isArray(featuresArray)) {
                        featuresArray = [];
                    }

                    html += `<div id="${fieldKey}Container" class="mt-2 space-y-4">`;

                    // Render existing features
                    featuresArray.forEach((feature, index) => {
                        html += `<div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">`;
                        html += `<div class="flex-1 space-y-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Title</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][title]" value="${escapeHtml(feature.title || '')}" placeholder="e.g., Expert Team" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Description</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][description]" value="${escapeHtml(feature.description || '')}" placeholder="e.g., Certified professionals" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<button type="button" onclick="removeFeature('${fieldKey}', ${index})" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                    });

                    html += `</div>`;
                    html += `<button type="button" onclick="addFeature('${fieldKey}')" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Feature</button>`;
                    break;
                case 'services':
                    // Handle services as repeatable fields
                    let servicesArray = data['services'] || [];
                    if (!Array.isArray(servicesArray)) {
                        servicesArray = [];
                    }

                    html += `<div id="servicesContainer" class="mt-2 space-y-4">`;

                    // Render existing services
                    servicesArray.forEach((service, index) => {
                        html += `<div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">`;
                        html += `<div class="flex-1 space-y-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Title</label>`;
                        html += `<input type="text" name="services[${index}][title]" value="${escapeHtml(service.title || '')}" placeholder="e.g., Web Development" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Description</label>`;
                        html += `<textarea name="services[${index}][description]" rows="2" placeholder="e.g., Professional web development services" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">${escapeHtml(service.description || '')}</textarea>`;
                        html += `</div>`;
                        html += `<div class="grid grid-cols-2 gap-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button Text</label>`;
                        html += `<input type="text" name="services[${index}][button_text]" value="${escapeHtml(service.button_text || '')}" placeholder="e.g., Learn More" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button URL</label>`;
                        html += `<input type="text" name="services[${index}][url]" value="${escapeHtml(service.url || '')}" placeholder="e.g., /services/web-development" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<button type="button" onclick="removeService(${index})" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                    });

                    html += `</div>`;
                    html += `<button type="button" onclick="addService()" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Service</button>`;
                    break;
                case 'media':
                    // Generate a unique ID for this media field based on field key and section ID
                    const sectionId = data.id || 'new';
                    const mediaFieldId = `${fieldKey}_${sectionId}`;
                    const mediaInfo = data[fieldKey + '_media'];
                    const hasMedia = mediaInfo || value;

                    html += `<div class="media-picker mt-1" data-media-field="${mediaFieldId}" data-allowed-types='["image"]'>`;
                    html += `<input type="hidden" name="${fieldKey}" id="${mediaFieldId}" value="${escapedValue}" ${field.required ? 'required' : ''}>`;
                    html += `<div id="${mediaFieldId}-preview" class="border-2 ${hasMedia ? 'border-solid border-blue-300 bg-blue-50 dark:bg-gray-900 dark:border-blue-600' : 'border-dashed border-gray-300 dark:border-gray-700'} rounded-lg p-4">`;

                    if (hasMedia && mediaInfo) {
                        // Show actual media info
                        let mediaIcon = '';
                            if (mediaInfo.type === 'image') {
                            mediaIcon = `<img src="${mediaInfo.url}" alt="${mediaInfo.name}" class="w-full h-full object-cover rounded-lg border border-gray-200 dark:border-gray-700">`;
                        } else if (mediaInfo.type === 'video') {
                            mediaIcon = `<video class="w-full h-full object-cover rounded-lg border" muted><source src="${mediaInfo.url}"></video>`;
                        } else {
                            mediaIcon = `<div class="w-full h-full bg-gray-100 dark:bg-gray-800 rounded-lg border flex items-center justify-center"><svg class="w-8 h-8 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg></div>`;
                        }

                        html += `<div class="flex items-center space-x-4">`;
                        html += `<div class="w-24 h-24 flex-shrink-0 bg-white dark:bg-gray-900 rounded-lg overflow-hidden">${mediaIcon}</div>`;
                        html += `<div class="flex-1">`;
                        html += `<h4 class="text-sm font-medium text-gray-900 dark:text-white">${mediaInfo.name}</h4>`;
                        html += `<p class="text-sm text-gray-500 dark:text-gray-400">${mediaInfo.type.charAt(0).toUpperCase() + mediaInfo.type.slice(1)} • ${Math.round(mediaInfo.size / 1024)} KB</p>`;
                        html += `</div>`;
                        html += `<div class="flex flex-col space-y-2">`;
                        html += `<button type="button" onclick="openMediaSelector('${mediaFieldId}')" class="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700">Change</button>`;
                        html += `<button type="button" onclick="removeMedia('${mediaFieldId}')" class="inline-flex items-center px-3 py-1 border border-red-300 shadow-sm text-xs font-medium rounded text-red-700 bg-white dark:bg-gray-800 hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                        html += `</div>`;
                    } else if (hasMedia && value) {
                        // Fallback: show ID if we have value but no media info
                        html += `<div class="flex items-center space-x-4">`;
                        html += `<div class="w-24 h-24 flex-shrink-0 bg-gray-100 dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center justify-center">`;
                        html += `<svg class="w-8 h-8 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">`;
                        html += `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>`;
                        html += `</svg>`;
                        html += `</div>`;
                        html += `<div class="flex-1">`;
                        html += `<h4 class="text-sm font-medium text-gray-900 dark:text-white">Selected Media</h4>`;
                        html += `<p class="text-sm text-gray-500 dark:text-gray-400">Media ID: ${value}</p>`;
                        html += `</div>`;
                        html += `<div class="flex flex-col space-y-2">`;
                        html += `<button type="button" onclick="openMediaSelector('${mediaFieldId}')" class="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700">Change</button>`;
                        html += `<button type="button" onclick="removeMedia('${mediaFieldId}')" class="inline-flex items-center px-3 py-1 border border-red-300 shadow-sm text-xs font-medium rounded text-red-700 bg-white dark:bg-gray-800 hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                        html += `</div>`;
                    } else {
                        // No media selected
                        html += `<div class="text-center">`;
                        html += `<svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">`;
                        html += `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>`;
                        html += `</svg>`;
                        html += `<div class="mt-4">`;
                        html += `<button type="button" onclick="openMediaSelector('${mediaFieldId}')" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">`;
                        html += `<svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">`;
                        html += `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>`;
                        html += `</svg>`;
                        html += `Select Media`;
                        html += `</button>`;
                        html += `</div>`;
                        html += `</div>`;
                    }
                    html += `</div>`;
                    html += `</div>`;
                    break;
                case 'testimonials':
                    // Handle testimonials as repeatable fields
                    let testimonialsArray = data[fieldKey] || [];
                    if (!Array.isArray(testimonialsArray)) {
                        testimonialsArray = [];
                    }

                    html += `<div id="${fieldKey}Container" class="mt-2 space-y-4">`;

                    // Render existing testimonials
                    testimonialsArray.forEach((testimonial, index) => {
                        html += `<div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">`;
                        html += `<div class="flex-1 space-y-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Client Name</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][name]" value="${escapeHtml(testimonial.name || '')}" placeholder="e.g., John Doe" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][position]" value="${escapeHtml(testimonial.position || '')}" placeholder="e.g., CEO, Tech Company" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Company</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][company]" value="${escapeHtml(testimonial.company || '')}" placeholder="e.g., TechStart Inc." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Rating (1-5)</label>`;
                        html += `<input type="number" name="${fieldKey}[${index}][rating]" value="${testimonial.rating || 5}" min="1" max="5" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Testimonial Content</label>`;
                        html += `<textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="e.g., Working with this company was amazing..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">${escapeHtml(testimonial.content || '')}</textarea>`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<button type="button" onclick="removeTestimonial('${fieldKey}', ${index})" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                    });

                    html += `</div>`;
                    html += `<button type="button" onclick="addTestimonial('${fieldKey}')" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Testimonial</button>`;
                    break;
                case 'team_members':
                    // Handle team members as repeatable fields
                    let teamArray = data[fieldKey] || [];
                    if (!Array.isArray(teamArray)) {
                        teamArray = [];
                    }

                    html += `<div id="${fieldKey}Container" class="mt-2 space-y-4">`;

                    // Render existing team members
                    teamArray.forEach((member, index) => {
                        html += `<div class="flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200">`;
                        html += `<div class="flex-1 space-y-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Photo</label>`;
                        html += `<div class="flex items-center gap-3">`;
                        html += `<input type="hidden" name="${fieldKey}[${index}][image]" value="${escapeHtml(member.image || '')}" id="${fieldKey}_${index}_image_input">`;
                        html += `<div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0">`;
                        if (member.image && typeof member.image === 'string' && member.image.trim() !== '') {
                            html += `<img src="/storage/${member.image}" alt="Team member photo" class="w-20 h-20 object-cover rounded border">`;
                        } else {
                            html += `<div class="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>`;
                        }
                        html += `</div>`;
                        html += `<button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Photo</button>`;
                        if (member.image && typeof member.image === 'string' && member.image.trim() !== '') {
                            html += `<button type="button" onclick="removeTeamMemberImage('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">Remove</button>`;
                        }
                        html += `</div>`;
                        html += `</div>`;
                        html += `<div class="grid grid-cols-2 gap-3">`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Name</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][name]" value="${escapeHtml(member.name || '')}" placeholder="e.g., John Doe" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>`;
                        html += `<input type="text" name="${fieldKey}[${index}][position]" value="${escapeHtml(member.position || '')}" placeholder="e.g., CEO" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Bio</label>`;
                        html += `<textarea name="${fieldKey}[${index}][bio]" rows="2" placeholder="e.g., Experienced leader..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">${escapeHtml(member.bio || '')}</textarea>`;
                        html += `</div>`;
                        html += `<div class="space-y-2">`;
                        html += `<label class="block text-xs font-medium text-gray-600 dark:text-gray-400">Social Links</label>`;
                        html += `<div class="grid grid-cols-2 gap-3">`;
                        html += `<div>`;
                        html += `<input type="text" name="${fieldKey}[${index}][linkedin]" value="${escapeHtml(member.linkedin || '')}" placeholder="LinkedIn URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<input type="text" name="${fieldKey}[${index}][twitter]" value="${escapeHtml(member.twitter || '')}" placeholder="Twitter URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<input type="text" name="${fieldKey}[${index}][github]" value="${escapeHtml(member.github || '')}" placeholder="GitHub URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `<div>`;
                        html += `<input type="text" name="${fieldKey}[${index}][dribbble]" value="${escapeHtml(member.dribbble || '')}" placeholder="Dribbble URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `</div>`;
                        html += `<button type="button" onclick="removeTeamMember('${fieldKey}', ${index})" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>`;
                        html += `</div>`;
                    });

                    html += `</div>`;
                    html += `<button type="button" onclick="addTeamMember('${fieldKey}')" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">+ Add Team Member</button>`;
                    break;
            }

            html += '</div>';
        });

        dynamicFields.innerHTML = html;
    }

    // Stats management functions
    window.addStat = function() {
        const container = document.getElementById('statsContainer');
        const index = container.children.length;

        const statDiv = document.createElement('div');
        statDiv.className = 'flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
        statDiv.innerHTML = `
            <div class="flex-1 space-y-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Number/Value</label>
                    <input type="text" name="stats[${index}][number]" placeholder="e.g., 500+" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Label</label>
                    <input type="text" name="stats[${index}][label]" placeholder="e.g., Projects Delivered" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
            </div>
            <button type="button" onclick="removeStat(this)" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;

        container.appendChild(statDiv);
    }

    window.removeStat = function(element) {
        if (typeof element === 'number') {
            // Called with index - find and remove
            const container = document.getElementById('statsContainer');
            if (container.children[element]) {
                container.children[element].remove();
            }
        } else {
            // Called with button element
            element.closest('[class*="flex gap"]').remove();
        }
    }

    // Features management functions
    window.addFeature = function(fieldKey) {
        const container = document.getElementById(fieldKey + 'Container');
        const index = container.children.length;

        const featureDiv = document.createElement('div');
        featureDiv.className = 'flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
        featureDiv.innerHTML = `
            <div class="flex-1 space-y-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Title</label>
                    <input type="text" name="${fieldKey}[${index}][title]" placeholder="e.g., Expert Team" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Feature Description</label>
                    <input type="text" name="${fieldKey}[${index}][description]" placeholder="e.g., Certified professionals" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
            </div>
            <button type="button" onclick="removeFeature('${fieldKey}', this)" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;

        container.appendChild(featureDiv);
    }

    window.removeFeature = function(fieldKey, element) {
        if (typeof element === 'number') {
            // Called with index - find and remove
            const container = document.getElementById(fieldKey + 'Container');
            if (container.children[element]) {
                container.children[element].remove();
            }
        } else {
            // Called with button element
            element.closest('[class*="flex gap"]').remove();
        }
    }

    // Services management functions
    window.addService = function() {
        const container = document.getElementById('servicesContainer');
        const index = container.children.length;

        const serviceDiv = document.createElement('div');
        serviceDiv.className = 'flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
        serviceDiv.innerHTML = `
            <div class="flex-1 space-y-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Title</label>
                    <input type="text" name="services[${index}][title]" placeholder="e.g., Web Development" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Service Description</label>
                    <textarea name="services[${index}][description]" rows="2" placeholder="e.g., Professional web development services" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border"></textarea>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button Text</label>
                        <input type="text" name="services[${index}][button_text]" placeholder="e.g., Learn More" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Button URL</label>
                        <input type="text" name="services[${index}][url]" placeholder="e.g., /services/web-development" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                    </div>
                </div>
            </div>
            <button type="button" onclick="removeService(this)" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;

        container.appendChild(serviceDiv);
    }

    window.removeService = function(element) {
        if (typeof element === 'number') {
            // Called with index - find and remove
            const container = document.getElementById('servicesContainer');
            if (container.children[element]) {
                container.children[element].remove();
            }
        } else {
            // Called with button element
            element.closest('[class*="flex gap"]').remove();
        }
    }

    // Testimonials management functions
    window.addTestimonial = function(fieldKey) {
        const container = document.getElementById(fieldKey + 'Container');
        const index = container.children.length;

        const testimonialDiv = document.createElement('div');
        testimonialDiv.className = 'flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
        testimonialDiv.innerHTML = `
            <div class="flex-1 space-y-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Client Name</label>
                    <input type="text" name="${fieldKey}[${index}][name]" placeholder="e.g., John Doe" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>
                    <input type="text" name="${fieldKey}[${index}][position]" placeholder="e.g., CEO, Tech Company" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Company</label>
                    <input type="text" name="${fieldKey}[${index}][company]" placeholder="e.g., TechStart Inc." class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Rating (1-5)</label>
                    <input type="number" name="${fieldKey}[${index}][rating]" value="5" min="1" max="5" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Testimonial Content</label>
                    <textarea name="${fieldKey}[${index}][content]" rows="3" placeholder="e.g., Working with this company was amazing..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border"></textarea>
                </div>
            </div>
            <button type="button" onclick="removeTestimonial('${fieldKey}', this)" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;

        container.appendChild(testimonialDiv);
    }

    window.removeTestimonial = function(fieldKey, element) {
        if (typeof element === 'number') {
            // Called with index - find and remove
            const container = document.getElementById(fieldKey + 'Container');
            if (container.children[element]) {
                container.children[element].remove();
            }
        } else {
            // Called with button element
            element.closest('[class*="flex gap"]').remove();
        }
    }

    // Team members management functions
    window.addTeamMember = function(fieldKey) {
        const container = document.getElementById(fieldKey + 'Container');
        const index = container.children.length;

        const memberDiv = document.createElement('div');
        memberDiv.className = 'flex gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
        memberDiv.innerHTML = `
            <div class="flex-1 space-y-3">
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Photo</label>
                    <div class="flex items-center gap-3">
                        <input type="hidden" name="${fieldKey}[${index}][image]" value="" id="${fieldKey}_${index}_image_input">
                        <div id="${fieldKey}_${index}_image_preview" class="flex-shrink-0">
                            <div class="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>
                        </div>
                        <button type="button" onclick="openMediaSelector('${fieldKey}_${index}_image_input', '${fieldKey}_${index}_image_preview')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Photo</button>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Name</label>
                        <input type="text" name="${fieldKey}[${index}][name]" placeholder="e.g., John Doe" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Position</label>
                        <input type="text" name="${fieldKey}[${index}][position]" placeholder="e.g., CEO" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Bio</label>
                    <textarea name="${fieldKey}[${index}][bio]" rows="2" placeholder="e.g., Experienced leader..." class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border"></textarea>
                </div>
                <div class="space-y-2">
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400">Social Links</label>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <input type="text" name="${fieldKey}[${index}][linkedin]" placeholder="LinkedIn URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][twitter]" placeholder="Twitter URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][github]" placeholder="GitHub URL" class="block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                        </div>
                        <div>
                            <input type="text" name="${fieldKey}[${index}][dribbble]" placeholder="Dribbble URL" class="block w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm py-2 px-3 border">
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" onclick="removeTeamMember('${fieldKey}', this)" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">Remove</button>
        `;

        container.appendChild(memberDiv);
    }

    window.removeTeamMember = function(fieldKey, element) {
        if (typeof element === 'number') {
            // Called with index - find and remove
            const container = document.getElementById(fieldKey + 'Container');
            if (container.children[element]) {
                container.children[element].remove();
            }
        } else {
            // Called with button element
            element.closest('[class*="flex gap"]').remove();
        }
    }

    window.removeTeamMemberImage = function(inputId, previewId) {
        const input = document.getElementById(inputId);
        const preview = document.getElementById(previewId);
        
        input.value = '';
        preview.innerHTML = '<div class="w-20 h-20 bg-gray-200 dark:bg-gray-700 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No photo</div>';
    }

    function saveSection() {
        const formData = new FormData(form);

        // Ensure CSRF token is included
        if (!formData.has('_token')) {
            formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        }

        // Collect and convert stats from form fields to JSON
        const statsContainer = document.getElementById('statsContainer');
        if (statsContainer) {
            const stats = [];
            const statRows = statsContainer.querySelectorAll('[class*="flex gap"]');
            
            statRows.forEach((row, index) => {
                const numberInput = row.querySelector(`input[name="stats[${index}][number]"]`);
                const labelInput = row.querySelector(`input[name="stats[${index}][label]"]`);
                
                if (numberInput && labelInput && numberInput.value && labelInput.value) {
                    stats.push({
                        number: numberInput.value,
                        label: labelInput.value
                    });
                }
                
                // Remove the form fields so they don't get submitted
                numberInput?.remove();
                labelInput?.remove();
            });
            
            // Add stats_json field with the collected data
            if (stats.length > 0) {
                formData.set('stats_json', JSON.stringify(stats));
            }
        }

        // Collect and convert features from form fields to JSON (for all features-type fields)
        const allContainers = document.querySelectorAll('[id$="Container"]');
        allContainers.forEach(container => {
            const containerId = container.id;
            if (containerId.endsWith('Container')) {
                const fieldKey = containerId.replace('Container', '');
                const features = [];
                const featureRows = container.querySelectorAll('[class*="flex gap"]');

                featureRows.forEach((row, index) => {
                    // Declare variables for all field types
                    let nameInput, positionInput, companyInput, ratingInput, contentInput;
                    let titleInput, descriptionInput;

                    if (fieldKey === 'testimonials') {
                        // Special handling for testimonials
                        nameInput = row.querySelector(`input[name="${fieldKey}[${index}][name]"]`);
                        positionInput = row.querySelector(`input[name="${fieldKey}[${index}][position]"]`);
                        companyInput = row.querySelector(`input[name="${fieldKey}[${index}][company]"]`);
                        ratingInput = row.querySelector(`input[name="${fieldKey}[${index}][rating]"]`);
                        contentInput = row.querySelector(`textarea[name="${fieldKey}[${index}][content]"]`);

                        if (nameInput && contentInput && nameInput.value && contentInput.value) {
                            features.push({
                                name: nameInput.value,
                                position: positionInput?.value || '',
                                company: companyInput?.value || '',
                                rating: parseInt(ratingInput?.value) || 5,
                                content: contentInput.value
                            });
                        }
                    } else {
                        // Default handling for features
                        titleInput = row.querySelector(`input[name="${fieldKey}[${index}][title]"]`);
                        descriptionInput = row.querySelector(`input[name="${fieldKey}[${index}][description]"]`);

                        if (titleInput && descriptionInput && titleInput.value && descriptionInput.value) {
                            features.push({
                                title: titleInput.value,
                                description: descriptionInput.value
                            });
                        }
                    }

                    // Remove the form fields so they don't get submitted
                    if (fieldKey === 'testimonials') {
                        nameInput?.remove();
                        positionInput?.remove();
                        companyInput?.remove();
                        ratingInput?.remove();
                        contentInput?.remove();
                    } else {
                        titleInput?.remove();
                        descriptionInput?.remove();
                    }
                });

                // Add the field with the collected data
                if (features.length > 0) {
                    formData.set(fieldKey, JSON.stringify(features));
                }
            }
        });

        // Collect and convert services from form fields to JSON
        const servicesContainer = document.getElementById('servicesContainer');
        if (servicesContainer) {
            const services = [];
            const serviceRows = servicesContainer.querySelectorAll('[class*="flex gap"]');

            serviceRows.forEach((row, index) => {
                const titleInput = row.querySelector(`input[name="services[${index}][title]"]`);
                const descriptionInput = row.querySelector(`textarea[name="services[${index}][description]"]`);
                const buttonTextInput = row.querySelector(`input[name="services[${index}][button_text]"]`);
                const urlInput = row.querySelector(`input[name="services[${index}][url]"]`);

                if (titleInput && descriptionInput && titleInput.value && descriptionInput.value) {
                    services.push({
                        title: titleInput.value,
                        description: descriptionInput.value,
                        button_text: buttonTextInput?.value || 'Learn More',
                        url: urlInput?.value || '#'
                    });
                }

                // Remove the form fields so they don't get submitted
                titleInput?.remove();
                descriptionInput?.remove();
                buttonTextInput?.remove();
                urlInput?.remove();
            });

            // Add services field with the collected data
            if (services.length > 0) {
                formData.set('services', JSON.stringify(services));
            }
        }

        const sectionId = formData.get('section_id');
        const url = sectionId
            ? `/admin/homepage/sections/${sectionId}`
            : '/admin/homepage/sections';
        const method = sectionId ? 'POST' : 'POST'; // Always use POST, spoof method for PUT

        if (sectionId) {
            formData.append('_method', 'PUT');
        }

        fetch(url, {
            method: method,
            body: formData
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (data.success) {
                closeModal();
                location.reload();
            } else {
                alert('Error: ' + JSON.stringify(data.errors));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while saving the section.');
        });
    }

    function editSection(sectionId) {
        fetch(`/admin/homepage/sections/${sectionId}`)
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (data.success) {
                openModal(data.section);
            } else {
                alert('Error loading section data');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while loading the section.');
        });
    }

    function toggleSection(sectionId, button) {
        fetch(`/admin/homepage/sections/${sectionId}/toggle`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (data.success) {
                const statusSpan = button.closest('.section-item').querySelector('span');
                if (data.section.is_active) {
                    statusSpan.className = 'inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-semibold self-start sm:self-center bg-green-100 text-green-800 border border-green-200';
                    statusSpan.innerHTML = '<i class="fas fa-check-circle mr-1"></i>Active';
                    button.innerHTML = '<i class="fas fa-pause mr-2 h-4 w-4 flex-shrink-0"></i>Disable';
                    button.className = button.className.replace('bg-green-100 text-green-700 hover:bg-green-200', 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200');
                } else {
                    statusSpan.className = 'inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs font-semibold self-start sm:self-center bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white border border-gray-200';
                    statusSpan.innerHTML = '<i class="fas fa-pause-circle mr-1"></i>Inactive';
                    button.innerHTML = '<i class="fas fa-play mr-2 h-4 w-4 flex-shrink-0"></i>Enable';
                    button.className = button.className.replace('bg-yellow-100 text-yellow-700 hover:bg-yellow-200', 'bg-green-100 text-green-700 hover:bg-green-200');
                }
            } else {
                alert('Error toggling section');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while toggling the section.');
        });
    }

    function deleteSection(sectionId) {
        fetch(`/admin/homepage/sections/${sectionId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.querySelector(`[data-section-id="${sectionId}"]`).remove();
                location.reload(); // Reload to update stats
            } else {
                alert('Error deleting section');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while deleting the section.');
        });
    }

    function updateSectionOrder() {
        const sections = [];
        document.querySelectorAll('.section-item').forEach((item, index) => {
            sections.push({
                id: parseInt(item.dataset.sectionId),
                order_index: index
            });
        });

        fetch('/admin/homepage/sections/reorder', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({ sections: sections })
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                console.error('Error updating order:', data.errors);
                alert('Error updating section order');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating section order.');
        });
    }

    // Media picker functions
    window.openMediaSelector = function(fieldId) {
        const popup = window.open(`/admin/media-selector?type=image&fieldId=${encodeURIComponent(fieldId)}`, 'mediaSelector', 'width=800,height=600,scrollbars=yes,resizable=yes');
        if (popup) {
            popup.fieldId = fieldId;
            window.fieldId = fieldId; // Also set on parent window for consistency
        }
    };

    // Listen for media selection messages
    window.addEventListener('message', function(event) {
        if (event.origin !== window.location.origin) {
            return;
        }
        
        if (event.data.type === 'MEDIA_SELECTED') {
            const media = event.data.media;
            const fieldId = event.data.fieldId;
            updateMediaSelection(media.id, media.url, media.name, fieldId);
        }
    });

    function updateMediaSelection(mediaId, mediaUrl, mediaName, fieldId) {
        // Update the hidden input
        const hiddenInput = document.getElementById(fieldId);
        if (hiddenInput) {
            hiddenInput.value = mediaId;
        }

        // Update the UI
        const mediaContainer = document.querySelector(`[data-media-field="${fieldId}"] .border-2`);
        if (mediaContainer) {
            mediaContainer.className = 'border-2 border-solid border-blue-300 bg-blue-50 rounded-lg p-4';
            mediaContainer.innerHTML = `
                <div class="flex items-center space-x-4">
                    <img src="${mediaUrl}" alt="${mediaName}" class="w-16 h-16 object-cover rounded-lg">
                    <div class="flex-1">
                        <h4 class="text-sm font-medium text-gray-900">${mediaName}</h4>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Media ID: ${mediaId}</p>
                    </div>
                    <div class="flex flex-col space-y-2">
                        <button type="button" onclick="openMediaSelector('${fieldId}')" class="inline-flex items-center px-3 py-1 border border-gray-300 dark:border-gray-600 shadow-sm text-xs font-medium rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700">Change</button>
                        <button type="button" onclick="removeMedia('${fieldId}')" class="inline-flex items-center px-3 py-1 border border-red-300 shadow-sm text-xs font-medium rounded text-red-700 bg-white dark:bg-gray-800 hover:bg-red-50">Remove</button>
                    </div>
                </div>
            `;
        }
    };

    window.removeMedia = function(fieldId) {
        // Clear the hidden input
        const hiddenInput = document.getElementById(fieldId);
        if (hiddenInput) {
            hiddenInput.value = '';
        }

        // Update the UI
        const mediaContainer = document.querySelector(`[data-media-field="${fieldId}"] .border-2`);
        if (mediaContainer) {
            mediaContainer.className = 'border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4';
            mediaContainer.innerHTML = `
                <div class="text-center">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    <div class="mt-4">
                        <button type="button" onclick="openMediaSelector('${fieldId}')" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                            <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                            </svg>
                            Select Media
                        </button>
                    </div>
                </div>
            `;
        }
    };
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/homepage/index.blade.php ENDPATH**/ ?>