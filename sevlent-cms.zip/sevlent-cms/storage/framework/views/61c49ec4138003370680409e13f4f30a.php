<!-- Modern Services Section -->
<section class="py-24 bg-white relative overflow-hidden">
    <!-- Background Pattern -->
    <div class="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.5))] -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Header -->
        <div class="text-center mb-10" data-aos="fade-up">
            <!-- Badge -->
            <?php if(!empty($section->data['section_label'])): ?>
            <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full mb-6">
                <span class="text-sm font-semibold text-blue-700"><?php echo e($section->data['section_label']); ?></span>
            </div>
            <?php endif; ?>

            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight mb-6">
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-gray-900 via-purple-900 to-gray-900">
                    <?php echo e($section->title); ?>

                </span>
            </h2>

            <?php if($section->content): ?>
                <div class="text-body-lg md:text-body-xl text-gray-600 max-w-3xl mx-auto">
                    <?php echo $section->content; ?>

                </div>
            <?php endif; ?>
        </div>

        <!-- Services Grid -->
        <?php
            // Get all active services from database
            $servicesQuery = \App\Models\Service::where('status', 'active')
                ->with(['category', 'icon'])
                ->orderBy('created_at', 'desc');

            // Apply display limit if set
            $displayLimit = $section->data['display_limit'] ?? null;
            if ($displayLimit && is_numeric($displayLimit)) {
                $servicesQuery->limit((int)$displayLimit);
            }

            $allServices = $servicesQuery->get();
            $showViewAll = $section->data['show_view_all'] ?? true;
        ?>
        <?php if($allServices->count() > 0): ?>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $gradients = [
                        'from-blue-500 to-indigo-600',
                        'from-purple-500 to-pink-600',
                        'from-green-500 to-emerald-600',
                        'from-orange-500 to-red-600',
                        'from-cyan-500 to-blue-600',
                        'from-pink-500 to-purple-600',
                    ];
                    $icons = [
                        'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
                        'M13 10V3L4 14h7v7l9-11h-7z',
                        'M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4',
                        'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z',
                        'M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z',
                        'M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z',
                    ];
                    $gradient = $gradients[$index % count($gradients)];
                    $icon = $icons[$index % count($icons)];
                ?>
                <div class="group relative" data-aos="fade-up" data-aos-delay="<?php echo e($index * 100); ?>">
                    <!-- Card -->
                    <div class="relative h-full bg-white rounded-2xl border border-gray-200 p-6 transition-all duration-300 hover:shadow-xl hover:border-gray-300 hover:-translate-y-1">
                        <!-- Subtle Gradient Border on Hover -->
                        <div class="absolute inset-0 bg-gradient-to-r <?php echo e($gradient); ?> rounded-2xl opacity-0 group-hover:opacity-5 transition-opacity duration-300 -z-10"></div>

                        <!-- Card Content -->
                        <div class="flex items-start space-x-4">
                            <!-- Left Side: Icon -->
                            <div class="flex-shrink-0">
                                <?php if($service->icon): ?>
                                    <div class="w-14 h-14 bg-white rounded-xl flex items-center justify-center border-2 border-gray-100 transform group-hover:scale-105 transition-all duration-300 overflow-hidden relative">
                                        <?php if($service->icon->file_type === 'video'): ?>
                                        <video class="w-10 h-10 object-contain" muted>
                                            <source src="<?php echo e($service->icon->url); ?>" type="video/mp4">
                                        </video>
                                        <div class="absolute inset-0 flex items-center justify-center bg-black/20 rounded-xl">
                                            <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M8 5v14l11-7z"/>
                                            </svg>
                                        </div>
                                        <?php else: ?>
                                        <img src="<?php echo e($service->icon->url); ?>"
                                             alt="<?php echo e($service->name); ?>"
                                             class="w-10 h-10 object-contain">
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="w-14 h-14 bg-gradient-to-r <?php echo e($gradient); ?> rounded-xl flex items-center justify-center transform group-hover:scale-105 transition-all duration-300">
                                        <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($icon); ?>"/>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Right Side: Title, Description and Button -->
                            <div class="flex-1 min-w-0">
                                <h3 class="text-heading-sm font-bold text-gray-900 mb-2 group-hover:text-gray-800 transition-all duration-300">
                                    <?php echo e($service->name); ?>

                                </h3>

                                <p class="text-gray-600 text-sm mb-4 leading-relaxed">
                                    <?php echo e($service->short_description ?? 'Professional service offering'); ?>

                                </p>

                                <a href="<?php echo e(route('services.show', $service->slug)); ?>"
                                   class="inline-flex items-center px-6 py-2 bg-gradient-to-r <?php echo e($gradient); ?> text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                                    <span>Learn More</span>
                                    <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                                    </svg>
                                </a>
                            </div>
                        </div>

                        <!-- Subtle Decorative Corner -->
                        <div class="absolute top-0 right-0 w-12 h-12 bg-gradient-to-br <?php echo e($gradient); ?> opacity-0 group-hover:opacity-5 rounded-2xl transform translate-x-4 -translate-y-4 transition-all duration-300"></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <!-- View All Button -->
        <?php if($showViewAll && \App\Models\Service::where('status','active')->count() > $allServices->count()): ?>
            <div class="text-center mt-16" data-aos="fade-up">
                <a href="<?php echo e(route('services.index')); ?>"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all duration-300 transform hover:scale-105">
                    <span>View All Services</span>
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                    </svg>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Background Decoration -->
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full blur-3xl opacity-20 -z-10"></div>
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-200 to-indigo-200 rounded-full blur-3xl opacity-20 -z-10"></div>
</section><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/services.blade.php ENDPATH**/ ?>