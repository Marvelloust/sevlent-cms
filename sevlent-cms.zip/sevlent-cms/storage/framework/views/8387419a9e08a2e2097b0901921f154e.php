<!-- Modern Testimonials Section -->
<section class="py-24 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
    <!-- Background Elements -->
    <div class="absolute inset-0 bg-grid-slate-100 [mask-image:linear-gradient(0deg,white,rgba(255,255,255,0.6))] -z-10"></div>
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Section Header with CTA Button -->
        <div class="grid lg:grid-cols-2 gap-12 items-center mb-16" data-aos="fade-up">
            <!-- Left Side: Heading and Subheading -->
            <div class="space-y-6">
                <!-- Badge -->
                <?php if(!empty($section->data['section_label'])): ?>
                <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full">
                    <span class="text-sm font-semibold text-blue-700"><?php echo e($section->data['section_label']); ?></span>
                </div>
                <?php endif; ?>

                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    <span class="bg-clip-text text-transparent bg-gradient-to-r from-gray-900 via-purple-900 to-gray-900">
                        <?php echo e($section->title); ?>

                    </span>
                </h2>

                <?php if(!empty($section->data['subheadline'])): ?>
                    <div class="text-body-lg md:text-body-xl text-gray-600">
                        <?php echo $section->data['subheadline']; ?>

                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Side: CTA Button -->
            <?php if(!empty($section->data['cta_button_text'])): ?>
            <div class="lg:text-right" data-aos="fade-up" data-aos-delay="100">
                <a href="<?php echo e($section->data['cta_button_url'] ?? '#'); ?>"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all duration-300 transform hover:scale-105">
                    <span><?php echo e($section->data['cta_button_text']); ?></span>
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                    </svg>
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Testimonials Carousel -->
        <?php
            $testimonialsData = $section->data['testimonials'] ?? null;
            if ($testimonialsData && is_string($testimonialsData)) {
                $testimonialsData = json_decode($testimonialsData, true);
            }

            // Randomly select up to 6 testimonials
            if ($testimonialsData && is_array($testimonialsData) && count($testimonialsData) > 0) {
                shuffle($testimonialsData);
                $testimonialsData = array_slice($testimonialsData, 0, 6);
            }
        ?>

        <?php if($testimonialsData && is_array($testimonialsData) && count($testimonialsData) > 0): ?>
        <div class="relative mb-16">
            <!-- Carousel Container -->
            <div class="overflow-x-auto scrollbar-hide pb-4">
                <div class="flex space-x-6 px-4" style="width: max-content;">
                    <?php $__currentLoopData = $testimonialsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $gradients = [
                                'from-blue-500 to-indigo-600',
                                'from-purple-500 to-pink-600',
                                'from-green-500 to-emerald-600',
                                'from-orange-500 to-red-600',
                                'from-cyan-500 to-blue-600',
                                'from-pink-500 to-purple-600',
                            ];
                            $gradient = $gradients[$index % count($gradients)];
                        ?>

                        <div class="group relative bg-white rounded-2xl border border-gray-200 p-6 transition-all duration-300 hover:shadow-2xl hover:border-transparent hover:-translate-y-2 flex-shrink-0 w-80" data-aos="fade-up" data-aos-delay="<?php echo e($index * 100); ?>">
                            <!-- Gradient Border on Hover -->
                            <div class="absolute inset-0 bg-gradient-to-r <?php echo e($gradient); ?> rounded-2xl opacity-0 group-hover:opacity-5 transition-opacity duration-300 -z-10"></div>

                            <!-- Quote Icon - Top Right Corner -->
                            <div class="absolute top-4 right-4 opacity-20">
                                <svg class="w-8 h-8 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h4v10h-10z"/>
                                </svg>
                            </div>

                            <!-- Content -->
                            <blockquote class="text-gray-700 text-center mb-4 leading-relaxed pr-12">
                                "<?php echo e($testimonial['content'] ?? 'Testimonial content'); ?>"
                            </blockquote>

                            <!-- Rating -->
                            <?php if(!empty($testimonial['rating'])): ?>
                            <div class="flex justify-center mb-4">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <svg class="w-4 h-4 <?php echo e($i <= $testimonial['rating'] ? 'text-yellow-400' : 'text-gray-300'); ?>" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                    </svg>
                                <?php endfor; ?>
                            </div>
                            <?php endif; ?>

                            <!-- Author Info - Compact Horizontal Layout -->
                            <div class="flex items-center justify-center space-x-3">
                                <div class="w-10 h-10 bg-gradient-to-r <?php echo e($gradient); ?> rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                                    <?php echo e(substr($testimonial['name'] ?? 'Client', 0, 1)); ?>

                                </div>
                                <div class="text-left min-w-0 flex-1">
                                    <h4 class="font-semibold text-gray-900 text-sm truncate"><?php echo e($testimonial['name'] ?? 'Client Name'); ?></h4>
                                    <p class="text-xs text-gray-600 truncate"><?php echo e($testimonial['position'] ?? 'Position'); ?></p>
                                    <?php if(!empty($testimonial['company'])): ?>
                                    <p class="text-xs text-gray-500 truncate"><?php echo e($testimonial['company']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Scroll Indicators -->
            <div class="flex justify-center space-x-2 mt-6">
                <div class="flex space-x-2">
                    <?php for($i = 0; $i < count($testimonialsData); $i++): ?>
                    <button class="w-2 h-2 rounded-full bg-gray-300 transition-all duration-300 hover:bg-gray-400 carousel-indicator" data-slide="<?php echo e($i); ?>"></button>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        </div>
    </div>
</section><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/testimonials.blade.php ENDPATH**/ ?>