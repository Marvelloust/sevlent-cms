<!-- Modern Hero Section -->
<?php
    $backgroundImage = $section->data['background_image'] ?? null;
    if (!$backgroundImage && $section->page && $section->page->banner) {
        $backgroundImage = $section->page->banner->id;
    }
    $backgroundMedia = $backgroundImage ? \App\Models\Media::find($backgroundImage) : null;
    $backgroundImageUrl = $backgroundMedia ? $backgroundMedia->url : null;
    $isVideoBackground = $backgroundMedia && $backgroundMedia->file_type === 'video';
?>

<section class="relative h-screen flex items-center overflow-hidden"
         <?php if($backgroundImageUrl && !$isVideoBackground): ?>
         style="background-image: linear-gradient(90deg, rgba(var(--color-primary-rgb), 0.8) 0%, rgba(var(--color-secondary-rgb), 0.4) 50%, transparent 100%), url('<?php echo e($backgroundImageUrl); ?>'); background-size: cover; background-position: center; background-attachment: fixed;"
         <?php else: ?>
         style="background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 50%, var(--color-accent) 100%);"
         <?php endif; ?>>

    
    <?php if($isVideoBackground): ?>
    <video class="absolute inset-0 w-full h-full object-cover" autoplay muted loop playsinline>
        <source src="<?php echo e($backgroundImageUrl); ?>" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="absolute inset-0 bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent"></div>
    <?php endif; ?>

    <!-- Animated Gradient Orbs -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute -top-1/2 -right-1/4 w-96 h-96 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
        <div class="absolute -bottom-1/2 -left-1/4 w-96 h-96 bg-gradient-to-br from-blue-400 to-indigo-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
    </div>

    <!-- Grid Pattern Overlay -->
    <div class="absolute inset-0 bg-grid-pattern opacity-10"></div>

    <!-- Content Container -->
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <?php
            $isAboutPage = $section->page && $section->page->slug === 'about';
        ?>
        <div class="grid <?php echo e($isAboutPage ? 'lg:grid-cols-1' : 'lg:grid-cols-2'); ?> gap-8 items-center">
            <!-- Left Content -->
            <div class="text-white space-y-6 <?php echo e($isAboutPage ? 'lg:text-center' : ''); ?>">
                <!-- Badge / Section Title -->
                <?php if(!empty($section->data['section_title'])): ?>
                    <div class="inline-flex items-center px-3 py-1.5 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                        <span class="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse mr-2"></span>
                        <span class="text-xs font-medium"><?php echo e($section->data['section_title']); ?></span>
                    </div>
                <?php endif; ?>

                <!-- Main Headline -->
                <h1 class="text-heading-xl md:text-heading-2xl lg:text-heading-3xl <?php echo e($isAboutPage ? 'lg:text-display-md' : ''); ?> font-bold leading-tight">
                    <span class="bg-clip-text text-transparent bg-gradient-to-r from-white to-white/90">
                        <?php echo e($section->data['headline'] ?? 'Transform Your Digital Vision'); ?>

                    </span>
                    <?php if(!empty($section->data['subheadline'])): ?>
                        <span class="block text-body-lg md:text-body-xl lg:text-heading-sm font-light text-white/80 mt-3">
                            <?php echo e($section->data['subheadline']); ?>

                        </span>
                    <?php endif; ?>
                </h1>

                <!-- Description -->
                <?php if(!empty($section->data['description'])): ?>
                    <p class="text-body-md md:text-body-lg text-white/70 leading-relaxed <?php echo e($isAboutPage ? 'max-w-4xl mx-auto' : 'max-w-xl'); ?>">
                        <?php echo e($section->data['description']); ?>

                    </p>
                <?php endif; ?>

                <!-- CTA Buttons -->
                <div class="flex flex-col sm:flex-row gap-3">
                    <?php if(!empty($section->data['primary_button_text'])): ?>
                        <a href="<?php echo e($section->data['primary_button_url'] ?? '#'); ?>"
                           class="group inline-flex items-center justify-center px-6 py-3 bg-white text-gray-900 font-semibold rounded-lg text-base shadow-lg shadow-white/20 transition-all duration-300 transform hover:scale-105 hover:shadow-white/30">
                            <span><?php echo e($section->data['primary_button_text']); ?></span>
                            <svg class="ml-2 w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                            </svg>
                        </a>
                    <?php endif; ?>

                    <?php if(!empty($section->data['secondary_button_text'])): ?>
                        <a href="<?php echo e($section->data['secondary_button_url'] ?? '#'); ?>"
                           class="group inline-flex items-center justify-center px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/30 text-white font-semibold rounded-lg text-base transition-all duration-300 transform hover:scale-105 hover:bg-white/20">
                            <span><?php echo e($section->data['secondary_button_text']); ?></span>
                            <svg class="ml-2 w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                            </svg>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Stats or Features -->
                <?php
                    $stats = $section->data['stats'] ?? null;
                    if ($stats && is_string($stats)) {
                        $stats = json_decode($stats, true);
                    }
                ?>
                <?php if($stats && is_array($stats) && count($stats) > 0): ?>
                    <div class="flex flex-wrap gap-6 pt-6">
                        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($stat['number']) && !empty($stat['label'])): ?>
                                <div class="text-center">
                                    <div class="text-2xl font-bold"><?php echo e($stat['number']); ?></div>
                                    <div class="text-sm text-white/60 mt-1"><?php echo e($stat['label']); ?></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Visual Element -->
            <?php if(!$isAboutPage): ?>
            <div class="hidden lg:block relative">
                <div class="relative w-full h-[500px]">
                    <!-- Floating Cards -->
                    <div class="absolute top-8 right-8 w-64 h-40 bg-white/5 backdrop-blur-md rounded-xl border border-white/10 p-4 transform rotate-2 hover:rotate-3 transition-all duration-500 shadow-xl z-10">
                        <div class="flex items-center space-x-3 mb-3">
                            <div class="w-10 h-10 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                </svg>
                            </div>
                            <div class="flex-1">
                                <div class="h-2 bg-white/30 rounded w-3/4 mb-1"></div>
                                <div class="h-1.5 bg-white/20 rounded w-1/2"></div>
                            </div>
                        </div>
                        <div class="space-y-1.5">
                            <div class="h-1.5 bg-white/25 rounded"></div>
                            <div class="h-1.5 bg-white/25 rounded w-5/6"></div>
                        </div>
                    </div>

                    <div class="absolute bottom-8 left-8 w-64 h-40 bg-white/5 backdrop-blur-md rounded-xl border border-white/10 p-4 transform -rotate-2 hover:-rotate-3 transition-all duration-500 shadow-xl z-20">
                        <div class="flex items-center justify-between mb-3">
                            <div class="w-8 h-8 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center">
                                <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                </svg>
                            </div>
                            <div class="flex space-x-1">
                                <div class="w-1.5 h-1.5 bg-white/30 rounded-full"></div>
                                <div class="w-1.5 h-1.5 bg-white/30 rounded-full"></div>
                                <div class="w-1.5 h-1.5 bg-white/30 rounded-full"></div>
                            </div>
                        </div>
                        <div class="space-y-1.5">
                            <div class="h-1.5 bg-white/25 rounded w-3/4"></div>
                            <div class="h-1.5 bg-white/25 rounded"></div>
                            <div class="h-1.5 bg-white/25 rounded w-2/3"></div>
                        </div>
                    </div>

                    <div class="absolute top-1/3 left-1/3 w-64 h-40 bg-white/5 backdrop-blur-md rounded-xl border border-white/10 p-4 transform rotate-1 hover:rotate-2 transition-all duration-500 shadow-xl z-30">
                        <div class="flex items-center space-x-3 mb-3">
                            <div class="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-lg flex items-center justify-center">
                                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                                </svg>
                            </div>
                            <div class="flex-1">
                                <div class="h-2 bg-white/30 rounded w-2/3 mb-1"></div>
                                <div class="h-1.5 bg-white/20 rounded w-1/2"></div>
                            </div>
                        </div>
                        <div class="space-y-1.5">
                            <div class="h-1.5 bg-white/25 rounded w-4/5"></div>
                            <div class="h-1.5 bg-white/25 rounded"></div>
                        </div>
                    </div>

                    <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-full blur-2xl animate-pulse"></div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Scroll Indicator -->
        <div class="absolute bottom-6 left-1/2 transform -translate-x-1/2">
            <div class="flex flex-col items-center text-white/50 animate-bounce">
                <span class="text-xs mb-1">Scroll to explore</span>
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                </svg>
            </div>
        </div>
    </div>

    <!-- Custom Animations -->
    <style>
        @keyframes blob {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(20px, -20px) scale(1.1); }
            50% { transform: translate(-20px, 20px) scale(0.9); }
            75% { transform: translate(20px, 20px) scale(1.05); }
        }
        .animate-blob {
            animation: blob 20s infinite;
        }
        .animation-delay-2000 {
            animation-delay: 2s;
        }
        .animation-delay-4000 {
            animation-delay: 4s;
        }
        .bg-grid-pattern {
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px);
            background-size: 50px 50px;
        }
    </style>
</section><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/hero.blade.php ENDPATH**/ ?>