<!-- Modern About Section -->
<section class="py-24 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-blue-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <?php
            $hasImage = !empty($section->data['image']);
            $features = $section->data['features'] ?? null;
            if ($features && is_string($features)) {
                $features = json_decode($features, true);
            }
            $hasFeatures = $features && is_array($features) && count($features) > 0;
        ?>

        <?php if($hasImage): ?>
            <!-- Two Column Layout with Image -->
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <!-- Image Side -->
                <div class="relative order-2 lg:order-1" data-aos="fade-right">
                    <div class="relative">
                        <!-- Main Image -->
                        <div class="relative rounded-2xl overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500 h-96">
                            <img
                                src="<?php echo e(optional(\App\Models\Media::find($section->data['image']))->url); ?>"
                                alt="<?php echo e($section->title); ?>"
                                class="w-full h-full object-cover"
                            >
                            <!-- Gradient Overlay -->
                            <div class="absolute inset-0 bg-gradient-to-tr from-purple-600/20 to-transparent"></div>
                        </div>

                        <!-- Floating Stats Card -->
                        <?php if(!empty($section->data['floating_stat_number']) || !empty($section->data['floating_stat_label'])): ?>
                        <div class="absolute -bottom-8 -right-8 bg-white rounded-2xl shadow-2xl p-4 border border-gray-100 transform hover:-translate-y-2 transition-transform duration-300">
                            <div class="flex items-center space-x-4">
                                <div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-2xl font-bold text-gray-900"><?php echo e($section->data['floating_stat_number'] ?? '10+'); ?></div>
                                    <div class="text-sm text-gray-600"><?php echo e($section->data['floating_stat_label'] ?? 'Years Experience'); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Decorative Elements -->
                        <div class="absolute -top-6 -left-6 w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full opacity-20 blur-2xl"></div>
                        <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full opacity-20 blur-2xl"></div>
                    </div>

                    <!-- Features Grid Below Image -->
                    <?php if($hasFeatures): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-12" data-aos="fade-up" data-aos-delay="200">
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $colors = [
                                    ['bg-gradient-to-br from-green-400 to-emerald-500', 'from-green-100 to-emerald-100'],
                                    ['bg-gradient-to-br from-blue-400 to-indigo-500', 'from-blue-100 to-indigo-100'],
                                    ['bg-gradient-to-br from-purple-400 to-pink-500', 'from-purple-100 to-pink-100'],
                                    ['bg-gradient-to-br from-orange-400 to-red-500', 'from-orange-100 to-red-100']
                                ];
                                $colorIndex = $index % count($colors);
                                $bgColor = $colors[$colorIndex][0];
                                $badgeColor = $colors[$colorIndex][1];
                            ?>
                            <div class="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg border border-white/20 space-y-3">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 <?php echo e($bgColor); ?> rounded-xl flex items-center justify-center flex-shrink-0">
                                        <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                        </svg>
                                    </div>
                                    <span class="font-semibold text-gray-900"><?php echo e($feature['title'] ?? 'Feature Title'); ?></span>
                                </div>
                                <p class="text-sm text-gray-600 ml-13"><?php echo e($feature['description'] ?? 'Feature description'); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Content Side -->
                <div class="space-y-8 order-1 lg:order-2" data-aos="fade-left">
                    <!-- Section Label -->
                    <?php if(!empty($section->data['section_label'])): ?>
                    <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
                        <span class="text-sm font-semibold text-purple-700"><?php echo e($section->data['section_label']); ?></span>
                    </div>
                    <?php endif; ?>

                    <!-- Title -->
                    <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                        <span class="bg-clip-text text-transparent bg-gradient-to-r from-gray-900 via-purple-900 to-gray-900">
                            <?php echo e($section->title); ?>

                        </span>
                    </h2>

                    <!-- Content -->
                    <div class="prose prose-lg max-w-none text-gray-600 leading-relaxed">
                        <?php echo $section->content; ?>

                    </div>

                    <!-- CTA Button -->
                    <?php if(!empty($section->data['cta_button_text'])): ?>
                    <div class="pt-4">
                        <a href="<?php echo e($section->data['cta_button_url'] ?? route('page', 'about')); ?>"
                           class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all duration-300 transform hover:scale-105">
                            <span><?php echo e($section->data['cta_button_text']); ?></span>
                            <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                            </svg>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Full Width Layout without Image -->
            <div class="text-center space-y-8" data-aos="fade-up">
                <!-- Section Label -->
                <?php if(!empty($section->data['section_label'])): ?>
                <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
                    <span class="text-sm font-semibold text-purple-700"><?php echo e($section->data['section_label']); ?></span>
                </div>
                <?php endif; ?>

                <!-- Title -->
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    <span class="bg-clip-text text-transparent bg-gradient-to-r from-gray-900 via-purple-900 to-gray-900">
                        <?php echo e($section->title); ?>

                    </span>
                </h2>

                <!-- Content -->
                <div class="prose prose-lg max-w-none text-gray-600 leading-relaxed">
                    <?php echo $section->content; ?>

                </div>

                <!-- Features Grid -->
                <?php if($hasFeatures): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-<?php echo e(min(count($features), 4)); ?> gap-6 pt-8" data-aos="fade-up" data-aos-delay="200">
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $colors = [
                                ['bg-gradient-to-br from-green-400 to-emerald-500', 'from-green-100 to-emerald-100'],
                                ['bg-gradient-to-br from-blue-400 to-indigo-500', 'from-blue-100 to-indigo-100'],
                                ['bg-gradient-to-br from-purple-400 to-pink-500', 'from-purple-100 to-pink-100'],
                                ['bg-gradient-to-br from-orange-400 to-red-500', 'from-orange-100 to-red-100']
                            ];
                            $colorIndex = $index % count($colors);
                            $bgColor = $colors[$colorIndex][0];
                            $badgeColor = $colors[$colorIndex][1];
                        ?>
                        <div class="bg-white/70 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-white/20 space-y-3">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 <?php echo e($bgColor); ?> rounded-xl flex items-center justify-center flex-shrink-0">
                                    <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                    </svg>
                                </div>
                                <span class="font-semibold text-gray-900 text-left"><?php echo e($feature['title'] ?? 'Feature Title'); ?></span>
                            </div>
                            <p class="text-sm text-gray-600 text-left ml-13"><?php echo e($feature['description'] ?? 'Feature description'); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- CTA Button -->
                <?php if(!empty($section->data['cta_button_text'])): ?>
                <div class="pt-8">
                    <a href="<?php echo e($section->data['cta_button_url'] ?? route('page', 'about')); ?>"
                       class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all duration-300 transform hover:scale-105">
                        <span><?php echo e($section->data['cta_button_text']); ?></span>
                        <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                        </svg>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/frontend/sections/about.blade.php ENDPATH**/ ?>