

<?php $__env->startSection('title', 'View Contact'); ?>
<?php $__env->startSection('page-title', 'View Contact'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r rounded-xl shadow-lg overflow-hidden" style="background: linear-gradient(to right, #ea580c, #dc2626);">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($contact->is_read ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'); ?>">
                            <i class="fas fa-<?php echo e($contact->is_read ? 'envelope-open' : 'envelope'); ?> mr-1"></i>
                            <?php echo e($contact->is_read ? 'Read' : 'Unread'); ?>

                        </span>
                        <?php if($contact->subject): ?>
                        <span class="ml-3 text-sm font-medium" style="color: #fed7aa;">
                            <i class="fas fa-tag mr-1"></i>
                            <?php echo e($contact->subject); ?>

                        </span>
                        <?php endif; ?>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2"><?php echo e($contact->name); ?></h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #fed7aa;">
                        <span>
                            <i class="fas fa-envelope mr-2"></i><?php echo e($contact->email); ?>

                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Received <?php echo e($contact->created_at->format('M d, Y')); ?>

                        </span>
                        <span>
                            <i class="fas fa-clock mr-2"></i><?php echo e($contact->created_at->diffForHumans()); ?>

                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="mailto:<?php echo e($contact->email); ?>" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-reply mr-2"></i>Reply
                    </a>
                    <a href="<?php echo e(route('admin.contacts.index')); ?>" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Contact Information -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-user mr-2 text-orange-600"></i>Contact Information
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <dl class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Full Name</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($contact->name); ?></p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email Address</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">
                                <a href="mailto:<?php echo e($contact->email); ?>" class="text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300"><?php echo e($contact->email); ?></a>
                            </p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Subject</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($contact->subject ?? 'No subject'); ?></p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($contact->is_read ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300' : 'bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300'); ?>">
                                <?php echo e($contact->is_read ? 'Read' : 'Unread'); ?>

                            </span>
                        </div>
                        <div class="md:col-span-2">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Received</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($contact->created_at->format('M d, Y \a\t g:i A')); ?></p>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Message Content -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-envelope-open mr-2 text-blue-600"></i>Message
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="bg-gray-50 dark:bg-gray-900 rounded-lg p-6 border-l-4 border-orange-500">
                        <div class="prose prose-sm max-w-none dark:prose-invert prose-p:text-gray-700 dark:text-gray-300">
                            <?php echo nl2br(e($contact->message)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Status Management -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-tasks mr-2 text-green-600"></i>Status Management
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <?php if(!$contact->is_read): ?>
                        <form method="POST" action="<?php echo e(route('admin.contacts.mark-read', $contact)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-3 rounded-lg font-semibold transition-colors duration-200">
                                <i class="fas fa-envelope-open mr-2"></i>Mark as Read
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-check-circle text-green-500 text-3xl mb-2"></i>
                            <p class="text-sm text-gray-600 dark:text-gray-400">This message has been read</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-bolt mr-2 text-yellow-600"></i>Quick Actions
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <a href="mailto:<?php echo e($contact->email); ?>" class="block px-4 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors duration-200">
                            <i class="fas fa-reply mr-3"></i>Reply to Sender
                        </a>
                    </div>
                    <div class="px-6 py-4">
                        <form method="POST" action="<?php echo e(route('admin.contacts.destroy', $contact)); ?>" onsubmit="return confirm('Are you sure you want to delete this contact message? This action cannot be undone.');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="w-full text-left px-4 py-3 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors duration-200">
                                <i class="fas fa-trash mr-3"></i>Delete Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Message Timeline -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-history mr-2 text-indigo-600"></i>Timeline
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Received</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($contact->created_at->format('M d, Y \a\t g:i A')); ?></p>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($contact->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($contact->updated_at->format('M d, Y \a\t g:i A')); ?></p>
                        <p class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($contact->updated_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/contacts/show.blade.php ENDPATH**/ ?>