

<?php $__env->startSection('title', 'Create Project'); ?>
<?php $__env->startSection('page-title', 'Create New Project'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r  from-blue-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-plus-circle mr-3"></i>Create New Project
                    </h1>
                    <p class="text-white">Showcase your work and achievements</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.projects.index')); ?>" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Projects
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="<?php echo e(route('admin.projects.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Essential details for your project</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Title -->
                    <div class="lg:col-span-2">
                        <label for="title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-heading mr-2 text-gray-500"></i>Project Title <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Enter an engaging project title" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Slug -->
                    <div class="lg:col-span-2">
                        <label for="slug" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-link mr-2 text-gray-500"></i>URL Slug <span class="text-red-500">*</span>
                        </label>
                        <div class="flex">
                            <span class="inline-flex items-center px-3 py-3 bg-gray-100 dark:bg-gray-800 border border-r-0 border-gray-300 dark:border-gray-600 rounded-l-lg text-gray-500 dark:text-gray-400 text-sm">
                                /projects/
                            </span>
                            <input type="text" name="slug" id="slug" value="<?php echo e(old('slug')); ?>"
                                   class="flex-1 px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-r-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="url-friendly-slug" required>
                        </div>
                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Description -->
                    <div class="lg:col-span-2">
                        <label for="description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-alt mr-2 text-gray-500"></i>Short Description
                        </label>
                        <textarea name="description" id="description" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Brief project summary"><?php echo e(old('description')); ?></textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Appears in project listings and previews
                        </p>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Project Content Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-edit mr-2 text-green-600"></i>Project Content
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Build your project details using content blocks</p>
            </div>
            <div class="px-6 py-6">
                <!-- Content Blocks -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-cubes mr-2 text-gray-500"></i>Content Blocks
                    </label>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">Build your project content using content blocks. Add headings, paragraphs, images, lists, and links.</p>

                    <div id="content_blocks_container" class="space-y-4">
                        <!-- Content blocks will be added here -->
                    </div>

                    <button type="button" id="add_content_block_btn" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 transition-all duration-200">
                        <i class="fas fa-plus mr-2"></i>
                        Add Content Block
                    </button>
                </div>
            </div>

            <!-- Project Details Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-cogs mr-2 text-purple-600"></i>Project Details
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Technical information and media</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Technologies -->
                    <div class="lg:col-span-2">
                        <label for="technologies" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-code mr-2 text-gray-500"></i>Technologies Used
                        </label>
                        <input type="text" name="technologies" id="technologies" value="<?php echo e(old('technologies')); ?>"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 <?php $__errorArgs = ['technologies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="e.g., PHP, Laravel, MySQL, React, Vue.js">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Comma-separated list of technologies, frameworks, and tools used
                        </p>
                        <?php $__errorArgs = ['technologies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                            </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Project Images -->
                    <div class="lg:col-span-2">
                        <div class="mb-4">
                            <label class="block text-base font-bold text-gray-900 dark:text-white mb-1">
                                <i class="fas fa-images mr-2 text-purple-600"></i>Project Images
                            </label>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Upload high-quality images to showcase your project's features and design</p>
                        </div>
                        <?php echo $__env->make('admin.media.multiple-picker', [
                            'fieldName' => 'media_ids',
                            'selectedMedia' => collect(),
                            'label' => '',
                            'help' => 'Select multiple images to showcase your project',
                            'required' => false,
                            'allowedTypes' => ['image'],
                            'previewSize' => 'w-32 h-24'
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>

            <!-- Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-cog mr-2 text-orange-600"></i>Project Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Configure how your project appears</p>
            </div>
            <div class="px-6 py-6">
                <!-- Status -->
                <div class="mb-6">
                    <label for="status" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                        <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Publication Status <span class="text-red-500">*</span>
                    </label>
                    <div class="flex items-center space-x-6">
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="active" <?php echo e(old('status') == 'active' ? 'checked' : ''); ?>

                                   class="form-radio h-5 w-5 text-green-600 focus:ring-green-500">
                            <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                <i class="fas fa-eye mr-1 text-green-600"></i>Active
                            </span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="inactive" <?php echo e(old('status') == 'inactive' ? 'checked' : ''); ?>

                                   class="form-radio h-5 w-5 text-red-600 focus:ring-red-500">
                            <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                <i class="fas fa-eye-slash mr-1 text-red-600"></i>Inactive
                            </span>
                        </label>
                    </div>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i><?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Make sure all required fields are filled before creating.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="<?php echo e(route('admin.projects.index')); ?>" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Create Project
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
let contentBlockIndex = 0;

// Add Content Block
function addContentBlock(type = 'paragraph', content = '', image = '') {
    const container = document.getElementById('content_blocks_container');
    const blockDiv = document.createElement('div');
    blockDiv.className = 'p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
    
    const escapedContent = content.replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/\n/g, '\\n');
    const escapedImage = image.replace(/'/g, "\\'");
    
    let blockContentHTML = getBlockContentHTML(type, contentBlockIndex, escapedContent, escapedImage);
    
    blockDiv.innerHTML = `
        <div class="flex gap-3">
            <div class="flex-1">
                <div class="mb-3">
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Block Type</label>
                    <select name="content_blocks[${contentBlockIndex}][type]" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" onchange="handleBlockTypeChange(this, ${contentBlockIndex})">
                        <option value="heading" ${type === 'heading' ? 'selected' : ''}>Heading</option>
                        <option value="paragraph" ${type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
                        <option value="image" ${type === 'image' ? 'selected' : ''}>Image</option>
                        <option value="list" ${type === 'list' ? 'selected' : ''}>Bullet List</option>
                        <option value="link" ${type === 'link' ? 'selected' : ''}>Link</option>
                    </select>
                </div>
                <div id="block_content_${contentBlockIndex}">
                    ${blockContentHTML}
                </div>
            </div>
            <button type="button" onclick="this.parentElement.parentElement.remove()" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50 h-fit">
                Remove
            </button>
        </div>
    `;
    
    container.appendChild(blockDiv);
    contentBlockIndex++;
}

// Get block content HTML based on type
function getBlockContentHTML(type, index, content = '', image = '') {
    const escapedContent = content.replace(/\\n/g, '\n');
    
    if (type === 'heading') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Heading Text</label>
            <input type="text" name="content_blocks[${index}][content]" value="${content}" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter heading text">
        `;
    } else if (type === 'paragraph') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Paragraph Text</label>
            <textarea name="content_blocks[${index}][content]" rows="4" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter paragraph text. Use **text** for bold, *text* for italic.">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Formatting: **bold**, *italic*</p>
        `;
    } else if (type === 'image') {
        const imagePreview = image ? 
            `<img src="/storage/${image}" alt="Block image" class="w-32 h-32 object-cover rounded border">` : 
            '<div class="w-32 h-32 bg-gray-200 dark:bg-gray-700 rounded border dark:border-gray-600 flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';
        
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
            <input type="hidden" name="content_blocks[${index}][image]" id="block_image_${index}" value="${image}">
            <div id="block_image_preview_${index}" class="mb-2">
                ${imagePreview}
            </div>
            <button type="button" onclick="openContentBlockMediaSelector('block_image_${index}', 'block_image_preview_${index}')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
            <input type="text" name="content_blocks[${index}][content]" value="${content}" class="mt-2 block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Image caption (optional)">
        `;
    } else if (type === 'list') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">List Items (one per line)</label>
            <textarea name="content_blocks[${index}][content]" rows="5" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter each list item on a new line">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Each line will be a bullet point</p>
        `;
    } else if (type === 'link') {
        const parts = content.split('|');
        const linkText = parts[0] || '';
        const linkUrl = parts[1] || '';
        
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Link Text</label>
            <input type="text" name="content_blocks[${index}][link_text]" value="${linkText}" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm mb-2" placeholder="Enter link text">
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Link URL</label>
            <input type="url" name="content_blocks[${index}][content]" value="${linkUrl}" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="https://example.com">
        `;
    }
}

// Handle block type change
function handleBlockTypeChange(select, index) {
    const type = select.value;
    const contentContainer = document.getElementById(`block_content_${index}`);
    contentContainer.innerHTML = getBlockContentHTML(type, index);
}

// Content block media selector function
function openContentBlockMediaSelector(fieldName, previewId) {
    window.currentMediaField = fieldName;
    window.currentMediaPreview = previewId;
    window.fieldId = fieldName;
    
    const selectorWindow = window.open('/admin/media-selector?type=image', 'Media Selector', 'width=1200,height=800,scrollbars=yes,resizable=yes');
    
    const messageHandler = function(event) {
        if (event.origin !== window.location.origin) return;
        
        if (event.data && event.data.type === 'MEDIA_SELECTED') {
            const media = event.data.media;
            const input = document.getElementById(fieldName);
            const preview = document.getElementById(previewId);
            
            if (input) {
                input.value = media.file_path || media.path || '';
            }
            
            if (preview) {
                preview.innerHTML = `<img src="${media.url}" alt="Selected image" class="w-32 h-32 object-cover rounded border">`;
            }
            
            selectorWindow.close();
            window.removeEventListener('message', messageHandler);
        }
    };
    
    window.addEventListener('message', messageHandler);
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    const addButton = document.getElementById('add_content_block_btn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            addContentBlock('paragraph');
        });
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/projects/create.blade.php ENDPATH**/ ?>