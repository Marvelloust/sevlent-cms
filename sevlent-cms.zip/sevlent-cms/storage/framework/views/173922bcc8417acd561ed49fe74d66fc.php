

<?php $__env->startSection('title', 'View Page'); ?>
<?php $__env->startSection('page-title', 'View Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($page->status === 'published' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'); ?>">
                            <i class="fas <?php echo e($page->status === 'published' ? 'fa-check-circle' : 'fa-clock'); ?> mr-1"></i>
                            <?php echo e(ucfirst($page->status)); ?>

                        </span>
                        <span class="ml-3 text-sm font-medium text-gray-300 dark:text-white">
                            <i class="fas fa-globe mr-1"></i>
                            <a href="<?php echo e(url('/' . $page->slug)); ?>" target="_blank" class="hover:text-white underline dark:text-gray-300">
                                View Live
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2"><?php echo e($page->title); ?></h1>
                    <div class="flex flex-wrap gap-6 text-gray-100 dark:text-gray-200 text-sm">
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Created <?php echo e($page->created_at->format('M d, Y')); ?>

                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated <?php echo e($page->updated_at->diffForHumans()); ?>

                        </span>
                        <span class="text-gray-100 dark:text-gray-200">
                            <i class="fas fa-link mr-2"></i><code class="bg-blue-500 bg-opacity-30 dark:bg-blue-800 dark:bg-opacity-30 text-gray-900 dark:text-white px-2 py-1 rounded"><?php echo e($page->slug); ?></code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.pages.sections.index', $page)); ?>" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-puzzle-piece mr-2"></i>Sections
                    </a>
                    <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-300 font-semibold rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700 transition-all duration-200">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="<?php echo e(route('admin.pages.index')); ?>" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Banner Image Preview -->
    <?php if($page->banner): ?>
        <div class="rounded-xl overflow-hidden shadow-lg">
            <img src="<?php echo e($page->banner->url); ?>" alt="Banner" class="w-full h-96 object-cover">
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content Preview -->
        <div class="lg:col-span-2">
            <!-- Content Section -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-file-alt mr-2 text-blue-600"></i>Page Content
                    </h3>
                </div>
                <div class="px-6 py-8">
                    <div class="prose prose-sm max-w-none prose-a:text-blue-600 prose-a:underline prose-img:rounded-lg prose-img:shadow-md text-gray-900 dark:text-gray-200 dark:prose-invert">
                        <?php echo $page->content; ?>

                    </div>
                </div>
            </div>

            <!-- Page Sections -->
            <?php if($page->sections && $page->sections->count() > 0): ?>
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-th-large mr-2 text-green-600"></i>Page Sections (<?php echo e($page->sections->count()); ?>)
                        </h3>
                    </div>
                    <div class="divide-y divide-gray-200 dark:divide-gray-700">
                        <?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="px-6 py-4 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors duration-200">
                                <div class="flex items-start justify-between mb-2">
                                    <h4 class="text-base font-semibold text-gray-900 dark:text-white"><?php echo e($section->title); ?></h4>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">
                                        <?php echo e($section->type); ?>

                                    </span>
                                </div>
                                <?php if($section->description): ?>
                                    <p class="text-sm text-gray-600 dark:text-gray-400"><?php echo e(Str::limit($section->description, 150)); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                        <a href="<?php echo e(route('admin.pages.sections.index', $page)); ?>" class="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-300 dark:hover:text-blue-400">
                            <i class="fas fa-arrow-right mr-1"></i>Manage Sections
                        </a>
                    </div>
                </div>
                <?php else: ?>
                <div class="mt-8 bg-blue-50 dark:bg-gray-900 rounded-xl border-2 border-blue-200 dark:border-gray-700 p-6">
                    <div class="flex">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-300 text-xl mr-4 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-blue-900 dark:text-white mb-1">No Sections Added</h4>
                            <p class="text-sm text-blue-800 dark:text-gray-300">This page doesn't have any sections yet. 
                                <a href="<?php echo e(route('admin.pages.sections.index', $page)); ?>" class="font-semibold hover:underline dark:text-blue-300">Add sections</a> to build out your page.
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar: Metadata -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Basic Info Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>Page Info
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($page->status === 'published' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'); ?>">
                            <?php echo e(ucfirst($page->status)); ?>

                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">URL Slug</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-gray-800 dark:text-white break-all"><?php echo e($page->slug); ?></code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Created</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($page->created_at->format('M d, Y H:i')); ?></p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300"><?php echo e($page->updated_at->format('M d, Y H:i')); ?></p>
                    </div>
                </div>
            </div>

            <!-- SEO Metadata Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-search mr-2 text-purple-600"></i>SEO Metadata
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <?php if($page->seo?->meta_title): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Title</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-blue-50 dark:bg-gray-900 p-2 rounded border-l-2 border-blue-500 dark:border-blue-700">
                                <?php echo e($page->seo->meta_title); ?>

                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium"><?php echo e(strlen($page->seo->meta_title)); ?></span> characters
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta title set</p>
                        </div>
                    <?php endif; ?>

                    <?php if($page->seo?->meta_description): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Description</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-green-50 dark:bg-gray-900 p-2 rounded border-l-2 border-green-500 dark:border-green-700 leading-relaxed">
                                <?php echo e($page->seo->meta_description); ?>

                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium"><?php echo e(strlen($page->seo->meta_description)); ?></span> characters
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta description set</p>
                        </div>
                    <?php endif; ?>

                    <?php if($page->seo?->meta_keywords): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Keywords</p>
                            <div class="flex flex-wrap gap-2">
                                <?php $__currentLoopData = explode(',', $page->seo->meta_keywords); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100 text-xs font-semibold rounded-full">
                                        <?php echo e(trim($keyword)); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($page->seo?->canonical_url): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Canonical URL</p>
                            <a href="<?php echo e($page->seo->canonical_url); ?>" target="_blank" class="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-300 dark:hover:text-blue-400 break-all">
                                <?php echo e($page->seo->canonical_url); ?>

                                <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                    <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="text-sm font-medium text-purple-600 hover:text-purple-700 dark:text-purple-300 dark:hover:text-purple-400">
                        <i class="fas fa-edit mr-1"></i>Edit SEO
                    </a>
                </div>
            </div>

            <!-- Social Sharing Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Sharing
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <?php if($page->seo?->og_title): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Title</p>
                            <p class="text-sm text-gray-800 dark:text-white"><?php echo e($page->seo->og_title); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($page->seo?->og_description): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Description</p>
                            <p class="text-sm text-gray-800 dark:text-white"><?php echo e($page->seo->og_description); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($page->seo?->ogImage): ?>
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Image</p>
                            <img src="<?php echo e(asset('storage/' . $page->seo->ogImage->file_path)); ?>" alt="OG" class="w-full h-32 object-cover rounded">
                        </div>
                    <?php endif; ?>

                    <?php if(!$page->seo?->og_title && !$page->seo?->og_description && !$page->seo?->ogImage): ?>
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-share-alt mr-2"></i>No OG data configured</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/pages/show.blade.php ENDPATH**/ ?>