<!-- Sidebar -->
<div class="fixed inset-y-0 left-0 z-50 flex" :class="sidebarOpen ? 'block' : 'hidden md:block'" :style="sidebarCollapsed && window.innerWidth >= 768 ? 'width: 4rem' : 'width: 16rem'">
    <div class="flex flex-col w-full h-full bg-white dark:bg-gradient-to-b dark:from-slate-800 dark:via-slate-900 dark:to-slate-900 shadow-xl transition-all duration-300 ease-in-out" :class="sidebarCollapsed ? 'md:w-16' : 'md:w-64'">
        <!-- Logo -->
        <div class="flex items-center h-16 px-4 bg-gradient-to-r from-blue-500 to-purple-600" :class="sidebarCollapsed ? 'md:px-2' : 'md:px-4'">
            <div class="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                <i class="fas fa-cogs text-white text-sm"></i>
            </div>
            <div class="ml-3" :class="sidebarCollapsed ? 'md:hidden' : ''">
                <p class="text-base font-semibold text-white">Sevlent CMS</p>
                <p class="text-xs text-white">Admin Panel</p>
            </div>
            
        </div>

        <!-- Navigation -->
        <div class="flex-1 flex flex-col overflow-y-auto sidebar-scrollbar">
            <nav class="flex-1 px-2 py-4 space-y-1">
                <!-- Dashboard -->
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                   class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                    <i class="fas fa-tachometer-alt text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                    <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Dashboard</span>
                </a>

                <!-- Analytics -->
                <a href="<?php echo e(route('admin.analytics.index')); ?>"
                   class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.analytics.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                    <i class="fas fa-chart-line text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                    <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Analytics</span>
                </a>

                <!-- Content Management -->
                <div class="space-y-1">
                    <div :class="sidebarCollapsed ? 'md:px-1 md:text-center' : 'md:px-3'" class="px-3 py-2 text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider transition-all duration-300">
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''">Content</span>
                    </div>

                    <a href="<?php echo e(route('admin.pages.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.pages.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-file-alt text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Pages</span>
                    </a>

                    

                    <a href="<?php echo e(route('admin.services.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.services.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-concierge-bell text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Services</span>
                    </a>

                    <a href="<?php echo e(route('admin.blogs.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.blogs.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-blog text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Blog Posts</span>
                    </a>

                    <a href="<?php echo e(route('admin.blog-categories.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.blog-categories.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-tags text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Blog Categories</span>
                    </a>

                    <a href="<?php echo e(route('admin.blog-tags.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.blog-tags.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-hashtag text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Blog Tags</span>
                    </a>

                    <a href="<?php echo e(route('admin.service-categories.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.service-categories.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-folder text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Service Categories</span>
                    </a>

                    <a href="<?php echo e(route('admin.projects.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.projects.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-project-diagram text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Projects</span>
                    </a>

                    <a href="<?php echo e(route('admin.media.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.media.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-images text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Media</span>
                    </a>

                    <a href="<?php echo e(route('admin.menus.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.menus.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-bars text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Menus</span>
                    </a>
                </div>

                <!-- System Management -->
                <?php if(auth()->user()->hasRole('super_admin')): ?>
                <div class="space-y-1">
                    <div :class="sidebarCollapsed ? 'md:px-1 md:text-center' : 'md:px-3'" class="px-3 py-2 text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wider transition-all duration-300">
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''">System</span>
                    </div>

                    <a href="<?php echo e(route('admin.users.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.users.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-users text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Users</span>
                    </a>

                    <a href="<?php echo e(route('admin.settings.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.settings.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-cog text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Settings</span>
                    </a>

                    <a href="<?php echo e(route('admin.careers.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.careers.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-briefcase text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Careers</span>
                    </a>

                    <a href="<?php echo e(route('admin.job-applications.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.job-applications.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-file-alt text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Job Applications</span>
                    </a>

                    <a href="<?php echo e(route('admin.contacts.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.contacts.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-envelope text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Contacts</span>
                    </a>

                    <a href="<?php echo e(route('admin.activities.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.activities.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-history text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Activities</span>
                    </a>

                    <a href="<?php echo e(route('admin.contact-settings.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.contact-settings.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-map-marker-alt text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">Contact Settings</span>
                    </a>

                    <a href="<?php echo e(route('admin.faqs.index')); ?>"
                       class="group flex items-center px-3 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('admin.faqs.*') ? 'bg-blue-100 dark:bg-slate-700 text-blue-700 dark:text-white' : 'text-gray-700 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-gray-900 dark:hover:text-white'); ?> transition-all duration-200" :class="sidebarCollapsed ? 'justify-center px-2' : ''">
                        <i class="fas fa-question-circle text-gray-500 dark:text-slate-400 group-hover:text-gray-700 dark:group-hover:text-slate-300" :class="sidebarCollapsed ? 'mr-0' : 'mr-3'"></i>
                        <span :class="sidebarCollapsed ? 'md:hidden' : ''" class="transition-all duration-300">FAQs</span>
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</div><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>