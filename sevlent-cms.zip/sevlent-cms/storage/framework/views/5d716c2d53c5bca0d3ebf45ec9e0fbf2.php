

<?php $__env->startSection('title', 'Service Categories'); ?>
<?php $__env->startSection('page-title', 'Manage Service Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-blue-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-folder-open mr-3"></i>Service Categories Management
                    </h1>
                    <p class="text-white">Organize and manage your service categories</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.service-categories.create')); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-indigo-600 font-semibold rounded-lg shadow-md hover:bg-indigo-50 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Create New Category
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-indigo-500">
            <div class="flex items-center">
                <div class="p-3 bg-indigo-100 rounded-full">
                    <i class="fas fa-folder-open text-indigo-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Categories</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($totalCategories); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 rounded-full">
                    <i class="fas fa-check-circle text-green-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active Categories</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($activeCategories); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-red-500">
            <div class="flex items-center">
                <div class="p-3 bg-red-100 rounded-full">
                    <i class="fas fa-times-circle text-red-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Inactive Categories</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($inactiveCategories); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 rounded-full">
                    <i class="fas fa-cogs text-blue-600 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">With Services</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($categoriesWithServices); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Categories Table -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Filters Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <form method="GET" action="<?php echo e(route('admin.service-categories.index')); ?>" class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div class="flex flex-col sm:flex-row gap-4 flex-1">
                    <!-- Search -->
                    <div class="flex-1">
                        <label for="search" class="sr-only">Search categories</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                                   class="block w-full pl-10 pr-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                                   placeholder="Search categories...">
                        </div>
                    </div>

                    <!-- Status Filter -->
                    <div class="w-full sm:w-40">
                        <label for="status" class="sr-only">Filter by status</label>
                        <select name="status" id="status"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('status') === 'all' || !request('status') ? 'selected' : ''); ?>>All Status</option>
                            <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>

                    <!-- Sort Options -->
                    <div class="w-full sm:w-48">
                        <label for="sort_by" class="sr-only">Sort by</label>
                        <select name="sort_by" id="sort_by"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="name" <?php echo e(request('sort_by') === 'name' || !request('sort_by') ? 'selected' : ''); ?>>Name</option>
                            <option value="slug" <?php echo e(request('sort_by') === 'slug' ? 'selected' : ''); ?>>Slug</option>
                            <option value="status" <?php echo e(request('sort_by') === 'status' ? 'selected' : ''); ?>>Status</option>
                            <option value="services_count" <?php echo e(request('sort_by') === 'services_count' ? 'selected' : ''); ?>>Service Count</option>
                            <option value="created_at" <?php echo e(request('sort_by') === 'created_at' ? 'selected' : ''); ?>>Created Date</option>
                            <option value="updated_at" <?php echo e(request('sort_by') === 'updated_at' ? 'selected' : ''); ?>>Updated Date</option>
                        </select>
                    </div>

                    <!-- Sort Direction -->
                    <div class="w-full sm:w-32">
                        <label for="sort_direction" class="sr-only">Sort direction</label>
                        <select name="sort_direction" id="sort_direction"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="asc" <?php echo e(request('sort_direction') === 'asc' || !request('sort_direction') ? 'selected' : ''); ?>>Ascending</option>
                            <option value="desc" <?php echo e(request('sort_direction') === 'desc' ? 'selected' : ''); ?>>Descending</option>
                        </select>
                    </div>
                </div>

                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.service-categories.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-times mr-2"></i>Clear
                    </a>
                </div>
            </form>
        </div>

        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600"></i>All Categories
                    <?php if(request('search') || request('status') !== 'all' && request('status')): ?>
                        <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                            (<?php echo e($categories->total()); ?> result<?php echo e($categories->total() !== 1 ? 's' : ''); ?>)
                        </span>
                    <?php endif; ?>
                </h3>
                <?php if(request('search') || request('status') !== 'all' && request('status')): ?>
                    <div class="mt-2 sm:mt-0 flex flex-wrap gap-2">
                        <?php if(request('search')): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
                                Search: "<?php echo e(request('search')); ?>"
                                <a href="<?php echo e(request()->fullUrlWithQuery(['search' => null])); ?>" class="ml-1 text-indigo-600 dark:text-indigo-300 hover:text-indigo-800 dark:hover:text-indigo-100">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('status') && request('status') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200">
                                Status: <?php echo e(ucfirst(request('status'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => null])); ?>" class="ml-1 text-green-600 dark:text-green-300 hover:text-green-800 dark:hover:text-green-100">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-900">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-folder-open mr-2"></i>Name
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-link mr-2"></i>Slug
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-info-circle mr-2"></i>Status
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Service Count
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Created
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-10 h-10 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-full flex items-center justify-center">
                                        <i class="fas fa-folder-open text-white text-sm"></i>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900 dark:text-white"><?php echo e($category->name); ?></div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400">ID: <?php echo e($category->id); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                                <code class="bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white px-2 py-1 rounded text-xs"><?php echo e($category->slug); ?></code>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($category->status === 'active' ? 'bg-green-100 dark:bg-green-200 text-green-800 dark:text-green-200 border border-green-200 dark:border-green-800' : 'bg-red-100 dark:bg-red-200 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-800'); ?>">
                                    <i class="fas <?php echo e($category->status === 'active' ? 'fa-check-circle' : 'fa-times-circle'); ?> mr-1"></i>
                                    <?php echo e(ucfirst($category->status)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($category->services_count > 0 ? 'bg-blue-100 dark:bg-blue-200 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800' : 'bg-gray-100 dark:bg-gray-200 text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-600'); ?>">
                                    <i class="fas <?php echo e($category->services_count > 0 ? 'fa-cogs' : 'fa-inbox'); ?> mr-1"></i>
                                    <?php echo e($category->services_count); ?> service<?php echo e($category->services_count !== 1 ? 's' : ''); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                                <?php echo e($category->created_at->format('M d, Y')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.service-categories.edit', $category)); ?>" class="inline-flex items-center px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 transition-colors duration-150">
                                        <i class="fas fa-edit mr-1"></i>Edit
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.service-categories.destroy', $category)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="inline-flex items-center px-3 py-1 bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors duration-150"
                                                onclick="showDeleteConfirmation('Are you sure you want to delete this category? This action cannot be undone.', () => { this.closest('form').submit(); })"
                                                <?php echo e($category->services_count > 0 ? 'disabled class="opacity-50 cursor-not-allowed"' : ''); ?>>
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <i class="fas fa-folder-open text-gray-300 dark:text-gray-600 text-4xl mb-4"></i>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No categories found</h3>
                                    <p class="text-gray-500 dark:text-gray-400 mb-4">
                                        <?php if(request('search') || request('status') !== 'all' && request('status')): ?>
                                            No categories match your current filters. Try adjusting your search criteria.
                                        <?php else: ?>
                                            Get started by creating your first service category.
                                        <?php endif; ?>
                                    </p>
                                    <?php if(!request('search') && (!request('status') || request('status') === 'all')): ?>
                                        <a href="<?php echo e(route('admin.service-categories.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-150">
                                            <i class="fas fa-plus mr-2"></i>Create Your First Category
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.service-categories.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-150">
                                            <i class="fas fa-times mr-2"></i>Clear Filters
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if($categories->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            Showing <span class="font-medium"><?php echo e($categories->firstItem()); ?></span> to
                            <span class="font-medium"><?php echo e($categories->lastItem()); ?></span> of
                            <span class="font-medium"><?php echo e($categories->total()); ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-1">
                        
                        <?php if($categories->onFirstPage()): ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-l-lg">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($categories->previousPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-l-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </a>
                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $categories->getUrlRange(1, $categories->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $categories->currentPage()): ?>
                                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-indigo-600 cursor-default">
                                    <?php echo e($page); ?>

                                </span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                    <?php echo e($page); ?>

                                </a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($categories->hasMorePages()): ?>
                            <a href="<?php echo e($categories->nextPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-r-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-r-lg">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50" id="success-message">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('success-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50" id="error-message">
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-2"></i>
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('error-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/service-categories/index.blade.php ENDPATH**/ ?>