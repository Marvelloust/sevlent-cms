

<?php $__env->startSection('title', 'Contacts'); ?>
<?php $__env->startSection('page-title', 'Manage Contacts'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-envelope mr-3"></i>Contacts Management
                    </h1>
                    <p class="text-white">Manage and respond to contact form submissions</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="<?php echo e(route('admin.contacts.export', request()->query())); ?>" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-indigo-600 font-semibold rounded-lg shadow-md hover:bg-indigo-50 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-download mr-2"></i>
                        Export CSV
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <i class="fas fa-envelope text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Contacts</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($totalContacts); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-red-500">
            <div class="flex items-center">
                <div class="p-3 bg-red-100 dark:bg-red-900 rounded-full">
                    <i class="fas fa-envelope-open text-red-600 dark:text-red-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Unread</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($unreadContacts); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <i class="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Read</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($readContacts); ?></p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-full">
                    <i class="fas fa-calendar-day text-yellow-600 dark:text-yellow-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Today</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white"><?php echo e($todayContacts); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Contacts Table -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Filters Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <form method="GET" action="<?php echo e(route('admin.contacts.index')); ?>" class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div class="flex flex-col sm:flex-row gap-4 flex-1">
                    <!-- Search -->
                    <div class="flex-1">
                        <label for="search" class="sr-only">Search contacts</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" name="search" id="search" value="<?php echo e(request('search')); ?>"
                                   class="block w-full pl-10 pr-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                   placeholder="Search by name, email, subject...">
                        </div>
                    </div>

                    <!-- Status Filter -->
                    <div class="w-full sm:w-40">
                        <label for="status" class="sr-only">Filter by status</label>
                        <select name="status" id="status"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="all" <?php echo e(request('status') === 'all' || !request('status') ? 'selected' : ''); ?>>All Status</option>
                            <option value="unread" <?php echo e(request('status') === 'unread' ? 'selected' : ''); ?>>Unread</option>
                            <option value="read" <?php echo e(request('status') === 'read' ? 'selected' : ''); ?>>Read</option>
                        </select>
                    </div>

                    <!-- Sort Options -->
                    <div class="w-full sm:w-48">
                        <label for="sort_by" class="sr-only">Sort by</label>
                        <select name="sort_by" id="sort_by"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="created_at" <?php echo e(request('sort_by') === 'created_at' || !request('sort_by') ? 'selected' : ''); ?>>Submitted Date</option>
                            <option value="name" <?php echo e(request('sort_by') === 'name' ? 'selected' : ''); ?>>Name</option>
                            <option value="email" <?php echo e(request('sort_by') === 'email' ? 'selected' : ''); ?>>Email</option>
                            <option value="subject" <?php echo e(request('sort_by') === 'subject' ? 'selected' : ''); ?>>Subject</option>
                            <option value="is_read" <?php echo e(request('sort_by') === 'is_read' ? 'selected' : ''); ?>>Status</option>
                            <option value="updated_at" <?php echo e(request('sort_by') === 'updated_at' ? 'selected' : ''); ?>>Updated Date</option>
                        </select>
                    </div>

                    <!-- Sort Direction -->
                    <div class="w-full sm:w-32">
                        <label for="sort_direction" class="sr-only">Sort direction</label>
                        <select name="sort_direction" id="sort_direction"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm py-2 px-3">
                            <option value="desc" <?php echo e(request('sort_direction') === 'desc' || !request('sort_direction') ? 'selected' : ''); ?>>Descending</option>
                            <option value="asc" <?php echo e(request('sort_direction') === 'asc' ? 'selected' : ''); ?>>Ascending</option>
                        </select>
                    </div>
                </div>

                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.contacts.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-times mr-2"></i>Clear
                    </a>
                </div>
            </form>
        </div>

        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-list mr-2 text-gray-600 dark:text-gray-400"></i>All Contact Submissions
                    <?php if(request('search') || request('status') !== 'all' && request('status')): ?>
                        <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                            (<?php echo e($contacts->total()); ?> result<?php echo e($contacts->total() !== 1 ? 's' : ''); ?>)
                        </span>
                    <?php endif; ?>
                </h3>
                <?php if(request('search') || request('status') && request('status') !== 'all'): ?>
                    <div class="mt-2 sm:mt-0 flex flex-wrap gap-2">
                        <?php if(request('search')): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-300">
                                Search: "<?php echo e(request('search')); ?>"
                                <a href="<?php echo e(request()->fullUrlWithQuery(['search' => null])); ?>" class="ml-1 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                        <?php if(request('status') && request('status') !== 'all'): ?>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300">
                                Status: <?php echo e(ucfirst(request('status'))); ?>

                                <a href="<?php echo e(request()->fullUrlWithQuery(['status' => null])); ?>" class="ml-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50 dark:bg-gray-900">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-user mr-2"></i>Contact & Details
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-envelope mr-2"></i>Subject & Message
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-info-circle mr-2"></i>Status
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Submitted
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150 <?php echo e(!$contact->is_read ? 'bg-blue-50 dark:bg-blue-900/10' : ''); ?>">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-12 h-12">
                                        <div class="w-12 h-12 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center">
                                            <span class="text-sm font-bold text-white"><?php echo e(substr($contact->name, 0, 1)); ?></span>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900 dark:text-white"><?php echo e($contact->name); ?></div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($contact->email); ?></div>
                                        <?php if($contact->phone): ?>
                                            <div class="text-xs text-gray-400">
                                                <i class="fas fa-phone mr-1"></i><?php echo e($contact->phone); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="space-y-2">
                                    <div class="text-sm font-medium text-gray-900 dark:text-white"><?php echo e($contact->subject); ?></div>
                                    <div class="text-sm text-gray-600 dark:text-gray-400 line-clamp-2"><?php echo e(Str::limit($contact->message, 100)); ?></div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold <?php echo e($contact->is_read ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 border border-green-200 dark:border-green-800' : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300 border border-red-200 dark:border-red-800'); ?>">
                                    <i class="fas <?php echo e($contact->is_read ? 'fa-check-circle' : 'fa-envelope'); ?> mr-1"></i>
                                    <?php echo e($contact->is_read ? 'Read' : 'Unread'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                                <?php echo e($contact->created_at->format('M d, Y')); ?>

                                <div class="text-xs text-gray-400"><?php echo e($contact->created_at->format('H:i')); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.contacts.show', $contact)); ?>" class="inline-flex items-center px-3 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-200 dark:hover:bg-blue-900/40 transition-colors duration-150">
                                        <i class="fas fa-eye mr-1"></i>View
                                    </a>
                                    <?php if(!$contact->is_read): ?>
                                        <form method="POST" action="<?php echo e(route('admin.contacts.mark-read', $contact)); ?>" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="inline-flex items-center px-3 py-1 bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-md hover:bg-green-200 dark:hover:bg-green-900/40 transition-colors duration-150">
                                                <i class="fas fa-check mr-1"></i>Mark Read
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="POST" action="<?php echo e(route('admin.contacts.destroy', $contact)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="inline-flex items-center px-3 py-1 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded-md hover:bg-red-200 dark:hover:bg-red-900/40 transition-colors duration-150" onclick="showDeleteConfirmation('Are you sure you want to delete this contact submission? This action cannot be undone.', () => { this.closest('form').submit(); })">
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <i class="fas fa-envelope text-gray-300 text-4xl mb-4"></i>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No contact submissions found</h3>
                                    <p class="text-gray-500 dark:text-gray-400 mb-4">
                                        <?php if(request('search') || request('status') !== 'all' && request('status')): ?>
                                            No contact submissions match your current filters. Try adjusting your search criteria.
                                        <?php else: ?>
                                            No contact form submissions have been received yet. Contact submissions will appear here when visitors use your contact form.
                                        <?php endif; ?>
                                    </p>
                                    <?php if(!request('search') && (!request('status') || request('status') === 'all')): ?>
                                        <div class="text-sm text-gray-400">
                                            <i class="fas fa-info-circle mr-1"></i>Check your website's contact form to ensure it's properly configured.
                                        </div>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.contacts.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-150">
                                            <i class="fas fa-times mr-2"></i>Clear Filters
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if($contacts->hasPages()): ?>
            <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700 dark:text-gray-300">
                            Showing <span class="font-medium"><?php echo e($contacts->firstItem()); ?></span> to
                            <span class="font-medium"><?php echo e($contacts->lastItem()); ?></span> of
                            <span class="font-medium"><?php echo e($contacts->total()); ?></span> results
                        </p>
                    </div>
                    <div class="flex space-x-1">
                        
                        <?php if($contacts->onFirstPage()): ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-l-lg">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($contacts->previousPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-l-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </a>
                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $contacts->getUrlRange(1, $contacts->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $contacts->currentPage()): ?>
                                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-indigo-600 cursor-default">
                                    <?php echo e($page); ?>

                                </span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                    <?php echo e($page); ?>

                                </a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($contacts->hasMorePages()): ?>
                            <a href="<?php echo e($contacts->nextPageUrl()); ?>" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-r-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        <?php else: ?>
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-r-lg">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50" id="success-message">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('success-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50" id="error-message">
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-2"></i>
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('error-message').style.display = 'none';
        }, 5000);
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\omole\Documents\sevlent-cms\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>