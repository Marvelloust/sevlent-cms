{{-- @props(['type' => 'dots', 'opacity' => '0.1', 'color' => 'white', 'size' => '40'])

@php
    $patterns = [
        'dots' => [
            'background-image' => "radial-gradient(circle at 1px 1px, rgba(255,255,255,{$opacity}) 1px, transparent 0)",
            'background-size' => "{$size}px {$size}px"
        ],
        'grid' => [
            'background-image' => "
                linear-gradient(rgba(255,255,255,{$opacity}) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,{$opacity}) 1px, transparent 1px)
            ",
            'background-size' => "{$size}px {$size}px"
        ],
        'diagonal' => [
            'background-image' => "repeating-linear-gradient(
                45deg,
                rgba(255,255,255,{$opacity}),
                rgba(255,255,255,{$opacity}) 1px,
                transparent 1px,
                transparent {$size}px
            )"
        ],
        'stripes' => [
            'background-image' => "repeating-linear-gradient(
                90deg,
                rgba(255,255,255,{$opacity}),
                rgba(255,255,255,{$opacity}) 2px,
                transparent 2px,
                transparent {$size}px
            )"
        ],
        'hexagons' => [
            'background-image' => "
                radial-gradient(circle at 25px 25px, rgba(255,255,255,{$opacity}) 2px, transparent 2px),
                radial-gradient(circle at 75px 75px, rgba(255,255,255,{$opacity}) 2px, transparent 2px)
            ",
            'background-size' => "100px 100px"
        ],
        'waves' => [
            'background-image' => "
                radial-gradient(ellipse at top, rgba(255,255,255,{$opacity}) 0%, transparent 50%),
                radial-gradient(ellipse at bottom, rgba(255,255,255,{$opacity}) 0%, transparent 50%)
            ",
            'background-size' => "200px 100px, 200px 100px",
            'background-position' => "0 0, 0 100px"
        ],
        'crosses' => [
            'background-image' => "
                linear-gradient(rgba(255,255,255,{$opacity}) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,{$opacity}) 1px, transparent 1px),
                linear-gradient(rgba(255,255,255,{$opacity}) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,{$opacity}) 1px, transparent 1px)
            ",
            'background-size' => "{$size}px {$size}px, {$size}px {$size}px, {$size}px {$size}px, {$size}px {$size}px",
            'background-position' => "0 0, 0 0, {$size/2}px {$size/2}px, {$size/2}px {$size/2}px"
        ]
    ];

    $pattern = $patterns[$type] ?? $patterns['dots'];
@endphp

<div class="absolute inset-0" style="{{ collect($pattern)->map(fn($value, $key) => $key . ':' . $value)->join(';') }}"></div> --}}