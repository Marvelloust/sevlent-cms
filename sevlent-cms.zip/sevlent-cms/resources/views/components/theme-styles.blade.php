{{--
    Theme Styles Component
    
    This component generates CSS custom properties based on the theme colors
    set in the admin settings. It provides a consistent color scheme across
    the entire frontend.
--}}

@php
    // Get theme colors from settings with defaults
    $primaryColor = setting('primary_color', '#3b82f6'); // Default: Blue
    $secondaryColor = setting('secondary_color', '#8b5cf6'); // Default: Purple
    $accentColor = setting('accent_color', '#10b981'); // Default: Green

    // Helper function to convert hex to RGB
    function hexToRgb($hex) {
        $hex = ltrim($hex, '#');
        return [
            'r' => hexdec(substr($hex, 0, 2)),
            'g' => hexdec(substr($hex, 2, 2)),
            'b' => hexdec(substr($hex, 4, 2))
        ];
    }

    // Helper function to adjust color brightness
    function adjustBrightness($hex, $percent) {
        $rgb = hexToRgb($hex);
        $r = max(0, min(255, $rgb['r'] + ($rgb['r'] * $percent / 100)));
        $g = max(0, min(255, $rgb['g'] + ($rgb['g'] * $percent / 100)));
        $b = max(0, min(255, $rgb['b'] + ($rgb['b'] * $percent / 100)));
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }

    // Generate color variations
    $primaryRgb = hexToRgb($primaryColor);
    $secondaryRgb = hexToRgb($secondaryColor);
    $accentRgb = hexToRgb($accentColor);

    // Lighter and darker variations
    $primaryLight = adjustBrightness($primaryColor, 30);
    $primaryDark = adjustBrightness($primaryColor, -20);
    $secondaryLight = adjustBrightness($secondaryColor, 30);
    $secondaryDark = adjustBrightness($secondaryColor, -20);
    $accentLight = adjustBrightness($accentColor, 30);
    $accentDark = adjustBrightness($accentColor, -20);
    
    // Cache busting - force browser to reload when colors change
    $colorHash = md5($primaryColor . $secondaryColor . $accentColor);
    $timestamp = time(); // Add timestamp for aggressive cache busting
@endphp

<style id="theme-styles-{{ $colorHash }}" data-theme-hash="{{ $colorHash }}" data-timestamp="{{ $timestamp }}">
    /* Theme Colors Updated: {{ date('Y-m-d H:i:s') }} */
    /* Hash: {{ $colorHash }} | Timestamp: {{ $timestamp }} */
    /* Primary: {{ $primaryColor }} | Secondary: {{ $secondaryColor }} | Accent: {{ $accentColor }} */
    
    :root {
        /* Primary Color Variables */
        --color-primary: {{ $primaryColor }};
        --color-primary-rgb: {{ $primaryRgb['r'] }}, {{ $primaryRgb['g'] }}, {{ $primaryRgb['b'] }};
        --color-primary-light: {{ $primaryLight }};
        --color-primary-dark: {{ $primaryDark }};

        /* Secondary Color Variables */
        --color-secondary: {{ $secondaryColor }};
        --color-secondary-rgb: {{ $secondaryRgb['r'] }}, {{ $secondaryRgb['g'] }}, {{ $secondaryRgb['b'] }};
        --color-secondary-light: {{ $secondaryLight }};
        --color-secondary-dark: {{ $secondaryDark }};

        /* Accent Color Variables */
        --color-accent: {{ $accentColor }};
        --color-accent-rgb: {{ $accentRgb['r'] }}, {{ $accentRgb['g'] }}, {{ $accentRgb['b'] }};
        --color-accent-light: {{ $accentLight }};
        --color-accent-dark: {{ $accentDark }};
    }

    /* Theme-based utility classes */
    .bg-theme-primary {
        background-color: var(--color-primary) !important;
    }

    .bg-theme-primary-light {
        background-color: var(--color-primary-light) !important;
    }

    .bg-theme-primary-dark {
        background-color: var(--color-primary-dark) !important;
    }

    .bg-theme-secondary {
        background-color: var(--color-secondary) !important;
    }

    .bg-theme-secondary-light {
        background-color: var(--color-secondary-light) !important;
    }

    .bg-theme-secondary-dark {
        background-color: var(--color-secondary-dark) !important;
    }

    .bg-theme-accent {
        background-color: var(--color-accent) !important;
    }

    .bg-theme-accent-light {
        background-color: var(--color-accent-light) !important;
    }

    .bg-theme-accent-dark {
        background-color: var(--color-accent-dark) !important;
    }

    .text-theme-primary {
        color: var(--color-primary) !important;
    }

    .text-theme-secondary {
        color: var(--color-secondary) !important;
    }

    .text-theme-accent {
        color: var(--color-accent) !important;
    }

    .border-theme-primary {
        border-color: var(--color-primary) !important;
    }

    .border-theme-secondary {
        border-color: var(--color-secondary) !important;
    }

    .border-theme-accent {
        border-color: var(--color-accent) !important;
    }

    /* Hover variants */
    .hover\:bg-theme-primary:hover {
        background-color: var(--color-primary) !important;
    }

    .hover\:bg-theme-primary-dark:hover {
        background-color: var(--color-primary-dark) !important;
    }

    .hover\:bg-theme-secondary:hover {
        background-color: var(--color-secondary) !important;
    }

    .hover\:bg-theme-secondary-dark:hover {
        background-color: var(--color-secondary-dark) !important;
    }

    .hover\:text-theme-primary:hover {
        color: var(--color-primary) !important;
    }

    .hover\:text-theme-primary-dark:hover {
        color: var(--color-primary-dark) !important;
    }

    .hover\:text-theme-secondary:hover {
        color: var(--color-secondary) !important;
    }

    /* Gradient backgrounds */
    .bg-theme-gradient {
        background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-secondary) 100%) !important;
    }

    .bg-theme-gradient-reverse {
        background: linear-gradient(135deg, var(--color-secondary) 0%, var(--color-primary) 100%) !important;
    }

    /* ===============================================
       COMPREHENSIVE COLOR OVERRIDES FOR UNIFORMITY
       All colors map to theme colors for consistency
    =============================================== */

    /* BLUE & INDIGO → PRIMARY */
    .bg-blue-50, .bg-indigo-50 { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    .bg-blue-100, .bg-indigo-100 { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .bg-blue-200, .bg-indigo-200 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .bg-blue-300, .bg-indigo-300 { background-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .bg-blue-400, .bg-indigo-400 { background-color: var(--color-primary-light) !important; }
    .bg-blue-500, .bg-indigo-500 { background-color: var(--color-primary) !important; }
    .bg-blue-600, .bg-indigo-600 { background-color: var(--color-primary) !important; }
    .bg-blue-700, .bg-indigo-700 { background-color: var(--color-primary-dark) !important; }
    .bg-blue-800, .bg-indigo-800 { background-color: var(--color-primary-dark) !important; }
    .bg-blue-900, .bg-indigo-900 { background-color: var(--color-primary-dark) !important; }

    .text-blue-50, .text-indigo-50 { color: var(--color-primary-light) !important; }
    .text-blue-100, .text-indigo-100 { color: var(--color-primary-light) !important; }
    .text-blue-400, .text-indigo-400 { color: var(--color-primary-light) !important; }
    .text-blue-500, .text-indigo-500 { color: var(--color-primary) !important; }
    .text-blue-600, .text-indigo-600 { color: var(--color-primary) !important; }
    .text-blue-700, .text-indigo-700 { color: var(--color-primary-dark) !important; }
    .text-blue-800, .text-indigo-800 { color: var(--color-primary-dark) !important; }

    .border-blue-200, .border-indigo-200 { border-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .border-blue-300, .border-indigo-300 { border-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .border-blue-500, .border-indigo-500 { border-color: var(--color-primary) !important; }
    .border-blue-600, .border-indigo-600 { border-color: var(--color-primary) !important; }

    /* PURPLE & VIOLET → SECONDARY */
    .bg-purple-50, .bg-violet-50 { background-color: rgba(var(--color-secondary-rgb), 0.05) !important; }
    .bg-purple-100, .bg-violet-100 { background-color: rgba(var(--color-secondary-rgb), 0.1) !important; }
    .bg-purple-200, .bg-violet-200 { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .bg-purple-400, .bg-violet-400 { background-color: var(--color-secondary-light) !important; }
    .bg-purple-500, .bg-violet-500 { background-color: var(--color-secondary) !important; }
    .bg-purple-600, .bg-violet-600 { background-color: var(--color-secondary) !important; }
    .bg-purple-700, .bg-violet-700 { background-color: var(--color-secondary-dark) !important; }
    .bg-purple-800, .bg-violet-800 { background-color: var(--color-secondary-dark) !important; }

    .text-purple-100, .text-violet-100 { color: var(--color-secondary-light) !important; }
    .text-purple-400, .text-violet-400 { color: var(--color-secondary-light) !important; }
    .text-purple-500, .text-violet-500 { color: var(--color-secondary) !important; }
    .text-purple-600, .text-violet-600 { color: var(--color-secondary) !important; }
    .text-purple-700, .text-violet-700 { color: var(--color-secondary-dark) !important; }

    .border-purple-500, .border-violet-500 { border-color: var(--color-secondary) !important; }
    .border-purple-600, .border-violet-600 { border-color: var(--color-secondary) !important; }

    /* AMBER & ORANGE → PRIMARY (admin panel uses these heavily) */
    .bg-amber-50, .bg-orange-50 { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    .bg-amber-100, .bg-orange-100 { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .bg-amber-200, .bg-orange-200 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .bg-amber-400, .bg-orange-400 { background-color: var(--color-primary-light) !important; }
    .bg-amber-500, .bg-orange-500 { background-color: var(--color-primary) !important; }
    .bg-amber-600, .bg-orange-600 { background-color: var(--color-primary) !important; }
    .bg-amber-700, .bg-orange-700 { background-color: var(--color-primary-dark) !important; }
    .bg-amber-800, .bg-orange-800 { background-color: var(--color-primary-dark) !important; }

    .text-amber-50, .text-orange-50 { color: var(--color-primary-light) !important; }
    .text-amber-100, .text-orange-100 { color: var(--color-primary-light) !important; }
    .text-amber-400, .text-orange-400 { color: var(--color-primary-light) !important; }
    .text-amber-500, .text-orange-500 { color: var(--color-primary) !important; }
    .text-amber-600, .text-orange-600 { color: var(--color-primary) !important; }
    .text-amber-700, .text-orange-700 { color: var(--color-primary-dark) !important; }
    .text-amber-800, .text-orange-800 { color: var(--color-primary-dark) !important; }

    .border-amber-500, .border-orange-500 { border-color: var(--color-primary) !important; }
    .border-amber-600, .border-orange-600 { border-color: var(--color-primary) !important; }

    /* GREEN & EMERALD → ACCENT (for success states) */
    .bg-green-50, .bg-emerald-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    .bg-green-100, .bg-emerald-100 { background-color: rgba(var(--color-accent-rgb), 0.1) !important; }
    .bg-green-200, .bg-emerald-200 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .bg-green-400, .bg-emerald-400 { background-color: var(--color-accent-light) !important; }
    .bg-green-500, .bg-emerald-500 { background-color: var(--color-accent) !important; }
    .bg-green-600, .bg-emerald-600 { background-color: var(--color-accent) !important; }
    .bg-green-700, .bg-emerald-700 { background-color: var(--color-accent-dark) !important; }
    .bg-green-800, .bg-emerald-800 { background-color: var(--color-accent-dark) !important; }

    .text-green-100, .text-emerald-100 { color: var(--color-accent-light) !important; }
    .text-green-400, .text-emerald-400 { color: var(--color-accent-light) !important; }
    .text-green-500, .text-emerald-500 { color: var(--color-accent) !important; }
    .text-green-600, .text-emerald-600 { color: var(--color-accent) !important; }
    .text-green-700, .text-emerald-700 { color: var(--color-accent-dark) !important; }
    .text-green-800, .text-emerald-800 { color: var(--color-accent-dark) !important; }

    .border-green-500, .border-emerald-500 { border-color: var(--color-accent) !important; }
    .border-green-600, .border-emerald-600 { border-color: var(--color-accent) !important; }

    /* YELLOW → ACCENT LIGHT */
    .bg-yellow-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    .bg-yellow-100 { background-color: rgba(var(--color-accent-rgb), 0.1) !important; }
    .bg-yellow-200 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .bg-yellow-400 { background-color: var(--color-accent-light) !important; }
    .bg-yellow-500 { background-color: var(--color-accent) !important; }
    .bg-yellow-600 { background-color: var(--color-accent) !important; }

    .text-yellow-100 { color: var(--color-accent-light) !important; }
    .text-yellow-400 { color: var(--color-accent-light) !important; }
    .text-yellow-500 { color: var(--color-accent) !important; }
    .text-yellow-600 { color: var(--color-accent) !important; }
    .text-yellow-700 { color: var(--color-accent-dark) !important; }
    .text-yellow-800 { color: var(--color-accent-dark) !important; }

    /* TEAL & CYAN → ACCENT (Complete Coverage) */
    .bg-teal-50, .bg-cyan-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    .bg-teal-100, .bg-cyan-100 { background-color: rgba(var(--color-accent-rgb), 0.1) !important; }
    .bg-teal-200, .bg-cyan-200 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .bg-teal-300, .bg-cyan-300 { background-color: rgba(var(--color-accent-rgb), 0.3) !important; }
    .bg-teal-400, .bg-cyan-400 { background-color: var(--color-accent-light) !important; }
    .bg-teal-500, .bg-cyan-500 { background-color: var(--color-accent) !important; }
    .bg-teal-600, .bg-cyan-600 { background-color: var(--color-accent) !important; }
    .bg-teal-700, .bg-cyan-700 { background-color: var(--color-accent-dark) !important; }
    .bg-teal-800, .bg-cyan-800 { background-color: var(--color-accent-dark) !important; }
    .bg-teal-900, .bg-cyan-900 { background-color: var(--color-accent-dark) !important; }

    .text-teal-50, .text-cyan-50 { color: var(--color-accent-light) !important; }
    .text-teal-100, .text-cyan-100 { color: var(--color-accent-light) !important; }
    .text-teal-200, .text-cyan-200 { color: var(--color-accent-light) !important; }
    .text-teal-300, .text-cyan-300 { color: var(--color-accent-light) !important; }
    .text-teal-400, .text-cyan-400 { color: var(--color-accent-light) !important; }
    .text-teal-500, .text-cyan-500 { color: var(--color-accent) !important; }
    .text-teal-600, .text-cyan-600 { color: var(--color-accent) !important; }
    .text-teal-700, .text-cyan-700 { color: var(--color-accent-dark) !important; }
    .text-teal-800, .text-cyan-800 { color: var(--color-accent-dark) !important; }
    .text-teal-900, .text-cyan-900 { color: var(--color-accent-dark) !important; }

    .border-teal-50, .border-cyan-50 { border-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    .border-teal-100, .border-cyan-100 { border-color: rgba(var(--color-accent-rgb), 0.1) !important; }
    .border-teal-200, .border-cyan-200 { border-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .border-teal-300, .border-cyan-300 { border-color: rgba(var(--color-accent-rgb), 0.3) !important; }
    .border-teal-400, .border-cyan-400 { border-color: var(--color-accent-light) !important; }
    .border-teal-500, .border-cyan-500 { border-color: var(--color-accent) !important; }
    .border-teal-600, .border-cyan-600 { border-color: var(--color-accent) !important; }
    .border-teal-700, .border-cyan-700 { border-color: var(--color-accent-dark) !important; }
    .border-teal-800, .border-cyan-800 { border-color: var(--color-accent-dark) !important; }
    .border-teal-900, .border-cyan-900 { border-color: var(--color-accent-dark) !important; }

    .border-l-4.border-teal-500, .border-l-4.border-cyan-500 { border-left-color: var(--color-accent) !important; }
    .border-l-4.border-teal-600, .border-l-4.border-cyan-600 { border-left-color: var(--color-accent) !important; }

    /* ROSE → SECONDARY (Complete Coverage) */
    .bg-rose-50 { background-color: rgba(var(--color-secondary-rgb), 0.05) !important; }
    .bg-rose-100 { background-color: rgba(var(--color-secondary-rgb), 0.1) !important; }
    .bg-rose-200 { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .bg-rose-300 { background-color: rgba(var(--color-secondary-rgb), 0.3) !important; }
    .bg-rose-400 { background-color: var(--color-secondary-light) !important; }
    .bg-rose-500 { background-color: var(--color-secondary) !important; }
    .bg-rose-600 { background-color: var(--color-secondary) !important; }
    .bg-rose-700 { background-color: var(--color-secondary-dark) !important; }
    .bg-rose-800 { background-color: var(--color-secondary-dark) !important; }
    .bg-rose-900 { background-color: var(--color-secondary-dark) !important; }

    .text-rose-50 { color: rgba(var(--color-secondary-rgb), 0.7) !important; }
    .text-rose-100 { color: rgba(var(--color-secondary-rgb), 0.8) !important; }
    .text-rose-200 { color: var(--color-secondary-light) !important; }
    .text-rose-300 { color: var(--color-secondary-light) !important; }
    .text-rose-400 { color: var(--color-secondary-light) !important; }
    .text-rose-500 { color: var(--color-secondary) !important; }
    .text-rose-600 { color: var(--color-secondary) !important; }
    .text-rose-700 { color: var(--color-secondary-dark) !important; }
    .text-rose-800 { color: var(--color-secondary-dark) !important; }
    .text-rose-900 { color: var(--color-secondary-dark) !important; }

    .border-rose-50 { border-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .border-rose-100 { border-color: rgba(var(--color-secondary-rgb), 0.3) !important; }
    .border-rose-200 { border-color: rgba(var(--color-secondary-rgb), 0.4) !important; }
    .border-rose-300 { border-color: var(--color-secondary-light) !important; }
    .border-rose-400 { border-color: var(--color-secondary-light) !important; }
    .border-rose-500 { border-color: var(--color-secondary) !important; }
    .border-rose-600 { border-color: var(--color-secondary) !important; }
    .border-rose-700 { border-color: var(--color-secondary-dark) !important; }
    .border-rose-800 { border-color: var(--color-secondary-dark) !important; }
    .border-rose-900 { border-color: var(--color-secondary-dark) !important; }

    /* SLATE → PRIMARY (Complete Coverage) */
    .bg-slate-50 { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    .bg-slate-100 { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .bg-slate-200 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .bg-slate-300 { background-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .bg-slate-400 { background-color: var(--color-primary-light) !important; }
    .bg-slate-500 { background-color: var(--color-primary) !important; }
    .bg-slate-600 { background-color: var(--color-primary) !important; }
    .bg-slate-700 { background-color: var(--color-primary-dark) !important; }
    .bg-slate-800 { background-color: var(--color-primary-dark) !important; }
    .bg-slate-900 { background-color: var(--color-primary-dark) !important; }

    .text-slate-50 { color: rgba(var(--color-primary-rgb), 0.7) !important; }
    .text-slate-100 { color: rgba(var(--color-primary-rgb), 0.8) !important; }
    .text-slate-200 { color: var(--color-primary-light) !important; }
    .text-slate-300 { color: var(--color-primary-light) !important; }
    .text-slate-400 { color: var(--color-primary-light) !important; }
    .text-slate-500 { color: var(--color-primary) !important; }
    .text-slate-600 { color: var(--color-primary) !important; }
    .text-slate-700 { color: var(--color-primary-dark) !important; }
    .text-slate-800 { color: var(--color-primary-dark) !important; }
    .text-slate-900 { color: var(--color-primary-dark) !important; }

    .border-slate-50 { border-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .border-slate-100 { border-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .border-slate-200 { border-color: rgba(var(--color-primary-rgb), 0.4) !important; }
    .border-slate-300 { border-color: var(--color-primary-light) !important; }
    .border-slate-400 { border-color: var(--color-primary-light) !important; }
    .border-slate-500 { border-color: var(--color-primary) !important; }
    .border-slate-600 { border-color: var(--color-primary) !important; }
    .border-slate-700 { border-color: var(--color-primary-dark) !important; }
    .border-slate-800 { border-color: var(--color-primary-dark) !important; }
    .border-slate-900 { border-color: var(--color-primary-dark) !important; }

    /* HOVER STATES - Comprehensive */
    .hover\:bg-blue-100:hover, .hover\:bg-indigo-100:hover { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .hover\:bg-blue-600:hover, .hover\:bg-indigo-600:hover { background-color: var(--color-primary) !important; }
    .hover\:bg-blue-700:hover, .hover\:bg-indigo-700:hover { background-color: var(--color-primary-dark) !important; }
    .hover\:bg-blue-800:hover, .hover\:bg-indigo-800:hover { background-color: var(--color-primary-dark) !important; }
    
    .hover\:bg-purple-700:hover, .hover\:bg-violet-700:hover { background-color: var(--color-secondary-dark) !important; }
    
    .hover\:bg-amber-100:hover, .hover\:bg-orange-100:hover { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .hover\:bg-amber-700:hover, .hover\:bg-orange-700:hover { background-color: var(--color-primary-dark) !important; }
    
    .hover\:bg-green-700:hover, .hover\:bg-emerald-700:hover { background-color: var(--color-accent-dark) !important; }
    
    .hover\:bg-teal-100:hover, .hover\:bg-cyan-100:hover { background-color: rgba(var(--color-accent-rgb), 0.1) !important; }
    .hover\:bg-teal-600:hover, .hover\:bg-cyan-600:hover { background-color: var(--color-accent) !important; }
    .hover\:bg-teal-700:hover, .hover\:bg-cyan-700:hover { background-color: var(--color-accent-dark) !important; }
    .hover\:bg-teal-800:hover, .hover\:bg-cyan-800:hover { background-color: var(--color-accent-dark) !important; }

    .hover\:bg-rose-100:hover { background-color: rgba(var(--color-secondary-rgb), 0.1) !important; }
    .hover\:bg-rose-600:hover { background-color: var(--color-secondary) !important; }
    .hover\:bg-rose-700:hover { background-color: var(--color-secondary-dark) !important; }

    .hover\:bg-slate-100:hover { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .hover\:bg-slate-600:hover { background-color: var(--color-primary) !important; }
    .hover\:bg-slate-700:hover { background-color: var(--color-primary-dark) !important; }

    .hover\:text-blue-600:hover, .hover\:text-indigo-600:hover { color: var(--color-primary) !important; }
    .hover\:text-blue-800:hover, .hover\:text-indigo-800:hover { color: var(--color-primary-dark) !important; }
    .hover\:text-purple-600:hover { color: var(--color-secondary) !important; }
    .hover\:text-amber-600:hover, .hover\:text-orange-600:hover { color: var(--color-primary) !important; }
    .hover\:text-green-600:hover { color: var(--color-accent) !important; }
    .hover\:text-teal-600:hover, .hover\:text-cyan-600:hover { color: var(--color-accent) !important; }
    .hover\:text-teal-700:hover, .hover\:text-cyan-700:hover { color: var(--color-accent-dark) !important; }
    .hover\:text-rose-600:hover { color: var(--color-secondary) !important; }
    .hover\:text-rose-700:hover { color: var(--color-secondary-dark) !important; }
    .hover\:text-slate-600:hover { color: var(--color-primary) !important; }
    .hover\:text-slate-700:hover { color: var(--color-primary-dark) !important; }

    .hover\:border-teal-400:hover, .hover\:border-cyan-400:hover { border-color: var(--color-accent-light) !important; }
    .hover\:border-teal-500:hover, .hover\:border-cyan-500:hover { border-color: var(--color-accent) !important; }
    .hover\:border-rose-400:hover { border-color: var(--color-secondary-light) !important; }
    .hover\:border-rose-500:hover { border-color: var(--color-secondary) !important; }
    .hover\:border-slate-400:hover { border-color: var(--color-primary-light) !important; }
    .hover\:border-slate-500:hover { border-color: var(--color-primary) !important; }
    .hover\:border-green-300:hover, .hover\:border-emerald-300:hover { border-color: var(--color-accent-light) !important; }
    .hover\:border-green-400:hover, .hover\:border-emerald-400:hover { border-color: var(--color-accent-light) !important; }
    .hover\:border-green-500:hover, .hover\:border-emerald-500:hover { border-color: var(--color-accent) !important; }

    /* FOCUS STATES - Rings and Borders */
    .focus\:ring-blue-500:focus, .focus\:ring-indigo-500:focus { --tw-ring-color: var(--color-primary) !important; }
    .focus\:ring-purple-500:focus { --tw-ring-color: var(--color-secondary) !important; }
    .focus\:ring-amber-500:focus, .focus\:ring-orange-500:focus { --tw-ring-color: var(--color-primary) !important; }
    .focus\:ring-green-500:focus { --tw-ring-color: var(--color-accent) !important; }
    .focus\:ring-teal-500:focus, .focus\:ring-cyan-500:focus { --tw-ring-color: var(--color-accent) !important; }
    .focus\:ring-rose-500:focus { --tw-ring-color: var(--color-secondary) !important; }
    .focus\:ring-slate-500:focus { --tw-ring-color: var(--color-primary) !important; }

    .focus\:border-blue-500:focus, .focus\:border-indigo-500:focus { border-color: var(--color-primary) !important; }
    .focus\:border-purple-500:focus { border-color: var(--color-secondary) !important; }
    .focus\:border-amber-500:focus, .focus\:border-orange-500:focus { border-color: var(--color-primary) !important; }
    .focus\:border-green-500:focus { border-color: var(--color-accent) !important; }
    .focus\:border-teal-500:focus, .focus\:border-cyan-500:focus { border-color: var(--color-accent) !important; }
    .focus\:border-rose-500:focus { border-color: var(--color-secondary) !important; }
    .focus\:border-slate-500:focus { border-color: var(--color-primary) !important; }

    /* FORM RADIO/CHECKBOX COLORS */
    .text-green-600.form-radio, .text-green-600.form-checkbox { color: var(--color-accent) !important; }
    .text-blue-600.form-radio, .text-blue-600.form-checkbox { color: var(--color-primary) !important; }

    /* GRADIENTS - Common patterns */
    .from-blue-500, .from-indigo-500 { --tw-gradient-from: var(--color-primary) !important; }
    .from-blue-600, .from-indigo-600 { --tw-gradient-from: var(--color-primary) !important; }
    .from-blue-400, .from-indigo-400 { --tw-gradient-from: var(--color-primary-light) !important; }
    
    .from-purple-500, .from-violet-500 { --tw-gradient-from: var(--color-secondary) !important; }
    .from-purple-600, .from-violet-600 { --tw-gradient-from: var(--color-secondary) !important; }
    .from-purple-400, .from-violet-400 { --tw-gradient-from: var(--color-secondary-light) !important; }
    
    .from-amber-600, .from-orange-600 { --tw-gradient-from: var(--color-primary) !important; }
    
    .from-green-400, .from-emerald-400 { --tw-gradient-from: var(--color-accent-light) !important; }
    .from-green-500, .from-emerald-500 { --tw-gradient-from: var(--color-accent) !important; }
    .from-green-600, .from-emerald-600 { --tw-gradient-from: var(--color-accent) !important; }
    
    .from-teal-400, .from-cyan-400 { --tw-gradient-from: var(--color-accent-light) !important; }
    .from-teal-500, .from-cyan-500 { --tw-gradient-from: var(--color-accent) !important; }
    .from-teal-600, .from-cyan-600 { --tw-gradient-from: var(--color-accent) !important; }
    
    .from-rose-400 { --tw-gradient-from: var(--color-secondary-light) !important; }
    .from-rose-500 { --tw-gradient-from: var(--color-secondary) !important; }
    .from-rose-600 { --tw-gradient-from: var(--color-secondary) !important; }
    
    .from-slate-400 { --tw-gradient-from: var(--color-primary-light) !important; }
    .from-slate-500 { --tw-gradient-from: var(--color-primary) !important; }
    .from-slate-600 { --tw-gradient-from: var(--color-primary) !important; }
    .from-slate-900 { --tw-gradient-from: var(--color-primary-dark) !important; }
    
    .to-purple-600, .to-violet-600 { --tw-gradient-to: var(--color-secondary) !important; }
    .to-purple-700, .to-violet-700 { --tw-gradient-to: var(--color-secondary-dark) !important; }
    .to-indigo-600, .to-indigo-700 { --tw-gradient-to: var(--color-primary-dark) !important; }
    .to-blue-600, .to-blue-700 { --tw-gradient-to: var(--color-primary-dark) !important; }
    .to-pink-600 { --tw-gradient-to: var(--color-accent) !important; }
    
    .to-orange-600, .to-amber-600 { --tw-gradient-to: var(--color-primary-dark) !important; }
    
    .to-green-600, .to-emerald-600 { --tw-gradient-to: var(--color-accent) !important; }
    .to-green-700, .to-emerald-700 { --tw-gradient-to: var(--color-accent-dark) !important; }
    
    .to-teal-600, .to-cyan-600 { --tw-gradient-to: var(--color-accent) !important; }
    .to-teal-700, .to-cyan-700 { --tw-gradient-to: var(--color-accent-dark) !important; }
    
    .to-rose-100 { --tw-gradient-to: rgba(var(--color-secondary-rgb), 0.1) !important; }
    .to-rose-600 { --tw-gradient-to: var(--color-secondary) !important; }
    .to-rose-700 { --tw-gradient-to: var(--color-secondary-dark) !important; }
    
    .to-slate-600 { --tw-gradient-to: var(--color-primary) !important; }
    .to-slate-700 { --tw-gradient-to: var(--color-primary-dark) !important; }
    
    .via-purple-600, .via-violet-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-secondary), var(--tw-gradient-to) !important; }
    .via-blue-600, .via-indigo-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-primary), var(--tw-gradient-to) !important; }
    .via-pink-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-accent), var(--tw-gradient-to) !important; }
    .via-green-600, .via-emerald-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-accent), var(--tw-gradient-to) !important; }
    .via-teal-600, .via-cyan-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-accent), var(--tw-gradient-to) !important; }
    .via-rose-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-secondary), var(--tw-gradient-to) !important; }
    .via-slate-600 { --tw-gradient-stops: var(--tw-gradient-from), var(--color-primary), var(--tw-gradient-to) !important; }
    
    /* Gradient backgrounds with from/to/via fully mapped */
    .bg-gradient-to-br.from-blue-50, .bg-gradient-to-br.from-indigo-50,
    .bg-gradient-to-r.from-blue-50, .bg-gradient-to-r.from-indigo-50 { --tw-gradient-from: rgba(var(--color-primary-rgb), 0.05) !important; }
    
    .bg-gradient-to-br.from-blue-100, .bg-gradient-to-br.from-indigo-100,
    .bg-gradient-to-r.from-blue-100, .bg-gradient-to-r.from-indigo-100 { --tw-gradient-from: rgba(var(--color-primary-rgb), 0.1) !important; }
    
    .bg-gradient-to-br.from-purple-100, .bg-gradient-to-r.from-purple-100 { --tw-gradient-from: rgba(var(--color-secondary-rgb), 0.1) !important; }
    
    .bg-gradient-to-br.to-purple-100, .bg-gradient-to-r.to-purple-100,
    .bg-gradient-to-br.to-pink-100, .bg-gradient-to-r.to-pink-100 { --tw-gradient-to: rgba(var(--color-secondary-rgb), 0.1) !important; }
    
    .bg-gradient-to-br.to-indigo-100, .bg-gradient-to-r.to-indigo-100,
    .bg-gradient-to-br.to-blue-100, .bg-gradient-to-r.to-blue-100 { --tw-gradient-to: rgba(var(--color-primary-rgb), 0.1) !important; }
    
    .to-indigo-50, .to-blue-50 { --tw-gradient-to: rgba(var(--color-primary-rgb), 0.05) !important; }
    .to-purple-50, .to-pink-50 { --tw-gradient-to: rgba(var(--color-secondary-rgb), 0.05) !important; }
    
    .via-blue-50, .via-indigo-50 { --tw-gradient-stops: var(--tw-gradient-from), rgba(var(--color-primary-rgb), 0.05), var(--tw-gradient-to) !important; }
    .via-purple-50 { --tw-gradient-stops: var(--tw-gradient-from), rgba(var(--color-secondary-rgb), 0.05), var(--tw-gradient-to) !important; }
    
    /* Pink gradients → Accent */
    .from-pink-500 { --tw-gradient-from: var(--color-accent) !important; }
    .from-pink-600 { --tw-gradient-from: var(--color-accent) !important; }
    .from-pink-400 { --tw-gradient-from: var(--color-accent-light) !important; }

    /* FILE INPUT BUTTONS */
    .file\:bg-amber-50::-webkit-file-upload-button { background-color: rgba(var(--color-primary-rgb), 0.1) !important; }
    .file\:text-amber-700::-webkit-file-upload-button { color: var(--color-primary-dark) !important; }
    .hover\:file\:bg-amber-100:hover::-webkit-file-upload-button { background-color: rgba(var(--color-primary-rgb), 0.15) !important; }

    /* ================================================
       DARK MODE VARIANTS - Complete Coverage
    ================================================ */
    
    /* Dark Mode Backgrounds - Blue/Indigo → Primary */
    .dark .dark\:bg-blue-900 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-indigo-900 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-blue-800 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-indigo-800 { background-color: var(--color-primary-dark) !important; }
    
    /* Dark Mode Backgrounds with Opacity - Blue/Indigo → Primary */
    .dark .dark\:bg-blue-900\/20 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .dark .dark\:bg-indigo-900\/20 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .dark .dark\:bg-blue-900\/40 { background-color: rgba(var(--color-primary-rgb), 0.4) !important; }
    .dark .dark\:bg-indigo-900\/40 { background-color: rgba(var(--color-primary-rgb), 0.4) !important; }
    .dark .dark\:bg-blue-50 { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    
    /* Dark Mode  Backgrounds - Purple/Violet → Secondary */
    .dark .dark\:bg-purple-900 { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:bg-violet-900 { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:bg-purple-900\/20 { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .dark .dark\:bg-violet-900\/20 { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .dark .dark\:bg-purple-900\/40 { background-color: rgba(var(--color-secondary-rgb), 0.4) !important; }
    .dark .dark\:bg-purple-50 { background-color: rgba(var(--color-secondary-rgb), 0.05) !important; }
    
    /* Dark Mode Backgrounds - Green/Emerald → Accent */
    .dark .dark\:bg-green-900 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-emerald-900 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-green-900\/20 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .dark .dark\:bg-emerald-900\/20 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .dark .dark\:bg-green-900\/40 { background-color: rgba(var(--color-accent-rgb), 0.4) !important; }
    .dark .dark\:bg-green-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    
    /* Dark Mode Backgrounds - Teal/Cyan → Accent */
    .dark .dark\:bg-teal-900 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-cyan-900 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-teal-800 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-cyan-800 { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:bg-teal-900\/20 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .dark .dark\:bg-cyan-900\/20 { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .dark .dark\:bg-teal-900\/40 { background-color: rgba(var(--color-accent-rgb), 0.4) !important; }
    .dark .dark\:bg-cyan-900\/40 { background-color: rgba(var(--color-accent-rgb), 0.4) !important; }
    .dark .dark\:bg-teal-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    .dark .dark\:bg-cyan-50 { background-color: rgba(var(--color-accent-rgb), 0.05) !important; }
    
    /* Dark Mode Backgrounds - Rose → Secondary */
    .dark .dark\:bg-rose-900 { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:bg-rose-800 { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:bg-rose-900\/20 { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .dark .dark\:bg-rose-900\/40 { background-color: rgba(var(--color-secondary-rgb), 0.4) !important; }
    .dark .dark\:bg-rose-50 { background-color: rgba(var(--color-secondary-rgb), 0.05) !important; }
    
    /* Dark Mode Backgrounds - Slate → Primary */
    .dark .dark\:bg-slate-900 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-slate-800 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-slate-900\/20 { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .dark .dark\:bg-slate-900\/40 { background-color: rgba(var(--color-primary-rgb), 0.4) !important; }
    .dark .dark\:bg-slate-50 { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    
    /* Dark Mode Backgrounds - Orange/Amber → Primary */
    .dark .dark\:bg-orange-900 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-amber-900 { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:bg-yellow-900 { background-color: var(--color-accent-dark) !important; }
    
    /* Dark Mode Text Colors - Blue/Indigo → Primary */
    .dark .dark\:text-blue-100 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-blue-200 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-blue-300 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-blue-400 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-indigo-100 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-indigo-200 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-indigo-300 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-indigo-400 { color: var(--color-primary-light) !important; }
    
    /* Dark Mode Text Colors - Purple/Violet → Secondary */
    .dark .dark\:text-purple-100 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-purple-200 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-purple-300 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-purple-400 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-violet-200 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-violet-300 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-violet-400 { color: var(--color-secondary-light) !important; }
    
    /* Dark Mode Text Colors - Green/Emerald → Accent */
    .dark .dark\:text-green-100 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-green-200 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-green-300 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-green-400 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-emerald-300 { color: var(--color-accent-light) !important; }
    
    /* Dark Mode Text Colors - Teal/Cyan → Accent */
    .dark .dark\:text-teal-100 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-teal-200 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-teal-300 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-teal-400 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-cyan-100 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-cyan-200 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-cyan-300 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-cyan-400 { color: var(--color-accent-light) !important; }
    
    /* Dark Mode Text Colors - Rose → Secondary */
    .dark .dark\:text-rose-100 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-rose-200 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-rose-300 { color: var(--color-secondary-light) !important; }
    .dark .dark\:text-rose-400 { color: var(--color-secondary-light) !important; }
    
    /* Dark Mode Text Colors - Slate → Primary */
    .dark .dark\:text-slate-100 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-slate-200 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-slate-300 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-slate-400 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-emerald-400 { color: var(--color-accent-light) !important; }
    
    /* Dark Mode Text Colors - Yellow/Amber → Accent */
    .dark .dark\:text-yellow-200 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-yellow-400 { color: var(--color-accent-light) !important; }
    .dark .dark\:text-amber-200 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-amber-400 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-orange-200 { color: var(--color-primary-light) !important; }
    .dark .dark\:text-orange-400 { color: var(--color-primary-light) !important; }
    
    /* Dark Mode Borders - All colors */
    .dark .dark\:border-blue-800 { border-color: var(--color-primary-dark) !important; }
    .dark .dark\:border-purple-800 { border-color: var(--color-secondary-dark) !important; }
    .dark .dark\:border-green-800 { border-color: var(--color-accent-dark) !important; }
    .dark .dark\:border-blue-700 { border-color: var(--color-primary-dark) !important; }
    .dark .dark\:border-purple-700 { border-color: var(--color-secondary-dark) !important; }
    .dark .dark\:border-green-700 { border-color: var(--color-accent-dark) !important; }
    
    /* Dark Mode Hover States - Backgrounds */
    .dark .dark\:hover\:bg-blue-800:hover { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:hover\:bg-blue-900:hover { background-color: var(--color-primary-dark) !important; }
    .dark .dark\:hover\:bg-blue-900\/40:hover { background-color: rgba(var(--color-primary-rgb), 0.4) !important; }
    
    .dark .dark\:hover\:bg-purple-800:hover { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:hover\:bg-purple-900:hover { background-color: var(--color-secondary-dark) !important; }
    .dark .dark\:hover\:bg-purple-900\/40:hover { background-color: rgba(var(--color-secondary-rgb), 0.4) !important; }
    
    .dark .dark\:hover\:bg-green-800:hover { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:hover\:bg-green-900:hover { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:hover\:bg-green-900\/20:hover { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    
    .dark .dark\:hover\:bg-yellow-800:hover { background-color: var(--color-accent-dark) !important; }
    .dark .dark\:hover\:bg-yellow-900:hover { background-color: var(--color-accent-dark) !important; }
    
    /* Dark Mode Hover States - Text */
    .dark .dark\:hover\:text-blue-200:hover { color: var(--color-primary-light) !important; }
    .dark .dark\:hover\:text-purple-200:hover { color: var(--color-secondary-light) !important; }
    .dark .dark\:hover\:text-green-200:hover { color: var(--color-accent-light) !important; }

    /* Specific edge cases for status badges and stat cards */
    .border-l-4.border-blue-500 { border-left-color: var(--color-primary) !important; }
    .border-l-4.border-purple-500 { border-left-color: var(--color-secondary) !important; }
    .border-l-4.border-green-500 { border-left-color: var(--color-accent) !important; }
    .border-l-4.border-indigo-500 { border-left-color: var(--color-primary) !important; }
    .border-l-4.border-orange-500 { border-left-color: var(--color-primary) !important; }
    .border-l-4.border-amber-500 { border-left-color: var(--color-primary) !important; }

    /* Additional border color overrides  */
    .border-green-200 { border-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .border-blue-200 { border-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .border-purple-200 { border-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .border-green-400 { border-color: var(--color-accent-light) !important; }
    .border-blue-400 { border-color: var(--color-primary-light) !important; }
    .border-purple-400 { border-color: var(--color-secondary-light) !important; }

    /* Comprehensive text color additions */
    .text-purple-200 { color: var(--color-secondary-light) !important; }
    .text-purple-300 { color: var(--color-secondary-light) !important; }
    .text-purple-800 { color: var(--color-secondary-dark) !important; }
    .text-blue-200 { color: var(--color-primary-light) !important; }
    .text-blue-300 { color: var(--color-primary-light) !important; }
    .text-green-200 { color: var(--color-accent-light) !important; }
    .text-green-300 { color: var(--color-accent-light) !important; }

    /* Background additions for all remaining shades */
    .bg-purple-300 { background-color: rgba(var(--color-secondary-rgb), 0.3) !important; }
    .bg-blue-300 { background-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .bg-green-300 { background-color: rgba(var(--color-accent-rgb), 0.3) !important; }
    .bg-purple-900 { background-color: var(--color-secondary-dark) !important; }
    .bg-blue-900 { background-color: var(--color-primary-dark) !important; }
    .bg-green-900 { background-color: var(--color-accent-dark) !important; }
    
    /* Hover background additions */
    .hover\:bg-blue-50:hover { background-color: rgba(var(--color-primary-rgb), 0.05) !important; }
    .hover\:bg-blue-200:hover { background-color: rgba(var(--color-primary-rgb), 0.2) !important; }
    .hover\:bg-purple-50:hover { background-color: rgba(var(--color-secondary-rgb), 0.05) !important; }
    .hover\:bg-purple-200:hover { background-color: rgba(var(--color-secondary-rgb), 0.2) !important; }
    .hover\:bg-green-200:hover { background-color: rgba(var(--color-accent-rgb), 0.2) !important; }
    .hover\:bg-green-800:hover { background-color: var(--color-accent-dark) !important; }

    /* Hover text additions */
    .hover\:text-blue-200:hover { color: var(--color-primary-light) !important; }
    .hover\:text-purple-200:hover { color: var(--color-secondary-light) !important; }
    .hover\:text-purple-800:hover { color: var(--color-secondary-dark) !important; }
    .hover\:text-green-200:hover { color: var(--color-accent-light) !important; }
    .hover\:text-green-800:hover { color: var(--color-accent-dark) !important; }
    
    /* Border hover states */
    .hover\:border-blue-300:hover { border-color: rgba(var(--color-primary-rgb), 0.3) !important; }
    .hover\:border-purple-300:hover { border-color: rgba(var(--color-secondary-rgb), 0.3) !important; }

    /* ================================================
       SEMANTIC STATUS COLORS - Fixed across themes
       These override theme colors for clarity
    ================================================ */
    
    /* Status Success (Published, Active, Hired) - Always Green */
    .status-success { background-color: #dcfce7 !important; color: #166534 !important; }
    .dark .status-success { background-color: #166534 !important; color: #dcfce7 !important; }
    
    /* Status Warning (Draft, Pending, Review) - Always Yellow/Orange */
    .status-warning { background-color: #fef3c7 !important; color: #92400e !important; }
    .dark .status-warning { background-color: #92400e !important; color: #fef3c7 !important; }
    
    /* Status Danger (Rejected, Inactive, Error) - Always Red */
    .status-danger { background-color: #fee2e2 !important; color: #991b1b !important; }
    .dark .status-danger { background-color: #991b1b !important; color: #fee2e2 !important; }
    
    /* Status Info (Reviewed, Shortlisted) - Always Blue */
    .status-info { background-color: #dbeafe !important; color: #1e3a8a !important; }
    .dark .status-info { background-color: #1e3a8a !important; color: #dbeafe !important; }
    
    /* Form validation - Always semantic colors */
    .text-red-500, .text-red-600, .border-red-500 { 
        color: #ef4444 !important; 
        border-color: #ef4444 !important;
    }

    /* ================================================
       SIDEBAR PROTECTION - Fixed colors regardless of theme
       Ensures sidebar text is always readable in both light and dark modes
    ================================================ */
    
    /* Sidebar Background - Dark mode slate gradient */
    .dark .dark\:from-slate-800,
    .dark .dark\:via-slate-900,
    .dark .dark\:to-slate-900 {
        background-color: #1e293b !important; /* Fixed slate-800 */
    }
    .dark .dark\:from-slate-800 { --tw-gradient-from: #1e293b !important; }
    .dark .dark\:via-slate-900 { --tw-gradient-via: #0f172a !important; }
    .dark .dark\:to-slate-900 { --tw-gradient-to: #0f172a !important; }
    
    /* Sidebar menu items - Light mode */
    nav a.text-gray-700,
    nav a .text-gray-500,
    nav div.text-gray-500 {
        color: #374151 !important; /* gray-700 for text, gray-500 for icons */
    }
    
    /* Sidebar menu items - Dark mode */
    .dark nav a.dark\:text-slate-300,
    .dark nav a span,
    .dark nav div span {
        color: #e2e8f0 !important; /* Fixed slate-200 - Always readable */
    }
    
    .dark nav a .dark\:text-slate-400,
    .dark nav a i.dark\:text-slate-400 {
        color: #94a3b8 !important; /* Fixed slate-400 - Always readable */
    }
    
    /* Sidebar hover states - Dark mode */
    .dark nav a:hover.dark\:hover\:text-white,
    .dark nav a:hover span {
        color: #ffffff !important;
    }
    
    .dark nav a:hover .dark\:group-hover\:text-slate-300,
    .dark nav a:hover i {
        color: #cbd5e1 !important; /* Fixed slate-300 */
    }
    
    /* Sidebar active states - Dark mode */
    .dark nav a.dark\:bg-slate-700 {
        background-color: #334155 !important; /* Fixed slate-700 */
    }
    
    .dark nav a.dark\:text-white,
    .dark nav a.dark\:text-white span {
        color: #ffffff !important;
    }
    
    /* Sidebar section headers - Dark mode */
    .dark nav div.dark\:text-slate-400 {
        color: #94a3b8 !important; /* Fixed slate-400 */
    }

</style>
