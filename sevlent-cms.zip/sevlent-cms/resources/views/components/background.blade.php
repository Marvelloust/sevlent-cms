@props([
    'pattern' => 'dots',
    'patternOpacity' => '0.1',
    'patternColor' => 'white',
    'patternSize' => '40',
    'gradient' => null,
    'overlay' => null,
    'floatingElements' => false,
    'backgroundMedia' => null,
    'backgroundVideoOverlay' => 'bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent'
])

{{-- Media Background --}}
@if($backgroundMedia)
    @php
        $media = is_object($backgroundMedia) ? $backgroundMedia : \App\Models\Media::find($backgroundMedia);
        $isVideo = $media && $media->file_type === 'video';
    @endphp

    @if($isVideo && $media)
    <video class="absolute inset-0 w-full h-full object-cover" autoplay muted loop playsinline>
        <source src="{{ $media->url }}" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <div class="absolute inset-0 {{ $backgroundVideoOverlay }}"></div>
    @elseif($media)
    <div class="absolute inset-0" style="background-image: url('{{ $media->url }}'); background-size: cover; background-position: center; background-attachment: fixed;"></div>
    @endif
@endif

<div class="absolute inset-0">
    {{-- Background Pattern --}}
    @if($pattern && $pattern !== 'none')
        <x-background-pattern
            :type="$pattern"
            :opacity="$patternOpacity"
            :color="$patternColor"
            :size="$patternSize"
        />
    @endif

    {{-- Gradient Overlay --}}
    @if($gradient)
        @php
            $gradients = [
                'hero-dark' => 'bg-gradient-to-t from-black/40 via-black/10 to-transparent',
                'hero-light' => 'bg-gradient-to-t from-white/20 via-white/5 to-transparent',
                'section-blue' => 'bg-gradient-to-br from-blue-600/10 via-purple-600/5 to-indigo-700/10',
                'section-warm' => 'bg-gradient-to-br from-orange-500/10 via-red-500/5 to-pink-500/10',
                'section-cool' => 'bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-indigo-500/10',
                'fade-top' => 'bg-gradient-to-t from-white via-white/50 to-transparent',
                'fade-bottom' => 'bg-gradient-to-b from-transparent via-white/50 to-white',
                'fade-both' => 'bg-gradient-to-b from-white/80 via-transparent to-white/80'
            ];
        @endphp
        <div class="absolute inset-0 {{ $gradients[$gradient] ?? $gradient }}"></div>
    @endif

    {{-- Custom Overlay --}}
    @if($overlay)
        <div class="absolute inset-0 {{ $overlay }}"></div>
    @endif

    {{-- Floating Elements --}}
    @if($floatingElements)
        <div class="absolute inset-0">
            {{-- Floating dots --}}
            <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
            <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
            <div class="absolute bottom-24 left-1/4 w-2 h-2 bg-white rounded-full opacity-25 animate-pulse" style="animation-delay: 2s;"></div>
            <div class="absolute bottom-32 right-1/3 w-5 h-5 bg-white rounded-full opacity-15 animate-pulse" style="animation-delay: 0.5s;"></div>

            {{-- Geometric shapes --}}
            <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
            <div class="absolute bottom-16 left-16 w-8 h-8 border border-white rounded-full opacity-20"></div>
        </div>
    @endif
</div>