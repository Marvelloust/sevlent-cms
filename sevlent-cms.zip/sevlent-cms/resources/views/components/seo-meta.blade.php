{{--
    SEO Meta Tags Component

    This component renders SEO meta tags for pages, blogs, and services.
    It uses the SeoMetadata model to get SEO data and falls back to global settings.

    Usage:
    @include('components.seo-meta', ['seoable' => $page]) // For pages, blogs, services
    or
    @include('components.seo-meta') // For homepage/other pages without specific SEO data
--}}

@php
    $seoable = $seoable ?? null;
    $seo = $seoable ? $seoable->seo : null;

    // Get global settings
    $settings = \App\Models\Setting::pluck('value', 'key')->toArray();

    // Determine meta title
    $metaTitle = $seo?->meta_title ??
                 ($seoable ? ($seoable->title ?? $seoable->name ?? '') : '') ??
                 $settings['default_meta_title'] ??
                 config('app.name');

    // Determine meta description
    $metaDescription = $seo?->meta_description ??
                      ($seoable ? ($seoable->short_description ?? $seoable->excerpt ?? '') : '') ??
                      $settings['default_meta_description'] ??
                      'Welcome to ' . config('app.name');

    // Determine canonical URL
    $canonicalUrl = $seo?->canonical_url ?? url()->current();

    // Open Graph data
    $ogTitle = $seo?->og_title ?? $metaTitle;
    $ogDescription = $seo?->og_description ?? $metaDescription;
    $ogImage = $seo?->ogImage ? $seo->ogImage->url : null;
    $ogUrl = $canonicalUrl;

    // Keywords
    $keywords = $seo?->meta_keywords ?? '';
@endphp

{{-- Basic Meta Tags --}}
<meta name="description" content="{{ Str::limit($metaDescription, 160) }}">
@if($keywords)
    <meta name="keywords" content="{{ $keywords }}">
@endif
<meta name="robots" content="index, follow">
<link rel="canonical" href="{{ $canonicalUrl }}">

{{-- Open Graph Meta Tags --}}
<meta property="og:title" content="{{ Str::limit($ogTitle, 60) }}">
<meta property="og:description" content="{{ Str::limit($ogDescription, 160) }}">
<meta property="og:url" content="{{ $ogUrl }}">
<meta property="og:type" content="website">
@if($ogImage)
    <meta property="og:image" content="{{ asset($ogImage) }}">
    <meta property="og:image:alt" content="{{ $seoable ? ($seoable->title ?? $seoable->name ?? $ogTitle) : $ogTitle }}">
@endif

{{-- Twitter Card Meta Tags --}}
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ Str::limit($ogTitle, 60) }}">
<meta name="twitter:description" content="{{ Str::limit($ogDescription, 160) }}">
@if($ogImage)
    <meta name="twitter:image" content="{{ asset($ogImage) }}">
@endif

{{-- Page Title --}}
<title>{{ $metaTitle }}</title>