{{--
    Navigation Submenu Component

    Used recursively to render nested menu items
--}}

@foreach($items as $item)
@if($item->is_active)
<li class="submenu-item">
    <a href="{{ $item->url }}"
       target="{{ $item->target }}"
       class="submenu-link block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-blue-600 {{ $item->css_class }}">
        @if($item->icon)
            <i class="{{ $item->icon }} mr-2"></i>
        @endif
        {{ $item->title }}
    </a>

    {{-- Render children if they exist and depth allows --}}
    @if($item->children->count() > 0 && $currentDepth < $maxDepth)
    <ul class="submenu nested absolute left-full top-0 bg-white shadow-lg rounded-md py-2 min-w-48">
        @include('components.navigation-submenu', ['items' => $item->children, 'maxDepth' => $maxDepth, 'currentDepth' => $currentDepth + 1])
    </ul>
    @endif
</li>
@endif
@endforeach