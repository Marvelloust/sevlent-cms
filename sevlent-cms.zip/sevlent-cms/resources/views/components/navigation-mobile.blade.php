{{--
    Mobile Navigation Component

    Usage:
    @include('components.navigation-mobile', [
        'menu' => 'main', // Menu name or ID
        'class' => 'mobile-navigation' // CSS class for the nav element
    ])
--}}

@php
    $menuName = $menu ?? 'main';
    $navClass = $class ?? 'mobile-navigation';

    // Find menu by name or ID
    if (is_numeric($menuName)) {
        $menu = \App\Models\Menu::find($menuName);
    } else {
        $menu = \App\Models\Menu::where('name', $menuName)->first();
    }

    if (!$menu) {
        return;
    }

    $menuItems = $menu->topLevelItems()->active()->get();
@endphp

@if($menuItems->count() > 0)
<div class="{{ $navClass }}">
    @foreach($menuItems as $item)
    <a href="{{ $item->url }}"
       target="{{ $item->target }}"
       class="block pl-3 pr-4 py-2 border-l-4 text-base font-medium {{ request()->url() === $item->url ? 'border-blue-500 text-blue-700 bg-blue-50' : 'border-transparent text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300' }} {{ $item->css_class }}">
        @if($item->icon)
            <i class="{{ $item->icon }} mr-2"></i>
        @endif
        {{ $item->title }}
    </a>

    {{-- Render children if they exist --}}
    @if($item->children->count() > 0)
        @include('components.navigation-mobile-submenu', ['items' => $item->children])
    @endif
    @endforeach
</div>
@endif