@php
    $logo = setting('logo');
    $primaryColor = setting('primary_color', '#3b82f6');
    $secondaryColor = setting('secondary_color', '#8b5cf6');
@endphp

@if($logo)
    <img {{ $attributes }} src="{{ asset('storage/' . $logo) }}" alt="{{ setting('site_name', 'SEVLENT CMS') }}">
@else
    <!-- Custom SEVLENT CMS Logo Fallback -->
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
        <!-- Background Circle -->
        <circle cx="50" cy="50" r="48" fill="url(#gradient)" />
        
        <!-- Letter 'S' -->
        <path d="M 35 30 Q 50 25 65 30 Q 70 35 68 42 Q 65 48 58 50 L 42 50 Q 35 52 32 58 Q 30 65 35 70 Q 50 75 65 70" 
              stroke="white" 
              stroke-width="6" 
              stroke-linecap="round" 
              fill="none" />
        
        <!-- Gradient Definition -->
        <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:{{ $primaryColor }};stop-opacity:1" />
                <stop offset="100%" style="stop-color:{{ $secondaryColor }};stop-opacity:1" />
            </linearGradient>
        </defs>
    </svg>
@endif
