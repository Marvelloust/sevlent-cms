{{--
    Mobile Navigation Submenu Component

    Used recursively to render nested menu items in mobile view
--}}

@foreach($items as $item)
@if($item->is_active)
<a href="{{ $item->url }}"
   target="{{ $item->target }}"
   class="block pl-6 pr-4 py-2 border-l-4 text-sm font-medium {{ request()->url() === $item->url ? 'border-blue-500 text-blue-700 bg-blue-50' : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50 hover:border-gray-300' }} {{ $item->css_class }}">
    @if($item->icon)
        <i class="{{ $item->icon }} mr-2"></i>
    @endif
    {{ $item->title }}
</a>

{{-- Render children if they exist --}}
@if($item->children->count() > 0)
    @include('components.navigation-mobile-submenu', ['items' => $item->children])
@endif
@endif
@endforeach