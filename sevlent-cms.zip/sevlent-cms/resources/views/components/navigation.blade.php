{{--
    Navigation Component

    Usage:
    @include('components.navigation', [
        'menu' => 'main', // Menu name or ID
        'class' => 'main-navigation', // CSS class for the nav element
        'depth' => 2 // Maximum depth to render (default: 2)
    ])
--}}

@php
    $menuName = $menu ?? 'main';
    $navClass = $class ?? 'navigation';
    $maxDepth = $depth ?? 2;
    $isScrolled = $scrolled ?? false;

    // Find menu by name or ID
    if (is_numeric($menuName)) {
        $menu = \App\Models\Menu::find($menuName);
    } else {
        $menu = \App\Models\Menu::where('name', $menuName)->first();
    }

    if (!$menu) {
        return;
    }

    $menuItems = $menu->topLevelItems()->active()->get();
@endphp

@if($menuItems->count() > 0)
<nav class="{{ $navClass }}">
    <ul class="menu-items flex space-x-4">
        @foreach($menuItems as $item)
        <li class="menu-item {{ $item->css_class }}">
            <a href="{{ $item->url }}"
               target="{{ $item->target }}"
               class="menu-link px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 {{ $isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200' }} {{ $item->css_class }}">
                @if($item->icon)
                    <i class="{{ $item->icon }} mr-2"></i>
                @endif
                {{ $item->title }}
            </a>

            {{-- Render children if they exist and depth allows --}}
            @if($item->children->count() > 0 && $item->depth < $maxDepth)
            <ul class="submenu absolute hidden bg-white shadow-lg rounded-md mt-2 py-2 min-w-48">
                @include('components.navigation-submenu', ['items' => $item->children, 'maxDepth' => $maxDepth, 'currentDepth' => $item->depth + 1])
            </ul>
            @endif
        </li>
        @endforeach
    </ul>
</nav>
@endif