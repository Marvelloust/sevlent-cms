<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Test Email</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 10px; margin-bottom: 20px;">
        <h1 style="color: white; margin: 0; text-align: center;">SEVLENT CMS</h1>
        <p style="color: white; margin: 10px 0 0 0; text-align: center;">Test Email</p>
    </div>

    <div style="background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
        <h2 style="color: #333; margin-top: 0;">Test Email Successful! ✅</h2>
        <p>This is a test email to verify that your Gmail SMTP configuration is working correctly.</p>

        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <strong>Test Details:</strong><br>
            - Time: {{ now()->format('Y-m-d H:i:s') }}<br>
            - Server: SEVLENT CMS<br>
            - Status: SMTP Connection Successful
        </div>

        <p>If you received this email, your notification system is properly configured!</p>
    </div>

    <div style="text-align: center; color: #666; font-size: 12px;">
        <p>This is an automated test email from SEVLENT CMS</p>
    </div>
</body>
</html>