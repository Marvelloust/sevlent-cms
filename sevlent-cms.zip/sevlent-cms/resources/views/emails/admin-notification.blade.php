<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $notification->title }}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            background: #ffffff;
            padding: 30px;
            border: 1px solid #e5e7eb;
            border-top: none;
        }
        .notification-box {
            background: #f9fafb;
            border-left: 4px solid #667eea;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .notification-title {
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 10px;
        }
        .notification-message {
            color: #6b7280;
            margin-bottom: 15px;
        }
        .notification-details {
            background: white;
            padding: 15px;
            border-radius: 4px;
            margin-top: 15px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: 600;
            color: #4b5563;
        }
        .detail-value {
            color: #6b7280;
        }
        .button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            margin: 20px 0;
        }
        .button:hover {
            opacity: 0.9;
        }
        .footer {
            background: #f9fafb;
            padding: 20px;
            border-radius: 0 0 10px 10px;
            text-align: center;
            color: #6b7280;
            font-size: 14px;
            border: 1px solid #e5e7eb;
            border-top: none;
        }
        .icon {
            width: 50px;
            height: 50px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="icon">
            <span>🔔</span>
        </div>
        <h1>New Notification</h1>
    </div>

    <div class="content">
        <p>Hello {{ $admin->name }},</p>
        
        <div class="notification-box">
            <div class="notification-title">
                {{ $notification->title }}
            </div>
            <div class="notification-message">
                {{ $notification->message }}
            </div>

            @if($notification->data)
            <div class="notification-details">
                <strong>Details:</strong>
                @foreach($notification->data as $key => $value)
                    <div class="detail-row">
                        <span class="detail-label">{{ ucfirst(str_replace('_', ' ', $key)) }}:</span>
                        <span class="detail-value">{{ $value }}</span>
                    </div>
                @endforeach
            </div>
            @endif
        </div>

        @if($notification->link)
        <center>
            <a href="{{ $notification->link }}" class="button">
                View Details
            </a>
        </center>
        @endif

        <p style="margin-top: 30px; color: #6b7280;">
            This notification was generated automatically by your CMS. You're receiving this because you're an administrator.
        </p>
    </div>

    <div class="footer">
        <p>© {{ date('Y') }} {{ config('app.name') }}. All rights reserved.</p>
        <p style="margin-top: 10px;">
            <a href="{{ route('admin.dashboard') }}" style="color: #667eea;">Admin Dashboard</a> | 
            <a href="{{ route('admin.settings.index') }}" style="color: #667eea;">Settings</a>
        </p>
    </div>
</body>
</html>
