<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Contact Form Submission</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #2563eb; color: white; padding: 20px; text-align: center; }
        .content { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .field { margin-bottom: 15px; }
        .field-label { font-weight: bold; color: #374151; }
        .field-value { background-color: white; padding: 10px; border-radius: 4px; border: 1px solid #e5e7eb; }
        .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>New Contact Form Submission</h1>
            <p>You have received a new message from your website contact form.</p>
        </div>

        <div class="content">
            <div class="field">
                <div class="field-label">Name:</div>
                <div class="field-value">{{ $contact->name }}</div>
            </div>

            <div class="field">
                <div class="field-label">Email:</div>
                <div class="field-value">{{ $contact->email }}</div>
            </div>

            @if($contact->phone)
            <div class="field">
                <div class="field-label">Phone:</div>
                <div class="field-value">{{ $contact->phone }}</div>
            </div>
            @endif

            <div class="field">
                <div class="field-label">Subject:</div>
                <div class="field-value">{{ $contact->subject }}</div>
            </div>

            <div class="field">
                <div class="field-label">Message:</div>
                <div class="field-value">{{ nl2br(e($contact->message)) }}</div>
            </div>

            <div class="field">
                <div class="field-label">Submitted:</div>
                <div class="field-value">{{ $contact->created_at->format('F j, Y \a\t g:i A') }}</div>
            </div>
        </div>

        <div class="footer">
            <p>This message was sent from your website contact form.</p>
            <p>You can view and manage all contact submissions in your <a href="{{ url('/admin/contacts') }}">admin panel</a>.</p>
        </div>
    </div>
</body>
</html>