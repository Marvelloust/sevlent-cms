<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-full">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }} - Login</title>

        <!-- Favicons -->
        @php
            $favicon = setting('favicon') ? asset('storage/' . setting('favicon')) : asset('favicon.ico');
        @endphp
        <link rel="icon" type="image/x-icon" href="{{ $favicon }}">
        <link rel="icon" type="image/png" sizes="32x32" href="{{ $favicon }}">
        <link rel="icon" type="image/png" sizes="16x16" href="{{ $favicon }}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{ $favicon }}">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])

        <!-- Theme Styles -->
        @include('components.theme-styles')
    </head>
    <body class="font-sans antialiased h-full">
        <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-500 via-purple-600 to-indigo-700 dark:from-gray-900 dark:via-purple-900 dark:to-gray-800 py-12 px-4 sm:px-6 lg:px-8">
            <!-- Background Pattern -->
            <div class="absolute inset-0 bg-grid-white/[0.05] bg-[size:20px_20px]"></div>
            
            <div class="max-w-md w-full space-y-8 relative z-10">
                <!-- Logo & Header -->
                <div class="text-center">
                    <div class="mx-auto h-20 w-20 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex items-center justify-center mb-6 transform hover:scale-105 transition-transform duration-200">
                        <x-application-logo class="w-12 h-12 text-indigo-600" />
                    </div>
                    <h2 class="text-4xl font-extrabold text-white mb-2">
                        Welcome Back
                    </h2>
                    <p class="text-blue-100 text-sm">
                        Sign in to your account to continue
                    </p>
                </div>

                <!-- Login Card -->
                <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl bg-opacity-95 dark:bg-opacity-95">
                    <div class="px-8 py-10">
                        {{ $slot }}
                    </div>
                </div>

                <!-- Footer -->
                <div class="text-center text-white text-sm">
                    <p class="opacity-90">
                        © {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
                    </p>
                </div>
            </div>
        </div>
    </body>
</html>
