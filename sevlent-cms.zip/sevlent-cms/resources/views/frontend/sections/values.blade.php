<!-- Core Values Section -->
<section class="py-24 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-teal-100 to-cyan-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8 mb-16" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-teal-50 text-teal-700 rounded-full text-sm font-medium">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Values' }}
            </h2>

            <!-- Subheadline -->
            @if(!empty($section->data['subheadline']))
                <p class="text-body-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
                    {{ $section->data['subheadline'] }}
                </p>
            @endif
        </div>

        <!-- Values Grid -->
        @php
            $valuesList = $section->data['values_list'] ?? null;
            if ($valuesList && is_string($valuesList)) {
                $valuesList = json_decode($valuesList, true);
            }
            $valuesCount = $valuesList && is_array($valuesList) ? count($valuesList) : 0;

            // Dynamic grid classes based on number of values
            $gridClasses = 'gap-8';
            if ($valuesCount === 1) {
                $gridClasses .= ' grid-cols-1';
            } elseif ($valuesCount === 2) {
                $gridClasses .= ' grid-cols-1 md:grid-cols-2';
            } elseif ($valuesCount === 3) {
                $gridClasses .= ' grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
            } elseif ($valuesCount === 4) {
                $gridClasses .= ' grid-cols-1 md:grid-cols-2 lg:grid-cols-4';
            } else {
                $gridClasses .= ' grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
            }
        @endphp
        @if($valuesList && is_array($valuesList))
            <div class="grid {{ $gridClasses }}" data-aos="fade-up" data-aos-delay="200">
                @foreach($valuesList as $index => $value)
                    <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300" data-aos="fade-up" data-aos-delay="{{ 300 + ($index * 100) }}">
                        <!-- Icon -->
                        <div class="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                            @if(!empty($value['icon']))
                                <i class="fas fa-{{ $value['icon'] }} text-2xl text-white"></i>
                            @else
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            @endif
                        </div>

                        <!-- Title -->
                        <h3 class="text-heading-sm font-bold text-gray-900 mb-4 text-center">
                            {{ $value['title'] ?? '' }}
                        </h3>

                        <!-- Description -->
                        <p class="text-gray-600 text-center leading-relaxed">
                            {{ $value['description'] ?? '' }}
                        </p>
                    </div>
                @endforeach
            </div>
        @else
            <!-- Default Values -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-aos="fade-up" data-aos-delay="200">
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4 text-center">Integrity</h3>
                    <p class="text-gray-600 text-center leading-relaxed">We uphold the highest standards of honesty and ethical behavior in everything we do.</p>
                </div>

                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4 text-center">Collaboration</h3>
                    <p class="text-gray-600 text-center leading-relaxed">We believe in the power of teamwork and working together towards common goals.</p>
                </div>

                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4 text-center">Innovation</h3>
                    <p class="text-gray-600 text-center leading-relaxed">We continuously seek new ways to improve and deliver exceptional results.</p>
                </div>
            </div>
        @endif
    </div>
</section>