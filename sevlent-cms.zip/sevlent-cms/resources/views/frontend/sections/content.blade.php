@php
    $bgColors = [
        'white' => 'bg-white',
        'gray' => 'bg-gray-50',
        'blue' => 'bg-blue-50',
        'gradient' => 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    ];
    $bgClass = $bgColors[$section->data['background_color'] ?? 'white'] ?? 'bg-white';
@endphp

<!-- Modern Content Section -->
<section class="py-24 {{ $bgClass }} relative overflow-hidden">
    <!-- Background Decorations -->
    @if($bgClass === 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50')
        <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-100/40 to-indigo-100/40 rounded-full blur-3xl -z-10"></div>
        <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100/40 to-pink-100/40 rounded-full blur-3xl -z-10"></div>
    @endif

    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <!-- Header Section -->
        <div class="text-center mb-16" data-aos="fade-up">
            @if(!empty($section->data['section_badge']))
                <div class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold bg-white/80 backdrop-blur-sm text-gray-800 border border-gray-200/50 shadow-sm mb-6">
                    <span class="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mr-2"></span>
                    {{ $section->data['section_badge'] }}
                </div>
            @endif

            @if(!empty($section->data['headline']))
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight mb-6">
                    {{ $section->data['headline'] }}
                </h2>
            @endif

            @if(!empty($section->data['subheadline']))
                <p class="text-body-lg md:text-body-xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-8">
                    {{ $section->data['subheadline'] }}
                </p>
            @endif

            @if(!empty($section->title) && empty($section->data['headline']))
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight mb-8">
                    {{ $section->title }}
                </h2>
            @endif
        </div>

        <!-- Main Content -->
        @if(!empty($section->content))
            <div class="mb-16" data-aos="fade-up" data-aos-delay="200">
                <div class="bg-white/70 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-xl border border-white/20">
                    <div class="prose prose-xl prose-gray max-w-none">
                        <div class="text-body-lg md:text-body-xl text-gray-700 leading-relaxed">
                            {!! $section->content !!}
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- Content Blocks -->
        @if(!empty($section->data['content_blocks']) && is_array($section->data['content_blocks']))
            <div class="space-y-12" data-aos="fade-up" data-aos-delay="300">
                @foreach($section->data['content_blocks'] as $index => $block)
                    @if(isset($block['type']) && isset($block['content']))
                        @if($block['type'] === 'heading')
                            <div class="text-center" data-aos="fade-up" data-aos-delay="{{ 400 + ($index * 100) }}">
                                <h3 class="text-heading-lg md:text-heading-xl font-bold text-gray-900 mb-6 relative">
                                    {{ $block['content'] }}
                                    <div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
                                </h3>
                            </div>
                        @elseif($block['type'] === 'paragraph')
                            <div class="bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-white/30" data-aos="fade-up" data-aos-delay="{{ 400 + ($index * 100) }}">
                                <p class="text-body-lg md:text-body-xl text-gray-700 leading-relaxed text-center max-w-4xl mx-auto">
                                    {{ $block['content'] }}
                                </p>
                            </div>
                        @elseif($block['type'] === 'list')
                            @php
                                // Handle both string and array content
                                if (is_array($block['content'])) {
                                    $items = array_filter(array_map('trim', $block['content']));
                                } else {
                                    $items = explode("\n", $block['content']);
                                    $items = array_filter(array_map('trim', $items));
                                }
                            @endphp
                            @if(count($items) > 0)
                                <div class="bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-white/30" data-aos="fade-up" data-aos-delay="{{ 400 + ($index * 100) }}">
                                    <div class="grid md:grid-cols-2 gap-6">
                                        @foreach($items as $item)
                                            <div class="flex items-start group">
                                                <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mr-4 mt-1 group-hover:scale-110 transition-transform duration-200">
                                                    <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                    </svg>
                                                </div>
                                                <span class="text-gray-700 text-lg leading-relaxed group-hover:text-gray-900 transition-colors duration-200">{{ $item }}</span>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endif
                        @elseif($block['type'] === 'image')
                            <div class="text-center" data-aos="fade-up" data-aos-delay="{{ 400 + ($index * 100) }}">
                                @if($block['content'])
                                    <div class="relative inline-block">
                                        <div class="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-3xl blur-xl transform scale-110"></div>
                                        <img src="/storage/{{ $block['content'] }}"
                                             alt="{{ $block['alt'] ?? '' }}"
                                             class="relative w-full max-w-4xl h-auto rounded-3xl shadow-2xl border border-white/50">
                                        @if(isset($block['caption']) && !empty($block['caption']))
                                            <p class="text-center text-gray-600 mt-6 text-lg italic bg-white/50 backdrop-blur-sm rounded-xl py-3 px-6 inline-block">
                                                {{ $block['caption'] }}
                                            </p>
                                        @endif
                                    </div>
                                @endif
                            </div>
                        @endif
                    @endif
                @endforeach
            </div>
        @endif
        </div>
    </div>
</section>
