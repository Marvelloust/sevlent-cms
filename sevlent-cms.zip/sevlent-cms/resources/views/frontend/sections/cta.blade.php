<!-- Modern CTA Section -->
<section class="relative py-24 overflow-hidden">
    <!-- Animated Gradient Background -->
    <div class="absolute inset-0 bg-gradient-to-br from-purple-600 via-pink-600 to-indigo-700">
        <div class="absolute inset-0 bg-grid-white/[0.05]"></div>
        <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
    </div>

    <!-- Animated Orbs -->
    <div class="absolute inset-0 overflow-hidden">
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse animation-delay-2000"></div>
    </div>

    <div class="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8" data-aos="zoom-in">
            <!-- Badge -->
            @if(!empty($section->data['badge_text']))
            <div class="inline-flex items-center px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
                <span class="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2"></span>
                <span class="text-sm font-medium text-white">{{ $section->data['badge_text'] }}</span>
            </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-2xl md:text-heading-3xl lg:text-display-md font-bold text-white leading-tight">
                {{ $section->data['headline'] ?? $section->title }}
            </h2>

            <!-- Subheadline -->
            @if(!empty($section->data['subheadline']))
                <p class="text-body-lg md:text-body-xl text-white/90 max-w-3xl mx-auto leading-relaxed">
                    {{ $section->data['subheadline'] }}
                </p>
            @endif

            <!-- CTA Button -->
            @if(!empty($section->data['button_text']))
                <div class="pt-4">
                    <a href="{{ $section->data['button_url'] ?? '#' }}"
                       class="inline-flex items-center px-10 py-5 bg-white text-gray-900 font-bold rounded-xl text-lg shadow-2xl shadow-black/30 transition-all duration-300 transform hover:scale-105 hover:shadow-3xl group">
                        <span>{{ $section->data['button_text'] }}</span>
                        <svg class="ml-3 w-6 h-6 transition-transform duration-300 group-hover:translate-x-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                        </svg>
                    </a>
                </div>
            @endif

            <!-- Trust Indicators -->
            @php
                $trustIndicators = $section->data['trust_indicators'] ?? null;
                if ($trustIndicators && is_string($trustIndicators)) {
                    $trustIndicators = json_decode($trustIndicators, true);
                }
            @endphp
            @if($trustIndicators && is_array($trustIndicators) && count($trustIndicators) > 0)
            <div class="flex flex-wrap justify-center gap-8 pt-8 text-white/80">
                @foreach($trustIndicators as $indicator)
                <div class="flex items-start space-x-2">
                    <svg class="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <div class="flex flex-col">
                        <span class="text-sm font-medium">{{ $indicator['title'] ?? 'Trust Indicator' }}</span>
                        @if(!empty($indicator['description']))
                        <span class="text-xs text-white/60 mt-0.5">{{ $indicator['description'] }}</span>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
            @endif
        </div>
    </div>

    <style>
        .bg-grid-white\/\[0\.05\] {
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
        }
    </style>
</section>