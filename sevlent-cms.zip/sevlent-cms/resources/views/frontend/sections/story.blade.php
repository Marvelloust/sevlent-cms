<!-- Origin Story Timeline Section -->
<section class="py-24 bg-gradient-to-b from-white to-orange-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-orange-100 to-red-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8 mb-16" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-orange-50 text-orange-700 rounded-full text-sm font-medium">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Story' }}
            </h2>

            <!-- Subheadline -->
            @if(!empty($section->data['subheadline']))
                <p class="text-body-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
                    {{ $section->data['subheadline'] }}
                </p>
            @endif
        </div>

        <!-- Timeline Milestones -->
        @php
            $timelineItems = $section->data['timeline_items'] ?? null;
            if ($timelineItems && is_string($timelineItems)) {
                $timelineItems = json_decode($timelineItems, true);
            }
        @endphp
        @if($timelineItems && is_array($timelineItems) && count($timelineItems) > 0)
            <div class="relative">
                <!-- Timeline Line -->
                <div class="absolute left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gradient-to-b from-orange-300 to-red-300 hidden md:block"></div>

                <div class="space-y-8 md:space-y-0">
                    @foreach($timelineItems as $index => $item)
                        <div class="relative flex items-center {{ $index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse' }} flex-col md:gap-8 {{ $index > 0 ? 'mt-8 md:-mt-56' : '' }}" data-aos="{{ $index % 2 === 0 ? 'fade-right' : 'fade-left' }}" data-aos-delay="{{ 200 + ($index * 100) }}">
                            <!-- Timeline Dot -->
                            <div class="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-orange-500 rounded-full border-4 border-white shadow-lg z-10 hidden md:block"></div>

                            <!-- Content Card -->
                            <div class="w-full md:w-5/12 bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 {{ $index % 2 === 0 ? 'md:text-right' : 'md:text-left' }}">
                                <!-- Year (using icon field) -->
                                @if(!empty($item['icon']))
                                    <div class="inline-flex items-center px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm font-semibold mb-4">
                                        {{ $item['icon'] }}
                                    </div>
                                @endif

                                <!-- Title -->
                                <h3 class="text-2xl font-bold text-gray-900 mb-4">
                                    {{ $item['title'] ?? '' }}
                                </h3>

                                <!-- Description -->
                                <p class="text-gray-600 leading-relaxed">
                                    {{ $item['description'] ?? '' }}
                                </p>
                            </div>

                            <!-- Spacer for alternating layout -->
                            <div class="hidden md:block md:w-2/12"></div>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </div>
</section>