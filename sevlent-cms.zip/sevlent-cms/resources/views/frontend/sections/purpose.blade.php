<!-- Purpose Statement Section -->
@php
    $backgroundColor = $section->data['background_color'] ?? 'gradient';
    $bgClasses = [
        'white' => 'bg-white',
        'gray' => 'bg-gray-50',
        'blue' => 'bg-blue-50',
        'gradient' => 'bg-gradient-to-br from-purple-50 to-pink-50'
    ];
@endphp

<section class="py-24 {{ $bgClasses[$backgroundColor] ?? 'bg-gradient-to-br from-purple-50 to-pink-50' }} relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Purpose' }}
            </h2>

            <!-- Purpose Statement -->
            @if(!empty($section->data['purpose_statement']))
                <div class="max-w-4xl mx-auto text-body-lg text-gray-600 leading-relaxed bg-white/50 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
                    {!! nl2br(e($section->data['purpose_statement'])) !!}
                </div>
            @endif

            <!-- Additional Description -->
            @if(!empty($section->data['description']))
                <div class="max-w-3xl mx-auto text-lg text-gray-500 leading-relaxed mt-8">
                    {!! nl2br(e($section->data['description'])) !!}
                </div>
            @endif

            <!-- Decorative Quote Mark -->
            <div class="flex justify-center mt-12">
                <svg class="w-16 h-16 text-purple-300 opacity-50" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h4v10h-10z"/>
                </svg>
            </div>
        </div>
    </div>
</section>