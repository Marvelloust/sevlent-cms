<!-- Philosophy & Beliefs Section -->
<section class="py-24 bg-white relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <!-- Content Side -->
            <div class="space-y-8" data-aos="fade-right">
                <!-- Section Label -->
                @if(!empty($section->data['section_label']))
                    <div class="inline-flex items-center px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-full text-sm font-medium">
                        {{ $section->data['section_label'] }}
                    </div>
                @endif

                <!-- Headline -->
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    {{ $section->data['headline'] ?? 'Our Philosophy' }}
                </h2>

                <!-- Subheadline -->
                @if(!empty($section->data['subheadline']))
                    <p class="text-body-lg text-gray-600 leading-relaxed">
                        {{ $section->data['subheadline'] }}
                    </p>
                @endif

                <!-- Philosophy Content -->
                @if(!empty($section->data['philosophy_content']))
                    <div class="text-lg text-gray-600 leading-relaxed bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border-l-4 border-indigo-500">
                        {!! nl2br(e($section->data['philosophy_content'])) !!}
                    </div>
                @endif
            </div>

            <!-- Principles Side -->
            <div class="space-y-6" data-aos="fade-left">
                <h3 class="text-2xl font-bold text-gray-900 mb-8">Guiding Principles</h3>

                @php
                    $principles = $section->data['principles'] ?? null;
                    if ($principles && is_string($principles)) {
                        $principles = json_decode($principles, true);
                    }
                @endphp
                @if($principles && is_array($principles))
                    @foreach($principles as $index => $principle)
                        <div class="flex items-start space-x-4 bg-gray-50 rounded-xl p-6 transform hover:scale-105 transition-transform duration-300" data-aos="fade-up" data-aos-delay="{{ $index * 100 }}">
                            <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <span class="text-white font-bold text-sm">{{ $index + 1 }}</span>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-900 mb-2">{{ $principle['title'] ?? '' }}</h4>
                                <p class="text-gray-600 leading-relaxed">{{ $principle['description'] ?? '' }}</p>
                            </div>
                        </div>
                    @endforeach
                @else
                    <!-- Default Principles -->
                    <div class="space-y-6">
                        <div class="flex items-start space-x-4 bg-gray-50 rounded-xl p-6">
                            <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <span class="text-white font-bold text-sm">1</span>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-900 mb-2">Customer First</h4>
                                <p class="text-gray-600 leading-relaxed">Everything we do revolves around delivering exceptional value to our customers.</p>
                            </div>
                        </div>

                        <div class="flex items-start space-x-4 bg-gray-50 rounded-xl p-6">
                            <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <span class="text-white font-bold text-sm">2</span>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-900 mb-2">Continuous Learning</h4>
                                <p class="text-gray-600 leading-relaxed">We embrace change and constantly seek new knowledge to improve our craft.</p>
                            </div>
                        </div>

                        <div class="flex items-start space-x-4 bg-gray-50 rounded-xl p-6">
                            <div class="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <span class="text-white font-bold text-sm">3</span>
                            </div>
                            <div class="flex-1">
                                <h4 class="font-semibold text-gray-900 mb-2">Excellence</h4>
                                <p class="text-gray-600 leading-relaxed">We strive for perfection in every project and never settle for mediocrity.</p>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</section>