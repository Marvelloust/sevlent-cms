<!-- Community & Involvement Section -->
<section class="py-24 bg-gradient-to-r from-purple-50 to-pink-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-100 to-rose-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8 mb-16" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-purple-50 text-purple-700 rounded-full text-sm font-medium">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Join Our Community' }}
            </h2>

            <!-- Subheadline -->
            @if(!empty($section->data['subheadline']))
                <p class="text-body-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
                    {{ $section->data['subheadline'] }}
                </p>
            @endif
        </div>

        <!-- Culture Content Grid -->
        @if(!empty($section->data['culture_description']) || !empty($section->data['culture_image']))
            <div class="mb-16" data-aos="fade-up" data-aos-delay="300">
                <div class="max-w-7xl mx-auto">
                    @php
                        $hasDescription = !empty($section->data['culture_description']);
                        $hasImage = !empty($section->data['culture_image']);
                        $gridClasses = ($hasDescription && $hasImage) ? 'lg:grid-cols-2 gap-12' : 'grid-cols-1';
                    @endphp
                    <div class="grid {{ $gridClasses }} items-center">

                        <!-- Community Description -->
                        @if($hasDescription)
                            <div class="order-2 lg:order-1">
                                <div class="text-body-lg text-gray-600 leading-relaxed bg-white/70 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
                                    {!! nl2br(e($section->data['culture_description'])) !!}
                                </div>
                            </div>
                        @endif

                        <!-- Culture Image -->
                        @if($hasImage)
                            <div class="order-1 lg:order-2">
                                @php
                                    $media = \App\Models\Media::find($section->data['culture_image']);
                                @endphp
                                @if($media)
                                    <img src="{{ $media->url }}"
                                         alt="Culture Image"
                                         class="w-full h-64 md:h-80 lg:h-96 object-cover rounded-2xl shadow-lg">
                                @endif
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        @endif

        <!-- Community Features -->
        @php
            $features = $section->data['culture_highlights'] ?? null;
            if ($features && is_string($features)) {
                $features = json_decode($features, true);
            }
        @endphp
        @if($features && is_array($features))
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16" data-aos="fade-up" data-aos-delay="200">
                @foreach($features as $index => $feature)
                    <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300 text-center" data-aos="fade-up" data-aos-delay="{{ 300 + ($index * 100) }}">
                        <!-- Icon -->
                        <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                            @if(!empty($feature['icon']))
                                <i class="fas fa-{{ $feature['icon'] }} text-2xl text-white"></i>
                            @else
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                                </svg>
                            @endif
                        </div>

                        <!-- Title -->
                        <h3 class="text-heading-sm font-bold text-gray-900 mb-4">
                            {{ $feature['title'] ?? '' }}
                        </h3>

                        <!-- Description -->
                        <p class="text-gray-600 leading-relaxed">
                            {{ $feature['description'] ?? '' }}
                        </p>
                    </div>
                @endforeach
            </div>
        @endif

        <!-- Community Stats -->
        @php
            $stats = $section->data['stats'] ?? null;
            if ($stats && is_string($stats)) {
                $stats = json_decode($stats, true);
            }
        @endphp
        @if($stats && is_array($stats))
            <div class="bg-white/70 backdrop-blur-sm rounded-2xl p-8 shadow-lg mb-16" data-aos="fade-up" data-aos-delay="400">
                <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                    @foreach($stats as $stat)
                        <div class="text-center">
                            <div class="text-metric-sm md:text-metric-md font-bold text-purple-600 mb-2">
                                {{ $stat['number'] ?? '0' }}
                                @if(!empty($stat['suffix']))
                                    <span class="text-body-sm md:text-body-md">{{ $stat['suffix'] }}</span>
                                @endif
                            </div>
                            <p class="text-gray-600 font-medium">{{ $stat['label'] ?? '' }}</p>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif

        <!-- CTA Buttons -->
        @if(!empty($section->data['cta_button_text']))
            <div class="text-center" data-aos="fade-up" data-aos-delay="600">
                <a href="{{ $section->data['cta_button_url'] ?? '#' }}"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                    {{ $section->data['cta_button_text'] }}
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </a>
            </div>
        @endif
    </div>
</section>