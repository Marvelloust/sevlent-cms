<!-- Vision Statement Section -->
<section class="py-24 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-green-50 text-green-700 rounded-full text-sm font-medium">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Vision' }}
            </h2>

            <!-- Vision Statement -->
            @if(!empty($section->data['vision_statement']))
                <div class="max-w-4xl mx-auto text-body-lg text-gray-600 leading-relaxed">
                    {!! nl2br(e($section->data['vision_statement'])) !!}
                </div>
            @endif

            <!-- Additional Description -->
            @if(!empty($section->data['description']))
                <div class="max-w-3xl mx-auto text-lg text-gray-500 leading-relaxed mt-8">
                    {!! nl2br(e($section->data['description'])) !!}
                </div>
            @endif

            <!-- Background Media -->
            @if(!empty($section->data['background_image']))
                @php
                    $backgroundMedia = \App\Models\Media::find($section->data['background_image']);
                @endphp
                <div class="mt-16 relative">
                    <div class="relative rounded-2xl overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500">
                        @if($backgroundMedia && $backgroundMedia->file_type === 'video')
                        <video class="w-full h-96 object-cover" controls muted>
                            <source src="{{ $backgroundMedia->url }}" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                        @else
                        <img
                            src="{{ $backgroundMedia->url }}"
                            alt="{{ $section->title }}"
                            class="w-full h-96 object-cover"
                        >
                        @endif
                        <!-- Gradient Overlay -->
                        <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    </div>
                    <!-- Decorative Elements -->
                    <div class="absolute -top-6 -left-6 w-24 h-24 bg-gradient-to-br from-green-500 to-blue-500 rounded-full opacity-20 blur-2xl"></div>
                    <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full opacity-20 blur-2xl"></div>
                </div>
            @endif
        </div>
    </div>
</section>