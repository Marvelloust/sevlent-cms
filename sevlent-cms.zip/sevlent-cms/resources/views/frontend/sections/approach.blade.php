<!-- Approach & Methodology Section -->
<section class="py-24 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-green-100 to-teal-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-teal-100 to-cyan-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <!-- Content Side -->
            <div class="space-y-8" data-aos="fade-right">
                <!-- Section Label -->
                @if(!empty($section->data['section_label']))
                    <div class="inline-flex items-center px-3 py-1.5 bg-green-50 text-green-700 rounded-full text-sm font-medium">
                        {{ $section->data['section_label'] }}
                    </div>
                @endif

                <!-- Headline -->
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    {{ $section->data['headline'] ?? 'Our Approach' }}
                </h2>

                <!-- Subheadline -->
                @if(!empty($section->data['subheadline']))
                    <p class="text-body-lg text-gray-600 leading-relaxed">
                        {{ $section->data['subheadline'] }}
                    </p>
                @endif

                <!-- Approach Description -->
                @if(!empty($section->data['approach_description']))
                    <div class="text-lg text-gray-600 leading-relaxed">
                        {!! nl2br(e($section->data['approach_description'])) !!}
                    </div>
                @endif
            </div>

            <!-- Methodology Side -->
            <div class="space-y-8" data-aos="fade-left">
                <!-- Methodology Image -->
                @if(!empty($section->data['methodology_image']))
                    <div class="relative mb-8">
                        <div class="relative rounded-2xl overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-500 h-80">
                            <img
                                src="{{ optional(\App\Models\Media::find($section->data['methodology_image']))->url }}"
                                alt="{{ $section->title }}"
                                class="w-full h-full object-cover"
                            >
                            <!-- Gradient Overlay -->
                            <div class="absolute inset-0 bg-gradient-to-tr from-green-600/20 to-transparent"></div>
                        </div>
                        <!-- Decorative Elements -->
                        <div class="absolute -top-6 -left-6 w-24 h-24 bg-gradient-to-br from-green-500 to-teal-500 rounded-full opacity-20 blur-2xl"></div>
                        <div class="absolute -bottom-6 -right-6 w-32 h-32 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-full opacity-20 blur-2xl"></div>
                    </div>
                @endif

                <!-- Process Steps -->
                <div class="space-y-6">
                    <h3 class="text-2xl font-bold text-gray-900">Our Process</h3>

                    @php
                        $steps = $section->data['steps'] ?? null;
                        if ($steps && is_string($steps)) {
                            $steps = json_decode($steps, true);
                        }
                    @endphp
                    @if($steps && is_array($steps) && count($steps) > 0)
                        <div class="grid md:grid-cols-2 gap-6">
                            @foreach($steps as $index => $step)
                                <div class="flex items-start gap-4 bg-white p-6 rounded-xl border border-gray-100 hover:border-green-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-green-50/30 transition-all duration-300" data-aos="fade-up" data-aos-delay="{{ $index * 150 }}">
                                    <div class="flex-shrink-0 mt-0.5">
                                        <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-green-100 to-teal-100 hover:from-green-200 hover:to-teal-200 transition-colors duration-300 flex-shrink-0">
                                            <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                                            </svg>
                                        </div>
                                    </div>
                                    <div class="flex-1">
                                        <p class="text-base font-semibold text-gray-900 hover:text-gray-900 transition-colors">
                                            @if(is_array($step))
                                                {{ $step['title'] ?? 'Process Step' }}
                                            @else
                                                {{ $step }}
                                            @endif
                                        </p>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <!-- Default Process Steps -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <div class="flex items-start gap-4 bg-white p-6 rounded-xl border border-gray-100 hover:border-green-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-green-50/30 transition-all duration-300">
                                <div class="flex-shrink-0 mt-0.5">
                                    <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-green-100 to-teal-100 hover:from-green-200 hover:to-teal-200 transition-colors duration-300 flex-shrink-0">
                                        <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <p class="text-base font-semibold text-gray-900 hover:text-gray-900 transition-colors">Discovery & Analysis</p>
                                </div>
                            </div>

                            <div class="flex items-start gap-4 bg-white p-6 rounded-xl border border-gray-100 hover:border-green-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-green-50/30 transition-all duration-300">
                                <div class="flex-shrink-0 mt-0.5">
                                    <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-green-100 to-teal-100 hover:from-green-200 hover:to-teal-200 transition-colors duration-300 flex-shrink-0">
                                        <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <p class="text-base font-semibold text-gray-900 hover:text-gray-900 transition-colors">Strategic Planning</p>
                                </div>
                            </div>

                            <div class="flex items-start gap-4 bg-white p-6 rounded-xl border border-gray-100 hover:border-green-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-green-50/30 transition-all duration-300">
                                <div class="flex-shrink-0 mt-0.5">
                                    <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-green-100 to-teal-100 hover:from-green-200 hover:to-teal-200 transition-colors duration-300 flex-shrink-0">
                                        <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <p class="text-base font-semibold text-gray-900 hover:text-gray-900 transition-colors">Agile Development</p>
                                </div>
                            </div>

                            <div class="flex items-start gap-4 bg-white p-6 rounded-xl border border-gray-100 hover:border-green-300 hover:shadow-lg hover:bg-gradient-to-br hover:from-white hover:to-green-50/30 transition-all duration-300">
                                <div class="flex-shrink-0 mt-0.5">
                                    <div class="flex items-center justify-center h-10 w-10 rounded-lg bg-gradient-to-br from-green-100 to-teal-100 hover:from-green-200 hover:to-teal-200 transition-colors duration-300 flex-shrink-0">
                                        <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <p class="text-base font-semibold text-gray-900 hover:text-gray-900 transition-colors">Quality Assurance</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>