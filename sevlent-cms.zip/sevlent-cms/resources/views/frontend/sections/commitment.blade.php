<!-- Commitment & Promise Section -->
<section class="py-24 bg-gradient-to-r from-blue-50 to-indigo-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8 mb-16" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-white/80 backdrop-blur-sm text-blue-700 rounded-full text-sm font-medium border border-blue-200/50">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Commitment' }}
            </h2>

            <!-- Commitment Statement -->
            @if(!empty($section->data['commitment_statement']))
                <div class="max-w-4xl mx-auto text-body-lg text-gray-600 leading-relaxed bg-white/70 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
                    {!! nl2br(e($section->data['commitment_statement'])) !!}
                </div>
            @endif
        </div>

        <!-- Promises Grid -->
        @php
            $promises = $section->data['promises'] ?? null;
            if ($promises && is_string($promises)) {
                $promises = json_decode($promises, true);
            }
        @endphp
        @if($promises && is_array($promises))
            @php
                $promiseCount = count($promises);
                $gridClasses = match($promiseCount) {
                    1 => 'grid-cols-1',
                    2 => 'grid-cols-1 md:grid-cols-2',
                    3 => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
                    4 => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
                    default => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
                };
            @endphp
            <div class="grid {{ $gridClasses }} gap-6 md:gap-8 mb-16" data-aos="fade-up" data-aos-delay="200">
                @foreach($promises as $index => $promise)
                    <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300 text-center" data-aos="fade-up" data-aos-delay="{{ 300 + ($index * 100) }}">
                        <!-- Icon -->
                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                            @if(!empty($promise['icon']))
                                <i class="fas fa-{{ $promise['icon'] }} text-2xl text-white"></i>
                            @else
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            @endif
                        </div>

                        <!-- Title -->
                        <h3 class="text-heading-sm font-bold text-gray-900 mb-4">
                            {{ $promise['title'] ?? '' }}
                        </h3>

                        <!-- Description -->
                        <p class="text-gray-600 leading-relaxed">
                            {{ $promise['description'] ?? '' }}
                        </p>
                    </div>
                @endforeach
            </div>
        @else
            <!-- Default Promises -->
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16" data-aos="fade-up" data-aos-delay="200">
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300 text-center">
                    <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4">Quality Guarantee</h3>
                    <p class="text-gray-600 leading-relaxed">We stand behind our work with comprehensive quality assurance and support.</p>
                </div>

                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300 text-center">
                    <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4">Timely Delivery</h3>
                    <p class="text-gray-600 leading-relaxed">We respect your time and deliver projects on schedule without compromising quality.</p>
                </div>

                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2 transition-transform duration-300 text-center">
                    <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <h3 class="text-heading-sm font-bold text-gray-900 mb-4">Continuous Support</h3>
                    <p class="text-gray-600 leading-relaxed">Our relationship doesn't end at delivery - we're here to support you long-term.</p>
                </div>
            </div>
        @endif

        <!-- CTA Buttons -->
        @if(!empty($section->data['cta_button_text']))
            <div class="text-center" data-aos="fade-up" data-aos-delay="400">
                <a href="{{ $section->data['cta_button_url'] ?? '#' }}"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                    {{ $section->data['cta_button_text'] }}
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </a>
            </div>
        @endif
    </div>
</section>