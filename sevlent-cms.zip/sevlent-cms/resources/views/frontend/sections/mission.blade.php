<!-- Mission Statement Section -->
<section class="py-24 bg-white relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <!-- Content Side -->
            <div class="space-y-8" data-aos="fade-right">
                <!-- Section Label -->
                @if(!empty($section->data['section_label']))
                    <div class="inline-flex items-center px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-full text-sm font-medium">
                        {{ $section->data['section_label'] }}
                    </div>
                @endif

                <!-- Headline -->
                <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                    {{ $section->data['headline'] ?? 'Our Mission' }}
                </h2>

                <!-- Mission Statement -->
                @if(!empty($section->data['mission_statement']))
                    <div class="text-lg text-gray-600 leading-relaxed">
                        {!! nl2br(e($section->data['mission_statement'])) !!}
                    </div>
                @endif

                <!-- Additional Description -->
                @if(!empty($section->data['description']))
                    <div class="text-base text-gray-500 leading-relaxed">
                        {!! nl2br(e($section->data['description'])) !!}
                    </div>
                @endif
            </div>

            <!-- Icon/Image Side -->
            <div class="relative" data-aos="fade-left">
                @if(!empty($section->data['icon_image']))
                    <div class="relative">
                        <div class="w-full max-w-lg h-80 md:h-[550px] mx-auto bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-105 transition-transform duration-500 overflow-hidden">
                            <img
                                src="{{ optional(\App\Models\Media::find($section->data['icon_image']))->url }}"
                                alt="{{ $section->title }}"
                                class="w-full h-full object-cover rounded-2xl"
                            >
                        </div>
                        <!-- Decorative Elements -->
                        <div class="absolute -top-8 -right-8 w-24 h-24 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full opacity-20 blur-2xl"></div>
                        <div class="absolute -bottom-8 -left-8 w-32 h-32 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full opacity-20 blur-2xl"></div>
                    </div>
                @else
                    <!-- Default Mission Icon -->
                    <div class="w-full max-w-lg h-80 md:h-[550px] mx-auto bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-105 transition-transform duration-500">
                        <svg class="w-32 h-32 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                    </div>
                @endif
            </div>
        </div>
    </div>
</section>