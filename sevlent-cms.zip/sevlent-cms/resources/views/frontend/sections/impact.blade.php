<!-- Impact & Results Section -->
<section class="py-24 bg-gradient-to-r from-green-50 to-emerald-50 relative overflow-hidden">
    <!-- Background Decoration -->
    <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full blur-3xl opacity-30 -z-10"></div>
    <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-full blur-3xl opacity-30 -z-10"></div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center space-y-8 mb-16" data-aos="fade-up">
            <!-- Section Label -->
            @if(!empty($section->data['section_label']))
                <div class="inline-flex items-center px-3 py-1.5 bg-green-50 text-green-700 rounded-full text-sm font-medium border border-green-200/50">
                    {{ $section->data['section_label'] }}
                </div>
            @endif

            <!-- Headline -->
            <h2 class="text-heading-lg md:text-heading-xl lg:text-heading-2xl font-bold text-gray-900 leading-tight">
                {{ $section->data['headline'] ?? 'Our Impact' }}
            </h2>

            <!-- Impact Summary -->
            @if(!empty($section->data['impact_summary']))
                <div class="max-w-4xl mx-auto text-body-lg text-gray-600 leading-relaxed bg-white/70 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
                    {!! nl2br(e($section->data['impact_summary'])) !!}
                </div>
            @endif
        </div>

        <!-- Impact Metrics -->
        @php
            $metrics = $section->data['stats'] ?? null;
            if ($metrics && is_string($metrics)) {
                $metrics = json_decode($metrics, true);
            }
        @endphp
        @if($metrics && is_array($metrics))
            @php
                $metricCount = count($metrics);
                $gridClasses = match($metricCount) {
                    1 => 'grid-cols-1',
                    2 => 'grid-cols-1 md:grid-cols-2',
                    3 => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
                    4 => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
                    default => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'
                };
            @endphp
            <div class="grid {{ $gridClasses }} gap-6 md:gap-8 mb-16" data-aos="fade-up" data-aos-delay="200">
                @foreach($metrics as $index => $metric)
                    <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center transform hover:-translate-y-2 transition-transform duration-300" data-aos="fade-up" data-aos-delay="{{ 300 + ($index * 100) }}">
                        <!-- Number -->
                        <div class="text-metric-md md:text-metric-lg font-bold text-green-600 mb-4">
                            {{ $metric['number'] ?? '0' }}
                            @if(!empty($metric['suffix']))
                                <span class="text-body-sm md:text-body-md">{{ $metric['suffix'] }}</span>
                            @endif
                        </div>

                        <!-- Label -->
                        <h3 class="text-lg font-semibold text-gray-900 mb-2">
                            {{ $metric['label'] ?? '' }}
                        </h3>

                        <!-- Description -->
                        <p class="text-gray-600 text-sm leading-relaxed">
                            {{ $metric['description'] ?? '' }}
                        </p>
                    </div>
                @endforeach
            </div>
        @else
            <!-- Default Metrics -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mb-16" data-aos="fade-up" data-aos-delay="200">
                <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="text-4xl md:text-5xl font-bold text-green-600 mb-4">500+</div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Projects Completed</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">Successful projects delivered to satisfied clients worldwide.</p>
                </div>

                <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="text-4xl md:text-5xl font-bold text-green-600 mb-4">98%</div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Client Satisfaction</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">Our clients rate us highly for quality and reliability.</p>
                </div>

                <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="text-4xl md:text-5xl font-bold text-green-600 mb-4">24/7</div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Support Available</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">Round-the-clock support for all our clients.</p>
                </div>

                <div class="bg-white rounded-2xl p-6 md:p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center transform hover:-translate-y-2 transition-transform duration-300">
                    <div class="text-4xl md:text-5xl font-bold text-green-600 mb-4">5</div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Years Experience</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">Years of expertise in delivering exceptional results.</p>
                </div>
            </div>
        @endif

        <!-- Impact Stories -->
        @php
            $stories = $section->data['stories'] ?? null;
            if ($stories && is_string($stories)) {
                $stories = json_decode($stories, true);
            }
        @endphp
        @if($stories && is_array($stories))
            <div class="grid lg:grid-cols-2 gap-12 mb-16" data-aos="fade-up" data-aos-delay="400">
                @foreach($stories as $index => $story)
                    <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300" data-aos="fade-up" data-aos-delay="{{ 500 + ($index * 100) }}">
                        <!-- Story Title -->
                        <h3 class="text-2xl font-bold text-gray-900 mb-4">
                            {{ $story['title'] ?? '' }}
                        </h3>

                        <!-- Story Content -->
                        <p class="text-gray-600 leading-relaxed mb-6">
                            {{ $story['content'] ?? '' }}
                        </p>

                        <!-- Story Author -->
                        @if(!empty($story['author']))
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mr-4">
                                    <span class="text-white font-semibold text-sm">
                                        {{ substr($story['author'], 0, 1) }}
                                    </span>
                                </div>
                                <div>
                                    <p class="font-semibold text-gray-900">{{ $story['author'] }}</p>
                                    @if(!empty($story['role']))
                                        <p class="text-sm text-gray-600">{{ $story['role'] }}</p>
                                    @endif
                                </div>
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        @endif

        <!-- CTA Buttons -->
        @if(!empty($section->data['cta_button_text']))
            <div class="text-center" data-aos="fade-up" data-aos-delay="600">
                <a href="{{ $section->data['cta_button_url'] ?? '#' }}"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                    {{ $section->data['cta_button_text'] }}
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                </a>
            </div>
        @endif
    </div>
</section>