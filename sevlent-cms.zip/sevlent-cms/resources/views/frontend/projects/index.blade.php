@extends('frontend.layouts.app')

@section('title', 'Our Projects')

@section('content')
<!-- Hero Section -->
<div class="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 overflow-hidden">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-10">
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0); background-size: 40px 40px;"></div>
        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 1200 400" preserveAspectRatio="xMidYMid slice">
            <defs>
                <linearGradient id="projectLineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                    <stop offset="50%" style="stop-color:rgba(255,255,255,0.3);stop-opacity:1" />
                    <stop offset="100%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                </linearGradient>
            </defs>
            <line x1="0" y1="50" x2="1200" y2="50" stroke="url(#projectLineGradient)" stroke-width="1"/>
            <line x1="0" y1="150" x2="1200" y2="150" stroke="url(#projectLineGradient)" stroke-width="1"/>
            <line x1="0" y1="250" x2="1200" y2="250" stroke="url(#projectLineGradient)" stroke-width="1"/>
            <line x1="200" y1="0" x2="200" y2="400" stroke="url(#projectLineGradient)" stroke-width="1"/>
            <line x1="600" y1="0" x2="600" y2="400" stroke="url(#projectLineGradient)" stroke-width="1"/>
            <line x1="1000" y1="0" x2="1000" y2="400" stroke="url(#projectLineGradient)" stroke-width="1"/>
        </svg>
    </div>

    <!-- Floating Elements -->
    <div class="absolute inset-0">
        <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
    </div>

    <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>

    <div class="relative pt-32 pb-20">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                Our Projects
            </h1>
            <p class="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed drop-shadow">
                Explore our portfolio of successful projects and see how we've helped businesses achieve their goals.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#projects-list" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-blue-600 bg-white hover:bg-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                    View Projects
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                    </svg>
                </a>
                <a href="{{ route('contact.index') }}" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-base font-semibold rounded-lg text-white hover:bg-white/10 hover:border-white transition-all duration-300">
                    Get In Touch
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Projects Content -->
<div id="projects-list" class="bg-gray-50 py-16 -mt-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <!-- Projects Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @forelse($projects as $project)
            <div class="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 transform">
                @if($project->media->isNotEmpty())
                <div class="h-48 bg-gray-200 overflow-hidden">
                    <img src="{{ asset('storage/' . $project->media->first()->file_path) }}"
                         alt="{{ $project->title }}"
                         class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                </div>
                @else
                <div class="h-48 bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center group-hover:from-blue-500 group-hover:to-blue-700 transition-all duration-300">
                    <svg class="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                </div>
                @endif

                <div class="p-5 flex flex-col h-full">
                    <h3 class="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                        <a href="{{ route('projects.show', $project->slug) }}">
                            {{ $project->title }}
                        </a>
                    </h3>

                    <p class="text-gray-600 mb-3 line-clamp-3">
                        {{ Str::limit(strip_tags($project->description), 150) }}
                    </p>

                    @if($project->technologies)
                    <div class="mb-3">
                        <div class="flex flex-wrap gap-1">
                            @foreach(is_array($project->technologies) ? $project->technologies : explode(',', $project->technologies) as $tech)
                            <span class="px-3 py-1 text-xs bg-blue-100 text-blue-700 rounded-full font-medium">{{ trim($tech) }}</span>
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <div class="flex items-center justify-between mt-3">
                        <a href="{{ route('projects.show', $project->slug) }}"
                           class="inline-flex items-center text-blue-600 hover:text-blue-800 font-semibold group/link">
                            View Project
                            <svg class="ml-2 w-4 h-4 group-hover/link:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                            </svg>
                        </a>

                        @if($project->project_url)
                        <a href="{{ $project->project_url }}" target="_blank" rel="noopener noreferrer"
                           class="inline-flex items-center text-gray-400 hover:text-blue-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                            </svg>
                        </a>
                        @endif
                    </div>
                </div>
            </div>
            @empty
            <div class="col-span-full text-center py-16">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                </svg>
                <h3 class="mt-4 text-lg font-semibold text-gray-900">No projects available</h3>
                <p class="mt-1 text-gray-500">Check back later to see our latest work.</p>
            </div>
            @endforelse
        </div>

        <!-- Pagination -->
        @if($projects->hasPages())
        <div class="mt-16">
            <div class="flex justify-center">
                {{ $projects->links() }}
            </div>
        </div>
        @endif
    </div>
</div>
@endsection