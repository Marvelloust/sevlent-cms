@extends('frontend.layouts.app')

@php
    $seoable = $blog;
@endphp

@section('content')
<section class="bg-gradient-to-r from-blue-500 to-purple-600 h-32 lg:h-40 relative overflow-hidden">
    <!-- Dots Pattern -->
    <div class="absolute inset-0 opacity-20">
        <svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <pattern id="dots" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="10" cy="10" r="1" fill="white"/>
                </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#dots)"/>
        </svg>
    </div>
</section>
<!-- Breadcrumbs -->
<div class="bg-gray-100 py-4 lg:py-6">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="flex" aria-label="Breadcrumb">
            <ol class="flex items-center space-x-4">
                <li>
                    <a href="{{ route('home') }}" class="text-gray-400 hover:text-gray-500">
                        <svg class="flex-shrink-0 h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-5 5a1 1 0 001.414 1.414L9 3.414V15a1 1 0 102 0V3.414l3.293 3.293a1 1 0 001.414-1.414l-5-5z"/>
                        </svg>
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="flex-shrink-0 h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <a href="{{ route('blogs.index') }}" class="ml-4 text-sm font-medium text-gray-500 hover:text-gray-700">Blog</a>
                    </div>
                </li>
                <li>
                    <div class="flex items-center">
                        <svg class="flex-shrink-0 h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <span class="ml-4 text-sm font-medium text-gray-500">{{ $blog->title }}</span>
                    </div>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- Blog Header -->
<div class="bg-white">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-24">
        <div class="text-center">
            @if($blog->category)
            <span class="inline-block px-4 py-2 text-sm font-medium bg-blue-100 text-blue-800 rounded-full mb-6">
                {{ $blog->category->name }}
            </span>
            @endif

            <h1 class="text-heading-xl md:text-heading-2xl lg:text-heading-3xl font-bold text-gray-900 mb-6 leading-tight">{{ $blog->title }}</h1>

            @if($blog->excerpt)
            <p class="text-body-lg md:text-body-xl lg:text-heading-sm text-gray-600 mb-10 leading-relaxed">{{ $blog->excerpt }}</p>
            @endif

            <div class="flex flex-wrap items-center justify-center gap-6 lg:gap-8 text-sm text-gray-500 mb-8">
                @if($blog->author)
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                    </svg>
                    <span class="font-medium">{{ $blog->author->name }}</span>
                </div>
                @endif

                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                    </svg>
                    <time datetime="{{ $blog->published_at->format('Y-m-d') }}" class="font-medium">
                        {{ $blog->published_at->format('F j, Y') }}
                    </time>
                </div>

                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                    </svg>
                    <span class="font-medium">{{ ceil(str_word_count(strip_tags($blog->content)) / 200) }} min read</span>
                </div>
            </div>
        </div>

        @if($blog->image)
        <div class="mt-16 lg:mt-20">
            @if($blog->image->file_type === 'video')
            <video controls class="w-full rounded-xl shadow-2xl border border-gray-200">
                <source src="{{ $blog->image->url }}" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            @else
            <img src="{{ $blog->image->url }}"
                 alt="{{ $blog->image->alt_text ?? $blog->title }}"
                 class="w-full rounded-xl shadow-2xl border border-gray-200">
            @endif
        </div>
        @endif
    </div>
</div>

<!-- Blog Content -->
<div class="bg-white py-16 lg:py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            <!-- Main Content -->
            <div class="lg:col-span-2">
                <article class="prose prose-lg max-w-none">
                    @if($blog->content_blocks && count($blog->content_blocks) > 0)
                        @foreach($blog->content_blocks as $index => $block)
                            @if($block['type'] === 'heading')
                    <div class="@if($index > 0) pt-12 border-t border-gradient from-transparent via-gray-200 to-transparent @endif">
                        <h2 class="text-4xl md:text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-blue-600 mb-6 leading-tight">
                            {{ $block['content'] }}
                        </h2>
                    </div>

                            @elseif($block['type'] === 'paragraph')
                    <div class="group">
                        <p class="text-lg text-gray-700 leading-relaxed font-light hover:text-gray-900 transition-colors duration-300 mb-5">
                            {{ $block['content'] }}
                        </p>
                    </div>

                            @elseif($block['type'] === 'image' && isset($block['image']))
                                <figure class="my-12">
                                    <div class="rounded-2xl overflow-hidden shadow-xl border border-gray-200 hover:shadow-2xl transition-shadow duration-300">
                                        <img src="/storage/{{ $block['image'] }}" 
                                             alt="{{ $block['content'] ?? 'Blog image' }}"
                                             class="w-full h-auto object-cover">
                                    </div>
                                    @if(isset($block['content']) && $block['content'])
                                        <figcaption class="mt-6 text-center text-gray-600 italic text-base leading-relaxed">
                                            {{ $block['content'] }}
                                        </figcaption>
                                    @endif
                                </figure>

                            @elseif($block['type'] === 'list')
                                <div class="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 my-8 border border-gray-200 shadow-sm">
                                    <ul class="space-y-5">
                                        @foreach(explode("\n", $block['content']) as $item)
                                            @if(trim($item))
                                                <li class="text-lg text-gray-800 leading-relaxed flex items-start group">
                                                    <span class="inline-flex items-center justify-center h-6 w-6 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white text-sm font-bold mr-5 mt-1 flex-shrink-0 shadow-md group-hover:shadow-lg group-hover:scale-110 transition-all duration-300">
                                                        <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                                        </svg>
                                                    </span>
                                                    <span class="pt-0.5 group-hover:text-gray-900 transition-colors duration-300">{{ trim($item) }}</span>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                </div>

                            @elseif($block['type'] === 'link')
                                @php
                                    $parts = explode('|', $block['content']);
                                    $linkText = $parts[0] ?? 'Read more';
                                    $linkUrl = $parts[1] ?? '#';
                                @endphp
                                <div class="my-10">
                                    <a href="{{ $linkUrl }}"
                                       class="inline-flex items-center px-8 py-4 bg-white border-2 border-gray-200 hover:border-blue-400 text-gray-800 hover:text-blue-600 font-semibold rounded-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 group"
                                       target="_blank"
                                       rel="noopener noreferrer">
                                        <span>{{ $linkText }}</span>
                                        <svg class="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                        </svg>
                                    </a>
                                </div>
                            @endif
                        @endforeach
                    @else
                        <div>
                            {!! $blog->content !!}
                        </div>
                    @endif
                </article>
            </div>

            <!-- Sidebar -->
            <aside class="lg:col-span-1">
                <!-- Table of Contents -->
                @php
                    $headings = [];
                    if($blog->content_blocks && count($blog->content_blocks) > 0) {
                        foreach($blog->content_blocks as $index => $block) {
                            if($block['type'] === 'heading') {
                                $headings[] = ['index' => $index, 'content' => $block['content']];
                            }
                        }
                    }
                @endphp

                @if(count($headings) > 0)
                <div class="bg-gray-50 rounded-2xl p-8 border border-gray-200">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <svg class="w-6 h-6 mr-3 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/>
                        </svg>
                        Contents
                    </h3>
                    <nav class="space-y-4">
                        @foreach($headings as $heading)
                            <a href="#section-{{ $heading['index'] }}" 
                               class="block text-base text-gray-700 hover:text-blue-600 hover:translate-x-1 transition-all duration-200 border-l-2 border-transparent hover:border-blue-600 pl-4">
                                {{ Str::limit($heading['content'], 40) }}
                            </a>
                        @endforeach
                    </nav>
                </div>
                @endif

                <!-- Blog Meta -->
                <div class="mt-8 bg-white rounded-2xl p-8 border border-gray-200">
                    <h3 class="text-xl font-bold text-gray-900 mb-8">Blog Details</h3>
                    
                    <div class="space-y-6">
                        <!-- Category -->
                        @if($blog->category)
                        <div class="flex items-start">
                            <svg class="w-6 h-6 text-blue-600 mr-4 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M2 6a2 2 0 012-2h12a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"/>
                            </svg>
                            <div>
                                <p class="text-sm font-semibold text-gray-500 uppercase tracking-wide">Category</p>
                                <a href="#" class="text-lg font-semibold text-gray-900 hover:text-blue-600 transition-colors">
                                    {{ $blog->category->name }}
                                </a>
                            </div>
                        </div>
                        @endif

                        <!-- Published Date -->
                        <div class="flex items-start">
                            <svg class="w-6 h-6 text-blue-600 mr-4 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                            </svg>
                            <div>
                                <p class="text-sm font-semibold text-gray-500 uppercase tracking-wide">Published</p>
                                <time datetime="{{ $blog->published_at->format('Y-m-d') }}" class="text-lg font-semibold text-gray-900">
                                    {{ $blog->published_at->format('F j, Y') }}
                                </time>
                            </div>
                        </div>

                        <!-- Reading Time -->
                        <div class="flex items-start">
                            <svg class="w-6 h-6 text-blue-600 mr-4 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                            </svg>
                            <div>
                                <p class="text-sm font-semibold text-gray-500 uppercase tracking-wide">Reading Time</p>
                                <p class="text-lg font-semibold text-gray-900">
                                    {{ ceil(str_word_count(strip_tags($blog->content)) / 200) }} min read
                                </p>
                            </div>
                        </div>

                        <!-- Tags -->
                        @if($blog->tags && $blog->tags->count() > 0)
                        <div class="flex items-start pt-3">
                            <svg class="w-6 h-6 text-blue-600 mr-4 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M17.414 2.586a2 2 0 00-2.828 0L7.071 10.172a2 2 0 000 2.828l7.07 7.071a2 2 0 002.828 0l7.07-7.071a2 2 0 000-2.828l-7.07-7.07z"/>
                            </svg>
                            <div class="flex-1">
                                <p class="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Tags</p>
                                <div class="flex flex-wrap gap-3">
                                    @foreach($blog->tags as $tag)
                                        <a href="#" class="px-4 py-2 bg-blue-100 text-blue-700 text-sm font-medium rounded-full hover:bg-blue-200 transition-colors">
                                            {{ $tag->name }}
                                        </a>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Images Gallery -->
                @php
                    $images = [];
                    if($blog->content_blocks && count($blog->content_blocks) > 0) {
                        foreach($blog->content_blocks as $index => $block) {
                            if($block['type'] === 'image') {
                                $images[] = ['index' => $index, 'content' => $block['content'] ?? 'Image ' . (count($images) + 1)];
                            }
                        }
                    }
                @endphp
                @if(count($images) > 0)
                <div class="mt-8 bg-gray-50 rounded-2xl p-8 border border-gray-200">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <svg class="w-6 h-6 mr-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                        Images
                    </h3>
                    <div class="grid grid-cols-2 gap-3">
                        @foreach($images as $image)
                            <a href="#section-{{ $image['index'] }}"
                               class="group block aspect-square bg-white rounded-lg overflow-hidden border-2 border-gray-200 hover:border-green-400 transition-all duration-300 hover:shadow-md">
                                <img src="/storage/{{ $blog->content_blocks[$image['index']]['image'] }}"
                                     alt="{{ $image['content'] }}"
                                     class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                            </a>
                        @endforeach
                    </div>
                </div>
                @endif

                <!-- Links Collection -->
                @php
                    $links = [];
                    if($blog->content_blocks && count($blog->content_blocks) > 0) {
                        foreach($blog->content_blocks as $index => $block) {
                            if($block['type'] === 'link') {
                                $parts = explode('|', $block['content']);
                                $linkText = $parts[0] ?? 'Link ' . (count($links) + 1);
                                $links[] = ['index' => $index, 'text' => $linkText];
                            }
                        }
                    }
                @endphp
                @if(count($links) > 0)
                <div class="mt-8 bg-blue-50 rounded-2xl p-8 border border-blue-200">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <svg class="w-6 h-6 mr-3 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"/>
                        </svg>
                        Links
                    </h3>
                    <nav class="space-y-4">
                        @foreach($links as $link)
                            <a href="#section-{{ $link['index'] }}"
                               class="flex items-center p-4 bg-white rounded-lg border border-blue-200 hover:border-blue-400 hover:bg-blue-25 transition-all duration-300 group">
                                <div class="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4 group-hover:bg-blue-200 transition-colors">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                    </svg>
                                </div>
                                <div class="flex-1">
                                    <p class="text-sm font-semibold text-gray-900 group-hover:text-blue-700 transition-colors">{{ $link['text'] }}</p>
                                    <p class="text-xs text-gray-500">Click to view</p>
                                </div>
                                <svg class="w-4 h-4 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </a>
                        @endforeach
                    </nav>
                </div>
                @endif

                <!-- Author Bio -->
                <div class="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-gray-200">
                    <div class="flex flex-col items-start gap-6">
                        <div class="flex-shrink-0">
                            <div class="flex items-center justify-center h-16 w-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600">
                                <svg class="h-8 w-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                                </svg>
                            </div>
                        </div>
                        <div class="flex-1">
                            @if($blog->author)
                                <h4 class="text-lg font-bold text-gray-900">{{ $blog->author->name }}</h4>
                                <p class="text-gray-700 mt-2 leading-relaxed text-sm">
                                    Passionate about sharing insights and knowledge. Published {{ App\Models\Blog::where('author_id', $blog->author_id)->count() }} articles.
                                </p>
                            @else
                                <h4 class="text-lg font-bold text-gray-900">SEVLENT Editorial</h4>
                                <p class="text-gray-700 mt-2 leading-relaxed text-sm">
                                    Delivering quality content for tech enthusiasts and professionals.
                                </p>
                            @endif
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    </div>
</div>

<!-- Related Posts -->
@if($relatedBlogs->count() > 0)
<div class="bg-gradient-to-b from-gray-50 to-white py-20">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Related Posts</h2>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">Discover more articles that might interest you</p>
            <div class="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mt-6 rounded-full"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @foreach($relatedBlogs as $relatedBlog)
            <article class="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-gray-100 group">
                @if($relatedBlog->featured_image)
                <div class="relative h-56 bg-gray-200 overflow-hidden">
                    <img src="{{ asset('storage/' . $relatedBlog->featured_image) }}"
                         alt="{{ $relatedBlog->title }}"
                         class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                @endif

                <div class="p-6">
                    @if($relatedBlog->category)
                    <span class="inline-block px-3 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full mb-3">
                        {{ $relatedBlog->category->name }}
                    </span>
                    @endif

                    <h3 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                        <a href="{{ route('blogs.show', $relatedBlog->slug) }}" class="block">
                            {{ $relatedBlog->title }}
                        </a>
                    </h3>

                    <p class="text-gray-600 mb-4 line-clamp-3 leading-relaxed">
                        {{ Str::limit(strip_tags($relatedBlog->excerpt ?: $relatedBlog->content), 120) }}
                    </p>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center text-sm text-gray-500">
                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
                            </svg>
                            <time datetime="{{ $relatedBlog->published_at->format('Y-m-d') }}">
                                {{ $relatedBlog->published_at->format('M j, Y') }}
                            </time>
                        </div>
                        <a href="{{ route('blogs.show', $relatedBlog->slug) }}"
                           class="inline-flex items-center px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 hover:text-gray-900 font-medium rounded-md shadow-sm hover:shadow-md transform hover:-translate-y-0.5 transition-all duration-200 group border border-gray-200 hover:border-gray-300">
                            <span>Read More</span>
                            <svg class="w-4 h-4 ml-2 group-hover:translate-x-0.5 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </article>
            @endforeach
        </div>
    </div>
</div>
@endif

<!-- Newsletter Signup -->
<div class="bg-blue-600 py-16">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-3xl font-bold text-white mb-4">Stay Updated</h2>
        <p class="text-xl text-white mb-8">
            Subscribe to our newsletter for the latest insights and updates.
        </p>
        <form action="#" method="POST" class="max-w-md mx-auto">
            @csrf
            <div class="flex gap-4">
                <input type="email" name="email" placeholder="Enter your email"
                       class="flex-1 px-4 py-3 border-0 rounded-md focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600">
                <button type="submit" class="px-6 py-3 bg-white text-blue-600 font-medium rounded-md hover:bg-gray-50">
                    Subscribe
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
