@extends('frontend.layouts.app')

@section('title', 'Contact Us')

@section('content')
<!-- Hero Section -->
<div class="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 overflow-hidden pb-32">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-10">
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0); background-size: 40px 40px;"></div>
        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 1200 400" preserveAspectRatio="xMidYMid slice">
            <defs>
                <linearGradient id="contactLineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                    <stop offset="50%" style="stop-color:rgba(255,255,255,0.3);stop-opacity:1" />
                    <stop offset="100%" style="stop-color:rgba(255,255,255,0.1);stop-opacity:1" />
                </linearGradient>
            </defs>
            <line x1="0" y1="50" x2="1200" y2="50" stroke="url(#contactLineGradient)" stroke-width="1"/>
            <line x1="0" y1="150" x2="1200" y2="150" stroke="url(#contactLineGradient)" stroke-width="1"/>
            <line x1="0" y1="250" x2="1200" y2="250" stroke="url(#contactLineGradient)" stroke-width="1"/>
            <line x1="200" y1="0" x2="200" y2="400" stroke="url(#contactLineGradient)" stroke-width="1"/>
            <line x1="600" y1="0" x2="600" y2="400" stroke="url(#contactLineGradient)" stroke-width="1"/>
            <line x1="1000" y1="0" x2="1000" y2="400" stroke="url(#contactLineGradient)" stroke-width="1"/>
        </svg>
    </div>

    <!-- Floating Elements -->
    <div class="absolute inset-0">
        <div class="absolute top-20 left-20 w-4 h-4 bg-white rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute top-32 right-32 w-3 h-3 bg-white rounded-full opacity-30 animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute top-16 right-16 w-12 h-12 border-2 border-white rounded-lg opacity-10 rotate-45"></div>
    </div>

    <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent"></div>

    <div class="relative pt-32 pb-12">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                Get In Touch
            </h1>
            <p class="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed drop-shadow">
                We'd love to hear from you. Send us a message and we'll respond as soon as possible.
            </p>
        </div>
    </div>
</div>

<!-- Contact Form Overlay Section -->
<div class="relative -mt-24 z-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white/95 backdrop-blur-lg rounded-2xl shadow-2xl p-8 md:p-12 border border-white/20">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Contact Information -->
                <div class="lg:col-span-1 space-y-2">
                <!-- Address -->
                <div class="bg-white/50 rounded-xl p-5 hover:bg-white/70 transition-all hover:shadow-md border border-white/30 backdrop-blur">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Address</h3>
                            <p class="text-gray-600 mt-2">{!! nl2br(e($contactSettings['contact_address'])) !!}</p>
                        </div>
                    </div>
                </div>

                <!-- Phone -->
                <div class="bg-white/50 rounded-xl p-5 hover:bg-white/70 transition-all hover:shadow-md border border-white/30 backdrop-blur">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Phone</h3>
                            <p class="text-gray-600 mt-2"><a href="tel:{{ preg_replace('/[^0-9+]/', '', $contactSettings['contact_phone']) }}" class="hover:text-blue-600 transition-colors">{{ $contactSettings['contact_phone'] }}</a></p>
                        </div>
                    </div>
                </div>

                <!-- Email -->
                <div class="bg-white/50 rounded-xl p-5 hover:bg-white/70 transition-all hover:shadow-md border border-white/30 backdrop-blur">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Email</h3>
                            <p class="text-gray-600 mt-2"><a href="mailto:{{ $contactSettings['contact_email'] }}" class="hover:text-blue-600 transition-colors">{{ $contactSettings['contact_email'] }}</a></p>
                        </div>
                    </div>
                </div>

                <!-- Business Hours -->
                <div class="bg-white/50 rounded-xl p-5 hover:bg-white/70 transition-all hover:shadow-md border border-white/30 backdrop-blur">
                    <div class="flex items-start">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-bold text-gray-900">Business Hours</h3>
                            <p class="text-gray-600 mt-2">
                                {!! nl2br(e($contactSettings['contact_business_hours'])) !!}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="lg:col-span-2">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-8">Send us a Message</h2>

                    @if(session('success'))
                        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-md">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if($errors->any())
                        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
                            <ul class="list-disc list-inside">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form x-data="{ processing: false }" @submit="processing = true" action="{{ route('contact.store') }}" method="POST" class="space-y-6">
                        @csrf

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <!-- Name -->
                            <div>
                                <label for="name" class="block text-sm font-semibold text-gray-700">Full Name *</label>
                                <input type="text" name="name" id="name" value="{{ old('name') }}"
                                       class="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('name') border-red-300 @enderror"
                                       placeholder="Your full name"
                                       required>
                                @error('name')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>

                            <!-- Email -->
                            <div>
                                <label for="email" class="block text-sm font-semibold text-gray-700">Email Address *</label>
                                <input type="email" name="email" id="email" value="{{ old('email') }}"
                                       class="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('email') border-red-300 @enderror"
                                       placeholder="your.email@example.com"
                                       required>
                                @error('email')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <!-- Phone -->
                            <div>
                                <label for="phone" class="block text-sm font-semibold text-gray-700">Phone Number</label>
                                <input type="tel" name="phone" id="phone" value="{{ old('phone') }}" placeholder="Your phone number"
                                       class="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <!-- Subject -->
                            <div>
                                <label for="subject" class="block text-sm font-semibold text-gray-700">Subject *</label>
                                <input type="text" name="subject" id="subject" value="{{ old('subject') }}" placeholder="Subject of your inquiry"
                                       class="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('subject') border-red-300 @enderror"
                                       required>
                                @error('subject')
                                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>

                        <!-- Message -->
                        <div>
                            <label for="message" class="block text-sm font-semibold text-gray-700">Message *</label>
                            <textarea name="message" id="message" rows="5"
                                      class="mt-2 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('message') border-red-300 @enderror"
                                      placeholder="Tell us about your project or inquiry..." required>{{ old('message') }}</textarea>
                            @error('message')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Submit -->
                        <button type="submit" :disabled="processing" :class="processing ? 'opacity-60 cursor-not-allowed' : ''"
                                class="w-full inline-flex justify-center py-3 px-6 border border-transparent shadow-sm text-base font-semibold rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 hover:shadow-lg">
                            <span x-show="!processing" x-cloak class="inline-flex items-center">
                                Send Message
                                <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                                </svg>
                            </span>
                            <span x-show="processing" x-cloak class="inline-flex items-center space-x-3">
                                <svg class="animate-spin w-5 h-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                                </svg>
                                <span>Sending...</span>
                            </span>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Map Section -->
            <div class="lg:col-span-2 mt-12">
                <div class="text-center mb-8">
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">Find Us On Map</h3>
                    <p class="text-gray-600">Visit our office location</p>
                </div>

                <div class="rounded-lg shadow-lg overflow-hidden h-96 md:h-[280px]">
                    <iframe src="{{ $contactSettings['contact_map_url'] }}" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FAQ Section -->
<div class="bg-gradient-to-br from-gray-50 via-white to-blue-50 py-20 relative overflow-hidden">
    <!-- Background Pattern -->
    <div class="absolute inset-0 opacity-5">
        <div class="absolute inset-0" style="background-image: radial-gradient(circle at 2px 2px, rgba(59,130,246,0.3) 1px, transparent 0); background-size: 30px 30px;"></div>
    </div>

    <!-- Floating Elements -->
    <div class="absolute inset-0 pointer-events-none">
        <div class="absolute top-20 left-10 w-2 h-2 bg-blue-400 rounded-full opacity-20 animate-pulse"></div>
        <div class="absolute top-40 right-20 w-3 h-3 bg-purple-400 rounded-full opacity-15 animate-pulse" style="animation-delay: 1s;"></div>
        <div class="absolute bottom-20 left-1/4 w-1 h-1 bg-indigo-400 rounded-full opacity-25 animate-pulse" style="animation-delay: 2s;"></div>
    </div>

    <div class="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <div class="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mb-6 shadow-lg">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">{{ $contactSettings['faq_section_title'] }}</h2>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">{{ $contactSettings['faq_section_subtitle'] }}</p>
        </div>

        <div class="space-y-4" x-data="{ open: null }">
            @php
            $iconMap = [
                'clock' => 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
                'settings' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z',
                'lightbulb' => 'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z',
                'check' => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
                'calendar' => 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'
            ];
            
            $colorMap = [
                'blue' => ['from' => 'from-blue-500', 'to' => 'to-blue-600', 'text' => 'text-blue-600', 'hover' => 'text-blue-700', 'group' => 'text-blue-900', 'ring' => 'ring-blue-400'],
                'purple' => ['from' => 'from-purple-500', 'to' => 'to-purple-600', 'text' => 'text-purple-600', 'hover' => 'text-purple-700', 'group' => 'text-purple-900', 'ring' => 'ring-purple-400'],
                'indigo' => ['from' => 'from-indigo-500', 'to' => 'to-indigo-600', 'text' => 'text-indigo-600', 'hover' => 'text-indigo-700', 'group' => 'text-indigo-900', 'ring' => 'ring-indigo-400'],
                'green' => ['from' => 'from-green-500', 'to' => 'to-green-600', 'text' => 'text-green-600', 'hover' => 'text-green-700', 'group' => 'text-green-900', 'ring' => 'ring-green-400'],
                'orange' => ['from' => 'from-orange-500', 'to' => 'to-orange-600', 'text' => 'text-orange-600', 'hover' => 'text-orange-700', 'group' => 'text-orange-900', 'ring' => 'ring-orange-400']
            ];
            @endphp

            @forelse($faqs as $index => $faq)
            @php
            $colors = $colorMap[$faq->color] ?? $colorMap['blue'];
            $iconPath = $iconMap[$faq->icon] ?? $iconMap['clock'];
            $loopIndex = $index + 1;
            @endphp
            <!-- FAQ Item {{ $loopIndex }} -->
            <div class="group bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-xl transition-all duration-500 border border-white/50 overflow-hidden" :class="open === {{ $loopIndex }} ? 'ring-2 {{ $colors['ring'] }} ring-opacity-50 shadow-2xl' : ''">
                <button @click="open = open === {{ $loopIndex }} ? null : {{ $loopIndex }}" class="w-full px-8 py-6 flex items-center justify-between hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 transition-all duration-300">
                    <div class="flex items-center space-x-4">
                        <div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br {{ $colors['from'] }} {{ $colors['to'] }} rounded-xl flex items-center justify-center shadow-md">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $iconPath }}"/>
                            </svg>
                        </div>
                        <h3 class="text-lg font-bold text-gray-900 text-left group-hover:{{ $colors['group'] }} transition-colors">{{ $faq->question }}</h3>
                    </div>
                    <svg class="w-6 h-6 {{ $colors['text'] }} transition-all duration-300 group-hover:scale-110" :class="open === {{ $loopIndex }} ? 'rotate-180 {{ $colors['hover'] }}' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                    </svg>
                </button>
                <div x-show="open === {{ $loopIndex }}" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-95" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-95" class="px-8 pb-6">
                    <div class="pt-2 border-t border-gray-100">
                        <p class="text-gray-600 leading-relaxed">{{ $faq->answer }}</p>
                    </div>
                </div>
            </div>
            @empty
            <!-- No FAQs Message -->
            <div class="text-center py-12">
                <p class="text-gray-500 text-lg">No frequently asked questions available at this time.</p>
            </div>
            @endforelse
        </div>

        <!-- Additional Help -->
        <div class="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-100 shadow-lg text-center">
            <div class="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mb-4 shadow-md">
                <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <h3 class="text-2xl font-bold text-gray-900 mb-3">{{ $contactSettings['faq_help_title'] }}</h3>
            <p class="text-gray-600 mb-6 text-lg">{{ $contactSettings['faq_help_description'] }}</p>
            <a href="#contact-form" class="inline-flex items-center px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                {{ $contactSettings['faq_help_button_text'] }}
                <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/>
                </svg>
            </a>
        </div>
    </div>
</div>

@endsection
