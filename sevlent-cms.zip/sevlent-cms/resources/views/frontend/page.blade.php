@extends('frontend.layouts.app')

@php
    $seoable = $page;
@endphp

@section('content')

{{-- Page Banner - Only show if no hero section exists --}}
@if($page->banner && !$page->sections->where('type', 'hero')->count())
    <section>
        @if($page->banner->file_type === 'video')
        <video controls class="w-full">
            <source src="{{ $page->banner->url }}" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        @else
        <img src="{{ $page->banner->url }}" alt="{{ $page->title }}" class="w-full">
        @endif
    </section>
@endif

{{-- Dynamic Sections --}}
@foreach($page->sections as $section)
    @includeIf('frontend.sections.' . $section->type, ['section' => $section])
@endforeach

@endsection