<!-- Modern Navigation -->
<nav x-data="navigationState()" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300" :class="scrolled ? 'bg-white shadow-lg border-b border-gray-200' : 'bg-transparent border-b border-white/20 backdrop-blur-sm'">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-20">
            <!-- Logo & Brand -->
            <div class="flex items-center space-x-3">
                <!-- Dynamic Logo -->
                <div class="flex-shrink-0">
                    @if(isset($settings['logo']) && $settings['logo'])
                        <a href="{{ route('home') }}" class="block">
                            <img src="{{ asset('storage/' . $settings['logo']) }}"
                                 alt="{{ $settings['company_name'] ?? config('app.name', 'SEVLENT') }} Logo"
                                 class="h-10 w-auto max-w-[150px] object-contain">
                        </a>
                    @else
                        <!-- Fallback Logo -->
                        <a href="{{ route('home') }}" class="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg">
                            <span class="text-white font-bold text-lg">{{ substr($settings['company_name'] ?? config('app.name', 'SEVLENT'), 0, 1) }}</span>
                        </a>
                    @endif
                </div>
                <!-- Brand Name -->
                <div class="flex-shrink-0">
                    <a href="{{ route('home') }}" class="text-2xl font-bold transition-colors duration-300" :class="scrolled ? 'text-gray-900' : 'text-white'">
                        {{ $settings['company_name'] ?? config('app.name', 'SEVLENT') }}
                    </a>
                </div>
            </div>

            <!-- Desktop Navigation -->
            <div class="hidden lg:flex items-center space-x-6">
                <!-- Navigation Links -->
                <div class="flex items-center space-x-3">
                    {{-- Dynamic Navigation Menu --}}
                    @include('components.navigation', [
                        'menu' => 'Main Navigation',
                        'class' => 'main-navigation',
                        'depth' => 2
                    ])

                    {{-- Fallback hardcoded links if no menu exists --}}
                    @if(!\App\Models\Menu::where('name', 'Main Navigation')->exists())
                    <a href="{{ route('home') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('home') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Home
                    </a>
                    <a href="{{ route('services.index') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('services.*') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Services
                    </a>
                    <a href="{{ route('blogs.index') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('blogs.*') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Blog
                    </a>
                    <a href="{{ route('projects.index') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('projects.*') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Projects
                    </a>
                    <a href="{{ route('careers.index') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('careers.*') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Careers
                    </a>
                    <a href="{{ route('contact.index') }}" class="px-3 py-2 text-sm font-medium transition-colors duration-200 text-white" :class="scrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'" :style="request()->routeIs('contact.*') ? (scrolled ? 'color: var(--color-primary) !important' : 'color: #ffffff !important') : ''">
                        Contact
                    </a>
                    @endif
                </div>

                <!-- CTA Button -->
                <div class="flex items-center space-x-4">
                    <a href="{{ route('contact.index') }}" class="px-6 py-2.5 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5" :class="scrolled ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-white text-gray-900 hover:bg-gray-50'">
                        Get Started
                    </a>
                </div>
            </div>

            <!-- Mobile menu button -->
            <div class="lg:hidden">
                <button @click="mobileMenuOpen = !mobileMenuOpen"
                        type="button"
                        class="p-2 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-inset" :class="scrolled ? 'bg-gray-50 text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:ring-blue-500' : 'text-white hover:text-blue-200'"
                        aria-controls="mobile-menu"
                        :aria-expanded="mobileMenuOpen">
                    <span class="sr-only">Open main menu</span>
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path x-show="!mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        <path x-show="mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile menu -->
    <div x-show="mobileMenuOpen"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 transform -translate-y-2"
         x-transition:enter-end="opacity-100 transform translate-y-0"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 transform translate-y-0"
         x-transition:leave-end="opacity-0 transform -translate-y-2"
         class="lg:hidden bg-white border-t border-gray-200 shadow-lg"
         x-cloak>

        <div class="px-4 pt-2 pb-3 space-y-1">
            {{-- Dynamic Mobile Navigation Menu --}}
            @include('components.navigation-mobile', [
                'menu' => 'Main Navigation',
                'class' => 'mobile-navigation'
            ])

            {{-- Fallback hardcoded links if no menu exists --}}
            @if(!\App\Models\Menu::where('name', 'Main Navigation')->exists())
            <a href="{{ route('home') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('home') ? 'text-blue-600 bg-blue-50' : '' }}">
                Home
            </a>
            <a href="{{ route('services.index') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('services.*') ? 'text-blue-600 bg-blue-50' : '' }}">
                Services
            </a>
            <a href="{{ route('blogs.index') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('blogs.*') ? 'text-blue-600 bg-blue-50' : '' }}">
                Blog
            </a>
            <a href="{{ route('projects.index') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('projects.*') ? 'text-blue-600 bg-blue-50' : '' }}">
                Projects
            </a>
            <a href="{{ route('careers.index') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('careers.*') ? 'text-blue-600 bg-blue-50' : '' }}">
                Careers
            </a>
            <a href="{{ route('contact.index') }}" class="block px-3 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-lg transition-colors duration-200 {{ request()->routeIs('contact.*') ? 'text-blue-600 bg-blue-50' : '' }}">
                Contact
            </a>
            @endif

            <!-- Mobile CTA Button -->
            <div class="pt-4 pb-2">
                <a href="{{ route('contact.index') }}" class="block w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-full font-medium text-center transition-colors duration-200 shadow-md">
                    Get Started
                </a>
            </div>
        </div>
    </div>
</nav>

<script>
function navigationState() {
    return {
        scrolled: false,
        mobileMenuOpen: false,
        init() {
            this.updateScrollState();
            window.addEventListener('scroll', () => {
                this.updateScrollState();
            });
        },
        updateScrollState() {
            this.scrolled = window.scrollY > 50;
        }
    }
}
</script>

<style>
/* Override navigation component colors when navigation is transparent */
nav.bg-transparent .menu-link {
    color: white !important;
}

nav.bg-transparent .menu-link:hover {
    color: var(--color-primary-light) !important;
}

/* Ensure scrolled state overrides work */
nav.bg-white .menu-link {
    color: #374151 !important;
}

nav.bg-white .menu-link:hover {
    color: var(--color-primary) !important;
}

/* Cool sliding underline hover effect */
.menu-link {
    position: relative;
}

.menu-link::after {
    content: '';
    position: absolute;
    width: 0;
    height: 2px;
    bottom: 0;
    left: 50%;
    background-color: currentColor;
    transition: all 0.3s ease;
    transform: translateX(-50%);
}

.menu-link:hover::after {
    width: 100%;
}
</style>