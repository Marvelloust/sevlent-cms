<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- Cache Control - Force reload on theme changes -->
    @php
        $themeVersion = md5(setting('primary_color', '#3b82f6') . setting('secondary_color', '#8b5cf6') . setting('accent_color', '#10b981'));
    @endphp
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="theme-version" content="{{ $themeVersion }}">

    {{-- SEO Meta Tags --}}
    @include('components.seo-meta', ['seoable' => $seoable ?? null])

    <!-- Favicons -->
    @php
        $favicon = setting('favicon') ? asset('storage/' . setting('favicon')) : asset('favicon.ico');
    @endphp
    <link rel="icon" type="image/x-icon" href="{{ $favicon }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ $favicon }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ $favicon }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ $favicon }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:300,400,500,600,700&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <!-- Theme Styles -->
    @include('components.theme-styles')

    <!-- Custom Styles -->
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="font-sans antialiased">
    <!-- Navigation -->
    @include('frontend.layouts.navigation')

    <!-- Main Content -->
    <main>
        @yield('content')
    </main>

    <!-- Footer -->
    @include('frontend.layouts.footer')

    <!-- Flash Messages -->
    @if (session('success'))
        <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 5000)"
             class="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 5000)"
             class="fixed bottom-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {{ session('error') }}
        </div>
    @endif

    <!-- Auto-reload on theme change -->
    <script>
    (function() {
        const themeStyleElement = document.querySelector('style[data-theme-hash]');
        const currentThemeHash = themeStyleElement?.dataset.themeHash;
        const currentTimestamp = themeStyleElement?.dataset.timestamp;
        
        if (currentThemeHash) {
            const storedHash = localStorage.getItem('theme_hash');
            const storedTimestamp = localStorage.getItem('theme_timestamp');
            
            // If hash changed, force complete reload
            if (storedHash && storedHash !== currentThemeHash) {
                console.log('Theme changed detected - forcing reload...');
                // Clear all cached data
                if ('caches' in window) {
                    caches.keys().then(names => {
                        names.forEach(name => caches.delete(name));
                    });
                }
                // Update storage
                localStorage.setItem('theme_hash', currentThemeHash);
                localStorage.setItem('theme_timestamp', currentTimestamp);
                // Force hard reload with cache bypass
                window.location.href = window.location.href.split('?')[0] + '?t=' + currentTimestamp;
                return;
            }
            
            // Store current hash
            localStorage.setItem('theme_hash', currentThemeHash);
            localStorage.setItem('theme_timestamp', currentTimestamp);
            
            // Check for theme updates every 3 seconds
            let checkInterval = setInterval(function() {
                fetch(window.location.href.split('?')[0] + '?check=' + Date.now(), { 
                    cache: 'no-store',
                    headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
                })
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newStyleElement = doc.querySelector('style[data-theme-hash]');
                    const newHash = newStyleElement?.dataset.themeHash;
                    const newTimestamp = newStyleElement?.dataset.timestamp;
                    
                    if (newHash && newHash !== currentThemeHash) {
                        console.log('Theme update detected - reloading now...');
                        clearInterval(checkInterval);
                        // Clear all caches
                        if ('caches' in window) {
                            caches.keys().then(names => {
                                names.forEach(name => caches.delete(name));
                            });
                        }
                        localStorage.setItem('theme_hash', newHash);
                        localStorage.setItem('theme_timestamp', newTimestamp);
                        // Force complete reload
                        window.location.href = window.location.href.split('?')[0] + '?t=' + newTimestamp;
                    }
                })
                .catch(err => console.log('Theme check error:', err));
            }, 3000); // Check every 3 seconds
        }
    })();
    </script>
</body>
</html>