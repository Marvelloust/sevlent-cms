@extends('frontend.layouts.app')

@section('title', 'Our Services')

@section('content')
{{-- @php
    $backgroundMedia = $services->first()?->icon;
@endphp --}}
<!-- Hero Section -->
<div class="relative bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 overflow-hidden">
    {{-- Background Component --}}
    <x-background
        {{-- :backgroundMedia="$backgroundMedia" --}}
        backgroundVideoOverlay="bg-gradient-to-r from-blue-600/80 via-purple-600/40 to-transparent"
        pattern="dots"
        patternOpacity="0.1"
        floatingElements="true"
        gradient="hero-dark"
    />

    <div class="relative pt-32 pb-20">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg">
                Our Services
            </h1>
            <p class="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed drop-shadow">
                Discover our comprehensive range of software development and digital solutions designed to help your business grow.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#services-list" class="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-semibold rounded-lg text-blue-600 bg-white hover:bg-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1">
                    Explore Services
                    <svg class="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"/>
                    </svg>
                </a>
                <a href="{{ route('contact.index') }}" class="inline-flex items-center justify-center px-8 py-4 border-2 border-white/50 text-base font-semibold rounded-lg text-white hover:bg-white/10 hover:border-white transition-all duration-300">
                    Get In Touch
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Services Content -->
<div id="services-list" class="bg-gray-50 py-16 -mt-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <!-- Categories Filter -->
        @if($categories->count() > 0)
        <div class="mb-12">
            <div class="flex flex-wrap justify-center gap-4">
                <a href="{{ route('services.index') }}"
                   class="px-6 py-3 rounded-full text-sm font-medium {{ !request('category') ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700' }} hover:bg-blue-700 hover:text-white transition-colors">
                    All Services
                </a>
                @foreach($categories as $category)
                <a href="{{ route('services.index', ['category' => $category->slug]) }}"
                   class="px-6 py-3 rounded-full text-sm font-medium {{ request('category') === $category->slug ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700' }} hover:bg-blue-700 hover:text-white transition-colors">
                    {{ $category->name }}
                </a>
                @endforeach
            </div>
        </div>
        @endif

        <!-- Services Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @forelse($services as $service)
            <div class="group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
                @if($service->icon)
                <div class="h-48 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center group-hover:from-blue-50 group-hover:to-indigo-50 transition-all duration-300 overflow-hidden">
                    @if($service->icon->file_type === 'video')
                        <video class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" muted loop autoplay playsinline>
                            <source src="{{ $service->icon->url }}" type="{{ $service->icon->mime_type }}">
                        </video>
                    @else
                        <img src="{{ $service->icon->url }}"
                             alt="{{ $service->name }}"
                             class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                    @endif
                </div>
                @else
                <div class="h-48 bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                    <svg class="w-16 h-16 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                    </svg>
                </div>
                @endif

                <div class="p-8">
                    @if($service->category)
                    <span class="inline-block px-3 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full mb-4 uppercase tracking-wide">
                        {{ $service->category->name }}
                    </span>
                    @endif

                    <h3 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors leading-tight">
                        <a href="{{ route('services.show', $service->slug) }}" class="hover:text-blue-600 transition-colors">
                            {{ $service->name }}
                        </a>
                    </h3>

                    <p class="text-gray-600 mb-6 line-clamp-3 leading-relaxed">
                        {{ Str::limit(strip_tags($service->short_description), 150) }}
                    </p>

                    <div class="pt-4 border-t border-gray-100">
                        <a href="{{ route('services.show', $service->slug) }}"
                           class="inline-flex items-center text-blue-600 hover:text-blue-800 font-semibold group-hover:gap-2 transition-all duration-300">
                            Learn More
                            <svg class="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            @empty
            <div class="col-span-full text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No services available</h3>
                <p class="mt-1 text-sm text-gray-500">Check back later for our latest services.</p>
            </div>
            @endforelse
        </div>

        <!-- Pagination -->
        @if($services->hasPages())
        <div class="mt-12">
            {{ $services->links() }}
        </div>
        @endif
    </div>
</div>
@endsection