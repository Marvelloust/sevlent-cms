@extends('admin.layouts.app')

@section('title', 'Edit Career')
@section('page-title', 'Edit Career')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-briefcase mr-3"></i>Edit Career
                    </h1>
                    <p class="text-white">{{ $career->job_title }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $career->status === 'open' ? 'status-success' : 'status-danger' }}">
                            <i class="fas {{ $career->status === 'open' ? 'fa-door-open' : 'fa-door-closed' }} mr-1"></i>
                            {{ ucfirst($career->status) }}
                        </span>
                        <span class="ml-3 text-indigo-200 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Posted {{ $career->created_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.careers.show', $career) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-eye mr-2"></i>View Details
                    </a>
                    <a href="{{ route('admin.careers.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Careers
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.careers.update', $career) }}">
            @csrf
            @method('PUT')

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Essential job details and requirements</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Job Title -->
                    <div class="lg:col-span-2">
                        <label for="job_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-briefcase mr-2 text-gray-500"></i>Job Title <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="job_title" id="job_title" value="{{ old('job_title', $career->job_title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('job_title') border-red-500 @enderror"
                               placeholder="Enter job title" required>
                        @error('job_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Job Description -->
                    <div class="lg:col-span-2">
                        <label for="job_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-alt mr-2 text-gray-500"></i>Job Description
                        </label>
                        <textarea name="job_description" id="job_description" rows="5"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical @error('job_description') border-red-500 @enderror"
                                  placeholder="Describe the job role and responsibilities">{{ old('job_description', $career->job_description) }}</textarea>
                        @error('job_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Requirements -->
                    <div class="lg:col-span-2">
                        <label for="requirements" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-list-check mr-2 text-gray-500"></i>Requirements
                        </label>
                        <textarea name="requirements" id="requirements" rows="4"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical @error('requirements') border-red-500 @enderror"
                                  placeholder="List the job requirements and qualifications">{{ old('requirements', $career->requirements) }}</textarea>
                        @error('requirements')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Job Details Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-building mr-2 text-green-600"></i>Job Details
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Work arrangement and position details</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Location -->
                    <div>
                        <label for="location" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-map-marker-alt mr-2 text-gray-500"></i>Location
                        </label>
                        <input type="text" name="location" id="location" value="{{ old('location', $career->location) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('location') border-red-500 @enderror"
                               placeholder="e.g., Lagos, Nigeria">
                        @error('location')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Employment Type -->
                    <div>
                        <label for="employment_type" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-clock mr-2 text-gray-500"></i>Employment Type <span class="text-red-500">*</span>
                        </label>
                        <select name="employment_type" id="employment_type"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('employment_type') border-red-500 @enderror">
                            <option value="full-time" {{ old('employment_type', $career->employment_type) == 'full-time' ? 'selected' : '' }}>Full Time</option>
                            <option value="part-time" {{ old('employment_type', $career->employment_type) == 'part-time' ? 'selected' : '' }}>Part Time</option>
                            <option value="contract" {{ old('employment_type', $career->employment_type) == 'contract' ? 'selected' : '' }}>Contract</option>
                            <option value="freelance" {{ old('employment_type', $career->employment_type) == 'freelance' ? 'selected' : '' }}>Freelance</option>
                        </select>
                        @error('employment_type')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Department -->
                    <div>
                        <label for="department" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-sitemap mr-2 text-gray-500"></i>Department
                        </label>
                        <input type="text" name="department" id="department" value="{{ old('department', $career->department) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('department') border-red-500 @enderror"
                               placeholder="e.g., Engineering, Marketing, Sales">
                        @error('department')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Experience Level -->
                    <div>
                        <label for="experience_level" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-chart-line mr-2 text-gray-500"></i>Experience Level
                        </label>
                        <select name="experience_level" id="experience_level"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('experience_level') border-red-500 @enderror">
                            <option value="" {{ old('experience_level', $career->experience_level) == '' ? 'selected' : '' }}>Select Level</option>
                            <option value="entry-level" {{ old('experience_level', $career->experience_level) == 'entry-level' ? 'selected' : '' }}>Entry Level</option>
                            <option value="mid-level" {{ old('experience_level', $career->experience_level) == 'mid-level' ? 'selected' : '' }}>Mid Level</option>
                            <option value="senior-level" {{ old('experience_level', $career->experience_level) == 'senior-level' ? 'selected' : '' }}>Senior Level</option>
                            <option value="executive" {{ old('experience_level', $career->experience_level) == 'executive' ? 'selected' : '' }}>Executive</option>
                        </select>
                        @error('experience_level')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Work Type -->
                    <div>
                        <label for="work_type" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-home mr-2 text-gray-500"></i>Work Type <span class="text-red-500">*</span>
                        </label>
                        <select name="work_type" id="work_type"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('work_type') border-red-500 @enderror">
                            <option value="onsite" {{ old('work_type', $career->work_type) == 'onsite' ? 'selected' : '' }}>On-site</option>
                            <option value="remote" {{ old('work_type', $career->work_type) == 'remote' ? 'selected' : '' }}>Remote</option>
                            <option value="hybrid" {{ old('work_type', $career->work_type) == 'hybrid' ? 'selected' : '' }}>Hybrid</option>
                        </select>
                        @error('work_type')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Compensation & Openings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-dollar-sign mr-2 text-yellow-600"></i>Compensation & Openings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Salary information and position availability</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Salary Range -->
                    <div>
                        <label for="salary_range" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-money-bill-wave mr-2 text-gray-500"></i>Salary Range
                        </label>
                        <input type="text" name="salary_range" id="salary_range" value="{{ old('salary_range', $career->salary_range) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-all duration-200 @error('salary_range') border-red-500 @enderror"
                               placeholder="e.g., $50,000 - $70,000 per year">
                        @error('salary_range')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Number of Openings -->
                    <div>
                        <label for="number_of_openings" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-users mr-2 text-gray-500"></i>Number of Openings
                        </label>
                        <input type="number" name="number_of_openings" id="number_of_openings" value="{{ old('number_of_openings', $career->number_of_openings) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-all duration-200 @error('number_of_openings') border-red-500 @enderror"
                               placeholder="e.g., 1" min="1">
                        @error('number_of_openings')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Application Details Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-calendar-alt mr-2 text-purple-600"></i>Application Details
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Deadlines and contact information</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Application Deadline -->
                    <div>
                        <label for="application_deadline" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-calendar-times mr-2 text-gray-500"></i>Application Deadline
                        </label>
                        <input type="date" name="application_deadline" id="application_deadline" value="{{ old('application_deadline', $career->application_deadline ? $career->application_deadline->format('Y-m-d') : '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 @error('application_deadline') border-red-500 @enderror">
                        @error('application_deadline')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Expiry Date -->
                    <div>
                        <label for="expiry_date" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-calendar-check mr-2 text-gray-500"></i>Expiry Date
                        </label>
                        <input type="date" name="expiry_date" id="expiry_date" value="{{ old('expiry_date', $career->expiry_date ? $career->expiry_date->format('Y-m-d') : '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 @error('expiry_date') border-red-500 @enderror">
                        @error('expiry_date')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Contact Email -->
                    <div class="lg:col-span-2">
                        <label for="contact_email" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-envelope mr-2 text-gray-500"></i>Contact Email
                        </label>
                        <input type="email" name="contact_email" id="contact_email" value="{{ old('contact_email', $career->contact_email) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 @error('contact_email') border-red-500 @enderror"
                               placeholder="hiring@company.com">
                        @error('contact_email')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Additional Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-plus-circle mr-2 text-indigo-600"></i>Additional Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Skills, benefits, and company overview</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Skills -->
                    <div class="lg:col-span-2">
                        <label for="skills" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-code mr-2 text-gray-500"></i>Skills & Technologies
                        </label>
                        <textarea name="skills" id="skills" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 resize-vertical @error('skills') border-red-500 @enderror"
                                  placeholder="Enter skills separated by commas (e.g., PHP, Laravel, JavaScript, React)">{{ old('skills', is_array($career->skills) ? implode(', ', $career->skills) : $career->skills) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Enter skills separated by commas
                        </p>
                        @error('skills')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Benefits -->
                    <div class="lg:col-span-2">
                        <label for="benefits" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-gift mr-2 text-gray-500"></i>Benefits
                        </label>
                        <textarea name="benefits" id="benefits" rows="4"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 resize-vertical @error('benefits') border-red-500 @enderror"
                                  placeholder="Enter benefits separated by commas (e.g., Health Insurance, Flexible Hours, Remote Work)">{{ old('benefits', is_array($career->benefits) ? implode(', ', $career->benefits) : $career->benefits) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Enter benefits separated by commas
                        </p>
                        @error('benefits')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Company Overview -->
                    <div class="lg:col-span-2">
                        <label for="company_overview" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-building mr-2 text-gray-500"></i>Company Overview
                        </label>
                        <textarea name="company_overview" id="company_overview" rows="5"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 resize-vertical @error('company_overview') border-red-500 @enderror"
                                  placeholder="Brief overview of the company and culture">{{ old('company_overview', $career->company_overview) }}</textarea>
                        @error('company_overview')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-cog mr-2 text-orange-600"></i>Job Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Configure job posting status</p>
            </div>
            <div class="px-6 py-6">
                <!-- Status -->
                <div class="mb-6">
                    <label for="status" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                        <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Job Status <span class="text-red-500">*</span>
                    </label>
                    <div class="flex items-center space-x-6">
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="open" {{ old('status', $career->status) == 'open' ? 'checked' : '' }}
                                   class="form-radio h-5 w-5 text-green-600 focus:ring-green-500">
                            <span class="ml-2 text-sm font-medium text-gray-700">
                                <i class="fas fa-door-open mr-1" style="color: #16a34a"></i>Open
                            </span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="closed" {{ old('status', $career->status) == 'closed' ? 'checked' : '' }}
                                   class="form-radio h-5 w-5 text-red-600 focus:ring-red-500">
                            <span class="ml-2 text-sm font-medium text-gray-700">
                                <i class="fas fa-door-closed mr-1" style="color: #dc2626"></i>Closed
                            </span>
                        </label>
                    </div>
                    @error('status')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.careers.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update Career
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection