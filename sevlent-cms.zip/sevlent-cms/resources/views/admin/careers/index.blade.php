@extends('admin.layouts.app')

@section('title', 'Careers')
@section('page-title', 'Manage Careers')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r  from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-briefcase mr-3"></i>Careers Management
                    </h1>
                    <p class="text-white">Manage job openings and career opportunities</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.careers.create') }}" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-green-600 font-semibold rounded-lg shadow-md hover:bg-green-50 transition-all duration-200 transform hover:scale-105">
                        <i class="fas fa-plus mr-2"></i>
                        Create New Career
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <i class="fas fa-briefcase text-blue-600 dark:text-blue-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Total Careers</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ $totalCareers }}</p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                    <i class="fas fa-check-circle text-green-600 dark:text-green-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Open Positions</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ $openCareers }}</p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-red-500">
            <div class="flex items-center">
                <div class="p-3 bg-red-100 dark:bg-red-900 rounded-full">
                    <i class="fas fa-times-circle text-red-600 dark:text-red-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Closed Positions</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ $closedCareers }}</p>
                </div>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
            <div class="flex items-center">
                <div class="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-full">
                    <i class="fas fa-clock text-yellow-600 dark:text-yellow-400 text-xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Expiring Soon</p>
                    <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ $expiringSoon }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Careers Table -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Filters Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <form method="GET" action="{{ route('admin.careers.index') }}" class="space-y-3">
                <!-- All Filters in One Line -->
                <div class="flex flex-wrap gap-3">
                    <!-- Search -->
                    <div class="w-80">
                        <label for="search" class="sr-only">Search careers</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" name="search" id="search" value="{{ request('search') }}"
                                   class="block w-full pl-10 pr-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm"
                                   placeholder="Search careers by job title, department, or location...">
                        </div>
                    </div>

                    <!-- Status Filter -->
                    <div class="w-32">
                        <label for="status" class="sr-only">Filter by status</label>
                        <select name="status" id="status"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" {{ request('status') === 'all' || !request('status') ? 'selected' : '' }}>All Status</option>
                            <option value="open" {{ request('status') === 'open' ? 'selected' : '' }}>Open</option>
                            <option value="closed" {{ request('status') === 'closed' ? 'selected' : '' }}>Closed</option>
                        </select>
                    </div>

                    <!-- Employment Type Filter -->
                    <div class="w-40">
                        <label for="employment_type" class="sr-only">Filter by employment type</label>
                        <select name="employment_type" id="employment_type"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" {{ request('employment_type') === 'all' || !request('employment_type') ? 'selected' : '' }}>All Types</option>
                            <option value="full-time" {{ request('employment_type') === 'full-time' ? 'selected' : '' }}>Full-time</option>
                            <option value="part-time" {{ request('employment_type') === 'part-time' ? 'selected' : '' }}>Part-time</option>
                            <option value="contract" {{ request('employment_type') === 'contract' ? 'selected' : '' }}>Contract</option>
                            <option value="freelance" {{ request('employment_type') === 'freelance' ? 'selected' : '' }}>Freelance</option>
                        </select>
                    </div>

                    <!-- Work Type Filter -->
                    <div class="w-36">
                        <label for="work_type" class="sr-only">Filter by work type</label>
                        <select name="work_type" id="work_type"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="all" {{ request('work_type') === 'all' || !request('work_type') ? 'selected' : '' }}>All Work</option>
                            <option value="remote" {{ request('work_type') === 'remote' ? 'selected' : '' }}>Remote</option>
                            <option value="hybrid" {{ request('work_type') === 'hybrid' ? 'selected' : '' }}>Hybrid</option>
                            <option value="onsite" {{ request('work_type') === 'onsite' ? 'selected' : '' }}>On-site</option>
                        </select>
                    </div>

                    <!-- Sort Options -->
                    <div class="w-32">
                        <label for="sort_by" class="sr-only">Sort by</label>
                        <select name="sort_by" id="sort_by"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="created_at" {{ request('sort_by') === 'created_at' || !request('sort_by') ? 'selected' : '' }}>Created Date</option>
                            <option value="job_title" {{ request('sort_by') === 'job_title' ? 'selected' : '' }}>Job Title</option>
                            <option value="location" {{ request('sort_by') === 'location' ? 'selected' : '' }}>Location</option>
                            <option value="employment_type" {{ request('sort_by') === 'employment_type' ? 'selected' : '' }}>Employment Type</option>
                            <option value="work_type" {{ request('sort_by') === 'work_type' ? 'selected' : '' }}>Work Type</option>
                            <option value="status" {{ request('sort_by') === 'status' ? 'selected' : '' }}>Status</option>
                            <option value="expiry_date" {{ request('sort_by') === 'expiry_date' ? 'selected' : '' }}>Expiry Date</option>
                            <option value="updated_at" {{ request('sort_by') === 'updated_at' ? 'selected' : '' }}>Updated Date</option>
                        </select>
                    </div>

                    <!-- Sort Direction -->
                    <div class="w-32">
                        <label for="sort_direction" class="sr-only">Sort direction</label>
                        <select name="sort_direction" id="sort_direction"
                                class="block w-full border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg focus:ring-green-500 focus:border-green-500 text-sm py-2 px-3">
                            <option value="desc" {{ request('sort_direction') === 'desc' || !request('sort_direction') ? 'selected' : '' }}>Descending</option>
                            <option value="asc" {{ request('sort_direction') === 'asc' ? 'selected' : '' }}>Ascending</option>
                        </select>
                    </div>
                </div>

                <!-- Buttons on Second Line -->
                <div class="flex gap-2">
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="{{ route('admin.careers.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white text-sm font-medium rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors duration-150">
                        <i class="fas fa-times mr-2"></i>Clear
                    </a>
                </div>
            </form>
        </div>

        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-300">
                    <i class="fas fa-list mr-2 text-gray-600"></i>All Career Opportunities
                    @if(request('search') || request('status') !== 'all' && request('status') || request('employment_type') !== 'all' && request('employment_type') || request('work_type') !== 'all' && request('work_type'))
                        <span class="text-sm font-normal text-gray-600 dark:text-gray-400 ml-2">
                            ({{ $careers->total() }} result{{ $careers->total() !== 1 ? 's' : '' }})
                        </span>
                    @endif
                </h3>
                @if(request('search') || request('status') && request('status') !== 'all' || request('employment_type') && request('employment_type') !== 'all' || request('work_type') && request('work_type') !== 'all')
                    <div class="mt-2 sm:mt-0 flex flex-wrap gap-2">
                        @if(request('search'))
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300">
                                Search: "{{ request('search') }}"
                                <a href="{{ request()->fullUrlWithQuery(['search' => null]) }}" class="ml-1 text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        @endif
                        @if(request('status') && request('status') !== 'all')
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300">
                                Status: {{ ucfirst(request('status')) }}
                                <a href="{{ request()->fullUrlWithQuery(['status' => null]) }}" class="ml-1 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        @endif
                        @if(request('employment_type') && request('employment_type') !== 'all')
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-300">
                                Type: {{ ucfirst(str_replace('-', ' ', request('employment_type'))) }}
                                <a href="{{ request()->fullUrlWithQuery(['employment_type' => null]) }}" class="ml-1 text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        @endif
                        @if(request('work_type') && request('work_type') !== 'all')
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900/20 text-indigo-800 dark:text-indigo-300">
                                Work: {{ ucfirst(request('work_type')) }}
                                <a href="{{ request()->fullUrlWithQuery(['work_type' => null]) }}" class="ml-1 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200">
                                    <i class="fas fa-times"></i>
                                </a>
                            </span>
                        @endif
                    </div>
                @endif
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50 dark:bg-gray-900">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-briefcase mr-2"></i>Job Title & Details
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-map-marker-alt mr-2"></i>Location & Type
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-info-circle mr-2"></i>Status & Expiry
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Created
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    @forelse($careers as $career)
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-12 h-12">
                                        <div class="w-12 h-12 rounded-lg bg-gradient-to-r from-green-500 to-teal-500 flex items-center justify-center">
                                            <i class="fas fa-briefcase text-white text-sm"></i>
                                        </div>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900 dark:text-white">{{ $career->job_title }}</div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400">
                                            {{ $career->department ? $career->department : 'No Department' }}
                                            @if($career->number_of_openings)
                                                • {{ $career->number_of_openings }} opening{{ $career->number_of_openings > 1 ? 's' : '' }}
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                                <div class="space-y-1">
                                    <div class="flex items-center">
                                        <i class="fas fa-map-marker-alt text-gray-400 mr-2"></i>
                                        {{ $career->location ?: 'Not specified' }}
                                    </div>
                                    <div class="flex items-center">
                                        <i class="fas fa-clock text-gray-400 mr-2"></i>
                                        {{ ucfirst(str_replace('-', ' ', $career->employment_type)) }}
                                    </div>
                                    <div class="flex items-center">
                                        <i class="fas fa-building text-gray-400 mr-2"></i>
                                        {{ ucfirst($career->work_type) }}
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="space-y-2">
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $career->status === 'open' ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 border border-green-200 dark:border-green-800' : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300 border border-red-200 dark:border-red-800' }}">
                                        <i class="fas {{ $career->status === 'open' ? 'fa-check-circle' : 'fa-times-circle' }} mr-1"></i>
                                        {{ ucfirst($career->status) }}
                                    </span>
                                    @if($career->expiry_date)
                                        <div class="text-xs text-gray-500 dark:text-gray-400">
                                            <i class="fas fa-calendar-times mr-1"></i>
                                            Expires: {{ $career->expiry_date->format('M d, Y') }}
                                            @if($career->expiry_date->isPast() && $career->status === 'open')
                                                <span class="text-red-600 dark:text-red-400 font-medium">(Expired)</span>
                                            @elseif($career->expiry_date->diffInDays(now()) <= 7 && $career->status === 'open')
                                                <span class="text-yellow-600 dark:text-yellow-400 font-medium">(Soon)</span>
                                            @endif
                                        </div>
                                    @else
                                        <div class="text-xs text-gray-500 dark:text-gray-400">
                                            <i class="fas fa-infinity mr-1"></i>No expiry date
                                        </div>
                                    @endif
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                                {{ $career->created_at->format('M d, Y') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="{{ route('admin.careers.show', $career) }}" class="inline-flex items-center px-3 py-1 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-200 dark:hover:bg-blue-900/40 transition-colors duration-150">
                                        <i class="fas fa-eye mr-1"></i>View
                                    </a>
                                    <a href="{{ route('admin.careers.edit', $career) }}" class="inline-flex items-center px-3 py-1 bg-indigo-100 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded-md hover:bg-indigo-200 dark:hover:bg-indigo-900/40 transition-colors duration-150">
                                        <i class="fas fa-edit mr-1"></i>Edit
                                    </a>
                                    <form method="POST" action="{{ route('admin.careers.destroy', $career) }}" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" class="inline-flex items-center px-3 py-1 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded-md hover:bg-red-200 dark:hover:bg-red-900/40 transition-colors duration-150" onclick="showDeleteConfirmation('Are you sure you want to delete this career opportunity?', () => { this.closest('form').submit(); })">
                                            <i class="fas fa-trash mr-1"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center">
                                    <i class="fas fa-briefcase text-gray-300 text-4xl mb-4"></i>
                                    <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">No career opportunities found</h3>
                                    <p class="text-gray-500 dark:text-gray-400 mb-4">
                                        @if(request('search') || request('status') !== 'all' && request('status') || request('employment_type') !== 'all' && request('employment_type') || request('work_type') !== 'all' && request('work_type'))
                                            No career opportunities match your current filters. Try adjusting your search criteria.
                                        @else
                                            Get started by creating your first career opportunity.
                                        @endif
                                    </p>
                                    @if(!request('search') && (!request('status') || request('status') === 'all') && (!request('employment_type') || request('employment_type') === 'all') && (!request('work_type') || request('work_type') === 'all'))
                                        <a href="{{ route('admin.careers.create') }}" class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-150">
                                            <i class="fas fa-plus mr-2"></i>Create Your First Career
                                        </a>
                                    @else
                                        <a href="{{ route('admin.careers.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-150">
                                            <i class="fas fa-times mr-2"></i>Clear Filters
                                        </a>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        @if($careers->hasPages())
            <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium">{{ $careers->firstItem() }}</span> to
                            <span class="font-medium">{{ $careers->lastItem() }}</span> of
                            <span class="font-medium">{{ $careers->total() }}</span> results
                        </p>
                    </div>
                    <div class="flex space-x-1">
                        {{-- Previous Page Link --}}
                        @if ($careers->onFirstPage())
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-l-lg">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </span>
                        @else
                            <a href="{{ $careers->previousPageUrl() }}" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-l-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                <i class="fas fa-chevron-left mr-1"></i>
                                Previous
                            </a>
                        @endif

                        {{-- Pagination Elements --}}
                        @foreach ($careers->getUrlRange(1, $careers->lastPage()) as $page => $url)
                            @if ($page == $careers->currentPage())
                                <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-green-600 border border-green-600 cursor-default">
                                    {{ $page }}
                                </span>
                            @else
                                <a href="{{ $url }}" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                    {{ $page }}
                                </a>
                            @endif
                        @endforeach

                        {{-- Next Page Link --}}
                        @if ($careers->hasMorePages())
                            <a href="{{ $careers->nextPageUrl() }}" class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-r-lg hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 focus:z-10 focus:outline-none focus:ring-1 focus:ring-green-500 focus:border-green-500">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </a>
                        @else
                            <span class="relative inline-flex items-center px-3 py-2 text-sm font-medium text-gray-400 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 cursor-not-allowed rounded-r-lg">
                                Next
                                <i class="fas fa-chevron-right ml-1"></i>
                            </span>
                        @endif
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>

@if(session('success'))
    <div class="fixed top-4 right-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg shadow-lg z-50" id="success-message">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            {{ session('success') }}
        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('success-message').style.display = 'none';
        }, 5000);
    </script>
@endif

@if(session('error'))
    <div class="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg shadow-lg z-50" id="error-message">
        <div class="flex items-center">
            <i class="fas fa-exclamation-circle mr-2"></i>
            {{ session('error') }}
        </div>
    </div>
    <script>
        setTimeout(() => {
            document.getElementById('error-message').style.display = 'none';
        }, 5000);
    </script>
@endif
@endsection
