@extends('admin.layouts.app')

@section('title', 'View Career')
@section('page-title', 'View Career')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $career->status === 'open' || $career->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                            <i class="fas {{ $career->status === 'open' || $career->status === 'active' ? 'fa-check-circle' : 'fa-times-circle' }} mr-1"></i>
                            {{ ucfirst($career->status) }}
                        </span>
                        @if($career->application_deadline)
                        <span class="ml-3 text-sm font-medium" style="color: #d1fae5;">
                            <i class="fas fa-calendar-check mr-1"></i>
                            Deadline: {{ $career->application_deadline->format('M d, Y') }}
                        </span>
                        @endif
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $career->job_title }}</h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #d1fae5;">
                        <span>
                            <i class="fas fa-map-marker-alt mr-2"></i>{{ $career->location ?? 'Remote' }}
                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Posted {{ $career->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $career->updated_at->diffForHumans() }}
                        </span>
                        <span>
                            <i class="fas fa-link mr-2"></i><code class="bg-green-500 bg-opacity-30 px-2 py-1 rounded">{{ $career->slug }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.job-applications.index', ['career_id' => $career->id]) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-users mr-2"></i>Applications
                    </a>
                    <a href="{{ route('admin.careers.edit', $career) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg transition-all duration-200" style="background-color: white; color: #059669;" onmouseover="this.style.backgroundColor='#f0fdf4'" onmouseout="this.style.backgroundColor='white'">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="{{ route('admin.careers.index') }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Column -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Basic Information -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Basic Information</h3>
                </div>
                <div class="px-6 py-6">
                    <p class="text-gray-700 dark:text-gray-300">{{ $career->excerpt ?? 'Essential job details and requirements' }}</p>
                    <dl class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Job Title</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->job_title }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Location</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->location ?? '—' }}</p>
                        </div>
                    </dl>
                </div>
            </div>

            <!-- Job Description & Requirements -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Job Description</h3>
                </div>
                <div class="px-6 py-6">
                    {!! $career->job_description ? '<div class="prose max-w-none dark:prose-invert dark:text-gray-300">'. $career->job_description .'</div>' : '<p class="text-gray-700 dark:text-gray-300">No description provided.</p>' !!}
                </div>
                @if($career->requirements)
                <div class="px-6 py-6 border-t border-gray-100 dark:border-gray-700">
                    <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-2">Requirements</h4>
                    <p class="text-gray-700 dark:text-gray-300">{!! nl2br(e($career->requirements)) !!}</p>
                </div>
                @endif
            </div>

            <!-- Additional Information -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Additional Information</h3>
                </div>
                <div class="px-6 py-6 space-y-4">
                    <div>
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Skills & Technologies</p>
                        @php
                            $skills = [];
                            if(isset($career->skills)) {
                                if(is_array($career->skills)) {
                                    $skills = $career->skills;
                                } elseif(is_string($career->skills)) {
                                    $skills = array_filter(array_map('trim', explode(',', $career->skills)));
                                }
                            }
                        @endphp
                        @if(count($skills) > 0)
                            <div class="flex flex-wrap gap-2">
                                @foreach($skills as $skill)
                                    <span class="inline-flex items-center px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 text-sm">{{ $skill }}</span>
                                @endforeach
                            </div>
                        @else
                            <p class="text-sm text-gray-700 dark:text-gray-300">—</p>
                        @endif
                    </div>
                    <div>
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Benefits</p>
                        @php
                            $benefits = [];
                            if(isset($career->benefits)) {
                                if(is_array($career->benefits)) {
                                    $benefits = $career->benefits;
                                } elseif(is_string($career->benefits)) {
                                    $benefits = preg_split('/\r\n|\r|\n/', $career->benefits);
                                }
                            }
                        @endphp
                        @if(count($benefits) > 0)
                            <div class="space-y-2">
                                @foreach($benefits as $b)
                                    <p class="text-sm text-gray-700 dark:text-gray-300">{{ trim($b) }}</p>
                                @endforeach
                            </div>
                        @else
                            <p class="text-sm text-gray-700 dark:text-gray-300">—</p>
                        @endif
                    </div>
                    <div>
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Company Overview</p>
                        @if($career->company_overview)
                            <p class="text-sm text-gray-700 dark:text-gray-300">{!! nl2br(e($career->company_overview)) !!}</p>
                        @else
                            <p class="text-sm text-gray-700 dark:text-gray-300">—</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Job Details -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-briefcase mr-2 text-blue-600"></i>Job Details
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="space-y-4">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Employment Type</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ ucfirst($career->employment_type ?? '—') }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Department</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->department ?? '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Experience Level</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->experience_level ?? '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Work Type</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->work_type ?? '—' }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Compensation & Openings -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-dollar-sign mr-2 text-green-600"></i>Compensation & Openings
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="space-y-4">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Salary Range</p>
                            @php
                                $salaryRaw = $career->salary_range ?? null;
                                $salaryNumeric = null;
                                if ($salaryRaw !== null) {
                                    if (is_numeric($salaryRaw)) {
                                        $salaryNumeric = (float) $salaryRaw;
                                    } else {
                                        $clean = preg_replace('/[^0-9.]/', '', $salaryRaw);
                                        if ($clean !== '') {
                                            $salaryNumeric = (float) $clean;
                                        }
                                    }
                                }
                            @endphp
                            <p class="text-sm text-gray-700 dark:text-gray-300">
                                @if($salaryNumeric)
                                    ${{ number_format($salaryNumeric, 0) }}
                                @elseif($salaryRaw)
                                    {{ $salaryRaw }}
                                @else
                                    —
                                @endif
                            </p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Number of Openings</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->number_of_openings ?? '1' }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Application Details -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-calendar-alt mr-2 text-purple-600"></i>Application Details
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="space-y-4">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Application Deadline</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->application_deadline ? $career->application_deadline->format('F d, Y') : '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Expiry Date</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->expiry_date ? $career->expiry_date->format('F d, Y') : '—' }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Contact Email</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->contact_email ?? '—' }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Job Settings -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Job Settings</h3>
                </div>
                <div class="px-6 py-6">
                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Job Status</p>
                    <div class="mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $career->status === 'Open' || $career->status === 'open' || $career->status === 'active' ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300' : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300' }}">{{ ucfirst($career->status) }}</span>
                    </div>
                    <p class="mt-4 text-sm text-gray-600 dark:text-gray-400">Changes will be saved and applied immediately.</p>
                </div>
            </div>

            <!-- Meta Info -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Meta</h3>
                </div>
                <div class="px-6 py-6 divide-y divide-gray-100 dark:divide-gray-700">
                    <div class="pb-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Posted</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->created_at->format('F d, Y') }} ({{ $career->created_at->diffForHumans() }})</p>
                    </div>
                    <div class="pt-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $career->updated_at->format('F d, Y') }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection