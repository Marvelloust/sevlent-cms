@extends('admin.layouts.app')

@section('title', 'Settings')
@section('page-title', 'Global Website Settings')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-amber-600 to-orange-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-cog mr-3"></i>Global Settings
                    </h1>
                    <p class="text-white">Configure your website's core settings and branding</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Company Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-building mr-2 text-amber-600"></i>Company Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Basic company details and contact information</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Company Name -->
                    <div>
                        <label for="company_name" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-signature mr-2 text-gray-500"></i>Company Name
                        </label>
                        <input type="text" name="company_name" id="company_name" value="{{ old('company_name', $settings['company_name'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('company_name') border-red-500 @enderror"
                               placeholder="Enter company name">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Your organization's official name
                        </p>
                        @error('company_name')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Tagline -->
                    <div>
                        <label for="tagline" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-quote-left mr-2 text-gray-500"></i>Tagline
                        </label>
                        <input type="text" name="tagline" id="tagline" value="{{ old('tagline', $settings['tagline'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('tagline') border-red-500 @enderror"
                               placeholder="Enter tagline">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>A short phrase that represents your brand
                        </p>
                        @error('tagline')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="email" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-envelope mr-2 text-gray-500"></i>Email Address
                        </label>
                        <input type="email" name="email" id="email" value="{{ old('email', $settings['email'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('email') border-red-500 @enderror"
                               placeholder="Enter email address">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Primary contact email for your organization
                        </p>
                        @error('email')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Phone -->
                    <div>
                        <label for="phone" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-phone mr-2 text-gray-500"></i>Phone Number
                        </label>
                        <input type="text" name="phone" id="phone" value="{{ old('phone', $settings['phone'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('phone') border-red-500 @enderror"
                               placeholder="Enter phone number">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Business phone number with country code
                        </p>
                        @error('phone')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- Address -->
                <div class="lg:col-span-2">
                    <label for="address" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-map-marker-alt mr-2 text-gray-500"></i>Company Address
                    </label>
                    <textarea name="address" id="address" rows="3"
                              class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('address') border-red-500 @enderror"
                              placeholder="Enter company address">{{ old('address', $settings['address'] ?? '') }}</textarea>
                    <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>Full business address including street, city, state, and postal code
                    </p>
                    @error('address')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            <!-- Branding Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-palette mr-2 text-amber-600"></i>Branding
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Visual identity elements for your website</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Logo -->
                    <div>
                        <label for="logo" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-image mr-2 text-gray-500"></i>Company Logo
                        </label>
                        @if(isset($settings['logo']) && $settings['logo'])
                            <div class="mb-3 p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900">
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Current Logo:</p>
                                <img src="{{ asset('storage/' . $settings['logo']) }}" alt="Current Logo" class="w-32 h-16 object-contain border border-gray-200 dark:border-gray-700 rounded">
                            </div>
                        @endif
                        <input type="file" name="logo" id="logo"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 file:mr-4 file:py-2 file:px-4 file:rounded-l-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100 @error('logo') border-red-500 @enderror"
                               accept="image/*">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Upload a high-quality logo image (PNG, JPG, SVG recommended)
                        </p>
                        @error('logo')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Favicon -->
                    <div>
                        <label for="favicon" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-star mr-2 text-gray-500"></i>Favicon
                        </label>
                        @if(isset($settings['favicon']) && $settings['favicon'])
                            <div class="mb-3 p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-900">
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Current Favicon:</p>
                                <img src="{{ asset('storage/' . $settings['favicon']) }}" alt="Current Favicon" class="w-16 h-16 object-contain border border-gray-200 dark:border-gray-700 rounded">
                            </div>
                        @endif
                        <input type="file" name="favicon" id="favicon"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 file:mr-4 file:py-2 file:px-4 file:rounded-l-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100 @error('favicon') border-red-500 @enderror"
                               accept="image/*">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Small icon that appears in browser tabs (32x32px recommended)
                        </p>
                        @error('favicon')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- Theme Colors -->
                <div class="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <h4 class="text-base font-semibold text-gray-900 dark:text-white mb-4">
                        <i class="fas fa-paint-brush mr-2 text-amber-600"></i>Theme Colors
                    </h4>
                    <p class="text-sm text-gray-600 dark:text-gray-400 mb-6">
                        Set your brand colors to customize the entire website appearance. These colors will be applied to buttons, links, backgrounds, and other UI elements.
                    </p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Primary Color -->
                        <div>
                            <label for="primary_color" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                                <i class="fas fa-palette mr-2 text-gray-500"></i>Primary Color
                            </label>
                            <div class="flex items-center space-x-3">
                                <input type="color" name="primary_color" id="primary_color" 
                                       value="{{ old('primary_color', $settings['primary_color'] ?? '#3b82f6') }}"
                                       class="h-12 w-20 rounded-lg border-2 border-gray-300 dark:border-gray-600 cursor-pointer">
                                <input type="text" 
                                       value="{{ old('primary_color', $settings['primary_color'] ?? '#3b82f6') }}"
                                       class="flex-1 bg-white dark:bg-gray-900 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-sm"
                                       readonly
                                       id="primary_color_display">
                            </div>
                            <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                                Main brand color for buttons, links, and primary elements
                            </p>
                        </div>

                        <!-- Secondary Color -->
                        <div>
                            <label for="secondary_color" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                                <i class="fas fa-palette mr-2 text-gray-500"></i>Secondary Color
                            </label>
                            <div class="flex items-center space-x-3">
                                <input type="color" name="secondary_color" id="secondary_color" 
                                       value="{{ old('secondary_color', $settings['secondary_color'] ?? '#8b5cf6') }}"
                                       class="h-12 w-20 rounded-lg border-2 border-gray-300 dark:border-gray-600 cursor-pointer">
                                <input type="text" 
                                       value="{{ old('secondary_color', $settings['secondary_color'] ?? '#8b5cf6') }}"
                                       class="flex-1 bg-white dark:bg-gray-900 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-sm"
                                       readonly
                                       id="secondary_color_display">
                            </div>
                            <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                                Accent color for highlights and secondary elements
                            </p>
                        </div>

                        <!-- Accent Color -->
                        <div>
                            <label for="accent_color" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                                <i class="fas fa-palette mr-2 text-gray-500"></i>Accent Color
                            </label>
                            <div class="flex items-center space-x-3">
                                <input type="color" name="accent_color" id="accent_color" 
                                       value="{{ old('accent_color', $settings['accent_color'] ?? '#10b981') }}"
                                       class="h-12 w-20 rounded-lg border-2 border-gray-300 dark:border-gray-600 cursor-pointer">
                                <input type="text" 
                                       value="{{ old('accent_color', $settings['accent_color'] ?? '#10b981') }}"
                                       class="flex-1 bg-white dark:bg-gray-900 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-mono text-sm"
                                       readonly
                                       id="accent_color_display">
                            </div>
                            <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                                Used for success states and call-to-action elements
                            </p>
                        </div>
                    </div>

                    <!-- Preview Section -->
                    <div class="mt-6 p-6 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700">
                        <p class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-4">
                            <i class="fas fa-eye mr-2"></i>Color Preview
                        </p>
                        <div class="flex flex-wrap gap-3">
                            <button type="button" id="preview_primary" 
                                    class="px-6 py-2.5 rounded-lg text-white font-semibold shadow-md transition-transform hover:scale-105"
                                    style="background-color: {{ $settings['primary_color'] ?? '#3b82f6' }}">
                                Primary Button
                            </button>
                            <button type="button" id="preview_secondary" 
                                    class="px-6 py-2.5 rounded-lg text-white font-semibold shadow-md transition-transform hover:scale-105"
                                    style="background-color: {{ $settings['secondary_color'] ?? '#8b5cf6' }}">
                                Secondary Button
                            </button>
                            <button type="button" id="preview_accent" 
                                    class="px-6 py-2.5 rounded-lg text-white font-semibold shadow-md transition-transform hover:scale-105"
                                    style="background-color: {{ $settings['accent_color'] ?? '#10b981' }}">
                                Accent Button
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Social Media Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-share-alt mr-2 text-amber-600"></i>Social Media
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Connect your social media profiles</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Facebook -->
                    <div>
                        <label for="facebook" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook-f mr-2 text-blue-600"></i>Facebook
                        </label>
                        <input type="url" name="facebook" id="facebook" value="{{ old('facebook', $settings['facebook'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('facebook') border-red-500 @enderror"
                               placeholder="https://facebook.com/yourpage">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Your Facebook page or profile URL
                        </p>
                        @error('facebook')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Twitter -->
                    <div>
                        <label for="twitter" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-twitter mr-2 text-blue-400"></i>Twitter
                        </label>
                        <input type="url" name="twitter" id="twitter" value="{{ old('twitter', $settings['twitter'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('twitter') border-red-500 @enderror"
                               placeholder="https://twitter.com/yourprofile">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Your Twitter/X profile URL
                        </p>
                        @error('twitter')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- LinkedIn -->
                    <div>
                        <label for="linkedin" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-linkedin-in mr-2 text-blue-700"></i>LinkedIn
                        </label>
                        <input type="url" name="linkedin" id="linkedin" value="{{ old('linkedin', $settings['linkedin'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('linkedin') border-red-500 @enderror"
                               placeholder="https://linkedin.com/company/yourcompany">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Your LinkedIn company page or profile URL
                        </p>
                        @error('linkedin')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Instagram -->
                    <div>
                        <label for="instagram" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-instagram mr-2 text-pink-600"></i>Instagram
                        </label>
                        <input type="url" name="instagram" id="instagram" value="{{ old('instagram', $settings['instagram'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('instagram') border-red-500 @enderror"
                               placeholder="https://instagram.com/yourprofile">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Your Instagram profile URL
                        </p>
                        @error('instagram')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Footer Content Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-file-alt mr-2 text-amber-600"></i>Footer Content
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Content displayed in the website footer</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div>
                    <label for="footer_content" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-paragraph mr-2 text-gray-500"></i>Footer Text
                    </label>
                    <textarea name="footer_content" id="footer_content" rows="4"
                              class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('footer_content') border-red-500 @enderror"
                              placeholder="Enter footer content, copyright information, etc.">{{ old('footer_content', $settings['footer_content'] ?? '') }}</textarea>
                    <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>Copyright notices, additional links, or other footer information
                    </p>
                    @error('footer_content')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            <!-- Default SEO Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-search mr-2 text-amber-600"></i>Default SEO
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Default search engine optimization settings</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Default Meta Title -->
                    <div>
                        <label for="default_meta_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-heading mr-2 text-gray-500"></i>Default Meta Title
                        </label>
                        <input type="text" name="default_meta_title" id="default_meta_title" value="{{ old('default_meta_title', $settings['default_meta_title'] ?? '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('default_meta_title') border-red-500 @enderror"
                               placeholder="Enter default meta title">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Title that appears in search results when no specific title is set
                        </p>
                        @error('default_meta_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Default Meta Description -->
                    <div class="lg:col-span-2">
                        <label for="default_meta_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-text mr-2 text-gray-500"></i>Default Meta Description
                        </label>
                        <textarea name="default_meta_description" id="default_meta_description" rows="2"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-all duration-200 @error('default_meta_description') border-red-500 @enderror"
                                  placeholder="Default description for search engines">{{ old('default_meta_description', $settings['default_meta_description'] ?? '') }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Description that appears in search results when no specific description is set
                        </p>
                        @error('default_meta_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Changes to settings will take effect immediately. Make sure to review all changes before saving.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <button type="button" onclick="window.history.back()"
                                class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </button>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-amber-600 text-white font-semibold rounded-lg hover:bg-amber-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Save Settings
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
    // Color picker live preview
    document.addEventListener('DOMContentLoaded', function() {
        const colorInputs = [
            { picker: 'primary_color', display: 'primary_color_display', preview: 'preview_primary' },
            { picker: 'secondary_color', display: 'secondary_color_display', preview: 'preview_secondary' },
            { picker: 'accent_color', display: 'accent_color_display', preview: 'preview_accent' }
        ];

        colorInputs.forEach(function(config) {
            const picker = document.getElementById(config.picker);
            const display = document.getElementById(config.display);
            const preview = document.getElementById(config.preview);

            if (picker && display && preview) {
                picker.addEventListener('input', function() {
                    display.value = this.value;
                    preview.style.backgroundColor = this.value;
                });
            }
        });
    });
</script>
@endpush

@endsection