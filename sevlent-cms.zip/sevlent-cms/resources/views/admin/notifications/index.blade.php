@extends('admin.layouts.app')

@section('title', 'Notifications')

@section('content')
<div class="p-6">
    <!-- Header with gradient -->
    <div class="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-xl shadow-lg p-8 mb-6 text-white">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold mb-2">Notifications</h1>
                <p class="text-white">Stay updated with all your important alerts</p>
            </div>
            <div class="text-right">
                <div class="text-4xl font-bold">{{ $unreadCount }}</div>
                <div class="text-sm text-white">Unread</div>
            </div>
        </div>
    </div>

    <!-- Actions Card -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6 p-4">
        <!-- Filters -->
        <form method="GET" action="{{ route('admin.notifications.index') }}" class="mb-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label for="type" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Type</label>
                    <select name="type" id="type" class="w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <option value="">All Types</option>
                        @foreach($availableTypes as $type)
                        <option value="{{ $type }}" {{ request('type') === $type ? 'selected' : '' }}>
                            {{ ucfirst(str_replace('_', ' ', $type)) }}
                        </option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label for="read_status" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Status</label>
                    <select name="read_status" id="read_status" class="w-full rounded-md bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <option value="">All Status</option>
                        <option value="unread" {{ request('read_status') === 'unread' ? 'selected' : '' }}>Unread</option>
                        <option value="read" {{ request('read_status') === 'read' ? 'selected' : '' }}>Read</option>
                    </select>
                </div>

                <div>
                    <label for="date_from" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">From Date</label>
                    <input type="date" name="date_from" id="date_from" value="{{ request('date_from') }}" class="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>

                <div>
                    <label for="date_to" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">To Date</label>
                    <input type="date" name="date_to" id="date_to" value="{{ request('date_to') }}" class="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>
            </div>

            <div class="flex gap-2 mt-4">
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition duration-150">
                    <i class="fas fa-filter mr-2"></i>
                    Apply Filters
                </button>

                @if(request()->hasAny(['type', 'read_status', 'date_from', 'date_to']))
                <a href="{{ route('admin.notifications.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm font-medium rounded-lg transition duration-150">
                    <i class="fas fa-times mr-2"></i>
                    Clear Filters
                </a>
                @endif
            </div>
        </form>

        <div class="flex flex-wrap items-center justify-between gap-4">
            <div class="flex gap-2">
                @if($unreadCount > 0)
                <form action="{{ route('admin.notifications.mark-all-as-read') }}" method="POST" class="inline">
                    @csrf
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition duration-150">
                        <i class="fas fa-check-double mr-2"></i>
                        Mark All as Read
                    </button>
                </form>
                @endif
                
                @if($notifications->where('is_read', true)->count() > 0)
                <form id="clear-read-form" action="{{ route('admin.notifications.clear-read') }}" method="POST" class="inline">
                    @csrf
                    <button type="button" onclick="confirmClearRead()" class="inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm font-medium rounded-lg transition duration-150">
                        <i class="fas fa-trash mr-2"></i>
                        Clear Read
                    </button>
                </form>
                @endif
            </div>
        </div>
    </div>

    <!-- Notifications List -->
    <div class="space-y-4">
        @forelse($notifications as $notification)
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden {{ $notification->is_read ? 'opacity-75' : '' }}">
            <div class="p-6">
                <div class="flex items-start justify-between">
                    <div class="flex items-start space-x-4 flex-1">
                        <!-- Icon -->
                        <div class="flex-shrink-0">
                            <div class="{{ $notification->color_class }} rounded-full p-3">
                                <i class="{{ $notification->icon_class }} text-white"></i>
                            </div>
                        </div>

                        <!-- Content -->
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between mb-2">
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                                    {{ $notification->title }}
                                </h3>
                                @if(!$notification->is_read)
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    New
                                </span>
                                @endif
                            </div>
                            
                            <p class="text-gray-600 dark:text-gray-400 mb-3">
                                {{ $notification->message }}
                            </p>

                            <!-- Details -->
                            @if($notification->data && count($notification->data) > 0)
                            <div class="bg-gray-50 dark:bg-gray-900 rounded-lg p-3 mb-3">
                                <dl class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                                    @foreach($notification->data as $key => $value)
                                    <div>
                                        <dt class="text-gray-500 dark:text-gray-400 capitalize">{{ str_replace('_', ' ', $key) }}:</dt>
                                        <dd class="text-gray-900 dark:text-white font-medium">{{ $value }}</dd>
                                    </div>
                                    @endforeach
                                </dl>
                            </div>
                            @endif

                            <!-- Meta -->
                            <div class="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                                <span>{{ $notification->created_at->diffForHumans() }}</span>
                                
                                <div class="flex items-center space-x-3">
                                    @if($notification->link)
                                    <a href="{{ $notification->link }}" class="text-blue-600 hover:text-blue-800 font-medium">
                                        View Details <i class="fas fa-arrow-right ml-1"></i>
                                    </a>
                                    @endif
                                    
                                    @if(!$notification->is_read)
                                    <form action="{{ route('admin.notifications.mark-as-read', $notification->id) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-green-600 hover:text-green-800 font-medium">
                                            <i class="fas fa-check mr-1"></i> Mark as Read
                                        </button>
                                    </form>
                                    @endif
                                    
                                    <form id="delete-notification-form-{{ $notification->id }}" action="{{ route('admin.notifications.destroy', $notification->id) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="button" onclick="confirmDeleteNotification({{ $notification->id }}, '{{ addslashes($notification->title) }}')" class="text-red-600 hover:text-red-800 font-medium">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-12 text-center">
            <i class="fas fa-bell-slash text-6xl text-gray-300 dark:text-gray-600 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No Notifications</h3>
            <p class="text-gray-600 dark:text-gray-400">You're all caught up! No notifications at the moment.</p>
        </div>
        @endforelse
    </div>

    <!-- Pagination -->
    @if($notifications->hasPages())
    <div class="mt-6">
        {{ $notifications->links() }}
    </div>
    @endif
</div>

<script>
function confirmClearRead() {
    showDeleteConfirmation(
        'Are you sure you want to clear all read notifications? This action cannot be undone.',
        function() {
            document.getElementById('clear-read-form').submit();
        }
    );
}

function confirmDeleteNotification(notificationId, title) {
    showDeleteConfirmation(
        `Are you sure you want to delete the notification "${title}"? This action cannot be undone.`,
        function() {
            document.getElementById(`delete-notification-form-${notificationId}`).submit();
        }
    );
}
</script>
@endsection
