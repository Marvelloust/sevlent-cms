@extends('admin.layouts.app')

@section('title', 'View Page')
@section('page-title', 'View Page')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $page->status === 'published' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100' }}">
                            <i class="fas {{ $page->status === 'published' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($page->status) }}
                        </span>
                        <span class="ml-3 text-sm font-medium text-gray-300 dark:text-white">
                            <i class="fas fa-globe mr-1"></i>
                            <a href="{{ url('/' . $page->slug) }}" target="_blank" class="hover:text-white underline dark:text-gray-300">
                                View Live
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $page->title }}</h1>
                    <div class="flex flex-wrap gap-6 text-gray-100 dark:text-gray-200 text-sm">
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Created {{ $page->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $page->updated_at->diffForHumans() }}
                        </span>
                        <span class="text-gray-100 dark:text-gray-200">
                            <i class="fas fa-link mr-2"></i><code class="bg-blue-500 bg-opacity-30 dark:bg-blue-800 dark:bg-opacity-30 text-gray-900 dark:text-white px-2 py-1 rounded">{{ $page->slug }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.pages.sections.index', $page) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-puzzle-piece mr-2"></i>Sections
                    </a>
                    <a href="{{ route('admin.pages.edit', $page) }}" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-300 font-semibold rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700 transition-all duration-200">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="{{ route('admin.pages.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Banner Image Preview -->
    @if($page->banner)
        <div class="rounded-xl overflow-hidden shadow-lg">
            <img src="{{ $page->banner->url }}" alt="Banner" class="w-full h-96 object-cover">
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content Preview -->
        <div class="lg:col-span-2">
            <!-- Content Section -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-file-alt mr-2 text-blue-600"></i>Page Content
                    </h3>
                </div>
                <div class="px-6 py-8">
                    <div class="prose prose-sm max-w-none prose-a:text-blue-600 prose-a:underline prose-img:rounded-lg prose-img:shadow-md text-gray-900 dark:text-gray-200 dark:prose-invert">
                        {!! $page->content !!}
                    </div>
                </div>
            </div>

            <!-- Page Sections -->
            @if($page->sections && $page->sections->count() > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-th-large mr-2 text-green-600"></i>Page Sections ({{ $page->sections->count() }})
                        </h3>
                    </div>
                    <div class="divide-y divide-gray-200 dark:divide-gray-700">
                        @foreach($page->sections as $section)
                            <div class="px-6 py-4 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors duration-200">
                                <div class="flex items-start justify-between mb-2">
                                    <h4 class="text-base font-semibold text-gray-900 dark:text-white">{{ $section->title }}</h4>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">
                                        {{ $section->type }}
                                    </span>
                                </div>
                                @if($section->description)
                                    <p class="text-sm text-gray-600 dark:text-gray-400">{{ Str::limit($section->description, 150) }}</p>
                                @endif
                            </div>
                        @endforeach
                    </div>
                    <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                        <a href="{{ route('admin.pages.sections.index', $page) }}" class="text-sm font-medium text-blue-600 hover:text-blue-700 dark:text-blue-300 dark:hover:text-blue-400">
                            <i class="fas fa-arrow-right mr-1"></i>Manage Sections
                        </a>
                    </div>
                </div>
                @else
                <div class="mt-8 bg-blue-50 dark:bg-gray-900 rounded-xl border-2 border-blue-200 dark:border-gray-700 p-6">
                    <div class="flex">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-300 text-xl mr-4 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-blue-900 dark:text-white mb-1">No Sections Added</h4>
                            <p class="text-sm text-blue-800 dark:text-gray-300">This page doesn't have any sections yet. 
                                <a href="{{ route('admin.pages.sections.index', $page) }}" class="font-semibold hover:underline dark:text-blue-300">Add sections</a> to build out your page.
                            </p>
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <!-- Sidebar: Metadata -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Basic Info Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>Page Info
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $page->status === 'published' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100' }}">
                            {{ ucfirst($page->status) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">URL Slug</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-gray-800 dark:text-white break-all">{{ $page->slug }}</code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Created</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $page->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $page->updated_at->format('M d, Y H:i') }}</p>
                    </div>
                </div>
            </div>

            <!-- SEO Metadata Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-search mr-2 text-purple-600"></i>SEO Metadata
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($page->seo?->meta_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Title</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-blue-50 dark:bg-gray-900 p-2 rounded border-l-2 border-blue-500 dark:border-blue-700">
                                {{ $page->seo->meta_title }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($page->seo->meta_title) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta title set</p>
                        </div>
                    @endif

                    @if($page->seo?->meta_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Description</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-green-50 dark:bg-gray-900 p-2 rounded border-l-2 border-green-500 dark:border-green-700 leading-relaxed">
                                {{ $page->seo->meta_description }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($page->seo->meta_description) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta description set</p>
                        </div>
                    @endif

                    @if($page->seo?->meta_keywords)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Keywords</p>
                            <div class="flex flex-wrap gap-2">
                                @foreach(explode(',', $page->seo->meta_keywords) as $keyword)
                                    <span class="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100 text-xs font-semibold rounded-full">
                                        {{ trim($keyword) }}
                                    </span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @if($page->seo?->canonical_url)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Canonical URL</p>
                            <a href="{{ $page->seo->canonical_url }}" target="_blank" class="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-300 dark:hover:text-blue-400 break-all">
                                {{ $page->seo->canonical_url }}
                                <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                    @endif
                </div>
                <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                    <a href="{{ route('admin.pages.edit', $page) }}" class="text-sm font-medium text-purple-600 hover:text-purple-700 dark:text-purple-300 dark:hover:text-purple-400">
                        <i class="fas fa-edit mr-1"></i>Edit SEO
                    </a>
                </div>
            </div>

            <!-- Social Sharing Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Sharing
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($page->seo?->og_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Title</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $page->seo->og_title }}</p>
                        </div>
                    @endif

                    @if($page->seo?->og_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Description</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $page->seo->og_description }}</p>
                        </div>
                    @endif

                    @if($page->seo?->ogImage)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Image</p>
                            <img src="{{ asset('storage/' . $page->seo->ogImage->file_path) }}" alt="OG" class="w-full h-32 object-cover rounded">
                        </div>
                    @endif

                    @if(!$page->seo?->og_title && !$page->seo?->og_description && !$page->seo?->ogImage)
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-share-alt mr-2"></i>No OG data configured</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
