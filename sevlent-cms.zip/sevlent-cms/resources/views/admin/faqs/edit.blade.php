@extends('admin.layouts.app')

@section('title', 'Edit FAQ')
@section('page-title', 'Edit FAQ')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-question-circle mr-3"></i>Edit FAQ
                    </h1>
                    <p class="text-white">{{ Str::limit($faq->question, 60) }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $faq->is_active ? 'status-success' : 'status-danger' }}">
                            <i class="fas {{ $faq->is_active ? 'fa-eye' : 'fa-eye-slash' }} mr-1"></i>
                            {{ $faq->is_active ? 'Active' : 'Inactive' }}
                        </span>
                        <span class="ml-3 text-gray-300 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Updated {{ $faq->updated_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.faqs.show', $faq) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-eye mr-2"></i>View Details
                    </a>
                    <a href="{{ route('admin.faqs.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to FAQs
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.faqs.update', $faq) }}">
            @csrf
            @method('PUT')

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">The core question and answer content</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <!-- Question -->
                <div>
                    <label for="question" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-question mr-2 text-gray-500"></i>Question <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="question" id="question" value="{{ old('question', $faq->question) }}"
                           class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('question') border-red-500 @enderror"
                           placeholder="Enter your FAQ question" required>
                    @error('question')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>

                <!-- Answer -->
                <div>
                    <label for="answer" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-reply mr-2 text-gray-500"></i>Answer <span class="text-red-500">*</span>
                    </label>
                    <textarea name="answer" id="answer" rows="6"
                              class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical @error('answer') border-red-500 @enderror"
                              placeholder="Provide a detailed answer to the question" required>{{ old('answer', $faq->answer) }}</textarea>
                    @error('answer')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            <!-- Display Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-palette mr-2 text-green-600"></i>Display Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Visual customization and ordering</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Icon -->
                    <div>
                        <label for="icon" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-icons mr-2 text-gray-500"></i>Icon <span class="text-red-500">*</span>
                        </label>
                        <select name="icon" id="icon"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('icon') border-red-500 @enderror">
                            <option value="" disabled {{ old('icon', $faq->icon) == '' ? 'selected' : '' }}>Select an icon</option>
                            <option value="clock" {{ old('icon', $faq->icon) == 'clock' ? 'selected' : '' }}>
                                <i class="fas fa-clock mr-2"></i>Clock (Time)
                            </option>
                            <option value="settings" {{ old('icon', $faq->icon) == 'settings' ? 'selected' : '' }}>
                                <i class="fas fa-cog mr-2"></i>Settings (Services)
                            </option>
                            <option value="lightbulb" {{ old('icon', $faq->icon) == 'lightbulb' ? 'selected' : '' }}>
                                <i class="fas fa-lightbulb mr-2"></i>Lightbulb (Ideas)
                            </option>
                            <option value="check" {{ old('icon', $faq->icon) == 'check' ? 'selected' : '' }}>
                                <i class="fas fa-check mr-2"></i>Check (Support)
                            </option>
                            <option value="calendar" {{ old('icon', $faq->icon) == 'calendar' ? 'selected' : '' }}>
                                <i class="fas fa-calendar mr-2"></i>Calendar (Timeline)
                            </option>
                        </select>
                        @error('icon')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Color -->
                    <div>
                        <label for="color" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-palette mr-2 text-gray-500"></i>Color <span class="text-red-500">*</span>
                        </label>
                        <select name="color" id="color"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('color') border-red-500 @enderror">
                            <option value="" disabled {{ old('color', $faq->color) == '' ? 'selected' : '' }}>Select a color</option>
                            <option value="blue" {{ old('color', $faq->color) == 'blue' ? 'selected' : '' }}>
                                <span class="inline-block w-4 h-4 bg-blue-500 rounded-full mr-2"></span>Blue
                            </option>
                            <option value="purple" {{ old('color', $faq->color) == 'purple' ? 'selected' : '' }}>
                                <span class="inline-block w-4 h-4 bg-purple-500 rounded-full mr-2"></span>Purple
                            </option>
                            <option value="indigo" {{ old('color', $faq->color) == 'indigo' ? 'selected' : '' }}>
                                <span class="inline-block w-4 h-4 bg-indigo-500 rounded-full mr-2"></span>Indigo
                            </option>
                            <option value="green" {{ old('color', $faq->color) == 'green' ? 'selected' : '' }}>
                                <span class="inline-block w-4 h-4 bg-green-500 rounded-full mr-2"></span>Green
                            </option>
                            <option value="orange" {{ old('color', $faq->color) == 'orange' ? 'selected' : '' }}>
                                <span class="inline-block w-4 h-4 bg-orange-500 rounded-full mr-2"></span>Orange
                            </option>
                        </select>
                        @error('color')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Order -->
                    <div>
                        <label for="order" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-sort-numeric-up mr-2 text-gray-500"></i>Display Order
                        </label>
                        <input type="number" name="order" id="order" value="{{ old('order', $faq->order) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('order') border-red-500 @enderror"
                               placeholder="0" min="0">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Lower numbers appear first
                        </p>
                        @error('order')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Status Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-toggle-on mr-2 text-orange-600"></i>Status Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Control FAQ visibility on the website</p>
            </div>
            <div class="px-6 py-6">
                <!-- Is Active -->
                <div class="mb-6">
                    <label for="is_active" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                        <i class="fas fa-eye mr-2 text-gray-500"></i>FAQ Status <span class="text-red-500">*</span>
                    </label>
                    <div class="flex items-center space-x-6">
                        <label class="inline-flex items-center">
                            <input type="checkbox" name="is_active" value="1" {{ old('is_active', $faq->is_active) ? 'checked' : '' }}
                                   class="form-checkbox h-5 w-5 text-green-600 focus:ring-green-500 rounded">
                            <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                <i class="fas fa-eye mr-1" style="color: #16a34a"></i>Active (Visible on website)
                            </span>
                        </label>
                    </div>
                    <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>Inactive FAQs will not be displayed to website visitors
                    </p>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.faqs.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update FAQ
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Tips Section -->
    <div class="bg-blue-50 dark:bg-blue-900/20 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-blue-200 dark:border-blue-800 bg-blue-100 dark:bg-blue-900/30">
            <h3 class="text-lg font-semibold text-blue-900 dark:text-blue-300">
                <i class="fas fa-lightbulb mr-2 text-blue-600 dark:text-blue-400"></i>FAQ Best Practices
            </h3>
        </div>
        <div class="px-6 py-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-question mr-2 text-blue-600 dark:text-blue-400"></i>Question Guidelines
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Keep questions clear and concise
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Use natural language that visitors would ask
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Avoid jargon unless necessary
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-reply mr-2 text-blue-600 dark:text-blue-400"></i>Answer Guidelines
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Provide comprehensive but concise answers
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Choose appropriate icons and colors for visual hierarchy
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600 dark:text-green-400"></i>
                            Set order to control display sequence
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
