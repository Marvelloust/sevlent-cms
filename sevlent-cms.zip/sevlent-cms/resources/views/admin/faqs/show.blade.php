@extends('admin.layouts.app')

@section('title', 'View FAQ')
@section('page-title', 'View FAQ')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-question-circle mr-3"></i>FAQ Details
                    </h1>
                    <p class="text-white">{{ Str::limit($faq->question, 60) }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $faq->is_active ? 'status-success' : 'status-danger' }}">
                            <i class="fas {{ $faq->is_active ? 'fa-eye' : 'fa-eye-slash' }} mr-1"></i>
                            {{ $faq->is_active ? 'Active' : 'Inactive' }}
                        </span>
                        <span class="ml-3 text-gray-300 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Updated {{ $faq->updated_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.faqs.edit', $faq) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-edit mr-2"></i>Edit FAQ
                    </a>
                    <a href="{{ route('admin.faqs.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to FAQs
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Section -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Basic Information Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">The core question and answer content</p>
        </div>
        <div class="px-6 py-6 space-y-6">
            <!-- Question -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    <i class="fas fa-question mr-2 text-gray-500"></i>Question
                </label>
                <div class="w-full bg-gray-50 dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg">
                    {{ $faq->question }}
                </div>
            </div>

            <!-- Answer -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    <i class="fas fa-reply mr-2 text-gray-500"></i>Answer
                </label>
                <div class="w-full bg-gray-50 dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg min-h-[150px]">
                    {{ $faq->answer }}
                </div>
            </div>
        </div>

        <!-- Display Settings Section -->
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-palette mr-2 text-green-600"></i>Display Settings
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Visual customization and ordering</p>
        </div>
        <div class="px-6 py-6 space-y-6">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Icon -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-icons mr-2 text-gray-500"></i>Icon
                    </label>
                    <div class="w-full bg-gray-50 dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg">
                        <i class="fas fa-{{ $faq->icon }} mr-2"></i>{{ ucfirst($faq->icon) }}
                    </div>
                </div>

                <!-- Color -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-palette mr-2 text-gray-500"></i>Color
                    </label>
                    <div class="w-full bg-gray-50 dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg flex items-center">
                        <span class="inline-block w-4 h-4 bg-{{ $faq->color }}-500 rounded-full mr-2"></span>{{ ucfirst($faq->color) }}
                    </div>
                </div>

                <!-- Order -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-sort-numeric-down mr-2 text-gray-500"></i>Display Order
                    </label>
                    <div class="w-full bg-gray-50 dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg">
                        {{ $faq->order ?? 'N/A' }}
                    </div>
                </div>
            </div>

            <!-- Status -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Status
                </label>
                <div class="flex items-center">
                    <div class="px-4 py-2 rounded-lg {{ $faq->is_active ? 'bg-green-100 text-green-800 dark:bg-green-200 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-300 dark:text-red-200' }}">
                        <i class="fas {{ $faq->is_active ? 'fa-check-circle' : 'fa-times-circle' }} mr-2"></i>
                        {{ $faq->is_active ? 'Active - Visible to users' : 'Inactive - Hidden from users' }}
                    </div>
                </div>
            </div>
        </div>

        <!-- Metadata Section -->
        <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                <i class="fas fa-clock mr-2 text-purple-600"></i>Metadata
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div class="flex items-center text-gray-700 dark:text-gray-300">
                    <i class="fas fa-calendar-plus mr-3 text-blue-500"></i>
                    <div>
                        <span class="font-semibold">Created:</span>
                        <span class="ml-2">{{ $faq->created_at->format('M d, Y \a\t h:i A') }}</span>
                        <span class="text-gray-500 dark:text-gray-400 ml-1">({{ $faq->created_at->diffForHumans() }})</span>
                    </div>
                </div>
                <div class="flex items-center text-gray-700 dark:text-gray-300">
                    <i class="fas fa-calendar-check mr-3 text-green-500"></i>
                    <div>
                        <span class="font-semibold">Updated:</span>
                        <span class="ml-2">{{ $faq->updated_at->format('M d, Y \a\t h:i A') }}</span>
                        <span class="text-gray-500 dark:text-gray-400 ml-1">({{ $faq->updated_at->diffForHumans() }})</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions Section -->
        <div class="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
            <div class="flex flex-col sm:flex-row gap-3 justify-end">
                <a href="{{ route('admin.faqs.edit', $faq) }}" class="inline-flex items-center justify-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200">
                    <i class="fas fa-edit mr-2"></i>Edit FAQ
                </a>
                <form action="{{ route('admin.faqs.destroy', $faq) }}" method="POST" class="inline-block">
                    @csrf
                    @method('DELETE')
                    <button type="button" class="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200" onclick="showDeleteConfirmation('Are you sure you want to delete this FAQ? This action cannot be undone.', () => { this.closest('form').submit(); })">
                        <i class="fas fa-trash mr-2"></i>Delete FAQ
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
