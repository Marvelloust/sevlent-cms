@extends('admin.layouts.app')

@section('title', 'Create FAQ')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-rose-600 to-pink-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-question-circle mr-3"></i>Create New FAQ
                    </h1>
                    <p class="text-rose-100">Add frequently asked questions to help your visitors</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.faqs.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to FAQs
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form action="{{ route('admin.faqs.store') }}" method="POST">
            @csrf

            <!-- FAQ Details Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-question-circle mr-2 text-rose-600"></i>FAQ Details
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">The question and answer that will be displayed to visitors</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 gap-6">
                    <!-- Question -->
                    <div>
                        <label for="question" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-question mr-2 text-gray-500"></i>Question <span class="text-red-500">*</span>
                        </label>
                        <input type="text" class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all duration-200 @error('question') border-red-500 @enderror"
                               id="question" name="question" value="{{ old('question') }}" placeholder="Enter your FAQ question" required>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Keep the question clear and concise for better user experience
                        </p>
                        @error('question')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Answer -->
                    <div>
                        <label for="answer" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-comment mr-2 text-gray-500"></i>Answer <span class="text-red-500">*</span>
                        </label>
                        <textarea class="w-full px-4 py-3 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all duration-200 @error('answer') border-red-500 @enderror"
                                  id="answer" name="answer" rows="5" placeholder="Provide a detailed answer to the question" required>{{ old('answer') }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Provide comprehensive and helpful answers to address visitor concerns
                        </p>
                        @error('answer')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Display Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-palette mr-2 text-rose-600"></i>Display Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Visual customization and display options for the FAQ</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Icon -->
                    <div>
                        <label for="icon" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-icons mr-2 text-gray-500"></i>Icon <span class="text-red-500">*</span>
                        </label>
                        <select class="w-full px-4 py-3 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all duration-200 @error('icon') border-red-500 @enderror"
                                id="icon" name="icon" required>
                            <option value="" disabled {{ old('icon') ? '' : 'selected' }}>Select an icon</option>
                            <option value="clock" {{ old('icon') == 'clock' ? 'selected' : '' }}>🕐 Clock (Time)</option>
                            <option value="settings" {{ old('icon') == 'settings' ? 'selected' : '' }}>⚙️ Settings (Services)</option>
                            <option value="lightbulb" {{ old('icon') == 'lightbulb' ? 'selected' : '' }}>💡 Lightbulb (Ideas)</option>
                            <option value="check" {{ old('icon') == 'check' ? 'selected' : '' }}>✅ Check (Support)</option>
                            <option value="calendar" {{ old('icon') == 'calendar' ? 'selected' : '' }}>📅 Calendar (Timeline)</option>
                        </select>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Choose an appropriate icon for the FAQ category
                        </p>
                        @error('icon')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Color -->
                    <div>
                        <label for="color" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-palette mr-2 text-gray-500"></i>Color <span class="text-red-500">*</span>
                        </label>
                        <select class="w-full px-4 py-3 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all duration-200 @error('color') border-red-500 @enderror"
                                id="color" name="color" required>
                            <option value="" disabled {{ old('color') ? '' : 'selected' }}>Select a color</option>
                            <option value="blue" {{ old('color') == 'blue' ? 'selected' : '' }}>🔵 Blue</option>
                            <option value="purple" {{ old('color') == 'purple' ? 'selected' : '' }}>🟣 Purple</option>
                            <option value="indigo" {{ old('color') == 'indigo' ? 'selected' : '' }}>🔷 Indigo</option>
                            <option value="green" {{ old('color') == 'green' ? 'selected' : '' }}>🟢 Green</option>
                            <option value="orange" {{ old('color') == 'orange' ? 'selected' : '' }}>🟠 Orange</option>
                        </select>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Color theme for visual hierarchy and branding
                        </p>
                        @error('color')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Order -->
                    <div>
                        <label for="order" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-sort-numeric-up mr-2 text-gray-500"></i>Display Order
                        </label>
                        <input type="number" class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-rose-500 focus:border-rose-500 transition-all duration-200 @error('order') border-red-500 @enderror"
                               id="order" name="order" value="{{ old('order', 0) }}" placeholder="0" min="0">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Lower numbers appear first (0 = highest priority)
                        </p>
                        @error('order')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>

                <!-- Active Status -->
                <div class="flex items-center">
                    <input type="checkbox" class="rounded border-gray-300 dark:border-gray-600 text-rose-600 shadow-sm focus:border-rose-300 focus:ring focus:ring-rose-200 focus:ring-opacity-50"
                           id="is_active" name="is_active" {{ old('is_active', true) ? 'checked' : '' }}>
                    <label for="is_active" class="ml-3 block text-sm font-semibold text-gray-700 dark:text-gray-300">
                        <i class="fas fa-eye mr-2 text-gray-500"></i>Active (Display on website)
                    </label>
                </div>
                <p class="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                    <i class="fas fa-info-circle mr-1"></i>Inactive FAQs will not be visible to website visitors
                </p>
            </div>

            <!-- Tips Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-blue-50 dark:bg-blue-900/20">
                <h3 class="text-lg font-semibold text-blue-900 dark:text-blue-300">
                    <i class="fas fa-lightbulb mr-2 text-blue-600 dark:text-blue-400"></i>Best Practices
                </h3>
                <p class="text-sm text-blue-700 dark:text-blue-400 mt-1">Tips for creating effective FAQs</p>
            </div>
            <div class="px-6 py-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-question text-blue-500 dark:text-blue-400 mt-1"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">Clear Questions</h4>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Keep questions clear and concise for better user experience</p>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-comment-dots text-blue-500 dark:text-blue-400 mt-1"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">Comprehensive Answers</h4>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Provide detailed, helpful answers that fully address visitor concerns</p>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-palette text-blue-500 dark:text-blue-400 mt-1"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">Visual Consistency</h4>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Choose appropriate icons and colors for better visual hierarchy</p>
                        </div>
                    </div>

                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-sort-amount-up text-blue-500 dark:text-blue-400 mt-1"></i>
                        </div>
                        <div>
                            <h4 class="text-sm font-medium text-gray-900 dark:text-white">Order Matters</h4>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Set order numbers to control the display sequence of FAQs</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>After creating the FAQ, it will be available for display on your website's FAQ section. Make sure the question and answer are clear and helpful.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.faqs.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-rose-600 text-white font-semibold rounded-lg hover:bg-rose-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-plus mr-2"></i>Create FAQ
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
