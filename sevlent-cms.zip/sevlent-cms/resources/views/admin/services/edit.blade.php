@extends('admin.layouts.app')

@section('title', 'Edit Service')
@section('page-title', 'Edit Service')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-edit mr-3"></i>Edit Service
                    </h1>
                    <p class="text-white">{{ $service->name }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $service->status === 'active' ? 'status-success' : 'status-warning' }}">
                            <i class="fas {{ $service->status === 'active' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($service->status) }}
                        </span>
                        <span class="ml-3 text-indigo-200 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Updated {{ $service->updated_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.services.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Services
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.services.update', $service) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Essential details for your service</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Name -->
                    <div class="lg:col-span-2">
                        <label for="name" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-heading mr-2 text-gray-500"></i>Service Name <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="name" id="name" value="{{ old('name', $service->name) }}"
                               class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('name') border-red-500 @enderror"
                               placeholder="Enter service name" required>
                        @error('name')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Category -->
                    <div>
                        <label for="service_category_id" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-tags mr-2 text-gray-500"></i>Category
                        </label>
                        <select name="service_category_id" id="service_category_id"
                                class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('service_category_id') border-red-500 @enderror">
                            <option value="">Select Category</option>
                            @foreach(\App\Models\ServiceCategory::all() as $category)
                                <option value="{{ $category->id }}" {{ old('service_category_id', $service->service_category_id) == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        @error('service_category_id')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Status -->
                    <div>
                        <label for="status" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Status <span class="text-red-500">*</span>
                        </label>
                        <select name="status" id="status"
                                class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('status') border-red-500 @enderror">
                            <option value="active" {{ old('status', $service->status) == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ old('status', $service->status) == 'inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                        @error('status')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Content Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-edit mr-2 text-green-600"></i>Service Content
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Description and details of your service</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <!-- Short Description -->
                <div class="mb-6">
                    <label for="short_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-file-alt mr-2 text-gray-500"></i>Short Description
                    </label>
                    <textarea name="short_description" id="short_description" rows="3"
                              class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 resize-vertical @error('short_description') border-red-500 @enderror"
                              placeholder="Brief description of the service (shown on service cards)">{{ old('short_description', $service->short_description) }}</textarea>
                    <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>This will be shown on the service preview cards. Keep it concise (1-2 sentences).
                    </p>
                    @error('short_description')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>

                <!-- Content Blocks -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-th-large mr-2 text-gray-500"></i>Service Description Blocks
                    </label>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>Add headings, paragraphs, and images to describe your service. No HTML needed!
                    </p>

                    <div id="content_blocks_container" class="space-y-4">
                        <!-- Content blocks will be added here by JavaScript -->
                    </div>

                    <button type="button" id="add_content_block_btn" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        Add Content Block
                    </button>
                </div>

                <!-- Features List -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-star mr-2 text-gray-500"></i>Service Features
                    </label>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>List the key features or benefits of this service.
                    </p>

                    <div id="features_container" class="space-y-3">
                        <!-- Features will be added here by JavaScript -->
                    </div>

                    <button type="button" onclick="addFeature()" class="mt-3 inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        Add Feature
                    </button>
                </div>

                <!-- Pricing Information (Optional) -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-dollar-sign mr-2 text-gray-500"></i>Pricing Information <span class="text-gray-400">(Optional)</span>
                    </label>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="price_label" class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Price Label</label>
                            <input type="text" name="pricing_info[label]" id="price_label" value="{{ old('pricing_info.label', $service->pricing_info['label'] ?? '') }}"
                                   class="block w-full px-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 text-sm"
                                   placeholder="e.g., Starting at">
                        </div>
                        <div>
                            <label for="price_amount" class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Price Amount</label>
                            <input type="text" name="pricing_info[amount]" id="price_amount" value="{{ old('pricing_info.amount', $service->pricing_info['amount'] ?? '') }}"
                                   class="block w-full px-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 text-sm"
                                   placeholder="e.g., $99/month">
                        </div>
                    </div>
                    <div class="mt-3">
                        <label for="price_description" class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Pricing Description</label>
                        <textarea name="pricing_info[description]" id="price_description" rows="2"
                                  class="block w-full px-3 py-2 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 text-sm resize-none"
                                  placeholder="Additional pricing details or conditions">{{ old('pricing_info.description', $service->pricing_info['description'] ?? '') }}</textarea>
                    </div>
                </div>

                <!-- Icon -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-image mr-2 text-gray-500"></i>Icon Image/Video
                    </label>
                    @include('admin.media.picker', [
                        'fieldName' => 'icon_image',
                        'selectedMedia' => $service->icon,
                        'label' => 'Icon Image/Video',
                        'help' => 'Select an icon image or video for this service',
                        'required' => false,
                        'allowedTypes' => ['image', 'video'],
                        'previewSize' => 'w-24 h-24'
                    ])
                </div>
            </div>

            <!-- SEO Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-search mr-2 text-purple-600"></i>Search Engine Optimization (SEO)
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Help search engines understand your service</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- SEO Title -->
                    <div class="lg:col-span-2">
                        <label for="meta_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-tag mr-2 text-gray-500"></i>Meta Title
                        </label>
                        <input type="text" name="meta_title" id="meta_title" value="{{ old('meta_title', $service->seo?->meta_title) }}"
                               class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="SEO title for search engines" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Leave blank to use service name. Recommended: 50-60 characters
                        </p>
                        @error('meta_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Description -->
                    <div class="lg:col-span-2">
                        <label for="meta_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-text mr-2 text-gray-500"></i>Meta Description
                        </label>
                        <textarea name="meta_description" id="meta_description" rows="3"
                                  class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 resize-none @error('meta_description') border-red-500 @enderror"
                                  placeholder="Brief description for search engines" maxlength="500">{{ old('meta_description', $service->seo?->meta_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Brief description for search engines. Recommended: 150-160 characters
                        </p>
                        @error('meta_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Keywords -->
                    <div>
                        <label for="meta_keywords" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-key mr-2 text-gray-500"></i>Meta Keywords
                        </label>
                        <input type="text" name="meta_keywords" id="meta_keywords" value="{{ old('meta_keywords', $service->seo?->meta_keywords) }}"
                               class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="keyword1, keyword2, keyword3">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Comma-separated keywords (optional)
                        </p>
                        @error('meta_keywords')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Canonical URL -->
                    <div>
                        <label for="canonical_url" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-external-link-alt mr-2 text-gray-500"></i>Canonical URL
                        </label>
                        <input type="url" name="canonical_url" id="canonical_url" value="{{ old('canonical_url', $service->seo?->canonical_url) }}"
                               class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="https://example.com/service-url">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Canonical URL to prevent duplicate content issues
                        </p>
                        @error('canonical_url')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Social Media Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Media Sharing
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">How your service appears when shared on social media</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Open Graph Title -->
                    <div class="lg:col-span-2">
                        <label for="og_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Title
                        </label>
                        <input type="text" name="og_title" id="og_title" value="{{ old('og_title', $service->seo?->og_title) }}"
                               class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200"
                               placeholder="Title for social media sharing" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Title for social media sharing. Leave blank to use meta title
                        </p>
                        @error('og_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Description -->
                    <div class="lg:col-span-2">
                        <label for="og_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Description
                        </label>
                        <textarea name="og_description" id="og_description" rows="2"
                                  class="w-full px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200 resize-none @error('og_description') border-red-500 @enderror"
                                  placeholder="Description for social media sharing" maxlength="500">{{ old('og_description', $service->seo?->og_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Description for social media sharing. Leave blank to use meta description
                        </p>
                        @error('og_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Image -->
                    <div class="lg:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Image
                        </label>
                        @include('admin.media.picker', [
                            'fieldName' => 'og_image',
                            'selectedMedia' => $service->seo?->ogImage,
                            'label' => 'Open Graph Image',
                            'help' => 'Image for social media sharing (recommended: 1200x630px)',
                            'required' => false,
                            'allowedTypes' => ['image'],
                            'previewSize' => 'w-32 h-20'
                        ])
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.services.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update Service
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
let contentBlockIndex = 0;
let featureIndex = 0;

// Add Content Block
function addContentBlock(type = 'heading', content = '', image = '') {
    const container = document.getElementById('content_blocks_container');
    const blockDiv = document.createElement('div');
    blockDiv.className = 'p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';
    
    const escapedContent = content.replace(/'/g, "\\'").replace(/"/g, '&quot;');
    const escapedImage = image.replace(/'/g, "\\'");
    
    let blockContentHTML = '';
    if (type === 'heading') {
        blockContentHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Heading Text</label>
            <input type="text" name="content_blocks[${contentBlockIndex}][content]" value="${escapedContent}" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter heading text">
        `;
    } else if (type === 'paragraph') {
        blockContentHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Paragraph Text</label>
            <textarea name="content_blocks[${contentBlockIndex}][content]" rows="4" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter paragraph text">${escapedContent}</textarea>
        `;
    } else {
        const imagePreview = image ? 
            `<img src="/storage/${escapedImage}" alt="Block image" class="w-32 h-32 object-cover rounded border">` : 
            '<div class="w-32 h-32 bg-gray-200 dark:bg-gray-700 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';
        
        blockContentHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
            <input type="hidden" name="content_blocks[${contentBlockIndex}][image]" id="block_image_${contentBlockIndex}" value="${escapedImage}">
            <div id="block_image_preview_${contentBlockIndex}" class="mb-2">
                ${imagePreview}
            </div>
            <button type="button" onclick="openContentBlockMediaSelector('block_image_${contentBlockIndex}', 'block_image_preview_${contentBlockIndex}')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
            <input type="text" name="content_blocks[${contentBlockIndex}][content]" value="${escapedContent}" class="mt-2 block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Image caption (optional)">
        `;
    }
    
    blockDiv.innerHTML = `
        <div class="flex gap-3">
            <div class="flex-1">
                <div class="mb-3">
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Block Type</label>
                    <select name="content_blocks[${contentBlockIndex}][type]" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" onchange="handleBlockTypeChange(this, ${contentBlockIndex})">
                        <option value="heading" ${type === 'heading' ? 'selected' : ''}>Heading</option>
                        <option value="paragraph" ${type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
                        <option value="image" ${type === 'image' ? 'selected' : ''}>Image</option>
                    </select>
                </div>
                <div id="block_content_${contentBlockIndex}">
                    ${blockContentHTML}
                </div>
            </div>
            <button type="button" onclick="this.parentElement.parentElement.remove()" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50 h-fit">
                Remove
            </button>
        </div>
    `;
    
    container.appendChild(blockDiv);
    contentBlockIndex++;
}

// Handle block type change
function handleBlockTypeChange(select, index) {
    const type = select.value;
    const contentContainer = document.getElementById(`block_content_${index}`);
    
    if (type === 'heading') {
        contentContainer.innerHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Heading Text</label>
            <input type="text" name="content_blocks[${index}][content]" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter heading text">
        `;
    } else if (type === 'paragraph') {
        contentContainer.innerHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Paragraph Text</label>
            <textarea name="content_blocks[${index}][content]" rows="4" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter paragraph text"></textarea>
        `;
    } else {
        contentContainer.innerHTML = `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
            <input type="hidden" name="content_blocks[${index}][image]" id="block_image_${index}" value="">
            <div id="block_image_preview_${index}" class="mb-2">
            '<div class="w-32 h-32 bg-gray-200 dark:bg-gray-700 rounded border flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';
            </div>
            <button type="button" onclick="openContentBlockMediaSelector('block_image_${index}', 'block_image_preview_${index}')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
            <input type="text" name="content_blocks[${index}][content]" class="mt-2 block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Image caption (optional)">
        `;
    }
}

// Add Feature
function addFeature(text = '') {
    const container = document.getElementById('features_container');
    const featureDiv = document.createElement('div');
    featureDiv.className = 'flex gap-2';
    
    const escapedText = text.replace(/'/g, "\\'").replace(/"/g, '&quot;');
    
    featureDiv.innerHTML = `
        <input type="text" name="features[]" value="${escapedText}" class="flex-1 bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter feature or benefit">
        <button type="button" onclick="this.parentElement.remove()" class="px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50">
            Remove
        </button>
    `;
    
    container.appendChild(featureDiv);
    featureIndex++;
}

// Content block media selector function
function openContentBlockMediaSelector(fieldName, previewId) {
    // Store preview ID for callback - fieldId will come from the message
    if (!window.contentBlockPreviewMap) {
        window.contentBlockPreviewMap = {};
    }
    window.contentBlockPreviewMap[fieldName] = previewId;
    
    window.open(`/admin/media-selector?type=image&fieldId=${encodeURIComponent(fieldName)}`, 'Media Selector', 'width=1200,height=800,scrollbars=yes,resizable=yes');
}

// Global message listener for content block media selection
if (!window.contentBlockMediaListenerAttached) {
    window.contentBlockMediaListenerAttached = true;
    window.addEventListener('message', function(event) {
        if (event.origin !== window.location.origin) return;
        
        if (event.data && event.data.type === 'MEDIA_SELECTED') {
            const media = event.data.media;
            const fieldId = event.data.fieldId;
            const previewId = window.contentBlockPreviewMap ? window.contentBlockPreviewMap[fieldId] : null;
            
            const input = document.getElementById(fieldId);
            const preview = previewId ? document.getElementById(previewId) : null;
            
            if (input) {
                input.value = media.file_path || media.path || '';
            }
            
            if (preview) {
                preview.innerHTML = `<img src="${media.url}" alt="Selected image" class="w-32 h-32 object-cover rounded border">`;
            }
        }
    });
}

// Load existing content blocks and features
document.addEventListener('DOMContentLoaded', function() {
    // Add event listener to the add button
    const addButton = document.getElementById('add_content_block_btn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            addContentBlock('paragraph');
        });
    }
    
    // Load existing content blocks
    @if($service->content_blocks && is_array($service->content_blocks))
        @foreach($service->content_blocks as $block)
            addContentBlock(
                '{{ $block["type"] ?? "heading" }}',
                {!! json_encode($block["content"] ?? "") !!},
                '{{ $block["image"] ?? "" }}'
            );
        @endforeach
    @else
        addContentBlock('heading');
    @endif

    // Load existing features
    @if($service->features && is_array($service->features))
        @foreach($service->features as $feature)
            addFeature({!! json_encode($feature) !!});
        @endforeach
    @else
        addFeature();
    @endif
});
</script>

@endsection
