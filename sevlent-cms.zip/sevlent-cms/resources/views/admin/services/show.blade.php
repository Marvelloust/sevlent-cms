@extends('admin.layouts.app')

@section('title', 'View Service')
@section('page-title', 'View Service')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $service->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                            <i class="fas {{ $service->status === 'active' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($service->status) }}
                        </span>
                        <span class="ml-3 text-sm font-medium text-gray-200">
                            <i class="fas fa-globe mr-1"></i>
                            <a href="{{ url('/services/' . $service->slug) }}" target="_blank" class="hover:text-white underline">
                                View Live
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $service->name }}</h1>
                    <div class="flex flex-wrap gap-6 text-gray-300 text-sm">
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Created {{ $service->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $service->updated_at->diffForHumans() }}
                        </span>
                        <span>
                            <i class="fas fa-link mr-2"></i><code class="bg-blue-500 bg-opacity-30 px-2 py-1 rounded">{{ $service->slug }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.services.edit', $service) }}" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-800 text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-all duration-200">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="{{ route('admin.services.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Icon Image Preview -->
    @if($service->icon)
        <div class="rounded-xl overflow-hidden shadow-lg">
            <img src="{{ $service->icon->url }}" alt="Service Icon" class="w-full h-64 object-cover">
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Short Description -->
            @if($service->short_description)
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-file-alt mr-2 text-blue-600"></i>Short Description
                        </h3>
                    </div>
                    <div class="px-6 py-8">
                        <p class="text-gray-700 dark:text-gray-300 leading-relaxed">{{ $service->short_description }}</p>
                    </div>
                </div>
            @endif

            <!-- Content Blocks -->
            @if($service->content_blocks && count($service->content_blocks) > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-th-large mr-2 text-green-600"></i>Content Blocks ({{ count($service->content_blocks) }})
                        </h3>
                    </div>
                    <div class="divide-y divide-gray-200">
                        @foreach($service->content_blocks as $block)
                            <div class="px-6 py-6 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 transition-colors duration-200">
                                @if($block['type'] === 'heading')
                                    <h4 class="text-xl font-bold text-gray-900 dark:text-white mb-2">{{ $block['content'] ?? 'No heading text' }}</h4>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Heading Block</span>
                                @elseif($block['type'] === 'paragraph')
                                    <div class="prose prose-sm max-w-none prose-a:text-blue-600 dark:prose-a:text-blue-400 prose-a:underline dark:text-gray-300">
                                        {!! nl2br(e($block['content'] ?? 'No paragraph text')) !!}
                                    </div>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Paragraph Block</span>
                                @elseif($block['type'] === 'image')
                                    @if(isset($block['image']) && $block['image'])
                                        <div class="mb-4">
                                            <img src="/storage/{{ $block['image'] }}" alt="{{ $block['content'] ?? 'Block image' }}" class="w-full h-48 object-cover rounded-lg shadow-md">
                                        </div>
                                    @endif
                                    @if(isset($block['content']) && $block['content'])
                                        <p class="text-gray-700 dark:text-gray-300 mb-2">{{ $block['content'] }}</p>
                                    @endif
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Image Block</span>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
            @else
                <div class="mt-8 bg-blue-50 rounded-xl border-2 border-blue-200 p-6">
                    <div class="flex">
                        <i class="fas fa-info-circle text-blue-600 text-xl mr-4 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-blue-900 dark:text-blue-100 mb-1">No Content Blocks</h4>
                            <p class="text-sm text-blue-800 dark:text-blue-200">This service doesn't have any content blocks yet.
                                <a href="{{ route('admin.services.edit', $service) }}" class="font-semibold hover:underline">Add content blocks</a> to build out your service.
                            </p>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Features -->
            @if($service->features && count($service->features) > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-star mr-2 text-yellow-600"></i>Service Features ({{ count($service->features) }})
                        </h3>
                    </div>
                    <div class="px-6 py-6">
                        <ul class="space-y-3">
                            @foreach($service->features as $feature)
                                <li class="flex items-start">
                                    <i class="fas fa-check-circle text-green-600 mt-1 mr-3"></i>
                                    <span class="text-gray-700 dark:text-gray-300">{{ $feature }}</span>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif

            <!-- Pricing Information -->
            @if($service->pricing_info)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-dollar-sign mr-2 text-green-600"></i>Pricing Information
                        </h3>
                    </div>
                    <div class="px-6 py-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            @if(isset($service->pricing_info['label']))
                                <div>
                                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Label</p>
                                    <p class="text-lg font-semibold text-gray-900 dark:text-white">{{ $service->pricing_info['label'] }}</p>
                                </div>
                            @endif
                            @if(isset($service->pricing_info['amount']))
                                <div>
                                    <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Amount</p>
                                    <p class="text-2xl font-bold text-green-600">{{ $service->pricing_info['amount'] }}</p>
                                </div>
                            @endif
                        </div>
                        @if(isset($service->pricing_info['description']))
                            <div class="mt-4">
                                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Description</p>
                                <p class="text-gray-700 dark:text-gray-300">{{ $service->pricing_info['description'] }}</p>
                            </div>
                        @endif
                    </div>
                </div>
            @endif
        </div>

        <!-- Sidebar: Metadata -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Basic Info Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>Service Info
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $service->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                            {{ ucfirst($service->status) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Category</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $service->category->name ?? 'No Category' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">URL Slug</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-gray-800 dark:text-white break-all">{{ $service->slug }}</code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Created</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $service->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $service->updated_at->format('M d, Y H:i') }}</p>
                    </div>
                </div>
            </div>

            <!-- SEO Metadata Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-search mr-2 text-purple-600"></i>SEO Metadata
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($service->seo?->meta_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Title</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-blue-50 dark:bg-blue-900/20 p-2 rounded border-l-2 border-blue-500">
                                {{ $service->seo->meta_title }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($service->seo->meta_title) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta title set</p>
                        </div>
                    @endif

                    @if($service->seo?->meta_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Description</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-green-50 dark:bg-green-900/20 p-2 rounded border-l-2 border-green-500 leading-relaxed">
                                {{ $service->seo->meta_description }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($service->seo->meta_description) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta description set</p>
                        </div>
                    @endif

                    @if($service->seo?->meta_keywords)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Keywords</p>
                            <div class="flex flex-wrap gap-2">
                                @foreach(explode(',', $service->seo->meta_keywords) as $keyword)
                                    <span class="inline-block px-3 py-1 bg-yellow-100 dark:bg-yellow-300 text-yellow-800 dark:text-yellow-200 text-xs font-semibold rounded-full">
                                        {{ trim($keyword) }}
                                    </span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @if($service->seo?->canonical_url)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Canonical URL</p>
                            <a href="{{ $service->seo->canonical_url }}" target="_blank" class="text-sm text-blue-600 hover:text-blue-700 break-all">
                                {{ $service->seo->canonical_url }}
                                <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                    @endif
                </div>
                <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                    <a href="{{ route('admin.services.edit', $service) }}" class="text-sm font-medium text-purple-600 hover:text-purple-700">
                        <i class="fas fa-edit mr-1"></i>Edit SEO
                    </a>
                </div>
            </div>

            <!-- Social Sharing Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Sharing
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($service->seo?->og_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Title</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $service->seo->og_title }}</p>
                        </div>
                    @endif

                    @if($service->seo?->og_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Description</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $service->seo->og_description }}</p>
                        </div>
                    @endif

                    @if($service->seo?->ogImage)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Image</p>
                            <img src="{{ asset('storage/' . $service->seo->ogImage->file_path) }}" alt="OG" class="w-full h-32 object-cover rounded">
                        </div>
                    @endif

                    @if(!$service->seo?->og_title && !$service->seo?->og_description && !$service->seo?->ogImage)
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-share-alt mr-2"></i>No OG data configured</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
