@extends('admin.layouts.app')

@section('title', 'Edit Media')
@section('page-title', 'Edit Media File')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r rounded-xl shadow-lg overflow-hidden  from-blue-600 to-indigo-600">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-file-alt mr-3"></i>Edit Media File
                    </h1>
                    <p style="color: #d1fae5;">{{ Str::limit($medium->file_name, 50) }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                            <i class="fas fa-tag mr-1"></i>{{ ucfirst($medium->file_type) }}
                        </span>
                        <span class="ml-3 text-sm" style="color: #a7f3d0;">
                            <i class="fas fa-calendar mr-1"></i>Uploaded {{ $medium->created_at->diffForHumans() }}
                        </span>
                        <span class="ml-3 text-sm" style="color: #a7f3d0;">
                            <i class="fas fa-weight mr-1"></i>{{ number_format($medium->file_size / 1024, 1) }} KB
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.media.show', $medium) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-eye mr-2"></i>View File
                    </a>
                    <a href="{{ route('admin.media.index') }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Media Library
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Current File Preview Section -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900">
                <i class="fas fa-image mr-2 text-green-600"></i>Current File Preview
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">File information and preview</p>
        </div>
        <div class="px-6 py-6">
            <div class="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
                <!-- File Preview -->
                <div class="flex-shrink-0">
                    @if($medium->file_type === 'image')
                        <div class="relative">
                            <img src="{{ $medium->url }}" alt="{{ $medium->alt_text }}" class="w-24 h-24 object-cover rounded-lg border-2 border-gray-200 dark:border-gray-700 shadow-md">
                            <div class="absolute -top-2 -right-2 bg-green-500 text-white rounded-full p-1">
                                <i class="fas fa-image text-xs"></i>
                            </div>
                        </div>
                    @elseif($medium->file_type === 'video')
                        <div class="relative">
                            <video class="w-24 h-24 object-cover rounded-lg border-2 border-gray-200 dark:border-gray-700 shadow-md" muted>
                                <source src="{{ $medium->url }}" type="{{ $medium->mime_type }}">
                            </video>
                            <div class="absolute -top-2 -right-2 bg-blue-500 text-white rounded-full p-1">
                                <i class="fas fa-video text-xs"></i>
                            </div>
                        </div>
                    @elseif($medium->file_type === 'audio')
                        <div class="w-24 h-24 bg-gradient-to-br from-purple-100 to-purple-200 rounded-lg border-2 border-gray-200 dark:border-gray-700 shadow-md flex items-center justify-center">
                            <div class="text-center">
                                <i class="fas fa-music text-2xl text-purple-600 mb-1"></i>
                                <div class="text-xs text-purple-600 font-medium">AUDIO</div>
                            </div>
                        </div>
                    @else
                        <div class="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg border-2 border-gray-200 dark:border-gray-700 shadow-md flex items-center justify-center">
                            <div class="text-center">
                                <i class="fas fa-file text-2xl text-gray-600 dark:text-gray-400 mb-1"></i>
                                <div class="text-xs text-gray-600 dark:text-gray-400 font-medium">{{ strtoupper($medium->file_type ?? 'FILE') }}</div>
                            </div>
                        </div>
                    @endif
                </div>

                <!-- File Details -->
                <div class="flex-1 min-w-0">
                    <h4 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">{{ $medium->file_name }}</h4>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mb-1">
                                <i class="fas fa-tag mr-2 text-blue-500"></i>
                                <span class="font-medium">Type:</span> {{ ucfirst($medium->file_type) }}
                            </p>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mb-1">
                                <i class="fas fa-code mr-2 text-green-500"></i>
                                <span class="font-medium">MIME:</span> {{ $medium->mime_type }}
                            </p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mb-1">
                                <i class="fas fa-weight mr-2 text-orange-500"></i>
                                <span class="font-medium">Size:</span> {{ number_format($medium->file_size / 1024, 1) }} KB
                            </p>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mb-1">
                                <i class="fas fa-hashtag mr-2 text-purple-500"></i>
                                <span class="font-medium">ID:</span> {{ $medium->id }}
                            </p>
                        </div>
                    </div>
                    @if($medium->uploader)
                        <p class="text-sm text-gray-600 dark:text-gray-400 mt-2">
                            <i class="fas fa-user mr-2 text-indigo-500"></i>
                            <span class="font-medium">Uploaded by:</span> {{ $medium->uploader->name }}
                        </p>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.media.update', $medium) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Metadata Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900">
                    <i class="fas fa-tags mr-2 text-blue-600"></i>Metadata
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">File description and accessibility information</p>
            </div>
            <div class="px-6 py-6">
                <!-- Alt Text -->
                <div>
                    <label for="alt_text" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-universal-access mr-2 text-gray-500 dark:text-gray-400"></i>Alt Text
                        @if($medium->file_type === 'image')
                            <span class="text-gray-500 dark:text-gray-400">(for accessibility and SEO)</span>
                        @else
                            <span class="text-gray-500 dark:text-gray-400">(description)</span>
                        @endif
                    </label>
                    <input type="text" name="alt_text" id="alt_text" value="{{ old('alt_text', $medium->alt_text) }}"
                           class="w-full bg-white dark:bg-gray-900 px-4 py-3 border {{ $errors->has('alt_text') ? 'border-red-500' : 'border-gray-300 dark:border-gray-600' }} text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                           placeholder="Describe this file for accessibility and SEO">
                    @error('alt_text')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                        <p class="flex items-start">
                            <i class="fas fa-info-circle mr-2 mt-0.5 text-blue-500"></i>
                            @if($medium->file_type === 'image')
                                Alt text helps screen readers understand images and improves SEO. Keep it concise but descriptive (under 125 characters).
                            @else
                                This description helps identify the file in your media library and provides context for its use.
                            @endif
                        </p>
                    </div>
                </div>
            </div>

            <!-- File Replacement Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900">
                    <i class="fas fa-exchange-alt mr-2 text-orange-600"></i>File Replacement
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Upload a new file to replace the current one (optional)</p>
            </div>
            <div class="px-6 py-6">
                <!-- Replace File -->
                <div>
                    <label for="file" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-upload mr-2 text-gray-500 dark:text-gray-400"></i>Select New File
                    </label>
                    <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-lg hover:border-orange-400 dark:hover:border-orange-500 transition-colors duration-200">
                        <input id="file" name="file" type="file" class="sr-only"
                               accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar">
                        <div class="space-y-1 text-center">
                            <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 dark:text-gray-500 mb-3"></i>
                            <div class="flex text-sm text-gray-600 dark:text-gray-400">
                                <label for="file" class="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-orange-600 dark:text-orange-400 hover:text-orange-500 dark:hover:text-orange-300 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-orange-500">
                                    <span>Upload a file</span>
                                </label>
                                <p class="pl-1">or drag and drop</p>
                            </div>
                            <p class="text-xs text-gray-500 dark:text-gray-400">
                                Images, videos, audio, documents up to 50MB
                            </p>
                        </div>
                    </div>
                    @error('file')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                    <div class="mt-3 text-sm text-gray-600 dark:text-gray-400 bg-orange-50 dark:bg-orange-950 rounded-lg p-3">
                        <p class="flex items-start">
                            <i class="fas fa-exclamation-triangle mr-2 mt-0.5 text-orange-500 dark:text-orange-400"></i>
                            <strong>Warning:</strong> Replacing the file will permanently delete the current file and update all references. This action cannot be undone.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.media.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update Media File
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Usage Guidelines Section -->
    @if($medium->file_type === 'image')
    <div class="bg-blue-50 dark:bg-blue-950 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-blue-200 dark:border-blue-800 bg-blue-100 dark:bg-blue-900">
            <h3 class="text-lg font-semibold text-blue-900 dark:text-blue-300">
                <i class="fas fa-lightbulb mr-2 text-blue-600 dark:text-blue-400"></i>Image Usage Guidelines
            </h3>
        </div>
        <div class="px-6 py-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-universal-access mr-2 text-blue-600 dark:text-blue-400"></i>Accessibility Best Practices
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Use descriptive alt text that explains what the image shows
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Keep alt text concise but informative (under 125 characters)
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Avoid starting with "Image of" or "Picture of"
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            For decorative images, you can leave alt text empty
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-search mr-2 text-blue-600 dark:text-blue-400"></i>SEO Best Practices
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Include relevant keywords naturally in alt text
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Use descriptive file names (not IMG001.jpg)
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Ensure images are properly sized for web use
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Use appropriate image formats (JPEG for photos, PNG for graphics)
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.querySelector('.border-dashed');
    const fileInput = document.getElementById('file');

    // Drag and drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        dropZone.classList.add('border-orange-500', 'dark:border-orange-400', 'bg-orange-50', 'dark:bg-orange-950');
        dropZone.classList.remove('border-gray-300', 'dark:border-gray-600');
    }

    function unhighlight(e) {
        dropZone.classList.remove('border-orange-500', 'dark:border-orange-400', 'bg-orange-50', 'dark:bg-orange-950');
        dropZone.classList.add('border-gray-300', 'dark:border-gray-600');
    }

    dropZone.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0) {
            // Only handle the first file since this is for replacement
            const file = files[0];

            // Validate file
            if (validateFile(file)) {
                // Create a new DataTransfer object to update the file input
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                fileInput.files = dataTransfer.files;

                // Update the UI to show the selected file
                updateFileDisplay(file);
            }
        }
    }

    fileInput.addEventListener('change', function(e) {
        const files = e.target.files;
        if (files.length > 0) {
            const file = files[0];
            if (validateFile(file)) {
                updateFileDisplay(file);
            } else {
                // Clear the input if validation fails
                fileInput.value = '';
            }
        }
    });

    function validateFile(file) {
        const maxSize = 50 * 1024 * 1024; // 50MB
        const allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/svg+xml', 'image/webp',
            'video/mp4', 'video/avi', 'video/quicktime', 'video/webm',
            'audio/mpeg', 'audio/wav', 'audio/ogg',
            'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'text/plain', 'application/zip', 'application/x-rar-compressed'
        ];

        if (file.size > maxSize) {
            alert(`File "${file.name}" exceeds the maximum size of 50MB.`);
            return false;
        }

        if (!allowedTypes.includes(file.type) && file.type !== '') {
            // Allow files with empty type (some systems don't set MIME type properly)
            const extension = file.name.split('.').pop().toLowerCase();
            const allowedExtensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'zip', 'rar'];
            if (!allowedExtensions.includes(extension)) {
                alert(`File type of "${file.name}" is not supported.`);
                return false;
            }
        }

        return true;
    }

    function updateFileDisplay(file) {
        // Update the drop zone to show selected file
        const dropZoneContent = dropZone.querySelector('.space-y-1');
        dropZoneContent.innerHTML = `
            <div class="flex items-center justify-center space-x-3">
                ${getFileIcon(file.type)}
                <div class="text-center">
                    <p class="text-sm font-medium text-gray-900">${file.name}</p>
                    <p class="text-xs text-gray-500 dark:text-gray-400">${formatFileSize(file.size)}</p>
                    <button type="button" onclick="clearFile()" class="mt-2 text-xs text-red-600 hover:text-red-800">
                        <i class="fas fa-times mr-1"></i>Remove file
                    </button>
                </div>
            </div>
        `;

        // Change border color to indicate file is selected
        dropZone.classList.add('border-green-400', 'dark:border-green-500', 'bg-green-50', 'dark:bg-green-950');
        dropZone.classList.remove('border-gray-300', 'dark:border-gray-600', 'border-dashed');
    }

    function getFileIcon(mimeType) {
        if (mimeType.startsWith('image/')) {
            return '<i class="fas fa-image text-3xl text-green-600"></i>';
        } else if (mimeType.startsWith('video/')) {
            return '<i class="fas fa-video text-3xl text-blue-600"></i>';
        } else if (mimeType.startsWith('audio/')) {
            return '<i class="fas fa-music text-3xl text-purple-600"></i>';
        } else {
            return '<i class="fas fa-file text-3xl text-gray-600"></i>';
        }
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    window.clearFile = function() {
        // Clear the file input
        fileInput.value = '';

        // Reset the drop zone content
        const dropZoneContent = dropZone.querySelector('.space-y-1');
        dropZoneContent.innerHTML = `
            <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
            <div class="flex text-sm text-gray-600">
                <label for="file" class="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-orange-600 hover:text-orange-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-orange-500">
                    <span>Upload a file</span>
                </label>
                <p class="pl-1">or drag and drop</p>
            </div>
            <p class="text-xs text-gray-500 dark:text-gray-400">
                Images, videos, audio, documents up to 50MB
            </p>
        `;

        dropZone.classList.remove('border-green-400', 'dark:border-green-500', 'bg-green-50', 'dark:bg-green-950');
        dropZone.classList.add('border-gray-300', 'dark:border-gray-600', 'border-dashed');
    };
});
</script>
@endsection