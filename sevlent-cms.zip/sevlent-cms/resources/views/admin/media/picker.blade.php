{{--
    Media Picker Component

    Usage:
    @include('admin.media.picker', [
        'fieldName' => 'image_id', // The field name for the hidden input
        'selectedMedia' => $page->image ?? null, // The currently selected media (optional)
        'label' => 'Featured Image', // Label for the field
        'help' => 'Select an image for this page', // Help text
        'required' => false, // Whether the field is required
        'allowedTypes' => ['image'], // Array of allowed file types
        'previewSize' => 'w-32 h-32' // CSS classes for preview size
    ])
--}}

@php
    $fieldName = $fieldName ?? 'media_id';
    $selectedMedia = $selectedMedia ?? null;
    $label = $label ?? 'Select Media';
    $help = $help ?? '';
    $required = $required ?? false;
    $allowedTypes = $allowedTypes ?? ['image', 'video', 'audio', 'document'];
    $previewSize = $previewSize ?? 'w-24 h-24';
@endphp

<div class="media-picker" data-field="{{ $fieldName }}" data-allowed-types="{{ json_encode($allowedTypes) }}">
    <label for="{{ $fieldName }}" class="block text-sm font-medium text-gray-700 dark:text-gray-300">
        {{ $label }}
        @if($required)
            <span class="text-red-500">*</span>
        @endif
    </label>

    <!-- Hidden input to store selected media ID -->
    <input type="hidden" name="{{ $fieldName }}" id="{{ $fieldName }}" value="{{ $selectedMedia ? $selectedMedia->id : '' }}" {{ $required ? 'required' : '' }}>

    <!-- Current selection display -->
    <div class="mt-2">
        <div id="{{ $fieldName }}-preview" class="relative border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 transition-all duration-200 {{ $selectedMedia ? 'border-solid border-blue-400 dark:border-blue-700 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 shadow-sm' : 'hover:border-gray-400 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700' }}">
            @if($selectedMedia)
                <div class="flex items-center space-x-4">
                    <!-- Media preview with enhanced styling -->
                    <div class="{{ $previewSize }} flex-shrink-0 relative group">
                        <div class="absolute -inset-1 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-lg blur opacity-25 group-hover:opacity-40 transition duration-200"></div>
                        <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                            @if($selectedMedia->file_type === 'image')
                                <img src="{{ $selectedMedia->url }}" alt="{{ $selectedMedia->alt_text }}" class="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105">
                                <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                            @elseif($selectedMedia->file_type === 'video')
                                <video class="w-full h-full object-cover" muted>
                                    <source src="{{ $selectedMedia->url }}" type="{{ $selectedMedia->mime_type }}">
                                </video>
                                <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                    <div class="bg-white/90 rounded-full p-2">
                                        <svg class="w-4 h-4 text-gray-800 dark:text-white" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M8 5v14l11-7z"/>
                                        </svg>
                                    </div>
                                </div>
                            @elseif($selectedMedia->file_type === 'audio')
                                <div class="w-full h-full bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
                                    <svg class="w-10 h-10 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
                                    </svg>
                                </div>
                            @else
                                <div class="w-full h-full bg-gradient-to-br from-gray-100 to-slate-200 flex items-center justify-center">
                                    <svg class="w-10 h-10 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Media info with better typography -->
                    <div class="flex-1 min-w-0">
                        <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-1 truncate">{{ $selectedMedia->file_name }}</h4>
                        <div class="flex items-center space-x-3 text-xs text-gray-500 dark:text-gray-400 mb-1">
                            <span class="inline-flex items-center px-2 py-1 rounded-full bg-blue-100 text-blue-800 font-medium">
                                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                </svg>
                                {{ ucfirst($selectedMedia->file_type) }}
                            </span>
                            <span>{{ number_format($selectedMedia->file_size / 1024, 1) }} KB</span>
                        </div>
                        <p class="text-xs text-gray-400">{{ $selectedMedia->created_at->format('M d, Y \a\t g:i A') }}</p>
                    </div>

                    <!-- Enhanced action buttons -->
                    <div class="flex flex-col space-y-2">
                            <button type="button" onclick="openMediaSelector('{{ $fieldName }}')"
                                class="inline-flex items-center px-3 py-2 border border-blue-300 dark:border-blue-600 shadow-sm text-xs font-medium rounded-lg text-blue-700 dark:text-blue-200 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900 hover:border-blue-400 transition-colors duration-200">
                            <svg class="-ml-0.5 mr-1.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                            </svg>
                            Change
                        </button>
                        <button type="button" onclick="removeMedia('{{ $fieldName }}')"
                            class="inline-flex items-center px-3 py-2 border border-red-300 dark:border-red-600 shadow-sm text-xs font-medium rounded-lg text-red-700 dark:text-red-100 bg-white dark:bg-gray-800 hover:bg-red-50 dark:hover:bg-red-700 hover:border-red-400 transition-colors duration-200">
                            <svg class="-ml-0.5 mr-1.5 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                            Remove
                        </button>
                    </div>
                </div>
            @else
                <div class="text-center">
                    <div class="mx-auto w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-full flex items-center justify-center mb-4">
                        <svg class="w-8 h-8 text-gray-400 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <button type="button" onclick="openMediaSelector('{{ $fieldName }}')"
                                class="inline-flex items-center px-6 py-3 border border-transparent text-sm font-semibold rounded-xl text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                            <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                            </svg>
                            Select Media
                        </button>
                        @if($help)
                            <p class="text-sm text-gray-500 dark:text-gray-400">{{ $help }}</p>
                        @endif
                    </div>
                </div>
            @endif
        </div>
    </div>

    @error($fieldName)
        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
    @enderror
</div>

<script>
function openMediaSelector(fieldName) {
    const allowedTypes = document.querySelector(`[data-field="${fieldName}"]`).dataset.allowedTypes;
    const types = JSON.parse(allowedTypes);
    const url = `{{ route('admin.media.selector') }}?types=${encodeURIComponent(JSON.stringify(types))}&fieldId=${encodeURIComponent(fieldName)}`;

    window.open(url, 'mediaSelector', 'width=1200,height=800,scrollbars=yes,resizable=yes');
}

// Global message listener for media selection
if (!window.mediaPickerListenerAttached) {
    window.mediaPickerListenerAttached = true;
    window.addEventListener('message', function(event) {
        console.log('Received message:', event.data);
        if (event.origin !== window.location.origin) {
            console.log('Ignoring message from different origin:', event.origin);
            return;
        }

        if (event.data.type === 'MEDIA_SELECTED') {
            console.log('Processing MEDIA_SELECTED message');
            const fieldId = event.data.fieldId;
            updateMediaSelection(fieldId, event.data.media);
        }
    });
}

function updateMediaSelection(fieldName, media) {
    // Update hidden input
    document.getElementById(fieldName).value = media.id;

    // Update preview with enhanced styling
    const previewDiv = document.getElementById(`${fieldName}-preview`);
    previewDiv.className = 'relative border-2 border-solid border-blue-400 dark:border-blue-700 rounded-xl p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 shadow-sm';

    let mediaIcon = '';
    let fileTypeBadge = '';

    if (media.type === 'image') {
        mediaIcon = `<img src="${media.url}" alt="${media.name}" class="w-full h-full object-cover rounded-lg transition-transform duration-200 group-hover:scale-105">
        <div class="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>`;
        fileTypeBadge = `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
            Image
        </span>`;
    } else if (media.type === 'video') {
        mediaIcon = `<video class="w-full h-full object-cover rounded-lg" muted><source src="${media.url}"></video>
        <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <div class="bg-white/90 rounded-full p-2">
                <svg class="w-4 h-4 text-gray-800 dark:text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                </svg>
            </div>
        </div>`;
        fileTypeBadge = `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/>
            </svg>
            Video
        </span>`;
    } else if (media.type === 'audio') {
        mediaIcon = `<div class="w-full h-full bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center">
            <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
            </svg>
        </div>`;
        fileTypeBadge = `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
            </svg>
            Audio
        </span>`;
    } else {
        mediaIcon = `<div class="w-full h-full bg-gradient-to-br from-gray-100 to-slate-200 flex items-center justify-center">
            <svg class="w-8 h-8 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
        </div>`;
        fileTypeBadge = `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
            </svg>
            Document
        </span>`;
    }

    previewDiv.innerHTML = `
        <div class="flex items-center space-x-4">
            <div class="w-32 h-32 flex-shrink-0 relative group">
                <div class="absolute -inset-1 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-lg blur opacity-25 group-hover:opacity-40 transition duration-200"></div>
                <div class="relative bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                    ${mediaIcon}
                </div>
            </div>
            <div class="flex-1 min-w-0">
                <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-1 truncate">${media.name}</h4>
                <div class="flex items-center space-x-3 text-xs text-gray-500 dark:text-gray-400 mb-1">
                    ${fileTypeBadge}
                    <span>${media.type.charAt(0).toUpperCase() + media.type.slice(1)}</span>
                </div>
            </div>
                <div class="flex flex-col space-y-2">
                <button type="button" onclick="openMediaSelector('${fieldName}')" class="inline-flex items-center px-3 py-2 border border-blue-300 dark:border-blue-600 shadow-sm text-xs font-medium rounded-lg text-blue-700 dark:text-blue-200 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900 hover:border-blue-400 transition-colors duration-200">Change</button>
                <button type="button" onclick="removeMedia('${fieldName}')" class="inline-flex items-center px-3 py-2 border border-red-300 dark:border-red-600 shadow-sm text-xs font-medium rounded-lg text-red-700 dark:text-red-100 bg-white dark:bg-gray-800 hover:bg-red-50 dark:hover:bg-red-700 hover:border-red-400 transition-colors duration-200">Remove</button>
            </div>
        </div>
    `;
}

function removeMedia(fieldName) {
    // Clear hidden input
    document.getElementById(fieldName).value = '';

    // Reset preview
    const previewDiv = document.getElementById(`${fieldName}-preview`);
    previewDiv.className = 'relative border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-6 transition-all duration-200 hover:border-gray-400 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700';
    previewDiv.innerHTML = `
        <div class="text-center">
            <div class="mx-auto w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-full flex items-center justify-center mb-4">
                <svg class="w-8 h-8 text-gray-400 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
            <div class="space-y-3">
                <button type="button" onclick="openMediaSelector('${fieldName}')" class="inline-flex items-center px-6 py-3 border border-transparent text-sm font-semibold rounded-xl text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                    <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                    </svg>
                    Select Media
                </button>
            </div>
        </div>
    `;
}
</script>
