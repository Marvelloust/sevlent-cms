@extends('admin.layouts.app')

@section('title', 'Media Library')
@section('page-title', 'Manage Media')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r  from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-images mr-3"></i>Media Library
                    </h1>
                    <p class="text-white">Manage and organize your media files</p>
                    <div class="flex items-center mt-2 space-x-4">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/20 text-white">
                            <i class="fas fa-file mr-1"></i>
                            {{ $media->total() }} File{{ $media->total() !== 1 ? 's' : '' }}
                        </span>
                        @if($types->count() > 0)
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/20 text-white">
                            <i class="fas fa-tags mr-1"></i>
                            {{ $types->count() }} Type{{ $types->count() !== 1 ? 's' : '' }}
                        </span>
                        @endif
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.media.create') }}"
                       class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-cloud-upload-alt mr-2"></i>Upload Media
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters and Search Section -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900">
                <i class="fas fa-filter mr-2 text-emerald-600"></i>Search & Filter
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Find and organize your media files</p>
        </div>
        <div class="px-6 py-6">
            <form method="GET" action="{{ route('admin.media.index') }}" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <!-- Search -->
                    <div>
                        <label for="search" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-search mr-2 text-gray-500 dark:text-gray-400"></i>Search Files
                        </label>
                        <input type="text" name="search" id="search" value="{{ request('search') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-200"
                               placeholder="Search media files...">
                    </div>

                    <!-- Type Filter -->
                    <div>
                        <label for="type" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-alt mr-2 text-gray-500 dark:text-gray-400"></i>File Type
                        </label>
                        <select name="type" id="type"
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all duration-200">
                            <option value="">All Types</option>
                            @foreach($types as $type)
                                <option value="{{ $type }}" {{ request('type') === $type ? 'selected' : '' }}>
                                    {{ ucfirst($type) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Actions -->
                    <div class="flex items-end space-x-2">
                        <button type="submit"
                                class="inline-flex items-center px-6 py-3 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-filter mr-2"></i>Filter
                        </button>
                        <a href="{{ route('admin.media.index') }}"
                           class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Clear
                        </a>
                    </div>

                    <!-- Bulk Actions -->
                    <div class="flex items-end">
                        <button type="button" id="bulk-delete-btn"
                                class="inline-flex items-center px-6 py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-all duration-200 transform hover:scale-105 shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                                disabled>
                            <i class="fas fa-trash mr-2"></i>Delete Selected
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Media Grid Section -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form id="bulk-delete-form" method="POST" action="{{ route('admin.media.bulk-delete') }}">
            @csrf
            @method('DELETE')

            @if($media->count() > 0)
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-th mr-2 text-emerald-600"></i>Media Files
                    </h3>
                    <span class="text-sm text-gray-600 dark:text-gray-400">
                        Showing {{ $media->firstItem() }}-{{ $media->lastItem() }} of {{ $media->total() }} files
                    </span>
                </div>
            </div>

            <div class="px-6 py-6">
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-6 gap-4">
                    @foreach($media as $item)
                    <div class="group relative bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden hover:shadow-lg hover:border-emerald-300 transition-all duration-300 transform hover:-translate-y-1">
                        <!-- Checkbox for bulk selection -->
                        <div class="absolute top-3 left-3 z-20">
                            <input type="checkbox" name="media_ids[]" value="{{ $item->id }}"
                                   class="media-checkbox h-4 w-4 text-emerald-600 focus:ring-emerald-500 border-gray-300 dark:border-gray-600 rounded">
                        </div>

                        <!-- Media Preview -->
                        <div class="aspect-square bg-gray-100 dark:bg-gray-800 relative overflow-hidden">
                            @if($item->file_type === 'image')
                                <img src="{{ $item->url }}" alt="{{ $item->alt_text }}"
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                                <div class="absolute top-3 right-3 bg-green-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <i class="fas fa-image text-xs"></i>
                                </div>
                            @elseif($item->file_type === 'video')
                                <video class="w-full h-full object-cover" muted>
                                    <source src="{{ $item->url }}" type="{{ $item->mime_type }}">
                                </video>
                                <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div class="bg-blue-500 text-white rounded-full p-3">
                                        <i class="fas fa-play text-lg"></i>
                                    </div>
                                </div>
                                <div class="absolute top-3 right-3 bg-blue-500 text-white rounded-full p-1">
                                    <i class="fas fa-video text-xs"></i>
                                </div>
                            @elseif($item->file_type === 'audio')
                                <div class="w-full h-full bg-gradient-to-br from-purple-100 to-purple-200 flex items-center justify-center">
                                    <div class="text-center">
                                        <i class="fas fa-music text-3xl text-purple-600 mb-2"></i>
                                        <div class="text-xs text-purple-600 font-medium">AUDIO</div>
                                    </div>
                                </div>
                            @elseif($item->file_type === 'document')
                                <div class="w-full h-full bg-gradient-to-br from-red-100 to-red-200 flex items-center justify-center">
                                    <div class="text-center">
                                        <i class="fas fa-file-alt text-3xl text-red-600 mb-2"></i>
                                        <div class="text-xs text-red-600 font-medium">DOC</div>
                                    </div>
                                </div>
                            @else
                                <div class="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                                    <div class="text-center">
                                        <i class="fas fa-file text-3xl text-gray-600 dark:text-gray-400 mb-2"></i>
                                        <div class="text-xs text-gray-600 dark:text-gray-400 font-medium">{{ strtoupper(substr($item->file_type, 0, 3)) }}</div>
                                    </div>
                                </div>
                            @endif
                        </div>

                        <!-- Media Info -->
                        <div class="p-4">
                            <h4 class="text-sm font-semibold text-gray-900 dark:text-white mb-1 truncate" title="{{ $item->file_name }}">
                                {{ Str::limit($item->file_name, 20) }}
                            </h4>
                            <div class="space-y-1">
                                <p class="text-xs text-gray-600 dark:text-gray-400 flex items-center">
                                    <i class="fas fa-tag mr-1 text-blue-500"></i>
                                    {{ ucfirst($item->file_type) }}
                                </p>
                                <p class="text-xs text-gray-600 dark:text-gray-400 flex items-center">
                                    <i class="fas fa-weight mr-1 text-orange-500"></i>
                                    {{ number_format($item->file_size / 1024, 1) }} KB
                                </p>
                                <p class="text-xs text-gray-500 dark:text-gray-400 flex items-center">
                                    <i class="fas fa-calendar mr-1 text-gray-400"></i>
                                    {{ $item->created_at->format('M d, Y') }}
                                </p>
                            </div>
                        </div>

                        <!-- Actions Overlay -->
                        <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div class="flex justify-center space-x-2">
                                <a href="{{ route('admin.media.show', $item) }}"
                                   class="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors"
                                   title="View Details">
                                    <i class="fas fa-eye text-xs"></i>
                                </a>
                                <a href="{{ route('admin.media.edit', $item) }}"
                                   class="bg-green-600 text-white p-2 rounded-full hover:bg-green-700 transition-colors"
                                   title="Edit File">
                                    <i class="fas fa-edit text-xs"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.media.destroy', $item) }}" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="button"
                                            class="bg-red-600 text-white p-2 rounded-full hover:bg-red-700 transition-colors"
                                            title="Delete File"
                                            onclick="showDeleteConfirmation('Are you sure you want to delete this file? This action cannot be undone.', () => { this.closest('form').submit(); })">
                                        <i class="fas fa-trash text-xs"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>

                <!-- Pagination -->
                @if($media->hasPages())
                <div class="mt-8 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 rounded-b-xl">
                    <div class="px-6 py-4">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                            <div class="mb-4 sm:mb-0">
                                <p class="text-sm text-gray-700 dark:text-gray-300">
                                    Showing <span class="font-medium">{{ $media->firstItem() }}</span> to
                                    <span class="font-medium">{{ $media->lastItem() }}</span> of
                                    <span class="font-medium">{{ $media->total() }}</span> media files
                                </p>
                            </div>
                            <div class="flex justify-center">
                                {{ $media->onEachSide(1)->appends(request()->query())->links() }}
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </div>
            @else
            <!-- Empty State -->
            <div class="text-center py-16 px-6">
                <div class="mx-auto w-24 h-24 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-full flex items-center justify-center mb-6">
                    <i class="fas fa-images text-4xl text-emerald-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">No Media Files Yet</h3>
                <p class="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                    Start building your media library by uploading images, videos, documents, and other files.
                </p>
                <a href="{{ route('admin.media.create') }}"
                   class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold rounded-lg hover:from-emerald-700 hover:to-teal-700 transition-all duration-200 transform hover:scale-105 shadow-lg">
                    <i class="fas fa-cloud-upload-alt mr-3"></i>Upload Your First File
                </a>
            </div>

            <!-- Tips Section -->
            <div class="border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 px-6 py-8">
                <div class="max-w-4xl mx-auto">
                    <h4 class="text-lg font-semibold text-gray-900 dark:text-white mb-6 text-center">
                        <i class="fas fa-lightbulb mr-2 text-yellow-500"></i>Media Management Tips
                    </h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="text-center">
                            <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900 rounded-lg flex items-center justify-center mx-auto mb-3">
                                <i class="fas fa-search text-emerald-600 dark:text-emerald-400"></i>
                            </div>
                            <h5 class="font-medium text-gray-900 dark:text-white mb-2">Organize with Alt Text</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Add descriptive alt text to images for better accessibility and SEO.</p>
                        </div>
                        <div class="text-center">
                            <div class="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-3">
                                <i class="fas fa-tags text-blue-600 dark:text-blue-400"></i>
                            </div>
                            <h5 class="font-medium text-gray-900 dark:text-white mb-2">Use Filters</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Filter by file type and search by name to quickly find specific files.</p>
                        </div>
                        <div class="text-center">
                            <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-3">
                                <i class="fas fa-check-square text-purple-600 dark:text-purple-400"></i>
                            </div>
                            <h5 class="font-medium text-gray-900 dark:text-white mb-2">Bulk Operations</h5>
                            <p class="text-sm text-gray-600 dark:text-gray-400">Select multiple files for bulk deletion to manage your library efficiently.</p>
                        </div>
                    </div>
                </div>
            </div>
            @endif
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.media-checkbox');
    const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
    const bulkDeleteForm = document.getElementById('bulk-delete-form');

    function updateBulkDeleteButton() {
        const checkedBoxes = document.querySelectorAll('.media-checkbox:checked');
        bulkDeleteBtn.disabled = checkedBoxes.length === 0;
        bulkDeleteBtn.innerHTML = checkedBoxes.length === 0
            ? '<i class="fas fa-trash mr-2"></i>Delete Selected'
            : `<i class="fas fa-trash mr-2"></i>Delete ${checkedBoxes.length} Selected`;
    }

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateBulkDeleteButton);
    });

    bulkDeleteBtn.addEventListener('click', function() {
        const checkedBoxes = document.querySelectorAll('.media-checkbox:checked');
        if (checkedBoxes.length === 0) return;

        showDeleteConfirmation(
            `Are you sure you want to delete ${checkedBoxes.length} selected file(s)? This action cannot be undone.`,
            () => { bulkDeleteForm.submit(); }
        );
    });

    // Initialize button state
    updateBulkDeleteButton();
});
</script>
@endsection
