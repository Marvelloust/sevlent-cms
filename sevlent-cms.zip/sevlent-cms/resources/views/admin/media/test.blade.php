{{--
    Test Media Picker Component

    This is a simple test page to verify the media picker component works correctly.
--}}

@extends('admin.layouts.app')

@section('title', 'Test Media Picker')
@section('page-title', 'Test Media Picker Component')

@section('content')
<div class="space-y-6">
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-md">
        <div class="px-4 py-5 sm:p-6">
            <h2 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Media Picker Component Test</h2>

            <form method="POST" action="#" class="space-y-6">
                @csrf

                <!-- Image Picker -->
                @include('admin.media.picker', [
                    'fieldName' => 'test_image',
                    'selectedMedia' => null,
                    'label' => 'Test Image',
                    'help' => 'Select an image to test the picker',
                    'required' => false,
                    'allowedTypes' => ['image'],
                    'previewSize' => 'w-32 h-32'
                ])

                <!-- Video Picker -->
                @include('admin.media.picker', [
                    'fieldName' => 'test_video',
                    'selectedMedia' => null,
                    'label' => 'Test Video',
                    'help' => 'Select a video to test the picker',
                    'required' => false,
                    'allowedTypes' => ['video'],
                    'previewSize' => 'w-32 h-20'
                ])

                <!-- Document Picker -->
                @include('admin.media.picker', [
                    'fieldName' => 'test_document',
                    'selectedMedia' => null,
                    'label' => 'Test Document',
                    'help' => 'Select a document to test the picker',
                    'required' => false,
                    'allowedTypes' => ['document'],
                    'previewSize' => 'w-24 h-24'
                ])

                <!-- Submit Button -->
                <div class="flex justify-end">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md">
                        Test Submit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection