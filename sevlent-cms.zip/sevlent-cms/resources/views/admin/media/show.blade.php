@extends('admin.layouts.app')

@section('title', 'View Media')
@section('page-title', 'View Media File')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                            <i class="fas fa-file mr-1"></i>
                            {{ ucfirst($medium->file_type) }}
                        </span>
                        <span class="ml-3 text-sm font-medium text-gray-200">
                            <i class="fas fa-external-link-alt mr-1"></i>
                            <a href="{{ $medium->url }}" target="_blank" class="hover:text-white underline">
                                Open File
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $medium->file_name }}</h1>
                    <div class="flex flex-wrap gap-6 text-gray-300 text-sm">
                        <span>
                            <i class="fas fa-user mr-2"></i>Uploaded by {{ $medium->uploader->name ?? 'Unknown' }}
                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Uploaded {{ $medium->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-weight mr-2"></i>{{ number_format($medium->file_size / 1024, 1) }} KB
                        </span>
                        <span>
                            <i class="fas fa-code mr-2"></i><code class="bg-blue-500 bg-opacity-30 px-2 py-1 rounded">{{ $medium->mime_type }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.media.edit', $medium) }}" class="inline-flex items-center px-6 py-3 bg-white dark:bg-gray-300 text-blue-600 font-semibold rounded-lg hover:bg-yellow-100 transition-all duration-200">
                        <i class="fas fa-edit mr-2"></i>Edit File
                    </a>
                    <a href="{{ route('admin.media.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Media Preview -->
    <div class="rounded-xl overflow-hidden shadow-lg bg-white dark:bg-gray-800">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-eye mr-2 text-blue-600"></i>File Preview
            </h3>
        </div>
        <div class="p-8">
            <div class="bg-gray-50 dark:bg-gray-900 rounded-lg p-6 flex items-center justify-center">
                @if($medium->file_type === 'image')
                    <img src="{{ $medium->url }}" alt="{{ $medium->alt_text }}" class="max-w-full max-h-96 object-contain rounded-lg shadow-md">
                @elseif($medium->file_type === 'video')
                    <video controls class="max-w-full max-h-96 rounded-lg shadow-md">
                        <source src="{{ $medium->url }}" type="{{ $medium->mime_type }}">
                        Your browser does not support the video tag.
                    </video>
                @elseif($medium->file_type === 'audio')
                    <div class="w-full max-w-md">
                        <audio controls class="w-full">
                            <source src="{{ $medium->url }}" type="{{ $medium->mime_type }}">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                @else
                    <div class="flex flex-col items-center justify-center h-48 text-gray-500 dark:text-gray-400">
                        <svg class="w-20 h-20 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                        <p class="text-lg font-medium text-gray-600 dark:text-gray-400">{{ strtoupper(pathinfo($medium->file_name, PATHINFO_EXTENSION)) }} File</p>
                        <p class="text-sm text-gray-400 dark:text-gray-500 mt-1">{{ $medium->mime_type }}</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Quick Actions -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-bolt mr-2 text-yellow-600"></i>Quick Actions
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <button onclick="copyToClipboard('{{ $medium->url }}')" class="inline-flex items-center justify-center px-4 py-3 border border-gray-300 dark:border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200">
                            <i class="fas fa-copy mr-2"></i>
                            Copy URL
                        </button>
                        <a href="{{ $medium->url }}" target="_blank" class="inline-flex items-center justify-center px-4 py-3 border border-gray-300 dark:border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200">
                            <i class="fas fa-external-link-alt mr-2"></i>
                            Open in New Tab
                        </a>
                        @if($medium->file_type === 'image')
                        <button onclick="showEmbedCode()" class="inline-flex items-center justify-center px-4 py-3 border border-gray-300 dark:border-gray-600 shadow-sm text-sm leading-4 font-medium rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors duration-200">
                            <i class="fas fa-code mr-2"></i>
                            Get Embed Code
                        </button>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Usage Statistics -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-chart-bar mr-2 text-green-600"></i>Usage Statistics
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="bg-blue-50 dark:bg-blue-950 rounded-xl border-2 border-blue-200 dark:border-blue-800 p-6">
                        <div class="flex">
                            <i class="fas fa-info-circle text-blue-600 dark:text-blue-400 text-xl mr-4 mt-1"></i>
                            <div>
                                <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-1">Usage Tracking</h4>
                                <p class="text-sm text-blue-800 dark:text-blue-400">This file is used in 0 pages, 0 blog posts, and 0 other locations.</p>
                                <p class="text-xs text-blue-600 dark:text-blue-500 mt-2">Usage tracking will be available in a future update.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- File URL Card -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-link mr-2 text-purple-600"></i>File URL
                    </h3>
                </div>
                <div class="px-6 py-4">
                    <div class="flex">
                        <input type="text" readonly value="{{ $medium->url }}" id="file-url"
                               class="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-l-md bg-gray-50 dark:bg-gray-900 text-sm font-mono text-gray-800 dark:text-white">
                        <button onclick="copyToClipboard('{{ $medium->url }}')"
                                class="px-3 py-2 border border-l-0 border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-900 rounded-r-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar: File Information -->
        <div class="lg:col-span-1 space-y-6">
            <!-- File Details Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>File Information
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">File Name</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300 break-all">{{ $medium->file_name }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">File Type</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-200 text-blue-800 dark:text-blue-200">
                            {{ ucfirst($medium->file_type) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">MIME Type</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-900 px-2 py-1 rounded text-gray-800 dark:text-white">{{ $medium->mime_type }}</code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">File Size</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ number_format($medium->file_size / 1024, 1) }} KB</p>
                    </div>
                    @if($medium->alt_text)
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Alt Text</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $medium->alt_text }}</p>
                    </div>
                    @endif
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Uploaded By</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $medium->uploader->name ?? 'Unknown' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Upload Date</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $medium->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $medium->updated_at->format('M d, Y H:i') }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Embed Code Modal (for images) -->
    @if($medium->file_type === 'image')
    <div id="embed-modal" class="fixed inset-0 bg-gray-600 dark:bg-gray-900 bg-opacity-50 dark:bg-opacity-75 overflow-y-auto h-full w-full hidden z-50">
        <div class="relative top-20 mx-auto p-5 border dark:border-gray-700 w-96 shadow-lg rounded-md bg-white dark:bg-gray-800">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Embed Code</h3>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">HTML Image Tag</label>
                        <textarea readonly rows="3" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-900 text-sm font-mono text-gray-900 dark:text-white" onclick="this.select()">&lt;img src="{{ $medium->url }}" alt="{{ $medium->alt_text }}" /&gt;</textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Markdown</label>
                        <textarea readonly rows="2" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-900 text-sm font-mono text-gray-900 dark:text-white" onclick="this.select()">![{{ $medium->alt_text }}]({{ $medium->url }})</textarea>
                    </div>
                </div>
                <div class="flex justify-end mt-4">
                    <button onclick="hideEmbedCode()" class="px-4 py-2 bg-gray-500 dark:bg-gray-600 text-white rounded-md hover:bg-gray-600 dark:hover:bg-gray-700">Close</button>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Show success message
        showNotification('URL copied to clipboard!', 'success');
    }, function(err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showNotification('URL copied to clipboard!', 'success');
    });
}

function showEmbedCode() {
    document.getElementById('embed-modal').classList.remove('hidden');
}

function hideEmbedCode() {
    document.getElementById('embed-modal').classList.add('hidden');
}

function showNotification(message, type) {
    // Simple notification - you could enhance this with a proper notification system
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-4 py-2 rounded-md text-white z-50 ${type === 'success' ? 'bg-green-500' : 'bg-red-500'}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        document.body.removeChild(notification);
    }, 3000);
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('embed-modal');
    if (modal && event.target === modal) {
        hideEmbedCode();
    }
});
</script>
@endsection
