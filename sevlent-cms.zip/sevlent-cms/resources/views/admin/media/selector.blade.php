<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Select Media - {{ config('app.name', 'SEVLENT CMS') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <!-- Custom Styles -->
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="font-sans antialiased bg-gray-100">
    <div class="min-h-screen bg-gray-100 dark:bg-gray-800 py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
<div class="space-y-6">
    <!-- Header with enhanced styling -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-700 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div>
                    <h1 class="text-3xl font-bold text-white" id="selector-title">Select Media File</h1>
                    <p class="text-blue-100 mt-1">Choose from your media library</p>
                </div>
                <div class="flex space-x-3">
                    <button onclick="window.close()" class="inline-flex items-center px-4 py-2 border border-blue-300 shadow-sm text-sm font-medium rounded-lg text-blue-100 bg-blue-700/50 hover:bg-blue-600/50 backdrop-blur-sm transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                        Cancel
                    </button>
                    <button onclick="confirmSelection()" class="inline-flex items-center px-6 py-2 border border-transparent text-sm font-semibold rounded-lg text-white bg-green-500 hover:bg-green-600 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200" id="confirm-btn" style="display: none;">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        Confirm Selection
                    </button>
                    <a href="{{ route('admin.media.create') }}" target="_blank" class="inline-flex items-center px-6 py-2 border border-transparent text-sm font-semibold rounded-lg text-blue-700 bg-white dark:bg-gray-800 hover:bg-blue-50 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                        </svg>
                        Upload New
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters with enhanced styling -->
    <div class="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700">
        <div class="px-6 py-6">
            <form method="GET" action="{{ route('admin.media.selector') }}" class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <!-- Hidden types field -->
                @if(request('types'))
                    <input type="hidden" name="types" value="{{ request('types') }}">
                @endif
                @if(request('fieldId'))
                    <input type="hidden" name="fieldId" value="{{ request('fieldId') }}">
                @endif

                <!-- Search with enhanced styling -->
                <div class="relative">
                    <label for="search" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Search Files</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                            </svg>
                        </div>
                        <input type="text" name="search" id="search" value="{{ request('search') }}"
                               placeholder="File name or alt text..."
                               class="block w-full pl-10 pr-3 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:bg-white dark:focus:bg-gray-800">
                    </div>
                </div>

                <!-- Type Filter with enhanced styling -->
                <div>
                    <label for="type" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">File Type</label>
                    <select name="type" id="type" class="block w-full py-3 px-4 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors duration-200 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-white focus:bg-white dark:focus:bg-gray-800">
                        <option value="">All Types</option>
                        @php
                            $allowedTypes = request('types') ? json_decode(request('types'), true) : ['image', 'video', 'audio', 'document'];
                        @endphp
                        @if(in_array('image', $allowedTypes))
                            <option value="image" {{ request('type') === 'image' ? 'selected' : '' }}>📷 Images</option>
                        @endif
                        @if(in_array('video', $allowedTypes))
                            <option value="video" {{ request('type') === 'video' ? 'selected' : '' }}>🎥 Videos</option>
                        @endif
                        @if(in_array('audio', $allowedTypes))
                            <option value="audio" {{ request('type') === 'audio' ? 'selected' : '' }}>🎵 Audio</option>
                        @endif
                        @if(in_array('document', $allowedTypes))
                            <option value="document" {{ request('type') === 'document' ? 'selected' : '' }}>📄 Documents</option>
                        @endif
                    </select>
                </div>

                <!-- Actions with enhanced styling -->
                <div class="flex items-end space-x-3">
                    <button type="submit" class="inline-flex items-center px-6 py-3 border border-transparent text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/>
                        </svg>
                        Filter
                    </button>
                    @php
                        $clearParams = [];
                        if (request('types')) {
                            $clearParams['types'] = request('types');
                        }
                        if (request('fieldId')) {
                            $clearParams['fieldId'] = request('fieldId');
                        }
                        $clearUrl = route('admin.media.selector') . (!empty($clearParams) ? '?' . http_build_query($clearParams) : '');
                    @endphp
                    <a href="{{ $clearUrl }}" class="inline-flex items-center px-6 py-3 border border-gray-300 dark:border-gray-600 text-sm font-semibold rounded-lg text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                        </svg>
                        Clear
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Media Grid with enhanced styling -->
    <div class="bg-gray-50 dark:bg-gray-900 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            @if($media->count() > 0)
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-6">
                    @foreach($media as $item)
                        <div class="relative group bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-xl transform hover:-translate-y-2 transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-blue-400"
                             onclick="selectMedia({{ $item->id }}, '{{ $item->url }}', '{{ addslashes($item->file_name) }}', '{{ $item->file_type }}', '{{ $item->file_path }}')">

                            <!-- Enhanced selection indicator -->
                            <div class="absolute top-3 left-3 z-20">
                                <div id="selected-{{ $item->id }}" class="hidden w-6 h-6 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                                    <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                                    </svg>
                                </div>
                            </div>

                            <!-- Media Preview with enhanced styling -->
                            <div class="aspect-square bg-gray-100 dark:bg-gray-800 relative overflow-hidden">
                                @if($item->file_type === 'image')
                                    <img src="{{ $item->url }}" alt="{{ $item->alt_text }}" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                                    <!-- Subtle overlay on hover -->
                                    <div class="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                                @elseif($item->file_type === 'video')
                                    <video class="w-full h-full object-cover" muted>
                                        <source src="{{ $item->url }}" type="{{ $item->mime_type }}">
                                    </video>
                                    <div class="absolute inset-0 bg-black/50 flex items-center justify-center opacity-100 group-hover:opacity-80 transition-opacity duration-300">
                                        <div class="bg-white/90 rounded-full p-3 shadow-lg">
                                            <svg class="w-6 h-6 text-gray-800" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M8 5v14l11-7z"/>
                                            </svg>
                                        </div>
                                    </div>
                                @elseif($item->file_type === 'audio')
                                    <div class="flex items-center justify-center h-full bg-gradient-to-br from-purple-100 to-pink-100">
                                        <svg class="w-10 h-10 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
                                        </svg>
                                    </div>
                                @else
                                    <div class="flex items-center justify-center h-full bg-gradient-to-br from-gray-100 to-slate-200">
                                        <svg class="w-10 h-10 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                        </svg>
                                    </div>
                                @endif
                            </div>

                            <!-- Enhanced Media Info -->
                            <div class="p-4 bg-white dark:bg-gray-800">
                                <p class="text-sm font-semibold text-gray-900 dark:text-white truncate mb-2" title="{{ $item->file_name }}">
                                    {{ $item->file_name }}
                                </p>
                                <div class="flex items-center justify-between text-xs text-gray-500">
                                    <span class="inline-flex items-center px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white font-medium">
                                        @if($item->file_type === 'image')
                                            📷
                                        @elseif($item->file_type === 'video')
                                            🎥
                                        @elseif($item->file_type === 'audio')
                                            🎵
                                        @else
                                            📄
                                        @endif
                                        {{ ucfirst($item->file_type) }}
                                    </span>
                                    <span>{{ number_format($item->file_size / 1024, 1) }} KB</span>
                                </div>
                                <p class="text-xs text-gray-400 mt-1">{{ $item->created_at->format('M d, Y') }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Enhanced Pagination -->
                @if($media->hasPages())
                    <div class="mt-12 flex justify-center">
                        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4">
                            {{ $media->appends(request()->query())->links() }}
                        </div>
                    </div>
                @endif
            @else
                <!-- Enhanced empty state -->
                <div class="text-center py-16">
                    <div class="mx-auto w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-full flex items-center justify-center mb-6">
                        <svg class="w-12 h-12 text-gray-400 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">No media files found</h3>
                    <p class="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">Try adjusting your search criteria or upload some new files to get started.</p>
                    <a href="{{ route('admin.media.create') }}" target="_blank" class="inline-flex items-center px-6 py-3 border border-transparent text-sm font-semibold rounded-lg text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                        </svg>
                        Upload New Media
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>

<script>
let selectedMedia = null;
let selectedMediaMultiple = [];
let isMultiple = {{ request('multiple') ? 'true' : 'false' }};
let fieldId = {!! json_encode(request('fieldId', '')) !!};

console.log('Media Selector initialized with fieldId:', fieldId);
console.log('URL parameters:', window.location.search);

// Update UI based on selection mode
if (isMultiple) {
    document.getElementById('selector-title').textContent = 'Select Media Files';
    document.getElementById('confirm-btn').style.display = 'inline-block';
}

function selectMedia(id, url, name, type, filePath) {
    console.log('selectMedia called with:', { id, url, name, type, filePath });

    if (isMultiple) {
        toggleMediaSelection(id, url, name, type, filePath);
    } else {
        // Single selection mode
        // Remove previous selection
        if (selectedMedia) {
            document.getElementById(`selected-${selectedMedia}`).classList.add('hidden');
        }

        // Show new selection
        selectedMedia = id;
        document.getElementById(`selected-${id}`).classList.remove('hidden');

        // Send selection to parent window
        if (window.opener) {
            const message = {
                type: 'MEDIA_SELECTED',
                media: {
                    id: id,
                    url: url,
                    name: name,
                    type: type,
                    file_path: filePath
                },
                fieldId: fieldId
            };
            console.log('Sending message to opener:', message);
            window.opener.postMessage(message, '*');
            
            // Close window after a short delay to ensure message is processed
            setTimeout(() => {
                window.close();
            }, 100);
        }
    }
}

function toggleMediaSelection(id, url, name, type, filePath) {
    const index = selectedMediaMultiple.findIndex(media => media.id === id);

    if (index > -1) {
        // Remove from selection
        selectedMediaMultiple.splice(index, 1);
        document.getElementById(`selected-${id}`).classList.add('hidden');
    } else {
        // Add to selection
        selectedMediaMultiple.push({
            id: id,
            url: url,
            name: name,
            type: type,
            file_path: filePath
        });
        document.getElementById(`selected-${id}`).classList.remove('hidden');
    }

    // Update confirm button
    document.getElementById('confirm-btn').textContent = `Confirm Selection (${selectedMediaMultiple.length})`;
}

function confirmSelection() {
    if (selectedMediaMultiple.length === 0) {
        alert('Please select at least one media file.');
        return;
    }

    if (window.opener) {
        const message = {
            type: 'MEDIA_SELECTED_MULTIPLE',
            media: selectedMediaMultiple,
            fieldId: fieldId
        };
        console.log('Sending multiple selection message to opener:', message);
        window.opener.postMessage(message, '*');
        
        // Close window after a short delay to ensure message is processed
        setTimeout(() => {
            window.close();
        }, 100);
    }
}

// Handle messages from parent window (for pre-selecting media)
window.addEventListener('message', function(event) {
    if (event.data.type === 'SELECT_MEDIA') {
        selectMedia(event.data.media.id, event.data.media.url, event.data.media.name, event.data.media.type, event.data.media.file_path);
    }
});
</script>
</body>
</html>
