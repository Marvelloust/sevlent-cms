@extends('admin.layouts.app')

@section('title', 'Upload Media')
@section('page-title', 'Upload New Media')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-violet-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-cloud-upload-alt mr-3"></i>Upload Media Files
                    </h1>
                    <p class="text-white">Add images, videos, and documents to your media library</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.media.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Media Library
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Upload Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.media.store') }}" enctype="multipart/form-data" id="upload-form">
            @csrf

            <!-- Upload Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-upload mr-2 text-blue-600"></i>File Upload
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Select and upload your media files</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <!-- Drag & Drop Zone -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-file-upload mr-2 text-gray-500 dark:text-gray-400"></i>Select Files
                    </label>
                    <div id="drop-zone" class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center hover:border-violet-400 dark:hover:border-violet-500 transition-all duration-200 cursor-pointer bg-gray-50 dark:bg-gray-900 hover:bg-violet-50 dark:hover:bg-violet-950">
                        <div class="space-y-4">
                            <div class="mx-auto w-16 h-16 text-gray-400 dark:text-gray-500">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                                </svg>
                            </div>
                            <div>
                                <p class="text-xl font-medium text-gray-900 dark:text-white">Drop files here or click to browse</p>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">
                                    Supports: Images (JPEG, PNG, GIF, SVG, WebP), Videos (MP4, AVI, MOV, WebM), Audio (MP3, WAV, OGG), Documents (PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX), Archives (ZIP, RAR)
                                </p>
                                <p class="text-xs text-gray-400 dark:text-gray-500 mt-2">Maximum file size: 50MB per file • Maximum 10 files at once</p>
                            </div>
                        </div>
                        <input type="file" name="files[]" id="files" multiple
                               class="hidden"
                               accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar">
                    </div>
                    @error('files')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>

                <!-- File List -->
                <div id="file-list" class="hidden">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-list mr-2 text-gray-500 dark:text-gray-400"></i>Selected Files
                    </label>
                    <div id="file-items" class="space-y-2 bg-gray-50 dark:bg-gray-900 rounded-lg p-4"></div>
                </div>

                <!-- Progress Bar -->
                <div id="upload-progress" class="hidden">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-spinner mr-2 text-gray-500 dark:text-gray-400"></i>Upload Progress
                    </label>
                    <div class="mb-2 flex justify-between text-sm text-gray-600 dark:text-gray-400">
                        <span>Uploading files...</span>
                        <span id="progress-text">0%</span>
                    </div>
                    <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                        <div id="progress-bar" class="bg-violet-600 h-3 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Files will be processed and added to your media library.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.media.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" id="upload-btn"
                                class="inline-flex items-center px-6 py-3 bg-violet-600 text-white font-semibold rounded-lg hover:bg-violet-700 transition-all duration-200 transform hover:scale-105 shadow-md disabled:opacity-50 disabled:cursor-not-allowed">
                            <svg id="upload-icon" class="-ml-1 mr-2 h-5 w-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                            </svg>
                            <span id="upload-text">Upload Files</span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Upload Guidelines -->
    <div class="bg-violet-50 dark:bg-violet-950 border border-violet-200 dark:border-violet-800 rounded-xl p-6">
        <div class="flex">
            <div class="flex-shrink-0">
                <i class="fas fa-lightbulb text-violet-400 dark:text-violet-500 text-2xl"></i>
            </div>
            <div class="ml-4">
                <h3 class="text-lg font-semibold text-violet-800 dark:text-violet-300 mb-2">
                    <i class="fas fa-info-circle mr-2"></i>Upload Guidelines
                </h3>
                <div class="text-sm text-violet-700 dark:text-violet-400">
                    <ul class="list-disc list-inside space-y-2">
                        <li>Images are automatically optimized for web use with multiple sizes generated</li>
                        <li>Files are stored securely with unique filenames to prevent conflicts</li>
                        <li>You can edit alt text, captions, and replace files after upload</li>
                        <li>Use the media library to easily insert files into pages, blogs, and other content</li>
                        <li>Supported formats include images, videos, audio files, documents, and archives</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('files');
    const fileList = document.getElementById('file-list');
    const fileItems = document.getElementById('file-items');
    const uploadBtn = document.getElementById('upload-btn');
    const uploadForm = document.getElementById('upload-form');

    let selectedFiles = [];

    // Drag and drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        dropZone.classList.add('border-violet-400', 'bg-violet-50');
    }

    function unhighlight(e) {
        dropZone.classList.remove('border-violet-400', 'bg-violet-50');
    }

    dropZone.addEventListener('drop', handleDrop, false);
    dropZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }

    function handleFileSelect(e) {
        const files = e.target.files;
        handleFiles(files);
    }

    function handleFiles(files) {
        // Append new files to existing selection instead of replacing
        const newFiles = Array.from(files);
        newFiles.forEach(file => {
            // Check if file is not already in the list to avoid duplicates
            const isDuplicate = selectedFiles.some(existingFile => 
                existingFile.name === file.name && 
                existingFile.size === file.size && 
                existingFile.lastModified === file.lastModified
            );
            if (!isDuplicate) {
                selectedFiles.push(file);
            }
        });
        
        // Update the file input with all selected files
        updateFileInput();
        updateFileList();
        validateFiles();
    }

    function updateFileInput() {
        // Create a new DataTransfer object to update the file input
        const dataTransfer = new DataTransfer();
        selectedFiles.forEach(file => {
            dataTransfer.items.add(file);
        });
        fileInput.files = dataTransfer.files;
    }

    function updateFileList() {
        fileItems.innerHTML = '';

        if (selectedFiles.length > 0) {
            fileList.classList.remove('hidden');

            selectedFiles.forEach((file, index) => {
                const fileItem = document.createElement('div');
                fileItem.className = 'flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700';
                fileItem.innerHTML = `
                    <div class="flex items-center space-x-3">
                        <div class="flex-shrink-0">
                            ${getFileIcon(file.type)}
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">${file.name}</p>
                            <p class="text-xs text-gray-500 dark:text-gray-400">${formatFileSize(file.size)}</p>
                        </div>
                    </div>
                    <button type="button" onclick="removeFile(${index})" class="text-red-600 hover:text-red-800 dark:hover:text-red-400">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                `;
                fileItems.appendChild(fileItem);
            });
        } else {
            fileList.classList.add('hidden');
        }
    }

    function getFileIcon(mimeType) {
        if (mimeType.startsWith('image/')) {
            return '<svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>';
        } else if (mimeType.startsWith('video/')) {
            return '<svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>';
        } else if (mimeType.startsWith('audio/')) {
            return '<svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/></svg>';
        } else {
            return '<svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>';
        }
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function validateFiles() {
        const maxSize = 50 * 1024 * 1024; // 50MB
        const allowedTypes = [
            'image/jpeg', 'image/png', 'image/gif', 'image/svg+xml', 'image/webp',
            'video/mp4', 'video/avi', 'video/quicktime', 'video/webm',
            'audio/mpeg', 'audio/wav', 'audio/ogg',
            'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'text/plain', 'application/zip', 'application/x-rar-compressed'
        ];

        let isValid = true;
        let errorMessage = '';

        if (selectedFiles.length > 10) {
            isValid = false;
            errorMessage = 'Maximum 10 files allowed at once.';
        } else {
            selectedFiles.forEach(file => {
                if (file.size > maxSize) {
                    isValid = false;
                    errorMessage = `File "${file.name}" exceeds the maximum size of 50MB.`;
                } else if (!allowedTypes.includes(file.type) && file.type !== '') {
                    // Allow files with empty type (some systems don't set MIME type properly)
                    const extension = file.name.split('.').pop().toLowerCase();
                    const allowedExtensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'zip', 'rar'];
                    if (!allowedExtensions.includes(extension)) {
                        isValid = false;
                        errorMessage = `File type of "${file.name}" is not supported.`;
                    }
                }
            });
        }

        uploadBtn.disabled = !isValid || selectedFiles.length === 0;

        if (!isValid && errorMessage) {
            alert(errorMessage);
        }

        return isValid;
    }

    window.removeFile = function(index) {
        selectedFiles.splice(index, 1);
        updateFileInput();
        updateFileList();
        validateFiles();
    };

    // Form submission handling
    uploadForm.addEventListener('submit', function(e) {
        if (selectedFiles.length === 0) {
            e.preventDefault();
            alert('Please select at least one file to upload.');
            return;
        }

        if (!validateFiles()) {
            e.preventDefault();
            return;
        }

        // Update UI for upload in progress
        uploadBtn.disabled = true;
        uploadBtn.innerHTML = `
            <svg class="animate-spin -ml-1 mr-2 h-5 w-5 inline" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Uploading...
        `;
    });
});
</script>
@endsection