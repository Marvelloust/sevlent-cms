@extends('admin.layouts.app')

@section('title', 'Analytics')

@section('content')
<div class="p-6">
    <!-- Header with gradient -->
    <div class="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700  rounded-xl shadow-lg p-8 mb-6 text-white">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold mb-2">Analytics Dashboard</h1>
                <p class="text-white">Comprehensive insights into your CMS performance</p>
            </div>
            <div class="text-right">
                <button onclick="exportAnalytics()" class="inline-flex items-center px-4 py-2 bg-white dark:bg-gray-800 bg-opacity-20 hover:bg-opacity-30 text-white text-sm font-medium rounded-lg transition duration-150 backdrop-blur-sm">
                    <i class="fas fa-download mr-2"></i>
                    Export Data
                </button>
            </div>
        </div>
    </div>

    <!-- Filters Card -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6 p-6">
        <form method="GET" action="{{ route('admin.analytics.index') }}" id="analytics-filter-form">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label for="date_from" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        <i class="fas fa-calendar-alt mr-1"></i> From Date
                    </label>
                    <input type="date" name="date_from" id="date_from" value="{{ $dateFrom->format('Y-m-d') }}" class="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>

                <div>
                    <label for="date_to" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        <i class="fas fa-calendar-alt mr-1"></i> To Date
                    </label>
                    <input type="date" name="date_to" id="date_to" value="{{ $dateTo->format('Y-m-d') }}" class="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                </div>

                <div class="flex items-end">
                    <button type="submit" class="w-full inline-flex items-center justify-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition duration-150">
                        <i class="fas fa-filter mr-2"></i>
                        Apply Filters
                    </button>
                </div>
            </div>

            <!-- Quick Date Ranges -->
            <div class="mt-4 flex flex-wrap gap-2">
                <button type="button" onclick="setDateRange(7)" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Last 7 Days
                </button>
                <button type="button" onclick="setDateRange(30)" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Last 30 Days
                </button>
                <button type="button" onclick="setDateRange(90)" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Last 90 Days
                </button>
                <button type="button" onclick="setDateRange(365)" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Last Year
                </button>
                <button type="button" onclick="setDateRange('mtd')" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Month to Date
                </button>
                <button type="button" onclick="setDateRange('ytd')" class="px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 border border-transparent dark:border-gray-600 rounded-md transition shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-indigo-400 dark:focus:ring-offset-gray-900">
                    Year to Date
                </button>
            </div>
        </form>
    </div>

    <!-- Statistics Cards Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        @foreach($stats as $key => $stat)
        @php
            // Map colors to explicit Tailwind classes
            $colorClasses = [
                'blue' => ['border' => 'border-blue-500', 'bg' => 'bg-blue-100 dark:bg-blue-900', 'text' => 'text-blue-600 dark:text-blue-400'],
                'green' => ['border' => 'border-green-500', 'bg' => 'bg-green-100 dark:bg-green-900', 'text' => 'text-green-600 dark:text-green-400'],
                'purple' => ['border' => 'border-purple-500', 'bg' => 'bg-purple-100 dark:bg-purple-900', 'text' => 'text-purple-600 dark:text-purple-400'],
                'indigo' => ['border' => 'border-indigo-500', 'bg' => 'bg-indigo-100 dark:bg-indigo-900', 'text' => 'text-indigo-600 dark:text-indigo-400'],
                'yellow' => ['border' => 'border-yellow-500', 'bg' => 'bg-yellow-100 dark:bg-yellow-900', 'text' => 'text-yellow-600 dark:text-yellow-400'],
                'pink' => ['border' => 'border-pink-500', 'bg' => 'bg-pink-100 dark:bg-pink-900', 'text' => 'text-pink-600 dark:text-pink-400'],
                'red' => ['border' => 'border-red-500', 'bg' => 'bg-red-100 dark:bg-red-900', 'text' => 'text-red-600 dark:text-red-400'],
                'teal' => ['border' => 'border-teal-500', 'bg' => 'bg-teal-100 dark:bg-teal-900', 'text' => 'text-teal-600 dark:text-teal-400'],
            ];
            $classes = $colorClasses[$stat['color']] ?? $colorClasses['blue'];
        @endphp
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border-l-4 {{ $classes['border'] }}">
            <div class="flex items-center justify-between mb-3">
                <div class="flex items-center">
                    <div class="{{ $classes['bg'] }} rounded-full p-3 mr-3">
                        <i class="{{ $stat['icon'] }} {{ $classes['text'] }}"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500 dark:text-gray-400">{{ $stat['label'] }}</p>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ number_format($stat['current']) }}</p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between text-sm">
                <span class="text-gray-500 dark:text-gray-400">vs. previous period</span>
                @if($stat['change'] > 0)
                <span class="flex items-center text-green-600 dark:text-green-400 font-medium">
                    <i class="fas fa-arrow-up mr-1"></i>
                    {{ $stat['change'] }}%
                </span>
                @elseif($stat['change'] < 0)
                <span class="flex items-center text-red-600 dark:text-red-400 font-medium">
                    <i class="fas fa-arrow-down mr-1"></i>
                    {{ abs($stat['change']) }}%
                </span>
                @else
                <span class="flex items-center text-gray-500 dark:text-gray-400 font-medium">
                    <i class="fas fa-minus mr-1"></i>
                    0%
                </span>
                @endif
            </div>
        </div>
        @endforeach
    </div>

    <!-- Charts Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <!-- Content Trends Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-chart-line mr-2 text-blue-500"></i>
                    Content Trends
                </h3>
                <div class="text-xs text-gray-500 dark:text-gray-400">
                    <i class="fas fa-info-circle"></i> Over time
                </div>
            </div>
            <div class="h-80">
                <canvas id="contentTrendsChart"></canvas>
            </div>
        </div>

        <!-- Contacts Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-envelope mr-2 text-green-500"></i>
                    Contact Submissions
                </h3>
                <div class="text-xs text-gray-500 dark:text-gray-400">
                    <i class="fas fa-info-circle"></i> Daily submissions
                </div>
            </div>
            <div class="h-80">
                <canvas id="contactsChart"></canvas>
            </div>
        </div>

        <!-- Job Applications Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-user-tie mr-2 text-purple-500"></i>
                    Job Applications
                </h3>
                <div class="text-xs text-gray-500 dark:text-gray-400">
                    <i class="fas fa-info-circle"></i> Application trends
                </div>
            </div>
            <div class="h-80">
                <canvas id="jobApplicationsChart"></canvas>
            </div>
        </div>

        <!-- User Activity Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-chart-bar mr-2 text-indigo-500"></i>
                    System Activities
                </h3>
                <div class="text-xs text-gray-500 dark:text-gray-400">
                    <i class="fas fa-info-circle"></i> All user actions
                </div>
            </div>
            <div class="h-80">
                <canvas id="activitiesChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Distribution Charts Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <!-- Media Distribution Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-file-image mr-2 text-pink-500"></i>
                    Media by File Type
                </h3>
            </div>
            <div class="h-64">
                <canvas id="mediaDistributionChart"></canvas>
            </div>
        </div>

        <!-- Blog Categories Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-folder mr-2 text-yellow-500"></i>
                    Top Blog Categories
                </h3>
            </div>
            <div class="h-64">
                <canvas id="categoryDistributionChart"></canvas>
            </div>
        </div>

        <!-- Top Pages Chart -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-file-alt mr-2 text-teal-500"></i>
                    Top Pages by Sections
                </h3>
            </div>
            <div class="h-64">
                <canvas id="topPagesChart"></canvas>
            </div>
        </div>
    </div>

    <!-- New Users Chart -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-users mr-2 text-blue-500"></i>
                New User Registrations
            </h3>
            <div class="text-xs text-gray-500 dark:text-gray-400">
                <i class="fas fa-info-circle"></i> User growth over time
            </div>
        </div>
        <div class="h-80">
            <canvas id="usersChart"></canvas>
        </div>
    </div>
</div>

@push('scripts')
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Dark mode detection
function isDarkMode() {
    return document.documentElement.classList.contains('dark');
}

// Get colors based on dark mode
function getChartColors() {
    const dark = isDarkMode();
    return {
        textColor: dark ? '#e5e7eb' : '#374151',
        gridColor: dark ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0, 0, 0, 0.05)',
        legendColor: dark ? '#e5e7eb' : '#374151',
    };
}

// Chart.js default configuration
Chart.defaults.responsive = true;
Chart.defaults.maintainAspectRatio = false;
Chart.defaults.plugins.legend.display = true;
Chart.defaults.plugins.legend.position = 'bottom';

// Chart data from server
const chartData = @json($chartData);

// Store chart instances for updates
let chartInstances = [];

// Initialize all charts
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    
    // Watch for dark mode changes and update charts
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.attributeName === 'class') {
                updateChartsForTheme();
            }
        });
    });
    
    observer.observe(document.documentElement, {
        attributes: true
    });
});

function updateChartsForTheme() {
    const colors = getChartColors();
    
    chartInstances.forEach(chart => {
        if (chart.options.scales) {
            if (chart.options.scales.y) {
                chart.options.scales.y.ticks.color = colors.textColor;
                chart.options.scales.y.grid.color = colors.gridColor;
            }
            if (chart.options.scales.x) {
                chart.options.scales.x.ticks.color = colors.textColor;
            }
        }
        if (chart.options.plugins && chart.options.plugins.legend) {
            chart.options.plugins.legend.labels = {
                color: colors.legendColor
            };
        }
        chart.update();
    });
}

function initializeCharts() {
    const colors = getChartColors();
    chartInstances = []; // Clear existing instances
    
    // Content Trends Chart (Multi-line)
    const contentTrendsCtx = document.getElementById('contentTrendsChart');
    if (contentTrendsCtx) {
        const chart = new Chart(contentTrendsCtx, {
            type: 'line',
            data: {
                labels: chartData.content.labels,
                datasets: chartData.content.datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            color: colors.legendColor
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: { size: 14 },
                        bodyFont: { size: 13 },
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Contacts Chart (Area)
    const contactsCtx = document.getElementById('contactsChart');
    if (contactsCtx) {
        const chart = new Chart(contactsCtx, {
            type: 'line',
            data: {
                labels: chartData.contacts.labels,
                datasets: [{
                    label: 'Contacts',
                    data: chartData.contacts.data,
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Job Applications Chart (Bar)
    const jobApplicationsCtx = document.getElementById('jobApplicationsChart');
    if (jobApplicationsCtx) {
        const chart = new Chart(jobApplicationsCtx, {
            type: 'bar',
            data: {
                labels: chartData.jobApplications.labels,
                datasets: [{
                    label: 'Applications',
                    data: chartData.jobApplications.data,
                    backgroundColor: 'rgba(168, 85, 247, 0.8)',
                    borderColor: 'rgb(168, 85, 247)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Activities Chart (Area)
    const activitiesCtx = document.getElementById('activitiesChart');
    if (activitiesCtx) {
        const chart = new Chart(activitiesCtx, {
            type: 'line',
            data: {
                labels: chartData.activities.labels,
                datasets: [{
                    label: 'Activities',
                    data: chartData.activities.data,
                    borderColor: 'rgb(99, 102, 241)',
                    backgroundColor: 'rgba(99, 102, 241, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Media Distribution Chart (Doughnut)
    const mediaDistributionCtx = document.getElementById('mediaDistributionChart');
    if (mediaDistributionCtx) {
        // Generate colors dynamically based on data length
        const colors = [
            { bg: 'rgba(59, 130, 246, 0.8)', border: 'rgb(59, 130, 246)' },
            { bg: 'rgba(168, 85, 247, 0.8)', border: 'rgb(168, 85, 247)' },
            { bg: 'rgba(34, 197, 94, 0.8)', border: 'rgb(34, 197, 94)' },
            { bg: 'rgba(234, 179, 8, 0.8)', border: 'rgb(234, 179, 8)' },
            { bg: 'rgba(239, 68, 68, 0.8)', border: 'rgb(239, 68, 68)' },
            { bg: 'rgba(236, 72, 153, 0.8)', border: 'rgb(236, 72, 153)' },
            { bg: 'rgba(20, 184, 166, 0.8)', border: 'rgb(20, 184, 166)' },
            { bg: 'rgba(251, 146, 60, 0.8)', border: 'rgb(251, 146, 60)' },
        ];
        
        const backgroundColors = chartData.mediaDistribution.data.map((_, i) => colors[i % colors.length].bg);
        const borderColors = chartData.mediaDistribution.data.map((_, i) => colors[i % colors.length].border);
        
        const chart = new Chart(mediaDistributionCtx, {
            type: 'doughnut',
            data: {
                labels: chartData.mediaDistribution.labels,
                datasets: [{
                    data: chartData.mediaDistribution.data,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: colors.legendColor
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Category Distribution Chart (Horizontal Bar)
    const categoryDistributionCtx = document.getElementById('categoryDistributionChart');
    if (categoryDistributionCtx) {
        const chart = new Chart(categoryDistributionCtx, {
            type: 'bar',
            data: {
                labels: chartData.categoryDistribution.labels,
                datasets: [{
                    label: 'Blogs',
                    data: chartData.categoryDistribution.data,
                    backgroundColor: 'rgba(234, 179, 8, 0.8)',
                    borderColor: 'rgb(234, 179, 8)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    y: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Top Pages Chart (Horizontal Bar)
    const topPagesCtx = document.getElementById('topPagesChart');
    if (topPagesCtx) {
        const chart = new Chart(topPagesCtx, {
            type: 'bar',
            data: {
                labels: chartData.topPages.labels,
                datasets: [{
                    label: 'Sections',
                    data: chartData.topPages.data,
                    backgroundColor: 'rgba(20, 184, 166, 0.8)',
                    borderColor: 'rgb(20, 184, 166)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    y: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }

    // Users Chart (Area)
    const usersCtx = document.getElementById('usersChart');
    if (usersCtx) {
        const chart = new Chart(usersCtx, {
            type: 'line',
            data: {
                labels: chartData.users.labels,
                datasets: [{
                    label: 'New Users',
                    data: chartData.users.data,
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0,
                            color: colors.textColor
                        },
                        grid: {
                            color: colors.gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: colors.textColor
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        chartInstances.push(chart);
    }
}

// Date range helper functions
function setDateRange(range) {
    const today = new Date();
    let fromDate = new Date();
    
    if (range === 'mtd') {
        fromDate = new Date(today.getFullYear(), today.getMonth(), 1);
    } else if (range === 'ytd') {
        fromDate = new Date(today.getFullYear(), 0, 1);
    } else {
        fromDate.setDate(today.getDate() - range);
    }
    
    document.getElementById('date_from').value = formatDate(fromDate);
    document.getElementById('date_to').value = formatDate(today);
    document.getElementById('analytics-filter-form').submit();
}

function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Export analytics data
function exportAnalytics() {
    const dateFrom = document.getElementById('date_from').value;
    const dateTo = document.getElementById('date_to').value;
    
    const url = `{{ route('admin.analytics.export') }}?date_from=${dateFrom}&date_to=${dateTo}`;
    
    fetch(url)
        .then(response => response.json())
        .then(data => {
            // Create downloadable JSON file
            const dataStr = JSON.stringify(data, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `analytics-${dateFrom}-to-${dateTo}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        })
        .catch(error => {
            console.error('Export failed:', error);
            alert('Failed to export analytics data');
        });
}
</script>
@endpush
@endsection
