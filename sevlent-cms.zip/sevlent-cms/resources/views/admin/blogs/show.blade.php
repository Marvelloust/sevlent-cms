@extends('admin.layouts.app')

@section('title', 'View Blog')
@section('page-title', 'View Blog')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r rounded-xl shadow-lg overflow-hidden  from-blue-600 to-indigo-600">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $blog->status === 'published' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                            <i class="fas {{ $blog->status === 'published' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($blog->status) }}
                        </span>
                        <span class="ml-3 text-sm font-medium" style="color: #dbeafe;">
                            <i class="fas fa-globe mr-1"></i>
                            <a href="{{ url('/blog/' . $blog->slug) }}" target="_blank" class="hover:text-white underline">
                                View Live
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $blog->title }}</h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #dbeafe;">
                        <span>
                            <i class="fas fa-user mr-2"></i>By {{ $blog->author->name ?? 'Unknown' }}
                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>{{ $blog->published_at ? 'Published ' . $blog->published_at->format('M d, Y') : 'Created ' . $blog->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $blog->updated_at->diffForHumans() }}
                        </span>
                        <span>
                            <i class="fas fa-link mr-2"></i><code class="bg-blue-500 bg-opacity-30 px-2 py-1 rounded">{{ $blog->slug }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.blogs.edit', $blog) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg transition-all duration-200" style="background-color: white; color: #2563eb;" onmouseover="this.style.backgroundColor='#eff6ff'" onmouseout="this.style.backgroundColor='white'">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="{{ route('admin.blogs.index') }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Featured Image Preview -->
    @if($blog->image)
        <div class="rounded-xl overflow-hidden shadow-lg">
            <img src="{{ $blog->image->url }}" alt="Featured Image" class="w-full h-96 object-cover">
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Excerpt -->
            @if($blog->excerpt)
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-quote-left mr-2 text-blue-600"></i>Excerpt
                        </h3>
                    </div>
                    <div class="px-6 py-8">
                        <p class="text-gray-700 dark:text-gray-300 text-lg leading-relaxed italic">{{ $blog->excerpt }}</p>
                    </div>
                </div>
            @endif

            <!-- Content Blocks -->
            @if($blog->content_blocks && count($blog->content_blocks) > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-th-large mr-2 text-green-600"></i>Content Blocks ({{ count($blog->content_blocks) }})
                        </h3>
                    </div>
                    <div class="divide-y divide-gray-200">
                        @foreach($blog->content_blocks as $block)
                            <div class="px-6 py-6 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 transition-colors duration-200">
                                @if($block['type'] === 'heading')
                                    <h4 class="text-xl font-bold text-gray-900 dark:text-white mb-2">{{ $block['content'] ?? 'No heading text' }}</h4>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Heading Block</span>
                                @elseif($block['type'] === 'paragraph')
                                    <div class="prose prose-sm max-w-none prose-a:text-blue-600 dark:prose-a:text-blue-400 prose-a:underline dark:text-gray-300">
                                        {!! nl2br(e($block['content'] ?? 'No paragraph text')) !!}
                                    </div>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Paragraph Block</span>
                                @elseif($block['type'] === 'image')
                                    @if(isset($block['image']) && $block['image'])
                                        <div class="mb-4">
                                            <img src="/storage/{{ $block['image'] }}" alt="{{ $block['content'] ?? 'Block image' }}" class="w-full h-48 object-cover rounded-lg shadow-md">
                                        </div>
                                    @endif
                                    @if(isset($block['content']) && $block['content'])
                                        <p class="text-gray-700 dark:text-gray-300 mb-2">{{ $block['content'] }}</p>
                                    @endif
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Image Block</span>
                                @elseif($block['type'] === 'bullet_list')
                                    <ul class="space-y-2">
                                        @foreach($block['content'] as $item)
                                            <li class="flex items-start">
                                                <i class="fas fa-circle text-gray-400 dark:text-gray-500 mt-1 mr-3 text-xs"></i>
                                                <span class="text-gray-700 dark:text-gray-300">{{ $item }}</span>
                                            </li>
                                        @endforeach
                                    </ul>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Bullet List Block</span>
                                @elseif($block['type'] === 'link')
                                    <div class="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                        <a href="{{ $block['url'] ?? '#' }}" class="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium" target="_blank">
                                            <i class="fas fa-external-link-alt mr-2"></i>
                                            {{ $block['content'] ?? 'Link' }}
                                        </a>
                                    </div>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Link Block</span>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
            @else
                <div class="mt-8 bg-blue-50 dark:bg-blue-900/20 rounded-xl border-2 border-blue-200 dark:border-blue-800 p-6">
                    <div class="flex">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-400 text-xl mr-4 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-blue-900 dark:text-blue-100 mb-1">No Content Blocks</h4>
                            <p class="text-sm text-blue-800 dark:text-blue-200">This blog post doesn't have any content blocks yet.
                                <a href="{{ route('admin.blogs.edit', $blog) }}" class="font-semibold hover:underline">Add content blocks</a> to build out your blog post.
                            </p>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Legacy Content -->
            @if($blog->content)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-file-alt mr-2 text-orange-600"></i>Legacy Content
                        </h3>
                    </div>
                    <div class="px-6 py-8">
                        <div class="prose prose-sm max-w-none prose-a:text-blue-600 prose-a:underline prose-img:rounded-lg prose-img:shadow-md">
                            {!! $blog->content !!}
                        </div>
                    </div>
                </div>
            @endif

            <!-- Categories and Tags -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-tags mr-2 text-purple-600"></i>Categories & Tags
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="space-y-4">
                        @if($blog->categories && $blog->categories->count() > 0)
                            <div>
                                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">Categories</p>
                                <div class="flex flex-wrap gap-2">
                                    @foreach($blog->categories as $category)
                                        <span class="inline-flex items-center px-3 py-1 bg-blue-100 dark:bg-blue-300 text-blue-800 dark:text-blue-200 text-sm font-semibold rounded-full">
                                            <i class="fas fa-folder mr-2"></i>{{ $category->name }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                        @endif

                        @if($blog->tags && $blog->tags->count() > 0)
                            <div>
                                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">Tags</p>
                                <div class="flex flex-wrap gap-2">
                                    @foreach($blog->tags as $tag)
                                        <span class="inline-flex items-center px-3 py-1 bg-green-100 dark:bg-green-300 text-green-800 dark:text-green-200 text-sm font-semibold rounded-full">
                                            <i class="fas fa-tag mr-2"></i>{{ $tag->name }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                        @endif

                        @if((!$blog->categories || $blog->categories->count() === 0) && (!$blog->tags || $blog->tags->count() === 0))
                            <p class="text-gray-500 dark:text-gray-400 text-sm">No categories or tags assigned</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar: Metadata -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Basic Info Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>Blog Info
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $blog->status === 'published' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' }}">
                            {{ ucfirst($blog->status) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Author</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $blog->author->name ?? 'Unknown' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Published Date</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $blog->published_at ? $blog->published_at->format('M d, Y H:i') : 'Not Published' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">URL Slug</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-gray-800 dark:text-white break-all">{{ $blog->slug }}</code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Created</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $blog->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $blog->updated_at->format('M d, Y H:i') }}</p>
                    </div>
                </div>
            </div>

            <!-- SEO Metadata Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-search mr-2 text-purple-600"></i>SEO Metadata
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($blog->seo?->meta_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Title</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-blue-50 dark:bg-blue-900/20 p-2 rounded border-l-2 border-blue-500">
                                {{ $blog->seo->meta_title }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($blog->seo->meta_title) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta title set</p>
                        </div>
                    @endif

                    @if($blog->seo?->meta_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Description</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-green-50 dark:bg-green-900/20 p-2 rounded border-l-2 border-green-500 leading-relaxed">
                                {{ $blog->seo->meta_description }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($blog->seo->meta_description) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta description set</p>
                        </div>
                    @endif

                    @if($blog->seo?->meta_keywords)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Keywords</p>
                            <div class="flex flex-wrap gap-2">
                                @foreach(explode(',', $blog->seo->meta_keywords) as $keyword)
                                    <span class="inline-block px-3 py-1 bg-yellow-100 dark:bg-yellow-300 text-yellow-800 dark:text-yellow-200 text-xs font-semibold rounded-full">
                                        {{ trim($keyword) }}
                                    </span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @if($blog->seo?->canonical_url)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Canonical URL</p>
                            <a href="{{ $blog->seo->canonical_url }}" target="_blank" class="text-sm text-blue-600 hover:text-blue-700 break-all">
                                {{ $blog->seo->canonical_url }}
                                <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                    @endif
                </div>
                <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                    <a href="{{ route('admin.blogs.edit', $blog) }}" class="text-sm font-medium text-purple-600 hover:text-purple-700">
                        <i class="fas fa-edit mr-1"></i>Edit SEO
                    </a>
                </div>
            </div>

            <!-- Social Sharing Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Sharing
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($blog->seo?->og_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Title</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $blog->seo->og_title }}</p>
                        </div>
                    @endif

                    @if($blog->seo?->og_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Description</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $blog->seo->og_description }}</p>
                        </div>
                    @endif

                    @if($blog->seo?->ogImage)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Image</p>
                            <img src="{{ asset('storage/' . $blog->seo->ogImage->file_path) }}" alt="OG" class="w-full h-32 object-cover rounded">
                        </div>
                    @endif

                    @if(!$blog->seo?->og_title && !$blog->seo?->og_description && !$blog->seo?->ogImage)
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-share-alt mr-2"></i>No OG data configured</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
