@extends('admin.layouts.app')

@section('title', 'Edit Blog')
@section('page-title', 'Edit Blog')

@section('content')
<script>
let contentBlockIndex = 0;

// Add Content Block
function addContentBlock(type = 'paragraph', content = '', image = '') {
    const container = document.getElementById('content_blocks_container');
    const blockDiv = document.createElement('div');
    blockDiv.className = 'p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';

    const escapedContent = content.replace(/'/g, "\\'")
        .replace(/"/g, '&quot;')
        .replace(/\r\n/g, '\\n')
        .replace(/\n/g, '\\n');
    const escapedImage = image.replace(/'/g, "\\'");

    let blockContentHTML = getBlockContentHTML(type, contentBlockIndex, content, image);

    blockDiv.innerHTML = `
        <div class="flex gap-3">
            <div class="flex-1">
                <div class="mb-3">
                    <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Block Type</label>
                    <select name="content_blocks[${contentBlockIndex}][type]" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" onchange="handleBlockTypeChange(this, ${contentBlockIndex})">
                        <option value="heading" ${type === 'heading' ? 'selected' : ''}>Heading</option>
                        <option value="paragraph" ${type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
                        <option value="image" ${type === 'image' ? 'selected' : ''}>Image</option>
                        <option value="list" ${type === 'list' ? 'selected' : ''}>Bullet List</option>
                        <option value="link" ${type === 'link' ? 'selected' : ''}>Link</option>
                    </select>
                </div>
                <div id="block_content_${contentBlockIndex}">
                    ${blockContentHTML}
                </div>
            </div>
            <button type="button" onclick="this.parentElement.parentElement.remove()" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-md hover:bg-red-50 h-fit">
                Remove
            </button>
        </div>
    `;

    container.appendChild(blockDiv);

    // For links, set the values after adding the block
    if (type === 'link' && content.includes('|')) {
        const parts = content.split('|');
        const linkText = parts[0] || '';
        const linkUrl = parts[1] || '';

        setTimeout(() => {
            const blockContentDiv = document.getElementById(`block_content_${contentBlockIndex}`);
            const linkTextInput = blockContentDiv.querySelector('input[name*="[link_text]"]');
            const linkUrlInput = blockContentDiv.querySelector('input[name*="[content]"]');

            if (linkTextInput) linkTextInput.value = linkText;
            if (linkUrlInput) linkUrlInput.value = linkUrl;
        }, 10);
    }

    contentBlockIndex++;
}

// Get block content HTML based on type
function getBlockContentHTML(type, index, content = '', image = '') {
    // Escape content for HTML attributes
    const escapedContent = content.replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    if (type === 'heading') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Heading Text</label>
            
        `;
    } else if (type === 'paragraph') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Paragraph Text</label>
            <textarea name="content_blocks[${index}][content]" rows="4" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter paragraph text. Use **text** for bold, *text* for italic.">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500">Formatting: **bold**, *italic*</p>
        `;
    } else if (type === 'image') {
        const imagePreview = image ?
            `<img src="/storage/${image}" alt="Block image" class="w-32 h-32 object-cover rounded border">` :
            '<div class="w-32 h-32 bg-gray-200 rounded border flex items-center justify-center text-xs text-gray-500">No image</div>';

        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Image</label>
            <input type="hidden" name="content_blocks[${index}][image]" id="block_image_${index}" value="${image}">
            <div id="block_image_preview_${index}" class="mb-2">
                ${imagePreview}
            </div>
            <button type="button" onclick="openContentBlockMediaSelector('block_image_${index}', 'block_image_preview_${index}')" class="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">Select Image</button>
            
        `;
    } else if (type === 'list') {
        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">List Items (one per line)</label>
            <textarea name="content_blocks[${index}][content]" rows="5" class="block w-full bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm" placeholder="Enter each list item on a new line">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500">Each line will be a bullet point</p>
        `;
    } else if (type === 'link') {
        const parts = content.split('|');
        const linkText = parts[0] || '';
        const linkUrl = parts[1] || '';
        const escapedLinkText = linkText.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
        const escapedLinkUrl = linkUrl.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');

        return `
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Link Text</label>
            
            <label class="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Link URL</label>
            
        `;
    }
}

// Handle block type change
function handleBlockTypeChange(select, index) {
    const type = select.value;
    const contentContainer = document.getElementById(`block_content_${index}`);
    contentContainer.innerHTML = getBlockContentHTML(type, index);
}

// Content block media selector function
function openContentBlockMediaSelector(fieldName, previewId) {
    // Store preview ID for callback - fieldId will come from the message
    if (!window.contentBlockPreviewMap) {
        window.contentBlockPreviewMap = {};
    }
    window.contentBlockPreviewMap[fieldName] = previewId;

    window.open(`/admin/media-selector?type=image&fieldId=${encodeURIComponent(fieldName)}`, 'Media Selector', 'width=1200,height=800,scrollbars=yes,resizable=yes');
}

// Global message listener for content block media selection
if (!window.contentBlockMediaListenerAttached) {
    window.contentBlockMediaListenerAttached = true;
    window.addEventListener('message', function(event) {
        if (event.origin !== window.location.origin) return;

        if (event.data && event.data.type === 'MEDIA_SELECTED') {
            const media = event.data.media;
            const fieldId = event.data.fieldId;
            const previewId = window.contentBlockPreviewMap ? window.contentBlockPreviewMap[fieldId] : null;

            const input = document.getElementById(fieldId);
            const preview = previewId ? document.getElementById(previewId) : null;

            if (input) {
                input.value = media.file_path || media.path || '';
            }

            if (preview) {
                preview.innerHTML = `<img src="${media.url}" alt="Selected image" class="w-32 h-32 object-cover rounded border">`;
            }
        }
    });
}
</script>
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-edit mr-3"></i>Edit Blog Post
                    </h1>
                    <p class="text-white">{{ $blog->title }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $blog->status === 'published' ? 'status-success' : 'status-warning' }}">
                            <i class="fas {{ $blog->status === 'published' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($blog->status) }}
                        </span>
                        <span class="ml-3 text-indigo-200 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Updated {{ $blog->updated_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.blogs.show', $blog) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-eye mr-2"></i>Preview
                    </a>
                    <a href="{{ route('admin.blogs.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Blogs
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.blogs.update', $blog) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Essential details for your blog post</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Title -->
                    <div class="lg:col-span-2">
                        <label for="title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-heading mr-2 text-gray-500"></i>Blog Title <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="title" id="title" value="{{ old('title', $blog->title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('title') border-red-500 @enderror"
                               placeholder="Enter an engaging blog title" required>
                        @error('title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Slug -->
                    <div class="lg:col-span-2">
                        <label for="slug" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-link mr-2 text-gray-500"></i>URL Slug <span class="text-red-500">*</span>
                        </label>
                        <div class="flex">
                            <span class="inline-flex items-center px-3 py-3 bg-gray-100 dark:bg-gray-800 border border-r-0 border-gray-300 dark:border-gray-600 rounded-l-lg text-gray-500 dark:text-gray-400 text-sm">
                                /blog/
                            </span>
                            <input type="text" name="slug" id="slug" value="{{ old('slug', $blog->slug) }}"
                                   class="flex-1 px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-r-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('slug') border-red-500 @enderror"
                                   placeholder="url-friendly-slug" required>
                        </div>
                        @error('slug')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Excerpt -->
                    <div class="lg:col-span-2">
                        <label for="excerpt" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-alt mr-2 text-gray-500"></i>Excerpt
                        </label>
                        <textarea name="excerpt" id="excerpt" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical @error('excerpt') border-red-500 @enderror"
                                  placeholder="Brief summary of your blog post">{{ old('excerpt', $blog->excerpt) }}</textarea>
                        @error('excerpt')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Content Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-edit mr-2 text-green-600"></i>Blog Content
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Build your blog post with rich content blocks</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <!-- Content Blocks -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-th-large mr-2 text-gray-500"></i>Content Blocks
                    </label>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-3 flex items-center">
                        <i class="fas fa-info-circle mr-1"></i>Build your blog post using content blocks. Add headings, paragraphs, images, lists, and links.
                    </p>

                    <div id="content_blocks_container" class="space-y-4">
                        <!-- Content blocks will be added here -->
                    </div>

                    <button type="button" id="add_content_block_btn" class="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 transition-all duration-200">
                        <svg class="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        Add Content Block
                    </button>
                </div>

                <!-- Featured Image -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-image mr-2 text-gray-500"></i>Featured Image
                    </label>
                    @include('admin.media.picker', [
                        'fieldName' => 'featured_image',
                        'selectedMedia' => $blog->image,
                        'label' => 'Featured Image',
                        'help' => 'Select a featured image or video for this blog post',
                        'required' => false,
                        'allowedTypes' => ['image', 'video'],
                        'previewSize' => 'w-40 h-24'
                    ])
                </div>

                <!-- Categories and Tags -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Categories -->
                    <div>
                        <label for="categories" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-tags mr-2 text-gray-500"></i>Categories
                        </label>
                        <select name="categories[]" id="categories" multiple
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('categories') border-red-500 @enderror">
                            @foreach(\App\Models\BlogCategory::all() as $category)
                                <option value="{{ $category->id }}" {{ $blog->categories->contains($category->id) ? 'selected' : '' }}>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        @error('categories')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Tags -->
                    <div>
                        <label for="tags" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-hashtag mr-2 text-gray-500"></i>Tags
                        </label>
                        <select name="tags[]" id="tags" multiple
                                class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200 @error('tags') border-red-500 @enderror">
                            @foreach(\App\Models\BlogTag::all() as $tag)
                                <option value="{{ $tag->id }}" {{ $blog->tags->contains($tag->id) ? 'selected' : '' }}>{{ $tag->name }}</option>
                            @endforeach
                        </select>
                        @error('tags')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- SEO Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-search mr-2 text-purple-600"></i>Search Engine Optimization (SEO)
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Help search engines understand your blog post</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- SEO Title -->
                    <div class="lg:col-span-2">
                        <label for="meta_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-tag mr-2 text-gray-500"></i>Meta Title
                        </label>
                        <input type="text" name="meta_title" id="meta_title" value="{{ old('meta_title', $blog->seo?->meta_title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="SEO title for search engines" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Leave blank to use blog title. Recommended: 50-60 characters
                        </p>
                        @error('meta_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Description -->
                    <div class="lg:col-span-2">
                        <label for="meta_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-text mr-2 text-gray-500"></i>Meta Description
                        </label>
                        <textarea name="meta_description" id="meta_description" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 resize-none @error('meta_description') border-red-500 @enderror"
                                  placeholder="Brief description for search engines" maxlength="500">{{ old('meta_description', $blog->seo?->meta_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Brief description for search engines. Recommended: 150-160 characters
                        </p>
                        @error('meta_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Keywords -->
                    <div>
                        <label for="meta_keywords" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-key mr-2 text-gray-500"></i>Meta Keywords
                        </label>
                        <input type="text" name="meta_keywords" id="meta_keywords" value="{{ old('meta_keywords', $blog->seo?->meta_keywords) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="keyword1, keyword2, keyword3">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Comma-separated keywords (optional)
                        </p>
                        @error('meta_keywords')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Canonical URL -->
                    <div>
                        <label for="canonical_url" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-external-link-alt mr-2 text-gray-500"></i>Canonical URL
                        </label>
                        <input type="url" name="canonical_url" id="canonical_url" value="{{ old('canonical_url', $blog->seo?->canonical_url) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="https://example.com/blog-url">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Canonical URL to prevent duplicate content
                        </p>
                        @error('canonical_url')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Social Media Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Media Sharing
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">How your blog post appears when shared on social media</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Open Graph Title -->
                    <div class="lg:col-span-2">
                        <label for="og_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Title
                        </label>
                        <input type="text" name="og_title" id="og_title" value="{{ old('og_title', $blog->seo?->og_title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200"
                               placeholder="Title for social media sharing" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Title for social media sharing. Leave blank to use meta title
                        </p>
                        @error('og_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Description -->
                    <div class="lg:col-span-2">
                        <label for="og_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Description
                        </label>
                        <textarea name="og_description" id="og_description" rows="2"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200 resize-none @error('og_description') border-red-500 @enderror"
                                  placeholder="Description for social media sharing" maxlength="500">{{ old('og_description', $blog->seo?->og_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Description for social media sharing. Leave blank to use meta description
                        </p>
                        @error('og_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Image -->
                    <div class="lg:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Image
                        </label>
                        @include('admin.media.picker', [
                            'fieldName' => 'og_image',
                            'selectedMedia' => $blog->seo?->ogImage,
                            'label' => 'Open Graph Image',
                            'help' => 'Image or video for social media sharing (recommended: 1200x630px)',
                            'required' => false,
                            'allowedTypes' => ['image', 'video'],
                            'previewSize' => 'w-40 h-24'
                        ])
                    </div>
                </div>
            </div>

            <!-- Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-cog mr-2 text-orange-600"></i>Publication Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Configure how and when your blog post is published</p>
            </div>
            <div class="px-6 py-6">
                <!-- Status and Published At -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Status -->
                    <div>
                        <label for="status" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                            <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Publication Status <span class="text-red-500">*</span>
                        </label>
                        <div class="flex items-center space-x-6">
                            <label class="inline-flex items-center">
                                <input type="radio" name="status" value="draft" {{ old('status', $blog->status) == 'draft' ? 'checked' : '' }}
                                       class="form-radio h-5 w-5 text-yellow-600 focus:ring-yellow-500">
                                <span class="ml-2 text-sm font-medium text-gray-700">
                                    <i class="fas fa-edit mr-1" style="color: #d97706"></i>Draft
                                </span>
                            </label>
                            <label class="inline-flex items-center">
                                <input type="radio" name="status" value="published" {{ old('status', $blog->status) == 'published' ? 'checked' : '' }}
                                       class="form-radio h-5 w-5 text-green-600 focus:ring-green-500">
                                <span class="ml-2 text-sm font-medium text-gray-700">
                                    <i class="fas fa-check-circle mr-1" style="color: #16a34a"></i>Published
                                </span>
                            </label>
                        </div>
                        @error('status')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Published At -->
                    <div>
                        <label for="published_at" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-calendar mr-2 text-gray-500"></i>Published At
                        </label>
                        <input type="datetime-local" name="published_at" id="published_at"
                               value="{{ old('published_at', $blog->published_at ? $blog->published_at->format('Y-m-d\TH:i') : '') }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200 @error('published_at') border-red-500 @enderror">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Leave blank to publish immediately when status is set to published
                        </p>
                        @error('published_at')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.blogs.index') }}"  class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update Blog Post
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
// Initialize with existing content blocks or one empty paragraph block
document.addEventListener('DOMContentLoaded', function() {
    // Add event listener to the add button
    const addButton = document.getElementById('add_content_block_btn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            addContentBlock('paragraph');
        });
    }

    @if($blog->content_blocks && count($blog->content_blocks) > 0)
        const existingBlocks = {!! json_encode($blog->content_blocks) !!};
        existingBlocks.forEach(function(block) {
            const blockType = block.type || 'paragraph';
            const blockContent = block.content || '';
            const blockImage = block.image || '';
            const blockLinkText = block.link_text || '';

            let content = blockContent;
            if (blockType === 'link' && blockLinkText) {
                content = blockLinkText + '|' + blockContent;
            }

            addContentBlock(blockType, content, blockImage);
        });
    @else
        addContentBlock('paragraph');
    @endif
});
</script>

@endsection
