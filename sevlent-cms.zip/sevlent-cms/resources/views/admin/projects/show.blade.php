@extends('admin.layouts.app')

@section('title', 'View Project')
@section('page-title', 'View Project')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r rounded-xl shadow-lg overflow-hidden  from-blue-600 to-purple-600">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $project->status === 'active' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' }}">
                            <i class="fas {{ $project->status === 'active' ? 'fa-check-circle' : 'fa-times-circle' }} mr-1"></i>
                            {{ ucfirst($project->status) }}
                        </span>
                        <span class="ml-3 text-sm font-medium" style="color: #dbeafe;">
                            <i class="fas fa-globe mr-1"></i>
                            <a href="{{ url('/projects/' . $project->slug) }}" target="_blank" class="hover:text-white underline">
                                View Live
                            </a>
                        </span>
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $project->title }}</h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #dbeafe;">
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Created {{ $project->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $project->updated_at->diffForHumans() }}
                        </span>
                        <span>
                            <i class="fas fa-link mr-2"></i><code class="bg-blue-500 bg-opacity-30 px-2 py-1 rounded">{{ $project->slug }}</code>
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.projects.edit', $project) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg transition-all duration-200" style="background-color: white; color: #2563eb;" onmouseover="this.style.backgroundColor='#eff6ff'" onmouseout="this.style.backgroundColor='white'">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>
                    <a href="{{ route('admin.projects.index') }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Featured Image Preview -->
    @if($project->media->count() > 0)
        <div class="rounded-xl overflow-hidden shadow-lg">
            <img src="{{ $project->media->first()->url }}" alt="Project Featured Image" class="w-full h-96 object-cover">
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Description -->
            @if($project->description)
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-file-alt mr-2 text-blue-600"></i>Project Description
                        </h3>
                    </div>
                    <div class="px-6 py-8">
                        <div class="prose prose-sm max-w-none prose-a:text-blue-600 prose-a:underline prose-img:rounded-lg prose-img:shadow-md dark:text-gray-300">
                            {!! $project->description !!}
                        </div>
                    </div>
                </div>
            @endif

            <!-- Content Blocks -->
            @if($project->content_blocks && count($project->content_blocks) > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-th-large mr-2 text-green-600"></i>Project Details ({{ count($project->content_blocks) }})
                        </h3>
                    </div>
                    <div class="divide-y divide-gray-200 dark:divide-gray-700">
                        @foreach($project->content_blocks as $block)
                            <div class="px-6 py-6 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors duration-200">
                                @if($block['type'] === 'heading')
                                    <h4 class="text-xl font-bold text-gray-900 dark:text-white mb-2">{{ $block['content'] ?? 'No heading text' }}</h4>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Heading Block</span>
                                @elseif($block['type'] === 'paragraph')
                                    <div class="prose prose-sm max-w-none prose-a:text-blue-600 dark:prose-a:text-blue-400 prose-a:underline dark:text-gray-300">
                                        {!! nl2br(e($block['content'] ?? 'No paragraph text')) !!}
                                    </div>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Paragraph Block</span>
                                @elseif($block['type'] === 'image')
                                    @if(isset($block['image']) && $block['image'])
                                        <div class="mb-4">
                                            <img src="/storage/{{ $block['image'] }}" alt="{{ $block['content'] ?? 'Block image' }}" class="w-full h-48 object-cover rounded-lg shadow-md">
                                        </div>
                                    @endif
                                    @if(isset($block['content']) && $block['content'])
                                        <p class="text-gray-700 dark:text-gray-300 mb-2">{{ $block['content'] }}</p>
                                    @endif
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">Image Block</span>
                                @elseif($block['type'] === 'bullet_list')
                                    <ul class="space-y-2">
                                        @foreach($block['content'] as $item)
                                            <li class="flex items-start">
                                                <i class="fas fa-circle text-gray-400 dark:text-gray-500 mt-1 mr-3 text-xs"></i>
                                                <span class="text-gray-700 dark:text-gray-300">{{ $item }}</span>
                                            </li>
                                        @endforeach
                                    </ul>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Bullet List Block</span>
                                @elseif($block['type'] === 'link')
                                    <div class="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                                        <a href="{{ $block['url'] ?? '#' }}" class="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium" target="_blank">
                                            <i class="fas fa-external-link-alt mr-2"></i>
                                            {{ $block['content'] ?? 'Link' }}
                                        </a>
                                    </div>
                                    <span class="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-3 inline-block">Link Block</span>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </div>
            @else
                <div class="mt-8 bg-blue-50 dark:bg-blue-900/20 rounded-xl border-2 border-blue-200 dark:border-blue-800 p-6">
                    <div class="flex">
                        <i class="fas fa-info-circle text-blue-600 dark:text-blue-400 text-xl mr-4 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-blue-900 dark:text-blue-100 mb-1">No Content Blocks</h4>
                            <p class="text-sm text-blue-800 dark:text-blue-200">This project doesn't have any content blocks yet.
                                <a href="{{ route('admin.projects.edit', $project) }}" class="font-semibold hover:underline">Add content blocks</a> to build out your project details.
                            </p>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Project Images Gallery -->
            @if($project->media->count() > 1)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-images mr-2 text-purple-600"></i>Project Gallery ({{ $project->media->count() }} images)
                        </h3>
                    </div>
                    <div class="px-6 py-6">
                        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            @foreach($project->media as $media)
                                <div class="relative group">
                                    <img src="{{ $media->url }}" alt="Project Image" class="w-full h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200">
                                    <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 rounded-lg flex items-center justify-center">
                                        <a href="{{ $media->url }}" target="_blank" class="opacity-0 group-hover:opacity-100 text-white text-sm font-medium">
                                            <i class="fas fa-external-link-alt mr-1"></i>View
                                        </a>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif

            <!-- Technologies -->
            @if($project->technologies && count($project->technologies) > 0)
                <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fas fa-code mr-2 text-indigo-600"></i>Technologies Used
                        </h3>
                    </div>
                    <div class="px-6 py-6">
                        <div class="flex flex-wrap gap-3">
                            @foreach($project->technologies as $technology)
                                <span class="inline-flex items-center px-4 py-2 bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200 text-sm font-semibold rounded-full">
                                    <i class="fas fa-code mr-2"></i>{{ $technology }}
                                </span>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <!-- Sidebar: Metadata -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Basic Info Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-info-circle mr-2 text-gray-600 dark:text-gray-400"></i>Project Info
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $project->status === 'active' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200' }}">
                            {{ ucfirst($project->status) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">URL Slug</p>
                        <code class="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-gray-800 dark:text-white break-all">{{ $project->slug }}</code>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Images</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $project->media->count() }} image{{ $project->media->count() !== 1 ? 's' : '' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Created</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $project->created_at->format('M d, Y H:i') }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $project->updated_at->format('M d, Y H:i') }}</p>
                    </div>
                </div>
            </div>

            <!-- SEO Metadata Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-search mr-2 text-purple-600"></i>SEO Metadata
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($project->seo?->meta_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Title</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-blue-50 dark:bg-blue-900/20 p-2 rounded border-l-2 border-blue-500">
                                {{ $project->seo->meta_title }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($project->seo->meta_title) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta title set</p>
                        </div>
                    @endif

                    @if($project->seo?->meta_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Meta Description</p>
                            <p class="text-sm text-gray-800 dark:text-white bg-green-50 dark:bg-green-900/20 p-2 rounded border-l-2 border-green-500 leading-relaxed">
                                {{ $project->seo->meta_description }}
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">
                                <i class="fas fa-info-circle mr-1"></i>
                                <span class="font-medium">{{ strlen($project->seo->meta_description) }}</span> characters
                            </p>
                        </div>
                    @else
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-file-alt mr-2"></i>No meta description set</p>
                        </div>
                    @endif

                    @if($project->seo?->meta_keywords)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Keywords</p>
                            <div class="flex flex-wrap gap-2">
                                @foreach(explode(',', $project->seo->meta_keywords) as $keyword)
                                    <span class="inline-block px-3 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 text-xs font-semibold rounded-full">
                                        {{ trim($keyword) }}
                                    </span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    @if($project->seo?->canonical_url)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Canonical URL</p>
                            <a href="{{ $project->seo->canonical_url }}" target="_blank" class="text-sm text-blue-600 hover:text-blue-700 break-all">
                                {{ $project->seo->canonical_url }}
                                <i class="fas fa-external-link-alt ml-1"></i>
                            </a>
                        </div>
                    @endif
                </div>
                <div class="px-6 py-3 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 text-right">
                    <a href="{{ route('admin.projects.edit', $project) }}" class="text-sm font-medium text-purple-600 hover:text-purple-700">
                        <i class="fas fa-edit mr-1"></i>Edit SEO
                    </a>
                </div>
            </div>

            <!-- Social Sharing Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Sharing
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($project->seo?->og_title)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Title</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $project->seo->og_title }}</p>
                        </div>
                    @endif

                    @if($project->seo?->og_description)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Description</p>
                            <p class="text-sm text-gray-800 dark:text-white">{{ $project->seo->og_description }}</p>
                        </div>
                    @endif

                    @if($project->seo?->ogImage)
                        <div class="px-6 py-4">
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">OG Image</p>
                            <img src="{{ $project->seo->ogImage->url }}" alt="OG" class="w-full h-32 object-cover rounded">
                        </div>
                    @endif

                    @if(!$project->seo?->og_title && !$project->seo?->og_description && !$project->seo?->ogImage)
                        <div class="px-6 py-4 text-gray-500 dark:text-gray-400">
                            <p class="text-sm text-gray-500 dark:text-gray-400"><i class="fas fa-share-alt mr-2"></i>No OG data configured</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
