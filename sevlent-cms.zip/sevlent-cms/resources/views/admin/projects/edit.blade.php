@extends('admin.layouts.app')

@section('title', 'Edit Project')
@section('page-title', 'Edit Project')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-edit mr-3"></i>Edit Project
                    </h1>
                    <p class="text-white">{{ $project->title }}</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $project->status === 'active' ? 'status-success' : 'status-warning' }}">
                            <i class="fas {{ $project->status === 'active' ? 'fa-check-circle' : 'fa-clock' }} mr-1"></i>
                            {{ ucfirst($project->status) }}
                        </span>
                        <span class="ml-3 text-indigo-200 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Updated {{ $project->updated_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.projects.show', $project) }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-eye mr-2"></i>Preview
                    </a>
                    <a href="{{ route('admin.projects.index') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Projects
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Form -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <form method="POST" action="{{ route('admin.projects.update', $project) }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Basic Information Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-info-circle mr-2 text-blue-600"></i>Basic Information
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Essential details for your project</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Title -->
                    <div class="lg:col-span-2">
                        <label for="title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-heading mr-2 text-gray-500"></i>Project Title <span class="text-red-500">*</span>
                        </label>
                        <input type="text" name="title" id="title" value="{{ old('title', $project->title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('title') border-red-500 @enderror"
                               placeholder="Enter an engaging project title" required>
                        @error('title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Slug -->
                    <div class="lg:col-span-2">
                        <label for="slug" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-link mr-2 text-gray-500"></i>URL Slug <span class="text-red-500">*</span>
                        </label>
                        <div class="flex">
                            <span class="inline-flex items-center px-3 py-3 bg-gray-100 dark:bg-gray-800 border border-r-0 border-gray-300 dark:border-gray-600 rounded-l-lg text-gray-500 dark:text-gray-400 text-sm">
                                /projects/
                            </span>
                            <input type="text" name="slug" id="slug" value="{{ old('slug', $project->slug) }}"
                                   class="flex-1 px-4 py-3 bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-r-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('slug') border-red-500 @enderror"
                                   placeholder="url-friendly-slug" required>
                        </div>
                        @error('slug')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div class="lg:col-span-2">
                        <label for="description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-alt mr-2 text-gray-500"></i>Short Description
                        </label>
                        <textarea name="description" id="description" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-vertical @error('description') border-red-500 @enderror"
                                  placeholder="Brief project summary">{{ old('description', $project->description) }}</textarea>
                        @error('description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Technologies -->
                    <div>
                        <label for="technologies" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-code mr-2 text-gray-500"></i>Technologies
                        </label>
                        <input type="text" name="technologies" id="technologies" value="{{ old('technologies', is_array($project->technologies) ? implode(', ', $project->technologies) : $project->technologies) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('technologies') border-red-500 @enderror"
                               placeholder="e.g., PHP, Laravel, MySQL">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Comma-separated technologies used
                        </p>
                        @error('technologies')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Content Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-edit mr-2 text-green-600"></i>Project Content
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Build your project details using content blocks</p>
            </div>
            <div class="px-6 py-6">
                <!-- Content Blocks -->
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                        <i class="fas fa-cubes mr-2 text-gray-500"></i>Content Blocks
                    </label>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">Build your project content using blocks. Add headings, paragraphs, images, lists, and links.</p>

                    <div id="content_blocks_container" class="space-y-4">
                        <!-- Content blocks will be loaded here -->
                    </div>

                    <button type="button" id="add_content_block_btn" class="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition-all duration-200">
                        <i class="fas fa-plus mr-2"></i>Add Content Block
                    </button>
                </div>
            </div>

            <!-- Media Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-900">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-bold text-gray-900 dark:text-white flex items-center">
                            <i class="fas fa-images mr-2 text-purple-600"></i>Project Media
                        </h3>
                        <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Manage images and visual content for your project</p>
                    </div>
                    <div class="hidden sm:flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                        <span>High-res recommended</span>
                    </div>
                </div>
            </div>
            <div class="px-6 py-8 bg-gray-50 dark:bg-gray-900">
                <!-- Project Images -->
                <div class="mb-6">
                    <div class="mb-4">
                        <label class="block text-base font-bold text-gray-900 dark:text-white mb-1">
                            <i class="fas fa-image mr-2 text-purple-600"></i>Project Images
                        </label>
                        <p class="text-sm text-gray-600 dark:text-gray-400">Select and organize images that best represent your project</p>
                    </div>
                    @include('admin.media.multiple-picker', [
                        'fieldName' => 'media_ids',
                        'selectedMedia' => $project->media,
                        'label' => '',
                        'help' => 'Select multiple images for this project',
                        'required' => false,
                        'allowedTypes' => ['image'],
                        'previewSize' => 'w-38 h-32'
                    ])
                </div>
            </div>

            <!-- SEO Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-search mr-2 text-purple-600"></i>Search Engine Optimization (SEO)
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Help search engines understand your project</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- SEO Title -->
                    <div class="lg:col-span-2">
                        <label for="meta_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-tag mr-2 text-gray-500"></i>Meta Title
                        </label>
                        <input type="text" name="meta_title" id="meta_title" value="{{ old('meta_title', $project->seo?->meta_title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="SEO title for search engines" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Leave blank to use project title. Recommended: 50-60 characters
                        </p>
                        @error('meta_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Description -->
                    <div class="lg:col-span-2">
                        <label for="meta_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-file-text mr-2 text-gray-500"></i>Meta Description
                        </label>
                        <textarea name="meta_description" id="meta_description" rows="3"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 resize-none @error('meta_description') border-red-500 @enderror"
                                  placeholder="Brief description for search engines" maxlength="500">{{ old('meta_description', $project->seo?->meta_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Brief description for search engines. Recommended: 150-160 characters
                        </p>
                        @error('meta_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- SEO Keywords -->
                    <div>
                        <label for="meta_keywords" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-key mr-2 text-gray-500"></i>Meta Keywords
                        </label>
                        <input type="text" name="meta_keywords" id="meta_keywords" value="{{ old('meta_keywords', $project->seo?->meta_keywords) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="keyword1, keyword2, keyword3">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Comma-separated keywords (optional)
                        </p>
                        @error('meta_keywords')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Canonical URL -->
                    <div>
                        <label for="canonical_url" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fas fa-external-link-alt mr-2 text-gray-500"></i>Canonical URL
                        </label>
                        <input type="url" name="canonical_url" id="canonical_url" value="{{ old('canonical_url', $project->seo?->canonical_url) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                               placeholder="https://example.com/project-url">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Canonical URL to prevent duplicate content
                        </p>
                        @error('canonical_url')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Social Media Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-share-alt mr-2 text-pink-600"></i>Social Media Sharing
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">How your project appears when shared on social media</p>
            </div>
            <div class="px-6 py-6 space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Open Graph Title -->
                    <div class="lg:col-span-2">
                        <label for="og_title" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Title
                        </label>
                        <input type="text" name="og_title" id="og_title" value="{{ old('og_title', $project->seo?->og_title) }}"
                               class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200"
                               placeholder="Title for social media sharing" maxlength="255">
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Title for social media sharing. Leave blank to use meta title
                        </p>
                        @error('og_title')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Description -->
                    <div class="lg:col-span-2">
                        <label for="og_description" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Description
                        </label>
                        <textarea name="og_description" id="og_description" rows="2"
                                  class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-all duration-200 resize-none @error('og_description') border-red-500 @enderror"
                                  placeholder="Description for social media sharing" maxlength="500">{{ old('og_description', $project->seo?->og_description) }}</textarea>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                            <i class="fas fa-info-circle mr-1"></i>Description for social media sharing. Leave blank to use meta description
                        </p>
                        @error('og_description')
                            <p class="mt-2 text-sm text-red-600 flex items-center">
                                <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                            </p>
                        @enderror
                    </div>

                    <!-- Open Graph Image -->
                    <div class="lg:col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            <i class="fab fa-facebook mr-2 text-gray-500"></i>Open Graph Image
                        </label>
                        @include('admin.media.picker', [
                            'fieldName' => 'og_image',
                            'selectedMedia' => $project->seo?->ogImage,
                            'label' => 'Open Graph Image',
                            'help' => 'Image for social media sharing (recommended: 1200x630px)',
                            'required' => false,
                            'allowedTypes' => ['image'],
                            'previewSize' => 'w-40 h-24'
                        ])
                    </div>
                </div>
            </div>

            <!-- Settings Section -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <i class="fas fa-cog mr-2 text-orange-600"></i>Project Settings
                </h3>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Configure how your project behaves</p>
            </div>
            <div class="px-6 py-6">
                <!-- Status -->
                <div class="mb-6">
                    <label for="status" class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                        <i class="fas fa-toggle-on mr-2 text-gray-500"></i>Publication Status <span class="text-red-500">*</span>
                    </label>
                    <div class="flex items-center space-x-6">
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="active" {{ old('status', $project->status) == 'active' ? 'checked' : '' }}
                                   class="form-radio h-5 w-5 text-green-600 focus:ring-green-500">
                            <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                <i class="fas fa-check-circle mr-1" style="color: #16a34a"></i>Active
                            </span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="status" value="inactive" {{ old('status', $project->status) == 'inactive' ? 'checked' : '' }}
                                   class="form-radio h-5 w-5 text-yellow-600 focus:ring-yellow-500">
                            <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                                <i class="fas fa-clock mr-1" style="color: #d97706"></i>Inactive
                            </span>
                        </label>
                    </div>
                    @error('status')
                        <p class="mt-2 text-sm text-red-600 flex items-center">
                            <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                        </p>
                    @enderror
                </div>
            </div>

            <!-- Submit Section -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div class="mb-4 sm:mb-0">
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>Changes will be saved and applied immediately.
                        </p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3">
                        <a href="{{ route('admin.projects.index') }}" class="inline-flex items-center px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                            <i class="fas fa-times mr-2"></i>Cancel
                        </a>
                        <button type="submit" class="inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                            <i class="fas fa-save mr-2"></i>Update Project
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
let contentBlockIndex = 0;

// Add Content Block
function addContentBlock(type = 'paragraph', content = '', image = '') {
    const container = document.getElementById('content_blocks_container');
    const blockDiv = document.createElement('div');
    blockDiv.className = 'p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200';

    const escapedContent = content.replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/\n/g, '\\n');
    const escapedImage = image.replace(/'/g, "\\'");

    let blockContentHTML = getBlockContentHTML(type, contentBlockIndex, escapedContent, escapedImage);

    blockDiv.innerHTML = `
        <div class="flex gap-3">
            <div class="flex-1">
                <div class="mb-3">
                    <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Block Type</label>
                    <select name="content_blocks[${contentBlockIndex}][type]" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200" onchange="handleBlockTypeChange(this, ${contentBlockIndex})">
                        <option value="heading" ${type === 'heading' ? 'selected' : ''}>Heading</option>
                        <option value="paragraph" ${type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
                        <option value="image" ${type === 'image' ? 'selected' : ''}>Image</option>
                        <option value="list" ${type === 'list' ? 'selected' : ''}>Bullet List</option>
                        <option value="link" ${type === 'link' ? 'selected' : ''}>Link</option>
                    </select>
                </div>
                <div id="block_content_${contentBlockIndex}">
                    ${blockContentHTML}
                </div>
            </div>
            <button type="button" onclick="this.parentElement.parentElement.remove()" class="mt-auto px-3 py-2 border border-red-300 text-red-600 text-sm font-medium rounded-lg hover:bg-red-50 transition-all duration-200 h-fit">
                <i class="fas fa-trash mr-1"></i>Remove
            </button>
        </div>
    `;

    container.appendChild(blockDiv);
    contentBlockIndex++;
}

// Get block content HTML based on type
function getBlockContentHTML(type, index, content = '', image = '') {
    const escapedContent = content.replace(/\\n/g, '\n');

    if (type === 'heading') {
        return `
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Heading Text</label>
            <input type="text" name="content_blocks[${index}][content]" value="${content}" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200" placeholder="Enter heading text">
        `;
    } else if (type === 'paragraph') {
        return `
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Paragraph Text</label>
            <textarea name="content_blocks[${index}][content]" rows="4" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200 resize-vertical" placeholder="Enter paragraph text. Use **text** for bold, *text* for italic.">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Formatting: **bold**, *italic*</p>
        `;
    } else if (type === 'image') {
        const imagePreview = image ?
            `<img src="/storage/${image}" alt="Block image" class="w-32 h-32 object-cover rounded border">` :
            '<div class="w-32 h-32 bg-gray-200 dark:bg-gray-700 rounded border dark:border-gray-600 flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">No image</div>';

        return `
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Image</label>
            <input type="hidden" name="content_blocks[${index}][image]" id="block_image_${index}" value="${image}">
            <div id="block_image_preview_${index}" class="mb-2">
                ${imagePreview}
            </div>
            <button type="button" onclick="openContentBlockMediaSelector('block_image_${index}', 'block_image_preview_${index}')" class="px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-all duration-200">
                <i class="fas fa-image mr-1"></i>Select Image
            </button>
            <input type="text" name="content_blocks[${index}][content]" value="${content}" class="mt-2 block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200" placeholder="Image caption (optional)">
        `;
    } else if (type === 'list') {
        return `
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">List Items (one per line)</label>
            <textarea name="content_blocks[${index}][content]" rows="5" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200 resize-vertical" placeholder="Enter each list item on a new line">${escapedContent}</textarea>
            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Each line will be a bullet point</p>
        `;
    } else if (type === 'link') {
        const parts = content.split('|');
        const linkText = parts[0] || '';
        const linkUrl = parts[1] || '';

        return `
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Link Text</label>
            <input type="text" name="content_blocks[${index}][link_text]" value="${linkText}" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200 mb-2" placeholder="Enter link text">
            <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1">Link URL</label>
            <input type="url" name="content_blocks[${index}][content]" value="${linkUrl}" class="block w-full px-3 py-2 border bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm transition-all duration-200" placeholder="https://example.com">
        `;
    }
}

// Handle block type change
function handleBlockTypeChange(select, index) {
    const type = select.value;
    const contentContainer = document.getElementById(`block_content_${index}`);
    contentContainer.innerHTML = getBlockContentHTML(type, index);
}

// Content block media selector function
function openContentBlockMediaSelector(fieldName, previewId) {
    if (!window.contentBlockPreviewMap) {
        window.contentBlockPreviewMap = {};
    }
    window.contentBlockPreviewMap[fieldName] = previewId;

    window.open(`/admin/media-selector?type=image&fieldId=${encodeURIComponent(fieldName)}`, 'Media Selector', 'width=1200,height=800,scrollbars=yes,resizable=yes');
}

// Global message listener for content block media selection
if (!window.contentBlockMediaListenerAttached) {
    window.contentBlockMediaListenerAttached = true;
    window.addEventListener('message', function(event) {
        if (event.origin !== window.location.origin) return;

        if (event.data && event.data.type === 'MEDIA_SELECTED') {
            const media = event.data.media;
            const fieldId = event.data.fieldId;
            const previewId = window.contentBlockPreviewMap ? window.contentBlockPreviewMap[fieldId] : null;

            const input = document.getElementById(fieldId);
            const preview = previewId ? document.getElementById(previewId) : null;

            if (input) {
                input.value = media.file_path || media.path || '';
            }

            if (preview) {
                preview.innerHTML = `<img src="${media.url}" alt="Selected image" class="w-32 h-32 object-cover rounded border">`;
            }
        }
    });
}

// Initialize and load existing content blocks
document.addEventListener('DOMContentLoaded', function() {
    const addButton = document.getElementById('add_content_block_btn');
    if (addButton) {
        addButton.addEventListener('click', function() {
            addContentBlock('paragraph');
        });
    }

    // Load existing content blocks
    const existingBlocks = @json($project->content_blocks ?? []);
    if (existingBlocks && existingBlocks.length > 0) {
        existingBlocks.forEach(block => {
            addContentBlock(
                block.type || 'paragraph',
                block.content || '',
                block.image || ''
            );
        });
    }
});
</script>

@endsection
