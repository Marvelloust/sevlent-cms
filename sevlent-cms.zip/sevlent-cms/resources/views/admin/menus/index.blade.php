{{-- Menus Index --}}
@extends('admin.layouts.app')

@section('title', 'Menus Management')

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-bars mr-3"></i>Menus Management
                    </h1>
                    <p class="text-white">Create and manage navigation menus for your website</p>
                    <div class="flex items-center mt-2">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/20 text-white">
                            <i class="fas fa-list mr-1"></i>
                            {{ $menus->count() }} Menu{{ $menus->count() !== 1 ? 's' : '' }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.menus.create') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-plus mr-2"></i>Create Menu
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Menus Grid -->
    @if($menus->count() > 0)
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($menus as $menu)
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <!-- Card Header -->
            <div class="bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-4">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-bold text-white">{{ $menu->name }}</h3>
                    <div class="flex space-x-2">
                        <a href="{{ route('admin.menus.show', $menu) }}"
                           class="text-white/80 hover:text-white transition-colors p-1"
                           title="Edit Menu">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="{{ route('admin.menus.destroy', $menu) }}" method="POST" class="inline"
                              onsubmit="showDeleteConfirmation('Are you sure you want to delete this menu?', () => { this.submit(); }); return false;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-white/80 hover:text-white transition-colors p-1"
                                    title="Delete Menu">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Card Body -->
            <div class="px-6 py-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center text-gray-600">
                        <i class="fas fa-list-ul mr-2 text-blue-500"></i>
                        <span class="font-medium">{{ $menu->items->count() }}</span>
                        <span class="ml-1">item{{ $menu->items->count() !== 1 ? 's' : '' }}</span>
                    </div>
                    <div class="text-xs text-gray-500">
                        Created {{ $menu->created_at->diffForHumans() }}
                    </div>
                </div>

                <!-- Menu Preview -->
                @if($menu->topLevelItems->count() > 0)
                <div class="mb-4 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p class="text-xs font-medium text-gray-700 dark:text-gray-300 mb-2">Menu Items:</p>
                    <div class="space-y-1">
                        @foreach($menu->topLevelItems->take(3) as $item)
                        <div class="flex items-center text-sm text-gray-600">
                            <i class="fas fa-circle text-xs mr-2 text-gray-400"></i>
                            <span class="truncate">{{ $item->title }}</span>
                        </div>
                        @endforeach
                        @if($menu->topLevelItems->count() > 3)
                        <div class="text-xs text-gray-500 dark:text-gray-400 pl-4">
                            +{{ $menu->topLevelItems->count() - 3 }} more items
                        </div>
                        @endif
                    </div>
                </div>
                @endif

                <!-- Action Button -->
                <a href="{{ route('admin.menus.show', $menu) }}"
                   class="w-full inline-flex items-center justify-center px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                    <i class="fas fa-cog mr-2"></i>Manage Items
                </a>
            </div>
        </div>
        @endforeach
    </div>
    @else
    <!-- Empty State -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="text-center py-16 px-6">
            <div class="mx-auto w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mb-6">
                <i class="fas fa-bars text-4xl text-purple-600"></i>
            </div>
            <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">No Menus Yet</h3>
            <p class="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                Create your first navigation menu to organize your website's navigation structure and improve user experience.
            </p>
            <a href="{{ route('admin.menus.create') }}"
               class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 transform hover:scale-105 shadow-lg">
                <i class="fas fa-plus mr-3"></i>Create Your First Menu
            </a>
        </div>

        <!-- Tips Section -->
        <div class="border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 px-6 py-8">
            <div class="max-w-4xl mx-auto">
                <h4 class="text-lg font-semibold text-gray-900 dark:text-white mb-6 text-center">
                    <i class="fas fa-lightbulb mr-2 text-yellow-500"></i>Menu Management Tips
                </h4>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="text-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-sitemap text-blue-600"></i>
                        </div>
                        <h5 class="font-medium text-gray-900 dark:text-white mb-2">Organize Structure</h5>
                        <p class="text-sm text-gray-600">Create logical menu hierarchies with parent and child items for better navigation.</p>
                    </div>
                    <div class="text-center">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-link text-green-600"></i>
                        </div>
                        <h5 class="font-medium text-gray-900 dark:text-white mb-2">Link Types</h5>
                        <p class="text-sm text-gray-600">Link to pages, external URLs, or custom routes to create comprehensive navigation.</p>
                    </div>
                    <div class="text-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-palette text-purple-600"></i>
                        </div>
                        <h5 class="font-medium text-gray-900 dark:text-white mb-2">Customize Appearance</h5>
                        <p class="text-sm text-gray-600">Add icons, CSS classes, and styling to make your menus visually appealing.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection