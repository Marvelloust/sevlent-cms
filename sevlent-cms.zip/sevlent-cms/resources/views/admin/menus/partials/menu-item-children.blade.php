{{-- Menu Item Children Partial --}}
@foreach($items as $item)
<div class="menu-item nested-item flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 ml-8"
     data-id="{{ $item->id }}">
    <div class="flex items-center space-x-3">
        <i class="fas fa-grip-vertical text-gray-400 cursor-move"></i>
        <div>
            <span class="font-medium text-gray-900 dark:text-white">{{ $item->title }}</span>
            @if($item->url)
                <span class="text-sm text-gray-500 dark:text-gray-400 ml-2">{{ $item->url }}</span>
            @elseif($item->page)
                <span class="text-sm text-blue-600 ml-2">→ {{ $item->page->title }}</span>
            @endif
            @if(!$item->is_active)
                <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded ml-2">Inactive</span>
            @endif
        </div>
    </div>
    <div class="flex items-center space-x-2">
        <button onclick="editItem({{ $item->id }}, '{{ $item->title }}', '{{ $item->url }}', {{ $item->page_id ?: 'null' }}, '{{ $item->target }}', '{{ $item->css_class }}', '{{ $item->icon }}', {{ $item->is_active ? 'true' : 'false' }})"
                class="text-blue-600 hover:text-blue-800">
            <i class="fas fa-edit"></i>
        </button>
        <form action="{{ route('admin.menus.items.destroy', [$menu, $item]) }}" method="POST" class="inline"
              onsubmit="showDeleteConfirmation('Are you sure you want to delete this menu item?', () => { this.submit(); }); return false;">
            @csrf
            @method('DELETE')
            <button type="submit" class="text-red-600 hover:text-red-800">
                <i class="fas fa-trash"></i>
            </button>
        </form>
    </div>
</div>

{{-- Render children recursively --}}
@include('admin.menus.partials.menu-item-children', ['items' => $item->children, 'menu' => $menu])
@endforeach