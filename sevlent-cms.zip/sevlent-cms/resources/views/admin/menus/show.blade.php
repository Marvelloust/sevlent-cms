{{-- Show Menu with Items Management --}}
@extends('admin.layouts.app')

@section('title', 'Manage Menu Items')

@push('styles')
<style>
.menu-item {
    transition: all 0.2s ease;
}
.menu-item:hover {
    background-color: rgba(var(--color-primary-rgb), 0.05);
}
.dark .menu-item:hover {
    background-color: rgba(var(--color-primary-rgb), 0.1);
}
.menu-item.dragging {
    opacity: 0.5;
    transform: rotate(5deg);
}
.nested-item {
    margin-left: 2rem;
}
.sortable-placeholder {
    background: rgba(var(--color-primary-rgb), 0.1);
    border: 2px dashed rgba(var(--color-primary-rgb), 0.3);
    margin: 4px 0;
    height: 40px;
}
.dark .sortable-placeholder {
    background: rgba(var(--color-primary-rgb), 0.15);
    border-color: rgba(var(--color-primary-rgb), 0.4);
}
</style>
@endpush

@section('content')
<div class="space-y-8">
    <!-- Header Section -->
    <div class="bg-gradient-to-r from-indigo-600 to-blue-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-bars mr-3"></i>Manage "{{ $menu->name }}" Menu
                    </h1>
                    <p class="text-white">Add, edit, and reorder menu items</p>
                    <div class="flex items-center mt-2 space-x-4">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white/20 text-white">
                            <i class="fas fa-list mr-1"></i>
                            {{ $menu->items->count() }} Item{{ $menu->items->count() !== 1 ? 's' : '' }}
                        </span>
                        <span class="text-indigo-200 text-sm">
                            <i class="fas fa-calendar mr-1"></i>Created {{ $menu->created_at->diffForHumans() }}
                        </span>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <button onclick="showAddItemModal()"
                            class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-plus mr-2"></i>Add Item
                    </button>
                    <a href="{{ route('admin.menus.index') }}"
                       class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Menus
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu Items Section -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-list mr-2 text-indigo-600"></i>Menu Items
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Drag and drop items to reorder them. Click edit to modify item details.</p>
        </div>

        <div class="px-6 py-6">
            @if($menu->topLevelItems->count() > 0)
            <div id="menu-items" class="space-y-3">
                @foreach($menu->topLevelItems as $item)
                <div class="menu-item group flex items-center justify-between p-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-indigo-300 dark:hover:border-indigo-500 hover:shadow-md transition-all duration-200"
                     data-id="{{ $item->id }}">
                    <div class="flex items-center space-x-4 flex-1">
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-grip-vertical text-gray-400 dark:text-gray-500 cursor-move group-hover:text-indigo-500 dark:group-hover:text-indigo-400 transition-colors"></i>
                            @if($item->icon)
                                <i class="{{ $item->icon }} text-indigo-600 dark:text-indigo-400"></i>
                            @else
                                <div class="w-4 h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                            @endif
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center space-x-2">
                                <span class="font-semibold text-gray-900 dark:text-white">{{ $item->title }}</span>
                                @if(!$item->is_active)
                                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200">
                                        <i class="fas fa-eye-slash mr-1"></i>Inactive
                                    </span>
                                @endif
                            </div>
                            <div class="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                @if($item->url)
                                    <i class="fas fa-link mr-1 text-blue-500 dark:text-blue-400"></i>{{ $item->url }}
                                @elseif($item->page)
                                    <i class="fas fa-file-alt mr-1 text-green-500 dark:text-green-400"></i>{{ $item->page->title }}
                                @else
                                    <span class="text-gray-400 dark:text-gray-500">No link specified</span>
                                @endif
                                @if($item->target && $item->target !== '_self')
                                    <span class="ml-2 text-xs bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 px-2 py-1 rounded">
                                        {{ $item->target }}
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <button onclick="editItem({{ $item->id }}, '{{ addslashes($item->title) }}', '{{ addslashes($item->url) }}', {{ $item->page_id ?: 'null' }}, '{{ $item->target }}', '{{ addslashes($item->css_class) }}', '{{ addslashes($item->icon) }}', {{ $item->is_active ? 'true' : 'false' }})"
                                class="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 p-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950 transition-colors"
                                title="Edit Item">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.menus.items.destroy', [$menu, $item]) }}" method="POST" class="inline"
                              onsubmit="showDeleteConfirmation('Are you sure you want to delete this menu item?', () => { this.submit(); }); return false;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 transition-colors"
                                    title="Delete Item">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>

                {{-- Render children recursively --}}
                @include('admin.menus.partials.menu-item-children', ['items' => $item->children, 'menu' => $menu])
                @endforeach
            </div>
            @else
            <!-- Empty State -->
            <div class="text-center py-16">
                <div class="mx-auto w-24 h-24 bg-gradient-to-br from-indigo-100 to-blue-100 dark:from-indigo-900 dark:to-blue-900 rounded-full flex items-center justify-center mb-6">
                    <i class="fas fa-list text-4xl text-indigo-600 dark:text-indigo-400"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-3">No Menu Items Yet</h3>
                <p class="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
                    Start building your navigation menu by adding your first menu item.
                </p>
                <button onclick="showAddItemModal()"
                        class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-semibold rounded-lg hover:from-indigo-700 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg">
                    <i class="fas fa-plus mr-3"></i>Add First Item
                </button>
            </div>
            @endif
        </div>
    </div>

    <!-- Usage Tips Section -->
    @if($menu->topLevelItems->count() > 0)
    <div class="bg-blue-50 dark:bg-blue-950 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-blue-200 dark:border-blue-800 bg-blue-100 dark:bg-blue-900">
            <h3 class="text-lg font-semibold text-blue-900 dark:text-blue-300">
                <i class="fas fa-lightbulb mr-2 text-blue-600 dark:text-blue-400"></i>Menu Management Tips
            </h3>
        </div>
        <div class="px-6 py-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-arrows-alt mr-2 text-blue-600 dark:text-blue-400"></i>Reordering Items
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Drag items by the grip handle to reorder them
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Changes are saved automatically when you finish dragging
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Order affects how items appear in your navigation
                        </li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-3">
                        <i class="fas fa-cog mr-2 text-blue-600 dark:text-blue-400"></i>Advanced Features
                    </h4>
                    <ul class="space-y-2 text-sm text-blue-800 dark:text-blue-400">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Add icons using FontAwesome classes (e.g., "fas fa-home")
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Use CSS classes for custom styling
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle mr-2 mt-0.5 text-green-600"></i>
                            Set target="_blank" to open links in new tabs
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

{{-- Add/Edit Item Modal --}}
<div id="itemModal" class="fixed inset-0 bg-gray-600 dark:bg-gray-900 bg-opacity-50 dark:bg-opacity-75 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border dark:border-gray-700 w-full max-w-2xl shadow-lg rounded-xl bg-white dark:bg-gray-800">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-xl font-bold text-gray-900 dark:text-white" id="modalTitle">
                    <i class="fas fa-plus mr-2 text-indigo-600"></i>Add Menu Item
                </h3>
                <button onclick="closeModal()" class="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                    <i class="fas fa-times text-lg"></i>
                </button>
            </div>

            <form id="itemForm" action="{{ route('admin.menus.items.store', $menu) }}" method="POST">
                @csrf
                <input type="hidden" id="itemId" name="item_id">

                <div class="space-y-6">
                    <!-- Basic Information -->
                    <div class="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                        <h4 class="font-semibold text-gray-900 dark:text-white mb-4">
                            <i class="fas fa-info-circle mr-2 text-indigo-600"></i>Basic Information
                        </h4>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                                    Title <span class="text-red-500">*</span>
                                </label>
                                <input type="text" id="itemTitle" name="title"
                                       class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                                       placeholder="e.g., Home, About Us, Contact"
                                       required>
                                @error('title')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <!-- Link Configuration -->
                    <div class="bg-blue-50 dark:bg-blue-950 rounded-lg p-4">
                        <h4 class="font-semibold text-blue-900 dark:text-blue-300 mb-4">
                            <i class="fas fa-link mr-2 text-blue-600 dark:text-blue-400"></i>Link Configuration
                        </h4>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Link Type</label>
                                <div class="flex space-x-6">
                                    <label class="inline-flex items-center">
                                        <input type="radio" name="link_type" value="url" checked
                                               class="form-radio h-5 w-5 text-blue-600 focus:ring-blue-500">
                                        <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Custom URL</span>
                                    </label>
                                    <label class="inline-flex items-center">
                                        <input type="radio" name="link_type" value="page"
                                               class="form-radio h-5 w-5 text-blue-600 focus:ring-blue-500">
                                        <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Page</span>
                                    </label>
                                </div>
                            </div>

                            <div id="urlField">
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">URL</label>
                                <input type="text" id="itemUrl" name="url"
                                       class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                                       placeholder="/about, https://example.com, #section">
                                @error('url')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>

                            <div class="hidden" id="pageField">
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Page</label>
                                <select id="itemPageId" name="page_id"
                                        class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 @error('page_id') border-red-500 @enderror">
                                    <option value="">Select a page...</option>
                                    @foreach($pages as $page)
                                    <option value="{{ $page->id }}">{{ $page->title }}</option>
                                    @endforeach
                                </select>
                                @error('page_id')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <!-- Advanced Settings -->
                    <div class="bg-purple-50 dark:bg-purple-950 rounded-lg p-4">
                        <h4 class="font-semibold text-purple-900 dark:text-purple-300 mb-4">
                            <i class="fas fa-cog mr-2 text-purple-600 dark:text-purple-400"></i>Advanced Settings
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Target</label>
                                <select id="itemTarget" name="target"
                                        class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200 @error('target') border-red-500 @enderror">
                                    <option value="_self">Same Window (_self)</option>
                                    <option value="_blank">New Window (_blank)</option>
                                    <option value="_parent">Parent Frame (_parent)</option>
                                    <option value="_top">Top Frame (_top)</option>
                                </select>
                                @error('target')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">CSS Class</label>
                                <input type="text" id="itemCssClass" name="css_class"
                                       class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                                       placeholder="custom-class another-class">
                                @error('css_class')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Icon Class</label>
                                <input type="text" id="itemIcon" name="icon"
                                       class="w-full bg-white dark:bg-gray-900 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white dark:placeholder-gray-400 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                                       placeholder="fas fa-home">
                                @error('icon')
                                    <p class="mt-2 text-sm text-red-600 flex items-center">
                                        <i class="fas fa-exclamation-circle mr-1"></i>{{ $message }}
                                    </p>
                                @enderror
                            </div>

                            <div class="flex items-center">
                                <label class="inline-flex items-center cursor-pointer">
                                    <input type="checkbox" id="itemIsActive" name="is_active" value="1" checked
                                           class="form-checkbox h-5 w-5 text-green-600 focus:ring-green-500 rounded">
                                    <span class="ml-3 text-sm font-medium text-gray-700 dark:text-gray-300">
                                        <i class="fas fa-eye mr-1 text-green-600 dark:text-green-400"></i>Active
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                    <button type="button" onclick="closeModal()"
                            class="px-6 py-3 bg-gray-300 dark:bg-gray-700 text-gray-700 dark:text-gray-300 font-semibold rounded-lg hover:bg-gray-400 dark:hover:bg-gray-600 transition-all duration-200">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-6 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-semibold rounded-lg hover:from-indigo-700 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-md">
                        <i class="fas fa-save mr-2"></i>Save Item
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
let currentEditingItemId = null;

function showAddItemModal() {
    currentEditingItemId = null;
    document.getElementById('modalTitle').textContent = 'Add Menu Item';
    document.getElementById('itemForm').action = '{{ route("admin.menus.items.store", $menu) }}';
    document.getElementById('itemForm').method = 'POST';

    // Reset form
    document.getElementById('itemTitle').value = '';
    document.getElementById('itemUrl').value = '';
    document.getElementById('itemPageId').value = '';
    document.getElementById('itemTarget').value = '_self';
    document.getElementById('itemCssClass').value = '';
    document.getElementById('itemIcon').value = '';
    document.getElementById('itemIsActive').checked = true;

    toggleLinkType('url');
    document.getElementById('itemModal').classList.remove('hidden');
}

function editItem(id, title, url, pageId, target, cssClass, icon, isActive) {
    currentEditingItemId = id;
    document.getElementById('modalTitle').textContent = 'Edit Menu Item';
    document.getElementById('itemForm').action = '{{ route("admin.menus.items.update", [$menu, ":id"]) }}'.replace(':id', id);
    document.getElementById('itemForm').method = 'POST';

    // Add method override for PUT
    let methodInput = document.querySelector('input[name="_method"]');
    if (!methodInput) {
        methodInput = document.createElement('input');
        methodInput.type = 'hidden';
        methodInput.name = '_method';
        document.getElementById('itemForm').appendChild(methodInput);
    }
    methodInput.value = 'PUT';

    // Fill form
    document.getElementById('itemTitle').value = title;
    document.getElementById('itemTarget').value = target;
    document.getElementById('itemCssClass').value = cssClass || '';
    document.getElementById('itemIcon').value = icon || '';
    document.getElementById('itemIsActive').checked = isActive;

    if (pageId) {
        document.querySelector('input[name="link_type"][value="page"]').checked = true;
        document.getElementById('itemPageId').value = pageId;
        toggleLinkType('page');
    } else {
        document.querySelector('input[name="link_type"][value="url"]').checked = true;
        document.getElementById('itemUrl').value = url;
        toggleLinkType('url');
    }

    document.getElementById('itemModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('itemModal').classList.add('hidden');
    currentEditingItemId = null;
}

function toggleLinkType(type) {
    if (type === 'url') {
        document.getElementById('urlField').classList.remove('hidden');
        document.getElementById('pageField').classList.add('hidden');
        document.getElementById('itemPageId').value = '';
    } else {
        document.getElementById('urlField').classList.add('hidden');
        document.getElementById('pageField').classList.remove('hidden');
        document.getElementById('itemUrl').value = '';
    }
}

// Link type toggle
document.querySelectorAll('input[name="link_type"]').forEach(radio => {
    radio.addEventListener('change', function() {
        toggleLinkType(this.value);
    });
});

// Initialize sortable
document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.getElementById('menu-items');
    if (menuItems) {
        Sortable.create(menuItems, {
            handle: '.fa-grip-vertical',
            animation: 150,
            onEnd: function(evt) {
                updateOrder();
            }
        });
    }
});

function updateOrder() {
    const items = document.querySelectorAll('#menu-items .menu-item');
    const orderData = [];

    items.forEach((item, index) => {
        orderData.push({
            id: parseInt(item.dataset.id),
            order_index: index,
            parent_id: null // For now, we'll handle nested items separately
        });
    });

    fetch('{{ route("admin.menus.reorder", $menu) }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ items: orderData })
    });
}
</script>
@endpush