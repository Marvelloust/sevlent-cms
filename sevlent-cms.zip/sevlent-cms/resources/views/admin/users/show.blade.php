{{-- Show User --}}
@extends('admin.layouts.app')

@section('title', 'User Details')

@section('content')
<div class="space-y-8">
    <!-- Header Section with Status -->
    <div class="bg-gradient-to-r  from-blue-600 to-indigo-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                <div class="mb-6 sm:mb-0 flex-1">
                    <div class="flex items-center mb-3">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $user->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                            <i class="fas {{ $user->status === 'active' ? 'fa-check-circle' : 'fa-times-circle' }} mr-1"></i>
                            {{ ucfirst($user->status) }}
                        </span>
                        @if($user->email_verified_at)
                        <span class="ml-3 text-sm font-medium" style="color: #dbeafe;">
                            <i class="fas fa-envelope mr-1"></i>
                            Email Verified
                        </span>
                        @endif
                    </div>
                    <h1 class="text-4xl font-bold text-white mb-2">{{ $user->name }}</h1>
                    <div class="flex flex-wrap gap-6 text-sm" style="color: #dbeafe;">
                        <span>
                            <i class="fas fa-envelope mr-2"></i>{{ $user->email }}
                        </span>
                        <span>
                            <i class="fas fa-calendar mr-2"></i>Joined {{ $user->created_at->format('M d, Y') }}
                        </span>
                        <span>
                            <i class="fas fa-edit mr-2"></i>Updated {{ $user->updated_at->diffForHumans() }}
                        </span>
                        @if($user->email_verified_at)
                        <span>
                            <i class="fas fa-check-circle mr-2"></i>Verified {{ $user->email_verified_at->format('M d, Y') }}
                        </span>
                        @endif
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.users.edit', $user) }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg transition-all duration-200" style="background-color: white; color: #2563eb;" onmouseover="this.style.backgroundColor='#eff6ff'" onmouseout="this.style.backgroundColor='white'">
                        <i class="fas fa-edit mr-2"></i>Edit User
                    </a>
                    <a href="{{ route('admin.users.index') }}" class="inline-flex items-center px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-200 backdrop-blur-sm" style="background-color: rgba(255, 255, 255, 0.2); color: white;" onmouseover="this.style.backgroundColor='rgba(255, 255, 255, 0.3)'" onmouseout="this.style.backgroundColor='rgba(255, 255, 255, 0.2)'">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- User Avatar Preview -->
    <div class="flex justify-center">
        <div class="rounded-xl overflow-hidden shadow-lg bg-white dark:bg-gray-800 p-8">
            <div class="h-32 w-32 rounded-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center mx-auto">
                <span class="text-6xl font-medium text-gray-700 dark:text-white">{{ substr($user->name, 0, 1) }}</span>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Content -->
        <div class="lg:col-span-2">
            <!-- Basic Information -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-user mr-2 text-blue-600"></i>Basic Information
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <dl class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Full Name</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->name }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email Address</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->email }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Status</p>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $user->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                {{ ucfirst($user->status) }}
                            </span>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Member Since</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->created_at->format('M d, Y') }}</p>
                        </div>
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Last Updated</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->updated_at->format('M d, Y') }}</p>
                        </div>
                        @if($user->email_verified_at)
                        <div>
                            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email Verified</p>
                            <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->email_verified_at->format('M d, Y') }}</p>
                        </div>
                        @endif
                    </dl>
                </div>
            </div>

            <!-- Roles & Permissions -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-user-shield mr-2 text-green-600"></i>Roles & Permissions
                    </h3>
                </div>
                <div class="px-6 py-6">
                    @if($user->roles->count() > 0)
                        <div class="flex flex-wrap gap-3">
                            @foreach($user->roles as $role)
                                <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold
                                    @if($role->name === 'super_admin') bg-red-100 text-red-800
                                    @elseif($role->name === 'admin') bg-blue-100 text-blue-800
                                    @else bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white @endif">
                                    <i class="fas fa-user-shield mr-2"></i>
                                    {{ $role->name }}
                                    @if($role->description)
                                        <span class="ml-2 text-xs opacity-75">- {{ $role->description }}</span>
                                    @endif
                                </span>
                            @endforeach
                        </div>
                    @else
                        <div class="bg-yellow-50 rounded-xl border-2 border-yellow-200 p-6">
                            <div class="flex">
                                <i class="fas fa-exclamation-triangle text-yellow-600 text-xl mr-4 mt-1"></i>
                                <div>
                                    <h4 class="font-semibold text-yellow-900 mb-1">No Roles Assigned</h4>
                                    <p class="text-sm text-yellow-800">This user doesn't have any roles assigned yet.</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Media Statistics -->
            <div class="mt-8 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-images mr-2 text-purple-600"></i>Media Statistics
                    </h3>
                </div>
                <div class="px-6 py-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                            <div class="flex items-center">
                                <i class="fas fa-file-upload text-blue-600 dark:text-blue-400 text-2xl mr-4"></i>
                                <div>
                                    <p class="text-xs font-semibold text-blue-800 dark:text-blue-300 uppercase tracking-wide">Total Uploads</p>
                                    <p class="text-2xl font-bold text-blue-900 dark:text-blue-100">{{ $user->media->count() }}</p>
                                </div>
                            </div>
                        </div>
                        @if($user->media->count() > 0)
                        <div class="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                            <div class="flex items-center">
                                <i class="fas fa-weight text-green-600 dark:text-green-400 text-2xl mr-4"></i>
                                <div>
                                    <p class="text-xs font-semibold text-green-800 dark:text-green-300 uppercase tracking-wide">Total Size</p>
                                    <p class="text-2xl font-bold text-green-900 dark:text-green-100">{{ number_format($user->media->sum('file_size') / 1024 / 1024, 2) }} MB</p>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar: Quick Actions -->
        <div class="lg:col-span-1 space-y-6">
            <!-- Quick Actions Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-bolt mr-2 text-yellow-600"></i>Quick Actions
                    </h3>
                </div>
                <div class="divide-y divide-gray-200">
                    @if($user->id !== auth()->id())
                    <div class="px-6 py-4">
                        @php $toggleAction = $user->status === 'active' ? 'deactivate' : 'activate'; @endphp
                        <form action="{{ route('admin.users.toggle-status', $user) }}" method="POST" onsubmit="return confirm('Are you sure you want to {{ $toggleAction }} this user?');">
                            @csrf
                            @method('PATCH')
                            <button type="submit" class="w-full text-left px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 {{ $user->status === 'active' ? 'text-yellow-700 dark:text-yellow-400 hover:bg-yellow-50 dark:hover:bg-yellow-900/20' : 'text-green-700 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/20' }}">
                                <i class="fas fa-{{ $user->status === 'active' ? 'ban' : 'check-circle' }} mr-3"></i>
                                {{ $user->status === 'active' ? 'Deactivate' : 'Activate' }} User
                            </button>
                        </form>
                    </div>
                    @endif

                    <div class="px-6 py-4">
                        <a href="{{ route('admin.users.edit', $user) }}" class="block px-4 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:bg-gray-900 rounded-lg transition-colors duration-200">
                            <i class="fas fa-edit mr-3"></i>Edit User
                        </a>
                    </div>

                    @if($user->id !== auth()->id())
                    <div class="px-6 py-4">
                        <form action="{{ route('admin.users.destroy', $user) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="w-full text-left px-4 py-3 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors duration-200">
                                <i class="fas fa-trash mr-3"></i>Delete User
                            </button>
                        </form>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Account Summary Card -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        <i class="fas fa-chart-line mr-2 text-indigo-600"></i>Account Summary
                    </h3>
                </div>
                <div class="divide-y divide-gray-200 dark:divide-gray-700">
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Account Status</p>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $user->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                            {{ ucfirst($user->status) }}
                        </span>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Email Verification</p>
                        @if($user->email_verified_at)
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                            <i class="fas fa-check mr-1"></i>Verified
                        </span>
                        @else
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-800">
                            <i class="fas fa-clock mr-1"></i>Pending
                        </span>
                        @endif
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Roles Count</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->roles->count() }} role{{ $user->roles->count() !== 1 ? 's' : '' }}</p>
                    </div>
                    <div class="px-6 py-4">
                        <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Media Files</p>
                        <p class="text-sm text-gray-700 dark:text-gray-300">{{ $user->media->count() }} file{{ $user->media->count() !== 1 ? 's' : '' }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
