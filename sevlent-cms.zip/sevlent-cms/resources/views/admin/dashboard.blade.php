@extends('admin.layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-gray-900 dark:to-gray-900">
    <!-- Hero Header (Compact Info Card) -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-6 py-2">
        <div class="bg-gradient-to-r from-white/60 via-white/40 to-white/60 backdrop-blur-sm border border-gray-100 rounded-2xl shadow-md overflow-hidden dark:bg-gradient-to-r dark:from-gray-800 dark:via-gray-800 dark:to-gray-900 dark:border-gray-700">
            <div class="flex flex-col md:flex-row items-center gap-6 p-6">
                <div class="flex-shrink-0 bg-gradient-to-tr from-blue-600 to-indigo-600 p-4 rounded-xl text-white">
                    <svg class="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 7v4a1 1 0 001 1h3v6h8v-6h3a1 1 0 001-1V7M8 3h8v4H8V3z"/>
                    </svg>
                </div>

                <div class="flex-1">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900 dark:text-white">Welcome back, {{ auth()->user()->name }}!</h2>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Quick overview — content, status, and actions at a glance.</p>
                        </div>
                        <div class="hidden md:flex items-center space-x-3">
                            <a href="{{ route('admin.pages.index') }}" class="inline-flex items-center px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700">Manage Pages</a>
                            <a href="{{ route('admin.projects.index') }}" class="inline-flex items-center px-4 py-2 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-lg text-sm font-medium hover:bg-indigo-100 dark:bg-gray-800 dark:text-white dark:border-gray-700 dark:hover:bg-gray-700">Projects</a>
                        </div>
                    </div>

                    <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div class="p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700 shadow-sm">
                            <p class="text-xs text-gray-500 dark:text-gray-400">Pages</p>
                            <p class="text-lg font-bold text-gray-900 dark:text-white">{{ \App\Models\Page::count() }}</p>
                        </div>
                        <div class="p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700 shadow-sm">
                            <p class="text-xs text-gray-500 dark:text-gray-400">Projects</p>
                            <p class="text-lg font-bold text-gray-900 dark:text-white">{{ \App\Models\Project::count() }}</p>
                        </div>
                        <div class="p-3 bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700 shadow-sm">
                            <p class="text-xs text-gray-500 dark:text-gray-400">Pending Contacts</p>
                            <p class="text-lg font-bold text-gray-900 dark:text-white">{{ \App\Models\Contact::where('is_read', false)->count() }}</p>
                        </div>
                    </div>
                </div>

                <div class="flex-shrink-0 md:pl-4">
                    <div class="flex flex-col sm:flex-row md:flex-col gap-3">
                        <a href="{{ route('admin.contacts.index') }}" class="inline-flex items-center px-4 py-2 bg-orange-50 text-orange-700 border border-orange-100 rounded-lg text-sm font-medium hover:bg-orange-100">
                            <i class="fas fa-envelope mr-2"></i>Contacts
                        </a>
                        <a href="{{ route('admin.pages.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
                            <i class="fas fa-plus mr-2"></i>Create</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Stats Cards Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            @php
                $stats = [
                    ['label' => 'Total Pages', 'count' => \App\Models\Page::count(), 'from' => 'from-blue-500', 'to' => 'to-blue-700', 'icon' => 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'],
                    ['label' => 'Total Services', 'count' => \App\Models\Service::count(), 'from' => 'from-purple-600', 'to' => 'to-purple-700', 'icon' => 'M15 12a3 3 0 11-6 0 3 3 0 016 0z'],
                    ['label' => 'Blog Posts', 'count' => \App\Models\Blog::count(), 'from' => 'from-purple-500', 'to' => 'to-purple-700', 'icon' => 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5'],
                    ['label' => 'Total Projects', 'count' => \App\Models\Project::count(), 'from' => 'from-indigo-500', 'to' => 'to-indigo-700', 'icon' => 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2'],
                    ['label' => 'Total Careers', 'count' => \App\Models\Career::count(), 'from' => 'from-red-500', 'to' => 'to-red-700', 'icon' => 'M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745'],
                    ['label' => 'Applications', 'count' => \App\Models\JobApplication::count(), 'from' => 'from-orange-400', 'to' => 'to-orange-600', 'icon' => 'M9 12h6m-6 4h6']
                ];
            @endphp

            @foreach($stats as $stat)
                <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow duration-200 overflow-hidden">
                    <div class="p-4">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <div class="p-3 rounded-lg bg-gradient-to-br {{ $stat['from'] }} {{ $stat['to'] }} text-white">
                                    <div class="rounded-md p-2 bg-white/10">
                                        <svg class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $stat['icon'] }}"/>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="ml-4 flex-1">
                                <p class="text-xs text-gray-500 dark:text-gray-400">{{ $stat['label'] }}</p>
                                <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ $stat['count'] }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <!-- System Status & Activity Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- System Status -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">
                <div class="bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white flex items-center">
                        <i class="fas fa-shield-alt mr-2"></i>
                        System Status
                    </h3>
                    <p class="text-white text-sm mt-1">Current health and performance indicators</p>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200 dark:bg-gray-900 dark:border-gray-700">
                            <div class="flex items-center">
                                <div class="p-2 bg-green-100 rounded-lg mr-3 dark:bg-gray-800">
                                    <svg class="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">Database Connection</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">Operational</p>
                                </div>
                            </div>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800 dark:bg-gray-800 dark:text-green-300">
                                    <circle cx="4" cy="4" r="3"/>
                                </svg>
                                Connected
                            </span>
                        </div>

                        <div class="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200 dark:bg-gray-900 dark:border-gray-700">
                            <div class="flex items-center">
                                <div class="p-2 bg-blue-100 rounded-lg mr-3 dark:bg-gray-800">
                                    <svg class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">Storage Access</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">File system available</p>
                                </div>
                            </div>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 dark:bg-gray-800 dark:text-blue-300">
                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 8 8">
                                    <circle cx="4" cy="4" r="3"/>
                                </svg>
                                Available
                            </span>
                        </div>

                        <div class="flex items-center justify-between p-4 bg-purple-50 rounded-lg border border-purple-200 dark:bg-gray-900 dark:border-gray-700">
                            <div class="flex items-center">
                                <div class="p-2 bg-purple-100 rounded-lg mr-3 dark:bg-gray-800">
                                    <svg class="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">Cache Status</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">High performance</p>
                                </div>
                            </div>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800 dark:bg-gray-800 dark:text-purple-300">
                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 8 8">
                                    <circle cx="4" cy="4" r="3"/>
                                </svg>
                                Operational
                            </span>
                        </div>

                        <div class="flex items-center justify-between p-4 bg-yellow-50 rounded-lg border border-yellow-200 dark:bg-gray-900 dark:border-gray-700">
                            <div class="flex items-center">
                                <div class="p-2 bg-yellow-100 rounded-lg mr-3 dark:bg-gray-800">
                                    <svg class="h-5 w-5 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">Last Backup</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">Data protection</p>
                                </div>
                            </div>
                            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800 dark:bg-gray-800 dark:text-yellow-300">
                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 8 8">
                                    <circle cx="4" cy="4" r="3"/>
                                </svg>
                                {{ \App\Models\Setting::where('key', 'last_backup')->first()?->value ?? 'Never' }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">
                <div class="bg-gradient-to-r from-blue-500 to-indigo-600 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white flex items-center">
                        <i class="fas fa-clock mr-2"></i>
                        Recent Activity
                    </h3>
                    <p class="text-white text-sm mt-1">Latest updates and changes</p>
                </div>
                <div class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse($recentActivities as $activity)
                        <div class="p-4 hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors duration-150">
                            <div class="flex items-start space-x-3">
                                <div class="flex-shrink-0">
                                    <div class="p-2 bg-{{ $activity->color() }}-100 rounded-lg">
                                        <i class="{{ $activity->icon() }} text-{{ $activity->color() }}-600 h-5 w-5"></i>
                                    </div>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 dark:text-white">
                                        <a href="{{ $activity->getModelUrl() }}" class="hover:text-blue-600 dark:hover:text-blue-300 transition-colors duration-200">
                                            {{ $activity->title }}
                                        </a>
                                    </p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">{{ $activity->created_at->diffForHumans() }}</p>
                                </div>
                                <div class="flex-shrink-0">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        @switch($activity->action)
                                            @case('created') bg-green-100 text-green-800
                                            @case('updated') bg-blue-100 text-blue-800
                                            @case('deleted') bg-red-100 text-red-800
                                            @default bg-gray-100 dark:bg-gray-800 text-gray-800
                                        @endswitch">
                                        {{ ucfirst($activity->action) }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="p-6 text-center">
                            <div class="p-3 bg-gray-100 dark:bg-gray-800 rounded-full w-12 h-12 mx-auto mb-3">
                                <svg class="h-6 w-6 text-gray-400 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            </div>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">No recent activity</p>
                            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Start creating content to see activity here</p>
                        </div>
                    @endforelse

                    <!-- View All Link -->
                    @if($recentActivities->count() > 0)
                        <div class="p-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-700">
                            <a href="{{ route('admin.activities.index') }}" class="text-sm font-medium text-blue-600 hover:text-blue-500 transition-colors duration-200 flex items-center">
                                View all activities
                                <svg class="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Quick Actions & Pending Contacts -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Pending Contacts -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">
                <div class="bg-gradient-to-r from-orange-500 to-red-600 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white flex items-center">
                        <i class="fas fa-envelope mr-2"></i>
                        Pending Contacts
                    </h3>
                    <p class="text-white text-sm mt-1">Unread messages requiring attention</p>
                </div>
                <div class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse(\App\Models\Contact::where('is_read', false)->latest()->take(5)->get() as $contact)
                        <a href="{{ route('admin.contacts.show', $contact) }}" class="block hover:bg-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 transition-colors duration-150">
                            <div class="p-4">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-3">
                                        <div class="p-2 bg-orange-100 rounded-lg">
                                            <svg class="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"/>
                                            </svg>
                                        </div>
                                        <div>
                                            <p class="text-sm font-medium text-gray-900 dark:text-white">{{ $contact->name }}</p>
                                            <p class="text-sm text-gray-500 dark:text-gray-400">{{ Str::limit($contact->subject, 40) }}</p>
                                        </div>
                                    </div>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800 dark:bg-gray-800 dark:text-orange-300">
                                        Unread
                                    </span>
                                </div>
                            </div>
                        </a>
                    @empty
                        <div class="p-6 text-center">
                            <div class="p-3 bg-green-100 rounded-full w-12 h-12 mx-auto mb-3">
                                <svg class="h-6 w-6 text-green-600 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                            </div>
                            <p class="text-sm font-medium text-gray-900 dark:text-white">All caught up!</p>
                            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">No pending contact messages</p>
                        </div>
                    @endforelse
                </div>
                @if(\App\Models\Contact::where('is_read', false)->count() > 0)
                    <div class="bg-gray-50 dark:bg-gray-900 px-6 py-3 border-t border-gray-100 dark:border-gray-700">
                        <a href="{{ route('admin.contacts.index') }}" class="text-sm text-blue-600 hover:text-blue-500 font-medium flex items-center">
                            View all contacts
                            <svg class="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                            </svg>
                        </a>
                    </div>
                @endif
            </div>

            <!-- Quick Actions -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700 overflow-hidden">
                <div class="bg-gradient-to-r from-purple-500 to-indigo-600 px-6 py-4">
                    <h3 class="text-lg font-semibold text-white flex items-center">
                        <i class="fas fa-bolt mr-2"></i>
                        Quick Actions
                    </h3>
                    <p class="text-white text-sm mt-1">Common tasks to get you started</p>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 gap-4">
                        <a href="{{ route('admin.pages.create') }}" class="group p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200">
                            <div class="flex items-center space-x-3">
                                <div class="p-2 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors duration-200">
                                    <svg class="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white group-hover:text-blue-900">Create Page</p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Add a new page to your website</p>
                                </div>
                            </div>
                        </a>

                        <a href="{{ route('admin.services.create') }}" class="group p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all duration-200">
                            <div class="flex items-center space-x-3">
                                <div class="p-2 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors duration-200">
                                    <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white group-hover:text-green-900">Add Service</p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Create a new service offering</p>
                                </div>
                            </div>
                        </a>

                        <a href="{{ route('admin.blogs.create') }}" class="group p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-all duration-200">
                            <div class="flex items-center space-x-3">
                                <div class="p-2 bg-purple-100 rounded-lg group-hover:bg-purple-200 transition-colors duration-200">
                                    <svg class="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white group-hover:text-purple-900">Write Blog Post</p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Publish insights and updates</p>
                                </div>
                            </div>
                        </a>

                        <a href="{{ route('admin.projects.create') }}" class="group p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all duration-200">
                            <div class="flex items-center space-x-3">
                                <div class="p-2 bg-indigo-100 rounded-lg group-hover:bg-indigo-200 transition-colors duration-200">
                                    <svg class="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v4a1 1 0 001 1h3v6h8v-6h3a1 1 0 001-1V7M8 3h8v4H8V3z"/>
                                    </svg>
                                </div>
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white group-hover:text-indigo-900">Create Project</p>
                                    <p class="text-sm text-gray-500 dark:text-gray-400">Add a new project to your portfolio</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
