<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" x-data="{ darkMode: false }" 
      x-init="
        darkMode = localStorage.getItem('darkMode') === 'true' || (!localStorage.getItem('darkMode') && window.matchMedia('(prefers-color-scheme: dark)').matches);
        $watch('darkMode', val => {
            localStorage.setItem('darkMode', val);
            if (val) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        });
        if (darkMode) {
            document.documentElement.classList.add('dark');
        }
      "
      :class="{ 'dark': darkMode }">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- Cache Control - Force reload on theme changes -->
    @php
        $themeVersion = md5(setting('primary_color', '#3b82f6') . setting('secondary_color', '#8b5cf6') . setting('accent_color', '#10b981'));
    @endphp
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="theme-version" content="{{ $themeVersion }}">

    <title>{{ config('app.name', 'SEVLENT CMS') }} - @yield('title', 'Admin Dashboard')</title>

    <!-- Favicons -->
    @php
        $favicon = setting('favicon') ? asset('storage/' . setting('favicon')) : asset('favicon.ico');
    @endphp
    <link rel="icon" type="image/x-icon" href="{{ $favicon }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ $favicon }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ $favicon }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ $favicon }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <!-- Theme Styles -->
    @include('components.theme-styles')

    <!-- Custom Styles -->
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="font-sans antialiased bg-gray-100 dark:bg-gray-800 transition-colors duration-200" x-data="{ sidebarOpen: false, sidebarCollapsed: false }">
    <!-- Mobile sidebar backdrop -->
    <div x-show="sidebarOpen" @click="sidebarOpen = false" class="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 md:hidden" x-transition:enter="transition-opacity ease-linear duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition-opacity ease-linear duration-300" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"></div>

    <!-- Sidebar -->
    @include('admin.layouts.sidebar')

    <!-- Main Content -->
    <div :class="sidebarCollapsed ? 'md:ml-16' : 'md:ml-64'" class="flex flex-col min-h-screen transition-all duration-300 ease-in-out">
        <!-- Topbar -->
        @include('admin.layouts.topbar')

        <!-- Page Content -->
        <main class="flex-1 overflow-y-auto bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 pt-20 pb-6 px-4 md:px-6 transition-colors duration-200">
            @yield('content')
        </main>
    </div>

    <!-- Flash Messages -->
    @if (session('success'))
        <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 5000)"
             class="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 5000)"
             class="fixed bottom-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {{ session('error') }}
        </div>
    @endif

    <!-- Custom Delete Confirmation Modal -->
    <div x-data="deleteConfirmationModal()" x-show="showModal" x-cloak
         class="fixed inset-0 z-50 overflow-y-auto"
         aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <!-- Background overlay -->
            <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" class="fixed inset-0 bg-gray-50 dark:bg-gray-9000 bg-opacity-75 transition-opacity" @click="cancelDelete()" aria-hidden="true"></div>

            <!-- Modal panel -->
            <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100" x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" class="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-red-100 dark:bg-red-900/30 sm:mx-0 sm:h-10 sm:w-10">
                            <i class="fas fa-exclamation-triangle text-red-600 dark:text-red-400"></i>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white" id="modal-title">
                                Confirm Deletion
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500 dark:text-gray-400" x-text="message">
                                    Are you sure you want to delete this item?
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-900 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="button" @click="confirmDelete()" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-900 sm:ml-3 sm:w-auto sm:text-sm">
                        <i class="fas fa-trash mr-2"></i>Delete
                    </button>
                    <button type="button" @click="cancelDelete()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 dark:border-gray-600 shadow-sm px-4 py-2 bg-white dark:bg-gray-800 text-base font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-900 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Custom Toggle Confirmation Modal -->
    <div x-data="toggleConfirmationModal()" x-show="showModal" x-cloak
         class="fixed inset-0 z-50 overflow-y-auto"
         aria-labelledby="toggle-modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <!-- Background overlay -->
            <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="cancelToggle()" aria-hidden="true"></div>

            <!-- Modal panel -->
            <div x-show="showModal" x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100" x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100" x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95" class="inline-block align-bottom bg-white dark:bg-gray-800 rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white dark:bg-gray-800 px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div class="sm:flex sm:items-start">
                        <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/30 sm:mx-0 sm:h-10 sm:w-10" :class="isDisabling ? 'bg-yellow-100 dark:bg-yellow-900/30' : 'bg-green-100 dark:bg-green-900/30'">
                            <i class="fas fa-toggle-on text-blue-600 dark:text-blue-400" :class="isDisabling ? 'text-yellow-600 dark:text-yellow-400' : 'text-green-600 dark:text-green-400'"></i>
                        </div>
                        <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                            <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white" id="toggle-modal-title" x-text="title">
                                Confirm Action
                            </h3>
                            <div class="mt-2">
                                <p class="text-sm text-gray-500 dark:text-gray-400" x-text="message">
                                    Are you sure you want to perform this action?
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 dark:bg-gray-900 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="button" @click="confirmToggle()" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 text-base font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-gray-900 sm:ml-3 sm:w-auto sm:text-sm" :class="confirmButtonClass">
                        <i class="fas mr-2" :class="confirmButtonIcon"></i>
                        <span x-text="confirmButtonText">Confirm</span>
                    </button>
                    <button type="button" @click="cancelToggle()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 dark:border-gray-600 shadow-sm px-4 py-2 bg-white dark:bg-gray-800 text-base font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-900 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
    function deleteConfirmationModal() {
        return {
            showModal: false,
            message: 'Are you sure you want to delete this item?',
            onConfirm: null,
            onCancel: null,

            show(message, onConfirm, onCancel = null) {
                this.message = message;
                this.onConfirm = onConfirm;
                this.onCancel = onCancel;
                this.showModal = true;
            },

            confirmDelete() {
                if (this.onConfirm) {
                    this.onConfirm();
                }
                this.showModal = false;
            },

            cancelDelete() {
                if (this.onCancel) {
                    this.onCancel();
                }
                this.showModal = false;
            }
        }
    }

    function toggleConfirmationModal() {
        return {
            showModal: false,
            title: 'Confirm Action',
            message: 'Are you sure you want to perform this action?',
            isDisabling: false,
            onConfirm: null,
            onCancel: null,

            show(title, message, isDisabling, onConfirm, onCancel = null) {
                this.title = title;
                this.message = message;
                this.isDisabling = isDisabling;
                this.onConfirm = onConfirm;
                this.onCancel = onCancel;
                this.showModal = true;
            },

            confirmToggle() {
                if (this.onConfirm) {
                    this.onConfirm();
                }
                this.showModal = false;
            },

            cancelToggle() {
                if (this.onCancel) {
                    this.onCancel();
                }
                this.showModal = false;
            },

            get confirmButtonClass() {
                return this.isDisabling
                    ? 'bg-yellow-600 hover:bg-yellow-700 focus:ring-yellow-500'
                    : 'bg-green-600 hover:bg-green-700 focus:ring-green-500';
            },

            get confirmButtonIcon() {
                return this.isDisabling ? 'fa-pause' : 'fa-play';
            },

            get confirmButtonText() {
                return this.isDisabling ? 'Disable' : 'Enable';
            }
        }
    }

    // Global function to show delete confirmation
    window.showDeleteConfirmation = function(message, onConfirm, onCancel = null) {
        const modal = document.querySelector('[x-data*="deleteConfirmationModal"]')._x_dataStack[0];
        modal.show(message, onConfirm, onCancel);
    };

    // Global function to show toggle confirmation
    window.showToggleConfirmation = function(title, message, isDisabling, onConfirm, onCancel = null) {
        const modal = document.querySelector('[x-data*="toggleConfirmationModal"]')._x_dataStack[0];
        modal.show(title, message, isDisabling, onConfirm, onCancel);
    };

    // Auto-reload on theme change detection
    (function() {
        const themeStyleElement = document.querySelector('style[data-theme-hash]');
        const currentThemeHash = themeStyleElement?.dataset.themeHash;
        const currentTimestamp = themeStyleElement?.dataset.timestamp;
        
        if (currentThemeHash) {
            const storedHash = localStorage.getItem('theme_hash');
            const storedTimestamp = localStorage.getItem('theme_timestamp');
            
            // If hash changed, force complete reload
            if (storedHash && storedHash !== currentThemeHash) {
                console.log('Theme changed detected - forcing reload...');
                // Clear all cached data
                if ('caches' in window) {
                    caches.keys().then(names => {
                        names.forEach(name => caches.delete(name));
                    });
                }
                // Update storage
                localStorage.setItem('theme_hash', currentThemeHash);
                localStorage.setItem('theme_timestamp', currentTimestamp);
                // Force hard reload with cache bypass
                window.location.href = window.location.href.split('?')[0] + '?t=' + currentTimestamp;
                return;
            }
            
            // Store current hash
            localStorage.setItem('theme_hash', currentThemeHash);
            localStorage.setItem('theme_timestamp', currentTimestamp);
            
            // Check for theme updates every 3 seconds
            let checkInterval = setInterval(function() {
                fetch(window.location.href.split('?')[0] + '?check=' + Date.now(), { 
                    cache: 'no-store',
                    headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
                })
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newStyleElement = doc.querySelector('style[data-theme-hash]');
                    const newHash = newStyleElement?.dataset.themeHash;
                    const newTimestamp = newStyleElement?.dataset.timestamp;
                    
                    if (newHash && newHash !== currentThemeHash) {
                        console.log('Theme update detected - reloading now...');
                        clearInterval(checkInterval);
                        // Clear all caches
                        if ('caches' in window) {
                            caches.keys().then(names => {
                                names.forEach(name => caches.delete(name));
                            });
                        }
                        localStorage.setItem('theme_hash', newHash);
                        localStorage.setItem('theme_timestamp', newTimestamp);
                        // Force complete reload
                        window.location.href = window.location.href.split('?')[0] + '?t=' + newTimestamp;
                    }
                })
                .catch(err => console.log('Theme check error:', err));
            }, 3000); // Check every 3 seconds
        }
    })();
    </script>

    @stack('scripts')
</body>
</html>
