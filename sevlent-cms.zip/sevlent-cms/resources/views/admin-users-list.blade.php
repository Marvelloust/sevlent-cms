{{-- Admin Users List (Development Only) --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Users - Development</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="max-w-4xl mx-auto py-12 px-4">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-8">Available Admin Users</h1>
            <p class="text-gray-600 mb-6">Click on any admin user below to log in automatically (development only).</p>

            <div class="space-y-4">
                @forelse($admins as $admin)
                <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900">{{ $admin->name }}</h3>
                            <p class="text-gray-600">{{ $admin->email }}</p>
                            <div class="mt-2 flex flex-wrap gap-2">
                                @foreach($admin->roles as $role)
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                    @if($role->name === 'super_admin') bg-red-100 text-red-800
                                    @elseif($role->name === 'admin') bg-blue-100 text-blue-800
                                    @else bg-gray-100 text-gray-800 @endif">
                                    {{ $role->name }}
                                </span>
                                @endforeach
                            </div>
                        </div>
                        <a href="{{ route('login') }}?email={{ $admin->email }}"
                           class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                            Login as {{ $admin->name }}
                        </a>
                    </div>
                </div>
                @empty
                <div class="text-center py-8">
                    <p class="text-gray-500">No admin users found.</p>
                </div>
                @endforelse
            </div>

            <div class="mt-8 pt-6 border-t border-gray-200">
                <p class="text-sm text-gray-500">
                    <strong>Note:</strong> This page is for development purposes only and should be removed in production.
                </p>
            </div>
        </div>
    </div>
</body>
</html>