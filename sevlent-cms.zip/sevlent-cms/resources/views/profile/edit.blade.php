@extends('admin.layouts.app')

@section('title', 'Profile')
@section('page-title', 'Your Profile')

@section('content')
<div class="space-y-8">
    <!-- Header -->
    <div class="bg-gradient-to-r from-indigo-600 to-blue-600 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-white mb-2">
                        <i class="fas fa-user-circle mr-3"></i>Your Profile
                    </h1>
                    <p class="text-white">Manage your account information, password, and security settings.</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center px-6 py-3 bg-white/20 text-white font-semibold rounded-lg shadow-md hover:bg-white/30 transition-all duration-200 backdrop-blur-sm">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Profile Info -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-id-badge mr-2 text-indigo-600"></i>Profile Information
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Update your profile name and email address.</p>
        </div>
        <div class="px-6 py-6">
            @include('profile.partials.update-profile-information-form')
        </div>
    </div>

    <!-- Password -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-lock mr-2 text-indigo-600"></i>Security
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Change your account password.</p>
        </div>
        <div class="px-6 py-6">
            @include('profile.partials.update-password-form')
        </div>
    </div>

    <!-- Delete Account -->
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                <i class="fas fa-trash-alt mr-2 text-red-600"></i>Danger Zone
            </h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Permanently delete your account and all associated data.</p>
        </div>
        <div class="px-6 py-6">
            @include('profile.partials.delete-user-form')
        </div>
    </div>
</div>
@endsection
