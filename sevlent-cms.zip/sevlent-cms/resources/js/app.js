import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

// Testimonials Carousel Functionality
document.addEventListener('DOMContentLoaded', function() {
    const carouselIndicators = document.querySelectorAll('.carousel-indicator');
    const carouselContainer = document.querySelector('.overflow-x-auto');

    if (carouselIndicators.length > 0 && carouselContainer) {
        // Add click event to indicators
        carouselIndicators.forEach((indicator, index) => {
            indicator.addEventListener('click', function() {
                // Calculate scroll position (320px card width + 24px gap)
                const scrollPosition = index * 344; // 320px + 24px gap

                // Smooth scroll to the position
                carouselContainer.scrollTo({
                    left: scrollPosition,
                    behavior: 'smooth'
                });

                // Update active indicator
                updateActiveIndicator(index);
            });
        });

        // Update active indicator based on scroll position
        function updateActiveIndicator(activeIndex) {
            carouselIndicators.forEach((indicator, index) => {
                if (index === activeIndex) {
                    indicator.classList.remove('bg-gray-300');
                    indicator.classList.add('bg-purple-500');
                } else {
                    indicator.classList.remove('bg-purple-500');
                    indicator.classList.add('bg-gray-300');
                }
            });
        }

        // Listen for scroll events to update indicators
        carouselContainer.addEventListener('scroll', function() {
            const scrollLeft = carouselContainer.scrollLeft;
            const cardWidth = 344; // 320px + 24px gap
            const activeIndex = Math.round(scrollLeft / cardWidth);

            updateActiveIndicator(activeIndex);
        });

        // Set initial active indicator
        updateActiveIndicator(0);
    }
});
