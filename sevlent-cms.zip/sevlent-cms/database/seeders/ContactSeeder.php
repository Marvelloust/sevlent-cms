<?php

namespace Database\Seeders;

use App\Models\Contact;
use Illuminate\Database\Seeder;

class ContactSeeder extends Seeder
{
    public function run(): void
    {
        // Contact 1
        Contact::create([
            'name' => 'Sarah Johnson',
            'email' => 'sarah.johnson@techstartup.com',
            'phone' => '+1 (555) 123-4567',
            'subject' => 'Custom CMS Development Inquiry',
            'message' => 'Hi, I\'m interested in learning more about your custom CMS development services. We\'re a growing tech startup looking to build a scalable content management system for our blog and documentation.',
            'is_read' => false
        ]);

        // Contact 2
        Contact::create([
            'name' => 'Michael Chen',
            'email' => 'm.chen@retailcorp.com',
            'phone' => '+1 (555) 234-5678',
            'subject' => 'E-commerce Platform Consultation',
            'message' => 'We need to modernize our existing e-commerce platform. Looking for a comprehensive solution with multi-vendor support and advanced analytics.',
            'is_read' => true
        ]);

        // Contact 3
        Contact::create([
            'name' => 'Emily Rodriguez',
            'email' => 'emily@healthclinic.org',
            'phone' => '+1 (555) 345-6789',
            'subject' => 'Healthcare Management System',
            'message' => 'Our clinic is looking for a HIPAA-compliant patient management system with appointment scheduling and billing integration.',
            'is_read' => false
        ]);

        // Contact 4
        Contact::create([
            'name' => 'David Thompson',
            'email' => 'd.thompson@fintech.com',
            'phone' => '+1 (555) 456-7890',
            'subject' => 'Investment Platform Development',
            'message' => 'We need a secure investment management platform with real-time data integration and advanced reporting capabilities.',
            'is_read' => true
        ]);

        // Contact 5
        Contact::create([
            'name' => 'Lisa Wang',
            'email' => 'lisa.wang@university.edu',
            'phone' => '+1 (555) 567-8901',
            'subject' => 'Online Learning Platform',
            'message' => 'The university is interested in developing a comprehensive online learning platform with course management and student progress tracking.',
            'is_read' => false
        ]);

        // Contact 6
        Contact::create([
            'name' => 'Robert Martinez',
            'email' => 'r.martinez@realestate.com',
            'phone' => '+1 (555) 678-9012',
            'subject' => 'Real Estate Platform',
            'message' => 'We want to create a modern real estate platform with property listings, search filters, and virtual tour integration.',
            'is_read' => true
        ]);

        // Contact 7
        Contact::create([
            'name' => 'Jennifer Lee',
            'email' => 'j.lee@smartcity.gov',
            'phone' => '+1 (555) 789-0123',
            'subject' => 'IoT Monitoring System',
            'message' => 'The city is planning to implement an IoT-based environmental monitoring system for air quality and traffic management.',
            'is_read' => false
        ]);

        // Contact 8
        Contact::create([
            'name' => 'Kevin Brown',
            'email' => 'kevin@startup.io',
            'phone' => '+1 (555) 890-1234',
            'subject' => 'Mobile App Development',
            'message' => 'Looking to develop a cross-platform mobile application for our service-based business with real-time features.',
            'is_read' => true
        ]);

        // Contact 9
        Contact::create([
            'name' => 'Amanda Wilson',
            'email' => 'a.wilson@marketingagency.com',
            'phone' => '+1 (555) 901-2345',
            'subject' => 'Digital Marketing Website',
            'message' => 'Our agency needs a modern website with portfolio showcase, blog integration, and lead generation forms.',
            'is_read' => false
        ]);

        // Contact 10
        Contact::create([
            'name' => 'Carlos Garcia',
            'email' => 'carlos@logistics.com',
            'phone' => '+1 (555) 012-3456',
            'subject' => 'Logistics Management System',
            'message' => 'We need a comprehensive logistics management system with route optimization, inventory tracking, and real-time updates.',
            'is_read' => true
        ]);

        // Contact 11
        Contact::create([
            'name' => 'Rachel Kim',
            'email' => 'r.kim@restaurant.com',
            'phone' => '+1 (555) 123-4567',
            'subject' => 'Restaurant Management System',
            'message' => 'Looking for a POS system with online ordering, table reservations, and inventory management for our restaurant chain.',
            'is_read' => false
        ]);

        // Contact 12
        Contact::create([
            'name' => 'Thomas Anderson',
            'email' => 't.anderson@construction.com',
            'phone' => '+1 (555) 234-5678',
            'subject' => 'Construction Project Management',
            'message' => 'We need a project management platform for construction companies with timeline tracking, resource allocation, and document management.',
            'is_read' => true
        ]);
    }
}