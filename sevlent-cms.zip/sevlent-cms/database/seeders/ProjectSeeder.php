<?php

namespace Database\Seeders;

use App\Models\Project;
use App\Models\SeoMetadata;
use Illuminate\Database\Seeder;

class ProjectSeeder extends Seeder
{
    public function run(): void
    {
        // E-commerce Platform Project
        $project1 = Project::updateOrCreate(
            ['slug' => 'techstore-ecommerce-platform'],
            [
                'title' => 'TechStore - Enterprise E-commerce Platform',
                'slug' => 'techstore-ecommerce-platform',
                'description' => 'A comprehensive e-commerce platform built for TechStore, featuring advanced product catalog management, multi-vendor support, and integrated payment processing. Built using Laravel backend, React frontend, MySQL database, Redis caching, Stripe payments, and AWS hosting.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Project Overview',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'TechStore needed a scalable e-commerce solution to handle their growing product catalog and customer base. We developed a custom platform with advanced features including multi-vendor support, real-time inventory management, and comprehensive analytics.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Key Features',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Multi-vendor marketplace functionality
Real-time inventory tracking across warehouses
Integrated payment processing with Stripe
Advanced product search and filtering
Customer review and rating system
Automated email marketing campaigns
Admin dashboard with analytics'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Results',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => '300% increase in online sales within 6 months, 50% reduction in cart abandonment rate, and improved customer satisfaction scores.'
                    ]
                ],
                'technologies' => ['Laravel', 'React', 'MySQL', 'Redis', 'Stripe', 'AWS'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project1->id],
            [
                'meta_title' => 'TechStore E-commerce Platform - SEVLENT Case Study',
                'meta_description' => 'Discover how we built a scalable e-commerce platform for TechStore using Laravel, React, and modern cloud technologies.',
                'meta_keywords' => 'e-commerce, Laravel, React, case study, online store',
                'canonical_url' => '/projects/techstore-ecommerce-platform',
                'og_title' => 'TechStore E-commerce Platform - SEVLENT Case Study',
                'og_description' => 'Scalable e-commerce platform built with Laravel and React.',
                'og_image' => null
            ]
        );

        // Healthcare Management System Project
        $project2 = Project::updateOrCreate(
            ['slug' => 'medicare-health-management-system'],
            [
                'title' => 'MediCare - Healthcare Management System',
                'slug' => 'medicare-health-management-system',
                'description' => 'A comprehensive healthcare management system for clinics and hospitals, featuring patient records, appointment scheduling, and medical billing integration. Built with Node.js microservices, React frontend, PostgreSQL database, and deployed on Kubernetes.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Project Challenge',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'MediCare clinics needed a HIPAA-compliant system to manage patient records, appointments, and billing across multiple locations while ensuring data security and system reliability.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Solution Delivered',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Electronic Health Records (EHR) system
Appointment scheduling with automated reminders
Medical billing and insurance claims processing
Prescription management
Patient portal for online access
HIPAA-compliant data encryption
Multi-location support with centralized data'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Impact',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Reduced administrative overhead by 40%, improved patient satisfaction scores by 35%, and streamlined billing processes to reduce claim errors by 60%.'
                    ]
                ],
                'technologies' => ['Node.js', 'React', 'PostgreSQL', 'GraphQL', 'Docker', 'Kubernetes'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project2->id],
            [
                'meta_title' => 'MediCare Healthcare Management System - Case Study',
                'meta_description' => 'Learn how we built a HIPAA-compliant healthcare management system using modern microservices architecture.',
                'meta_keywords' => 'healthcare software, EHR, patient management, Node.js, microservices',
                'canonical_url' => '/projects/medicare-health-management-system',
                'og_title' => 'MediCare Healthcare Management System - Case Study',
                'og_description' => 'HIPAA-compliant healthcare management system with microservices.',
                'og_image' => null
            ]
        );

        // Financial Services Platform Project
        $project3 = Project::updateOrCreate(
            ['slug' => 'fintech-investment-platform'],
            [
                'title' => 'FinTech - Investment Management Platform',
                'slug' => 'fintech-investment-platform',
                'description' => 'A secure investment management platform for wealth management firms, featuring portfolio tracking, risk analysis, and client reporting capabilities. Built with Python Django, React frontend, PostgreSQL database, and real-time WebSocket connections.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Project Scope',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'A leading investment firm needed a sophisticated platform to manage client portfolios, track market data in real-time, and generate comprehensive investment reports.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Technical Implementation',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Real-time market data integration via WebSockets
Portfolio performance analytics and reporting
Risk assessment and modeling tools
Automated compliance reporting
Client portal with secure document sharing
Multi-factor authentication and encryption
Automated trading execution (optional)'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Business Outcome',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Enabled management of $500M+ in assets, reduced reporting time by 70%, and improved client engagement through enhanced portal features.'
                    ]
                ],
                'technologies' => ['Python', 'Django', 'PostgreSQL', 'React', 'WebSocket', 'AWS'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project3->id],
            [
                'meta_title' => 'FinTech Investment Platform - SEVLENT Portfolio',
                'meta_description' => 'Explore our secure investment management platform built with Python Django and React for wealth management firms.',
                'meta_keywords' => 'fintech, investment platform, portfolio management, Python, Django',
                'canonical_url' => '/projects/fintech-investment-platform',
                'og_title' => 'FinTech Investment Platform - SEVLENT Portfolio',
                'og_description' => 'Secure investment management platform for wealth management firms.',
                'og_image' => null
            ]
        );

        // Education Platform Project
        $project4 = Project::updateOrCreate(
            ['slug' => 'learnify-education-platform'],
            [
                'title' => 'Learnify - Online Learning Platform',
                'slug' => 'learnify-education-platform',
                'description' => 'A comprehensive online learning platform with course management, video streaming, progress tracking, and certification features. Built with Laravel backend, Vue.js frontend, MySQL database, and AWS S3 for video storage.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'About the Project',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Learnify needed a scalable platform to deliver online courses to thousands of students worldwide, with features for course creation, video hosting, and student progress tracking.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Platform Features',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Course creation and management system
Video streaming with adaptive bitrate
Interactive quizzes and assessments
Student progress tracking and analytics
Discussion forums and Q&A
Certificate generation upon completion
Payment integration for course purchases
Mobile-responsive design'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Success Metrics',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => '10,000+ active students, 500+ courses published, 85% course completion rate, and 4.8/5 average platform rating.'
                    ]
                ],
                'technologies' => ['Laravel', 'Vue.js', 'MySQL', 'AWS S3', 'Redis', 'Docker'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project4->id],
            [
                'meta_title' => 'Learnify Online Learning Platform - Case Study',
                'meta_description' => 'See how we built a comprehensive e-learning platform with video streaming and course management using Laravel and Vue.js.',
                'meta_keywords' => 'e-learning, online courses, education platform, Laravel, Vue.js',
                'canonical_url' => '/projects/learnify-education-platform',
                'og_title' => 'Learnify Online Learning Platform - Case Study',
                'og_description' => 'Comprehensive e-learning platform with video streaming and course management.',
                'og_image' => null
            ]
        );

        // Real Estate Platform Project
        $project5 = Project::updateOrCreate(
            ['slug' => 'propertyfinder-real-estate-platform'],
            [
                'title' => 'PropertyFinder - Real Estate Management Platform',
                'slug' => 'propertyfinder-real-estate-platform',
                'description' => 'A modern real estate platform with property listings, search filters, virtual tours, and agent management. Features advanced search algorithms, map integration, and automated valuation tools.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Project Overview',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'PropertyFinder needed a cutting-edge platform to showcase properties with virtual tours, provide advanced search capabilities, and connect buyers with agents.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Core Features',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Advanced property search with filters
Interactive map view with clustering
360° virtual tours integration
Agent profiles and messaging system
Automated property valuation estimates
Saved searches and email alerts
Mortgage calculator tools
Mobile app for iOS and Android'
                    ]
                ],
                'technologies' => ['Laravel', 'React', 'PostgreSQL', 'Google Maps API', 'AWS', 'Redis'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project5->id],
            [
                'meta_title' => 'PropertyFinder Real Estate Platform - Portfolio',
                'meta_description' => 'Discover our modern real estate platform with virtual tours, advanced search, and map integration.',
                'meta_keywords' => 'real estate software, property management, virtual tours, Laravel, React',
                'canonical_url' => '/projects/propertyfinder-real-estate-platform',
                'og_title' => 'PropertyFinder Real Estate Platform - Portfolio',
                'og_description' => 'Modern real estate platform with virtual tours and advanced search.',
                'og_image' => null
            ]
        );

        // IoT Monitoring System Project
        $project6 = Project::updateOrCreate(
            ['slug' => 'smartcity-iot-monitoring'],
            [
                'title' => 'SmartCity - IoT Environmental Monitoring',
                'slug' => 'smartcity-iot-monitoring',
                'description' => 'An IoT-based environmental monitoring system for smart cities, tracking air quality, traffic, and energy consumption. Built with Node.js backend, React dashboard, MongoDB database, and MQTT protocol for device communication.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Smart City Initiative',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'A municipal government needed a comprehensive IoTsystem to monitor environmental conditions, traffic patterns, and energy usage across the city in real-time.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'System Capabilities',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Real-time air quality monitoring
Traffic flow analysis and prediction
Energy consumption tracking
Automated alerts for threshold violations
Historical data analysis and reporting
Public dashboard for citizen access
Integration with city management systems
Scalable IoT device management'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Impact',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Improved air quality response time by 75%, optimized traffic management reducing congestion by 30%, and enabled data-driven city planning decisions.'
                    ]
                ],
                'technologies' => ['Node.js', 'React', 'MongoDB', 'MQTT', 'Docker', 'Kubernetes'],
                'status' => 'active'
            ]
        );

        SeoMetadata::updateOrCreate(
            ['seoable_type' => Project::class, 'seoable_id' => $project6->id],
            [
                'meta_title' => 'SmartCity IoT Monitoring System - Case Study',
                'meta_description' => 'Learn about our IoT environmental monitoring system for smart cities using Node.js, MongoDB, and MQTT.',
                'meta_keywords' => 'IoT, smart city, environmental monitoring, Node.js, MQTT',
                'canonical_url' => '/projects/smartcity-iot-monitoring',
                'og_title' => 'SmartCity IoT Monitoring System - Case Study',
                'og_description' => 'IoT environmental monitoring system for smart cities.',
                'og_image' => null
            ]
        );
    }
}