<?php

namespace Database\Seeders;

use App\Models\Page;
use App\Models\Section;
use App\Models\SeoMetadata;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get the first user to use as creator
        $user = \App\Models\User::first();
        if (!$user) {
            throw new \Exception('No users found. Please run UserSeeder first.');
        }

        // Create Home Page
        $homePage = Page::updateOrCreate(
            ['slug' => 'home'],
            [
                'title' => 'Home',
                'slug' => 'home',
                'content' => 'Welcome to SEVLENT Software Solutions - Your trusted partner in enterprise software development.',
                'status' => 'published',
                'order_index' => 1,
                'created_by' => $user->id
            ]
        );

        // Create SEO for Home Page
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Page::class, 'seoable_id' => $homePage->id],
            [
                'meta_title' => 'SEVLENT Software Solutions - Enterprise Software Development',
                'meta_description' => 'Leading enterprise software development company specializing in custom CMS, web applications, and digital solutions. Transform your business with our expert team.',
                'meta_keywords' => 'enterprise software, custom CMS, web development, digital solutions, software company',
                'canonical_url' => '/',
                'og_title' => 'SEVLENT Software Solutions - Enterprise Software Development',
                'og_description' => 'Leading enterprise software development company specializing in custom CMS, web applications, and digital solutions.',
                'og_image' => null
            ]
        );

        // Create Hero Section
        Section::updateOrCreate(
            ['page_id' => $homePage->id, 'type' => 'hero'],
            [
                'title' => 'Welcome to SEVLENT',
                'content' => '',
                'data' => [
                    'headline' => 'Transforming Businesses Through Innovative Software Solutions',
                    'subheadline' => 'We specialize in enterprise-grade content management systems, custom web applications, and digital transformation solutions that drive growth and efficiency.',
                    'button_text' => 'Start Your Project',
                    'button_url' => '/contact',
                    'background_image' => null
                ],
                'order_index' => 1,
                'is_active' => true
            ]
        );

        // Create About Section
        Section::updateOrCreate(
            ['page_id' => $homePage->id, 'type' => 'about'],
            [
                'title' => 'About SEVLENT Software Solutions',
                'content' => '<p>SEVLENT Software Solutions is a premier enterprise software development company founded in 2020. We specialize in creating scalable, secure, and innovative digital solutions that help businesses thrive in the modern digital landscape.</p><p>Our team of expert developers, designers, and strategists work closely with clients to understand their unique challenges and deliver tailored solutions that exceed expectations. From custom content management systems to complex enterprise applications, we have the expertise to bring your vision to life.</p><p>With a focus on cutting-edge technologies, agile development methodologies, and exceptional customer service, SEVLENT has become a trusted partner for businesses seeking digital transformation.</p>',
                'data' => [
                    'image' => null,
                    'stats' => [
                        ['label' => 'Years Experience', 'value' => '4+'],
                        ['label' => 'Projects Completed', 'value' => '150+'],
                        ['label' => 'Happy Clients', 'value' => '95%'],
                        ['label' => 'Team Members', 'value' => '25+']
                    ]
                ],
                'order_index' => 2,
                'is_active' => true
            ]
        );

        // Create Services Preview Section
        Section::updateOrCreate(
            ['page_id' => $homePage->id, 'type' => 'services'],
            [
                'title' => 'Our Core Services',
                'content' => '<p>We offer comprehensive software development services tailored to meet the unique needs of modern businesses. Our expertise spans across multiple domains, ensuring we can deliver the right solution for your specific requirements.</p>',
                'data' => [
                    'services' => [
                        [
                            'title' => 'Custom CMS Development',
                            'description' => 'Tailored content management systems built with scalability and user experience in mind.',
                            'icon' => 'fas fa-cogs'
                        ],
                        [
                            'title' => 'Web Application Development',
                            'description' => 'Modern, responsive web applications using the latest technologies and frameworks.',
                            'icon' => 'fas fa-globe'
                        ],
                        [
                            'title' => 'E-commerce Solutions',
                            'description' => 'Complete e-commerce platforms with payment integration and inventory management.',
                            'icon' => 'fas fa-shopping-cart'
                        ],
                        [
                            'title' => 'Mobile App Development',
                            'description' => 'Native and cross-platform mobile applications for iOS and Android devices.',
                            'icon' => 'fas fa-mobile-alt'
                        ]
                    ]
                ],
                'order_index' => 3,
                'is_active' => true
            ]
        );

        // Create Testimonials Section
        Section::updateOrCreate(
            ['page_id' => $homePage->id, 'type' => 'testimonials'],
            [
                'title' => 'What Our Clients Say',
                'content' => '',
                'data' => [
                    'testimonials' => [
                        [
                            'name' => 'Sarah Johnson',
                            'position' => 'CEO, TechStart Inc.',
                            'company' => 'TechStart Inc.',
                            'content' => 'SEVLENT delivered exactly what we needed - a robust CMS that scales with our business. Their attention to detail and technical expertise is outstanding.',
                            'rating' => 5
                        ],
                        [
                            'name' => 'Michael Chen',
                            'position' => 'CTO, Global Solutions Ltd.',
                            'company' => 'Global Solutions Ltd.',
                            'content' => 'Working with SEVLENT was a game-changer for our digital transformation. They understood our complex requirements and delivered a solution that exceeded our expectations.',
                            'rating' => 5
                        ],
                        [
                            'name' => 'Emily Rodriguez',
                            'position' => 'Marketing Director, Innovate Corp.',
                            'company' => 'Innovate Corp.',
                            'content' => 'The team at SEVLENT is professional, responsive, and truly cares about delivering quality work. Our new website has significantly improved our online presence.',
                            'rating' => 5
                        ]
                    ]
                ],
                'order_index' => 4,
                'is_active' => true
            ]
        );

        // Create CTA Section
        Section::updateOrCreate(
            ['page_id' => $homePage->id, 'type' => 'cta'],
            [
                'title' => 'Ready to Transform Your Business?',
                'content' => '',
                'data' => [
                    'headline' => 'Let\'s Build Something Amazing Together',
                    'subheadline' => 'Ready to take your business to the next level? Contact us today for a free consultation and discover how we can help you achieve your digital goals.',
                    'button_text' => 'Get Free Consultation',
                    'button_url' => '/contact',
                    'secondary_button_text' => 'View Our Work',
                    'secondary_button_url' => '/projects'
                ],
                'order_index' => 5,
                'is_active' => true
            ]
        );

        // Create About Page
        $aboutPage = Page::updateOrCreate(
            ['slug' => 'about'],
            [
                'title' => 'About Us',
                'slug' => 'about',
                'content' => 'Learn more about SEVLENT Software Solutions and our mission to deliver exceptional software development services.',
                'status' => 'published',
                'order_index' => 2,
                'created_by' => $user->id
            ]
        );

        // Create SEO for About Page
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Page::class, 'seoable_id' => $aboutPage->id],
            [
                'meta_title' => 'About Us - SEVLENT Software Solutions',
                'meta_description' => 'Learn about SEVLENT Software Solutions, our mission, values, and the expert team behind our enterprise software development services.',
                'meta_keywords' => 'about us, company, mission, values, software development team',
                'canonical_url' => '/about',
                'og_title' => 'About Us - SEVLENT Software Solutions',
                'og_description' => 'Learn about our mission to deliver exceptional software solutions.',
                'og_image' => null
            ]
        );

        // Create About Page Content Section
        Section::updateOrCreate(
            ['page_id' => $aboutPage->id, 'type' => 'content'],
            [
                'title' => 'Our Story',
                'content' => '<h2>Our Mission</h2><p>At SEVLENT Software Solutions, our mission is to empower businesses with cutting-edge technology solutions that drive growth, efficiency, and innovation. We believe that great software can transform how businesses operate and serve their customers.</p><h2>Our Vision</h2><p>To be the leading provider of enterprise software solutions, recognized for our commitment to quality, innovation, and customer success. We envision a world where businesses of all sizes can leverage technology to achieve their full potential.</p><h2>Our Values</h2><div class="grid md:grid-cols-2 gap-6 mt-6"><div><h3>Innovation</h3><p>We constantly explore new technologies and methodologies to deliver cutting-edge solutions that keep our clients ahead of the curve.</p></div><div><h3>Quality</h3><p>We maintain the highest standards in everything we do, from code quality to project delivery and customer service.</p></div><div><h3>Collaboration</h3><p>We believe in transparent communication and collaborative partnerships with our clients throughout the development process.</p></div><div><h3>Growth</h3><p>We are committed to continuous learning and improvement, both for our team and our clients\' businesses.</p></div></div>',
                'data' => [],
                'order_index' => 1,
                'is_active' => true
            ]
        );

        // Create Team Section
        Section::updateOrCreate(
            ['page_id' => $aboutPage->id, 'type' => 'team'],
            [
                'title' => 'Meet Our Team',
                'content' => '',
                'data' => [
                    'members' => [
                        [
                            'name' => 'John Smith',
                            'position' => 'CEO & Founder',
                            'bio' => 'With over 15 years in software development, John leads our vision and strategy.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/johnsmith',
                                'twitter' => 'https://twitter.com/johnsmith'
                            ]
                        ],
                        [
                            'name' => 'Sarah Davis',
                            'position' => 'CTO',
                            'bio' => 'Sarah oversees our technical architecture and ensures we use the best technologies.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/sarahdavis',
                                'github' => 'https://github.com/sarahdavis'
                            ]
                        ],
                        [
                            'name' => 'Mike Johnson',
                            'position' => 'Lead Developer',
                            'bio' => 'Mike specializes in full-stack development and leads our development team.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/mikejohnson',
                                'github' => 'https://github.com/mikejohnson'
                            ]
                        ],
                        [
                            'name' => 'Lisa Chen',
                            'position' => 'UI/UX Designer',
                            'bio' => 'Lisa creates beautiful, user-friendly interfaces that delight our users.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/lisachen',
                                'dribbble' => 'https://dribbble.com/lisachen'
                            ]
                        ]
                    ]
                ],
                'order_index' => 2,
                'is_active' => true
            ]
        );

        // Create Services Page
        $servicesPage = Page::updateOrCreate(
            ['slug' => 'services'],
            [
                'title' => 'Our Services',
                'slug' => 'services',
                'content' => 'Discover our comprehensive range of software development and digital solutions.',
                'status' => 'published',
                'order_index' => 3,
                'created_by' => $user->id
            ]
        );

        // Create SEO for Services Page
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Page::class, 'seoable_id' => $servicesPage->id],
            [
                'meta_title' => 'Our Services - Enterprise Software Development',
                'meta_description' => 'Explore our comprehensive software development services including custom CMS, web applications, mobile apps, and digital transformation solutions.',
                'meta_keywords' => 'services, software development, custom CMS, web applications, mobile apps',
                'canonical_url' => '/services',
                'og_title' => 'Our Services - SEVLENT Software Solutions',
                'og_description' => 'Explore our comprehensive software development services.',
                'og_image' => null
            ]
        );

        // Create Contact Page
        $contactPage = Page::updateOrCreate(
            ['slug' => 'contact'],
            [
                'title' => 'Contact Us',
                'slug' => 'contact',
                'content' => 'Get in touch with our team to discuss your project requirements.',
                'status' => 'published',
                'order_index' => 4,
                'created_by' => $user->id
            ]
        );

        // Create SEO for Contact Page
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Page::class, 'seoable_id' => $contactPage->id],
            [
                'meta_title' => 'Contact Us - Get Your Free Consultation',
                'meta_description' => 'Ready to start your project? Contact SEVLENT Software Solutions for a free consultation. We\'d love to discuss your requirements.',
                'meta_keywords' => 'contact, consultation, quote, project inquiry',
                'canonical_url' => '/contact',
                'og_title' => 'Contact Us - SEVLENT Software Solutions',
                'og_description' => 'Get in touch for a free consultation.',
                'og_image' => null
            ]
        );

        // Create Privacy Policy Page
        $privacyPage = Page::updateOrCreate(
            ['slug' => 'privacy-policy'],
            [
                'title' => 'Privacy Policy',
                'slug' => 'privacy-policy',
                'content' => 'Our privacy policy explains how we collect, use, and protect your personal information.',
                'status' => 'published',
                'order_index' => 5,
                'created_by' => $user->id
            ]
        );

        // Create Terms of Service Page
        $termsPage = Page::updateOrCreate(
            ['slug' => 'terms-of-service'],
            [
                'title' => 'Terms of Service',
                'slug' => 'terms-of-service',
                'content' => 'Please read our terms of service carefully before using our services.',
                'status' => 'published',
                'order_index' => 6,
                'created_by' => $user->id
            ]
        );
    }
}
