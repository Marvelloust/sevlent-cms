<?php

namespace Database\Seeders;

use App\Models\Career;
use App\Models\JobApplication;
use Illuminate\Database\Seeder;

class JobApplicationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get some careers
        $laravelDeveloper = Career::where('slug', 'senior-laravel-developer')->first();
        $reactDeveloper = Career::where('slug', 'react-frontend-developer')->first();
        $devopsEngineer = Career::where('slug', 'devops-engineer')->first();
        $uiDesigner = Career::where('slug', 'ui-ux-designer')->first();

        if ($laravelDeveloper) {
            // Application 1 for Laravel Developer
            JobApplication::updateOrCreate(
                ['email' => 'alex.martinez@example.com'],
                [
                    'career_id' => $laravelDeveloper->id,
                    'name' => 'Alex Martinez',
                    'email' => 'alex.martinez@example.com',
                    'phone' => '+1 (555) 987-6543',
                    'linkedin' => 'https://linkedin.com/in/alexmartinez',
                    'cover_letter' => 'I am excited to apply for the Senior Laravel Developer position at SEVLENT. With over 5 years of experience in Laravel development, I have successfully delivered multiple enterprise-level applications. My expertise includes building RESTful APIs, implementing complex business logic, and optimizing database performance. I am particularly impressed by your company\'s commitment to innovative solutions and would love to contribute to your team.',
                    'resume_path' => 'resumes/alex-martinez-resume.pdf',
                    'status' => 'reviewed',
                    'notes' => 'Strong Laravel background, good communication skills. Schedule for technical interview.'
                ]
            );

            // Application 2 for Laravel Developer
            JobApplication::updateOrCreate(
                ['email' => 'priya.sharma@example.com'],
                [
                    'career_id' => $laravelDeveloper->id,
                    'name' => 'Priya Sharma',
                    'email' => 'priya.sharma@example.com',
                    'phone' => '+1 (555) 876-5432',
                    'linkedin' => 'https://linkedin.com/in/priyasharma',
                    'cover_letter' => 'I am writing to express my interest in the Senior Laravel Developer role. I have been working with Laravel for 6+ years and have deep expertise in building scalable applications, implementing caching strategies, and maintaining clean, testable code. I am passionate about software architecture and best practices.',
                    'resume_path' => 'resumes/priya-sharma-resume.pdf',
                    'status' => 'pending',
                    'notes' => null
                ]
            );
        }

        if ($reactDeveloper) {
            // Application 1 for React Developer
            JobApplication::updateOrCreate(
                ['email' => 'james.wilson@example.com'],
                [
                    'career_id' => $reactDeveloper->id,
                    'name' => 'James Wilson',
                    'email' => 'james.wilson@example.com',
                    'phone' => '+1 (555) 765-4321',
                    'linkedin' => 'https://linkedin.com/in/jameswilson',
                    'cover_letter' => 'I am thrilled to apply for the React Frontend Developer position. With 4 years of experience building modern web applications using React, TypeScript, and Next.js, I have a proven track record of delivering high-quality user interfaces. I am particularly skilled in state management, performance optimization, and responsive design.',
                    'resume_path' => 'resumes/james-wilson-resume.pdf',
                    'status' => 'shortlisted',
                    'notes' => 'Excellent React skills, strong portfolio. Waiting for final decision.'
                ]
            );

            // Application 2 for React Developer
            JobApplication::updateOrCreate(
                ['email' => 'sophia.lee@example.com'],
                [
                    'career_id' => $reactDeveloper->id,
                    'name' => 'Sophia Lee',
                    'email' => 'sophia.lee@example.com',
                    'phone' => '+1 (555) 654-3210',
                    'linkedin' => 'https://linkedin.com/in/sophialee',
                    'cover_letter' => 'As a passionate frontend developer with 3+ years of React experience, I am excited about the opportunity to join SEVLENT. My experience includes building complex SPAs, implementing state management with Redux and Context API, and optimizing application performance. I stay current with the latest React features and best practices.',
                    'resume_path' => 'resumes/sophia-lee-resume.pdf',
                    'status' => 'pending',
                    'notes' => null
                ]
            );
        }

        if ($devopsEngineer) {
            // Application for DevOps Engineer
            JobApplication::updateOrCreate(
                ['email' => 'marcus.brown@example.com'],
                [
                    'career_id' => $devopsEngineer->id,
                    'name' => 'Marcus Brown',
                    'email' => 'marcus.brown@example.com',
                    'phone' => '+1 (555) 543-2109',
                    'linkedin' => 'https://linkedin.com/in/marcusbrown',
                    'cover_letter' => 'I am writing to apply for the DevOps Engineer position. With 5 years of experience in cloud infrastructure and CI/CD pipelines, I have successfully managed AWS environments, implemented containerization with Docker and Kubernetes, and automated deployment processes. I am passionate about infrastructure as code and continuous improvement.',
                    'resume_path' => 'resumes/marcus-brown-resume.pdf',
                    'status' => 'rejected',
                    'notes' => 'Strong technical skills but looking for more Kubernetes experience.'
                ]
            );
        }

        if ($uiDesigner) {
            // Application for UI/UX Designer
            JobApplication::updateOrCreate(
                ['email' => 'olivia.garcia@example.com'],
                [
                    'career_id' => $uiDesigner->id,
                    'name' => 'Olivia Garcia',
                    'email' => 'olivia.garcia@example.com',
                    'phone' => '+1 (555) 432-1098',
                    'linkedin' => 'https://linkedin.com/in/oliviagarcia',
                    'cover_letter' => 'I am excited to apply for the UI/UX Designer role at SEVLENT. With a strong portfolio of web and mobile app designs, I bring 4+ years of experience in creating user-centered designs that are both beautiful and functional. My expertise includes user research, wireframing, prototyping in Figma, and working collaboratively with development teams.',
                    'resume_path' => 'resumes/olivia-garcia-resume.pdf',
                    'status' => 'hired',
                    'notes' => 'Excellent portfolio and cultural fit. Offer accepted, starts next month.'
                ]
            );
        }

        // Additional random applications
        JobApplication::updateOrCreate(
            ['email' => 'ryan.patel@example.com'],
            [
                'career_id' => $laravelDeveloper?->id ?? 1,
                'name' => 'Ryan Patel',
                'email' => 'ryan.patel@example.com',
                'phone' => '+1 (555) 321-0987',
                'linkedin' => null,
                'cover_letter' => 'I am interested in joining your team as a Laravel developer. I have 2 years of experience working with PHP and Laravel framework.',
                'resume_path' => 'resumes/ryan-patel-resume.pdf',
                'status' => 'pending',
                'notes' => null
            ]
        );
    }
}
