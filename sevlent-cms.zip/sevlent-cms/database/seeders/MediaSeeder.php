<?php

namespace Database\Seeders;

use App\Models\Media;
use Illuminate\Database\Seeder;

class MediaSeeder extends Seeder
{
    public function run(): void
    {
        $mediaItems = [
            // Hero and Banner Images
            [
                'file_name' => 'hero-background.jpg',
                'file_path' => 'images/hero/hero-background.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 2048576,
                'alt_text' => 'Modern office workspace with computers and team collaboration',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'about-banner.jpg',
                'file_path' => 'images/banners/about-banner.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1843200,
                'alt_text' => 'About us banner showing professional team environment',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'services-banner.jpg',
                'file_path' => 'images/banners/services-banner.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1945600,
                'alt_text' => 'Our services - technology and innovation',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'contact-banner.jpg',
                'file_path' => 'images/banners/contact-banner.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1536000,
                'alt_text' => 'Contact us - Get in touch banner',
                'uploaded_by' => 1
            ],

            // About Images
            [
                'file_name' => 'about-team.jpg',
                'file_path' => 'images/about/about-team.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1536000,
                'alt_text' => 'SEVLENT development team working together',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'office-workspace.jpg',
                'file_path' => 'images/about/office-workspace.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1425920,
                'alt_text' => 'Modern office workspace environment',
                'uploaded_by' => 1
            ],

            // Service Icons
            [
                'file_name' => 'cms-icon.svg',
                'file_path' => 'images/services/icons/cms-icon.svg',
                'file_type' => 'image',
                'mime_type' => 'image/svg+xml',
                'file_size' => 5120,
                'alt_text' => 'Content Management System icon',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'web-app-icon.svg',
                'file_path' => 'images/services/icons/web-app-icon.svg',
                'file_type' => 'image',
                'mime_type' => 'image/svg+xml',
                'file_size' => 4800,
                'alt_text' => 'Web Application Development icon',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'ecommerce-icon.svg',
                'file_path' => 'images/services/icons/ecommerce-icon.svg',
                'file_type' => 'image',
                'mime_type' => 'image/svg+xml',
                'file_size' => 5200,
                'alt_text' => 'E-commerce Solutions icon',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'mobile-app-icon.svg',
                'file_path' => 'images/services/icons/mobile-app-icon.svg',
                'file_type' => 'image',
                'mime_type' => 'image/svg+xml',
                'file_size' => 4950,
                'alt_text' => 'Mobile App Development icon',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'digital-transform-icon.svg',
                'file_path' => 'images/services/icons/digital-transform-icon.svg',
                'file_type' => 'image',
                'mime_type' => 'image/svg+xml',
                'file_size' => 5400,
                'alt_text' => 'Digital Transformation icon',
                'uploaded_by' => 1
            ],

            // Project Screenshots
            [
                'file_name' => 'techstore-screenshot.jpg',
                'file_path' => 'images/projects/techstore-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1024000,
                'alt_text' => 'TechStore e-commerce platform screenshot',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'medicare-screenshot.jpg',
                'file_path' => 'images/projects/medicare-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 998400,
                'alt_text' => 'MediCare healthcare management system screenshot',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'fintech-screenshot.jpg',
                'file_path' => 'images/projects/fintech-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1126400,
                'alt_text' => 'FinTech investment platform screenshot',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'learnify-screenshot.jpg',
                'file_path' => 'images/projects/learnify-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1053696,
                'alt_text' => 'Learnify online learning platform screenshot',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'propertyfinder-screenshot.jpg',
                'file_path' => 'images/projects/propertyfinder-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1136640,
                'alt_text' => 'PropertyFinder real estate platform screenshot',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'smartcity-screenshot.jpg',
                'file_path' => 'images/projects/smartcity-screenshot.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 1089536,
                'alt_text' => 'SmartCity IoT monitoring dashboard screenshot',
                'uploaded_by' => 1
            ],

            // Blog Featured Images
            [
                'file_name' => 'web-dev-trends.jpg',
                'file_path' => 'images/blog/web-dev-trends.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 768000,
                'alt_text' => 'Modern web development technologies and frameworks',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'cms-benefits.jpg',
                'file_path' => 'images/blog/cms-benefits.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 742400,
                'alt_text' => 'Custom CMS advantages and benefits',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'api-development.jpg',
                'file_path' => 'images/blog/api-development.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 798720,
                'alt_text' => 'RESTful API development best practices',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'security-practices.jpg',
                'file_path' => 'images/blog/security-practices.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 819200,
                'alt_text' => 'Web application security best practices',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'digital-transformation.jpg',
                'file_path' => 'images/blog/digital-transformation.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 876544,
                'alt_text' => 'Digital transformation strategies for businesses',
                'uploaded_by' => 1
            ],

            // Company Branding
            [
                'file_name' => 'sevlent-logo.png',
                'file_path' => 'images/logo/sevlent-logo.png',
                'file_type' => 'image',
                'mime_type' => 'image/png',
                'file_size' => 256000,
                'alt_text' => 'SEVLENT Software Solutions logo',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'sevlent-logo-white.png',
                'file_path' => 'images/logo/sevlent-logo-white.png',
                'file_type' => 'image',
                'mime_type' => 'image/png',
                'file_size' => 248832,
                'alt_text' => 'SEVLENT Software Solutions white logo',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'favicon.ico',
                'file_path' => 'images/logo/favicon.ico',
                'file_type' => 'image',
                'mime_type' => 'image/x-icon',
                'file_size' => 15360,
                'alt_text' => 'SEVLENT favicon',
                'uploaded_by' => 1
            ],

            // Documents
            [
                'file_name' => 'company-brochure.pdf',
                'file_path' => 'documents/company-brochure.pdf',
                'file_type' => 'document',
                'mime_type' => 'application/pdf',
                'file_size' => 2048000,
                'alt_text' => 'SEVLENT company brochure and services overview',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'service-agreement-template.pdf',
                'file_path' => 'documents/service-agreement-template.pdf',
                'file_type' => 'document',
                'mime_type' => 'application/pdf',
                'file_size' => 512000,
                'alt_text' => 'Standard service agreement template',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'nda-template.pdf',
                'file_path' => 'documents/nda-template.pdf',
                'file_type' => 'document',
                'mime_type' => 'application/pdf',
                'file_size' => 358400,
                'alt_text' => 'Non-disclosure agreement template',
                'uploaded_by' => 1
            ],

            // Videos
            [
                'file_name' => 'company-intro.mp4',
                'file_path' => 'videos/company-intro.mp4',
                'file_type' => 'video',
                'mime_type' => 'video/mp4',
                'file_size' => 15728640,
                'alt_text' => 'SEVLENT company introduction video',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'product-demo.mp4',
                'file_path' => 'videos/product-demo.mp4',
                'file_type' => 'video',
                'mime_type' => 'video/mp4',
                'file_size' => 23068672,
                'alt_text' => 'Product demonstration video',
                'uploaded_by' => 1
            ],

            // Testimonials/Team
            [
                'file_name' => 'client-avatar-1.jpg',
                'file_path' => 'images/testimonials/client-avatar-1.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 128000,
                'alt_text' => 'Client testimonial avatar - Sarah Johnson',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'client-avatar-2.jpg',
                'file_path' => 'images/testimonials/client-avatar-2.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 135168,
                'alt_text' => 'Client testimonial avatar - Michael Chen',
                'uploaded_by' => 1
            ],
            [
                'file_name' => 'client-avatar-3.jpg',
                'file_path' => 'images/testimonials/client-avatar-3.jpg',
                'file_type' => 'image',
                'mime_type' => 'image/jpeg',
                'file_size' => 142336,
                'alt_text' => 'Client testimonial avatar - Emily Rodriguez',
                'uploaded_by' => 1
            ],
        ];

        foreach ($mediaItems as $item) {
            Media::updateOrCreate(
                ['file_path' => $item['file_path']],
                $item
            );
        }
    }
}