<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Setting;

class ContactSettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $settings = [
            [
                'key' => 'contact_address',
                'value' => "123 Business Street\nSuite 100\nCity, State 12345",
                'group_name' => 'contact',
            ],
            [
                'key' => 'contact_phone',
                'value' => '(555) 123-4567',
                'group_name' => 'contact',
            ],
            [
                'key' => 'contact_email',
                'value' => 'info@sevlentcms.com',
                'group_name' => 'contact',
            ],
            [
                'key' => 'contact_business_hours',
                'value' => "Mon - Fri: 9:00 AM - 6:00 PM\nSaturday: 10:00 AM - 4:00 PM\nSunday: Closed",
                'group_name' => 'contact',
            ],
            [
                'key' => 'contact_map_url',
                'value' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.1234567890!2d-74.0059!3d40.7128!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDM4Ii44Ik4gNzTCsDMnMjEuMSJX!5e0!3m2!1sen!2sus!4v1234567890',
                'group_name' => 'contact',
            ],
            [
                'key' => 'faq_section_title',
                'value' => 'Frequently Asked Questions',
                'group_name' => 'faq',
            ],
            [
                'key' => 'faq_section_subtitle',
                'value' => 'Find answers to common questions about our services and get the information you need',
                'group_name' => 'faq',
            ],
            [
                'key' => 'faq_help_title',
                'value' => 'Didn\'t find what you were looking for?',
                'group_name' => 'faq',
            ],
            [
                'key' => 'faq_help_description',
                'value' => 'Feel free to contact us directly and we\'ll be happy to answer your questions.',
                'group_name' => 'faq',
            ],
            [
                'key' => 'faq_help_button_text',
                'value' => 'Get in Touch',
                'group_name' => 'faq',
            ],
        ];

        foreach ($settings as $setting) {
            Setting::updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }
}
