<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ThemeColorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $themeColors = [
            [
                'key' => 'primary_color',
                'value' => '#3b82f6', // Blue
                'group_name' => 'branding',
            ],
            [
                'key' => 'secondary_color',
                'value' => '#8b5cf6', // Purple
                'group_name' => 'branding',
            ],
            [
                'key' => 'accent_color',
                'value' => '#10b981', // Green
                'group_name' => 'branding',
            ],
        ];

        foreach ($themeColors as $color) {
            Setting::updateOrCreate(
                ['key' => $color['key']],
                [
                    'value' => $color['value'],
                    'group_name' => $color['group_name']
                ]
            );
        }

        $this->command->info('Theme colors seeded successfully!');
    }
}

