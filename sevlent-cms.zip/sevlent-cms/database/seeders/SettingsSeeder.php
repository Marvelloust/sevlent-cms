<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $settings = [
            // Branding
            ['key' => 'company_name', 'value' => 'SEVLENT SOFTWARE SOLUTION LTD', 'group_name' => 'branding'],
            ['key' => 'tagline', 'value' => 'Enterprise Software Solutions', 'group_name' => 'branding'],
            ['key' => 'logo', 'value' => null, 'group_name' => 'branding'],
            ['key' => 'logo_white', 'value' => null, 'group_name' => 'branding'],
            ['key' => 'favicon', 'value' => null, 'group_name' => 'branding'],
            ['key' => 'company_description', 'value' => 'Leading provider of enterprise software solutions, custom CMS development, and digital transformation services.', 'group_name' => 'branding'],

            // Contact Information
            ['key' => 'email', 'value' => 'info@sevlent.com', 'group_name' => 'contact'],
            ['key' => 'support_email', 'value' => 'support@sevlent.com', 'group_name' => 'contact'],
            ['key' => 'sales_email', 'value' => 'sales@sevlent.com', 'group_name' => 'contact'],
            ['key' => 'phone', 'value' => '+1 (555) 123-4567', 'group_name' => 'contact'],
            ['key' => 'phone_secondary', 'value' => '+1 (555) 123-4568', 'group_name' => 'contact'],
            ['key' => 'address', 'value' => '123 Business Street, Tech City, TC 12345', 'group_name' => 'contact'],
            ['key' => 'address_line_2', 'value' => 'Suite 500', 'group_name' => 'contact'],
            ['key' => 'city', 'value' => 'Tech City', 'group_name' => 'contact'],
            ['key' => 'state', 'value' => 'TC', 'group_name' => 'contact'],
            ['key' => 'zip_code', 'value' => '12345', 'group_name' => 'contact'],
            ['key' => 'country', 'value' => 'United States', 'group_name' => 'contact'],

            // Social Media
            ['key' => 'social_facebook', 'value' => 'https://facebook.com/sevlent', 'group_name' => 'social'],
            ['key' => 'social_twitter', 'value' => 'https://twitter.com/sevlent', 'group_name' => 'social'],
            ['key' => 'social_linkedin', 'value' => 'https://linkedin.com/company/sevlent', 'group_name' => 'social'],
            ['key' => 'social_instagram', 'value' => 'https://instagram.com/sevlent', 'group_name' => 'social'],
            ['key' => 'social_youtube', 'value' => 'https://youtube.com/@sevlent', 'group_name' => 'social'],
            ['key' => 'social_github', 'value' => 'https://github.com/sevlent', 'group_name' => 'social'],

            // SEO Settings
            ['key' => 'default_meta_title', 'value' => 'SEVLENT - Enterprise Software Solutions', 'group_name' => 'seo'],
            ['key' => 'default_meta_description', 'value' => 'Leading provider of enterprise software solutions and CMS development services. Transform your business with our expert team.', 'group_name' => 'seo'],
            ['key' => 'default_meta_keywords', 'value' => 'software development, CMS, enterprise solutions, web development, mobile apps, digital transformation', 'group_name' => 'seo'],
            ['key' => 'site_verification_google', 'value' => null, 'group_name' => 'seo'],
            ['key' => 'site_verification_bing', 'value' => null, 'group_name' => 'seo'],
            ['key' => 'google_analytics_id', 'value' => null, 'group_name' => 'seo'],
            ['key' => 'google_tag_manager_id', 'value' => null, 'group_name' => 'seo'],

            // Footer Settings
            ['key' => 'footer_text', 'value' => '© 2026 SEVLENT SOFTWARE SOLUTION LTD. All rights reserved.', 'group_name' => 'footer'],
            ['key' => 'footer_description', 'value' => 'Transforming businesses through innovative software solutions.', 'group_name' => 'footer'],
            ['key' => 'footer_newsletter_enabled', 'value' => 'true', 'group_name' => 'footer'],
            ['key' => 'footer_newsletter_text', 'value' => 'Subscribe to our newsletter for the latest updates.', 'group_name' => 'footer'],

            // Email Settings
            ['key' => 'mail_from_address', 'value' => 'noreply@sevlent.com', 'group_name' => 'email'],
            ['key' => 'mail_from_name', 'value' => 'SEVLENT Software Solutions', 'group_name' => 'email'],
            ['key' => 'contact_notification_email', 'value' => 'info@sevlent.com', 'group_name' => 'email'],
            ['key' => 'job_application_notification_email', 'value' => 'hr@sevlent.com', 'group_name' => 'email'],

            // General Settings
            ['key' => 'site_name', 'value' => 'SEVLENT CMS', 'group_name' => 'general'],
            ['key' => 'site_url', 'value' => 'https://sevlent.com', 'group_name' => 'general'],
            ['key' => 'timezone', 'value' => 'America/New_York', 'group_name' => 'general'],
            ['key' => 'date_format', 'value' => 'M d, Y', 'group_name' => 'general'],
            ['key' => 'time_format', 'value' => 'h:i A', 'group_name' => 'general'],
            ['key' => 'items_per_page', 'value' => '12', 'group_name' => 'general'],
            ['key' => 'maintenance_mode', 'value' => 'false', 'group_name' => 'general'],

            // Business Hours
            ['key' => 'business_hours_monday', 'value' => '9:00 AM - 6:00 PM', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_tuesday', 'value' => '9:00 AM - 6:00 PM', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_wednesday', 'value' => '9:00 AM - 6:00 PM', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_thursday', 'value' => '9:00 AM - 6:00 PM', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_friday', 'value' => '9:00 AM - 6:00 PM', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_saturday', 'value' => 'Closed', 'group_name' => 'business_hours'],
            ['key' => 'business_hours_sunday', 'value' => 'Closed', 'group_name' => 'business_hours'],

            // Theme Settings
            ['key' => 'theme_primary_color', 'value' => '#3B82F6', 'group_name' => 'theme'],
            ['key' => 'theme_secondary_color', 'value' => '#10B981', 'group_name' => 'theme'],
            ['key' => 'theme_accent_color', 'value' => '#F59E0B', 'group_name' => 'theme'],
        ];

        foreach ($settings as $setting) {
            Setting::updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }
}
