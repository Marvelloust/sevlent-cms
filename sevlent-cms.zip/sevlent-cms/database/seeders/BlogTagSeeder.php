<?php

namespace Database\Seeders;

use App\Models\BlogTag;
use Illuminate\Database\Seeder;

class BlogTagSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $tags = [
            ['name' => 'Laravel', 'slug' => 'laravel'],
            ['name' => 'React', 'slug' => 'react'],
            ['name' => 'Vue.js', 'slug' => 'vue-js'],
            ['name' => 'JavaScript', 'slug' => 'javascript'],
            ['name' => 'TypeScript', 'slug' => 'typescript'],
            ['name' => 'PHP', 'slug' => 'php'],
            ['name' => 'Python', 'slug' => 'python'],
            ['name' => 'Node.js', 'slug' => 'node-js'],
            ['name' => 'SEO', 'slug' => 'seo'],
            ['name' => 'Performance', 'slug' => 'performance'],
            ['name' => 'Security', 'slug' => 'security'],
            ['name' => 'API', 'slug' => 'api'],
            ['name' => 'Database', 'slug' => 'database'],
            ['name' => 'UI/UX', 'slug' => 'ui-ux'],
            ['name' => 'Mobile', 'slug' => 'mobile'],
            ['name' => 'E-commerce', 'slug' => 'e-commerce'],
            ['name' => 'Cloud', 'slug' => 'cloud'],
            ['name' => 'DevOps', 'slug' => 'devops'],
            ['name' => 'Docker', 'slug' => 'docker'],
            ['name' => 'Kubernetes', 'slug' => 'kubernetes'],
            ['name' => 'AWS', 'slug' => 'aws'],
            ['name' => 'Azure', 'slug' => 'azure'],
            ['name' => 'Testing', 'slug' => 'testing'],
            ['name' => 'Best Practices', 'slug' => 'best-practices'],
            ['name' => 'Tutorial', 'slug' => 'tutorial'],
        ];

        foreach ($tags as $tag) {
            BlogTag::updateOrCreate(
                ['slug' => $tag['slug']],
                $tag
            );
        }
    }
}
