<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [
            [
                'name' => 'super_admin',
                'description' => 'Super Administrator with full system access and permissions'
            ],
            [
                'name' => 'admin',
                'description' => 'Administrator with access to most system features'
            ],
            [
                'name' => 'editor',
                'description' => 'Content Editor with permission to manage content'
            ],
            [
                'name' => 'author',
                'description' => 'Content Author with permission to create and edit own content'
            ],
            [
                'name' => 'viewer',
                'description' => 'Viewer with read-only access to the system'
            ]
        ];

        foreach ($roles as $roleData) {
            Role::updateOrCreate(
                ['name' => $roleData['name']],
                $roleData
            );
        }
    }
}
