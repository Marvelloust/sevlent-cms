<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserTestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create test users with different statuses
        $testUsers = [
            [
                'name' => 'John Doe',
                'email' => 'john@example.com',
                'password' => Hash::make('password123'),
                'status' => 'active',
                'roles' => ['admin'],
            ],
            [
                'name' => 'Jane Smith',
                'email' => 'jane@example.com',
                'password' => Hash::make('password123'),
                'status' => 'active',
                'roles' => [],
            ],
            [
                'name' => 'Bob Wilson',
                'email' => 'bob@example.com',
                'password' => Hash::make('password123'),
                'status' => 'inactive',
                'roles' => [],
            ],
            [
                'name' => 'Alice Johnson',
                'email' => 'alice@example.com',
                'password' => Hash::make('password123'),
                'status' => 'active',
                'roles' => [],
            ],
        ];

        foreach ($testUsers as $userData) {
            // Skip if user already exists
            if (User::where('email', $userData['email'])->exists()) {
                continue;
            }

            $roles = $userData['roles'];
            unset($userData['roles']);

            $user = User::create($userData);

            // Assign roles if specified
            if (!empty($roles)) {
                $roleIds = Role::whereIn('name', $roles)->pluck('id')->toArray();
                if (!empty($roleIds)) {
                    $user->roles()->sync($roleIds);
                }
            }
        }

        $this->command->info('Test users seeded successfully!');
    }
}
