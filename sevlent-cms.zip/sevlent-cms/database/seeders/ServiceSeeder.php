<?php

namespace Database\Seeders;

use App\Models\Service;
use App\Models\ServiceCategory;
use App\Models\SeoMetadata;
use Illuminate\Database\Seeder;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        // Get service category
        $developmentCategory = ServiceCategory::where('slug', 'development-services')->first();

        // Custom CMS Development Service
        $cmsService = Service::updateOrCreate(
            ['slug' => 'custom-cms-development'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'Custom CMS Development',
                'slug' => 'custom-cms-development',
                'short_description' => 'Tailored content management systems built with scalability, security, and user experience in mind. Perfect for businesses that need a CMS that fits their specific workflow and requirements.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Why Choose Custom CMS Development?',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Off-the-shelf CMS solutions often come with unnecessary features or lack the specific functionality your business needs. Our custom CMS development service creates a solution that perfectly matches your requirements.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Key Features',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Modular Architecture: Build exactly what you need
Scalable Design: Grows with your business
Advanced User Management: Role-based permissions
Media Management: Comprehensive file handling
SEO Optimization: Built-in SEO tools
API Integration: Connect with third-party services'
                    ]
                ],
                'features' => [
                    'Modular and scalable architecture',
                    'Advanced user management',
                    'Media library management',
                    'SEO optimization tools',
                    'Multi-language support',  
                    'Version control and rollback',
                    'Custom workflows',
                    'API integration'
                ],
                'pricing_info' => [
                    'starting_price' => '$15,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'Requirements analysis',
                        'Custom development',
                        'Testing and QA',
                        '3 months support',
                        'Training'
                    ]
                ],
                'icon_image' => 7,
                'status' => 'active'
            ]
        );

        // Create SEO for CMS Service
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $cmsService->id],
            [
                'meta_title' => 'Custom CMS Development - Enterprise Content Management Systems',
                'meta_description' => 'Get a custom CMS built specifically for your business needs. Scalable, secure, and feature-rich content management systems with advanced user management and SEO optimization.',
                'meta_keywords' => 'custom CMS, content management system, enterprise CMS, web development',
                'canonical_url' => '/services/custom-cms-development',
                'og_title' => 'Custom CMS Development - SEVLENT Software Solutions',
                'og_description' => 'Tailored content management systems built for your specific business needs.',
                'og_image' => null
            ]
        );

        // Web Application Development Service
        $webAppService = Service::updateOrCreate(
            ['slug' => 'web-application-development'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'Web Application Development',
                'slug' => 'web-application-development',
                'short_description' => 'High-performance web applications designed to solve complex business challenges. From MVPs to enterprise systems, we deliver scalable solutions.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Build Powerful Web Applications',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'In today\'s digital landscape, a robust web application can be the difference between leading your industry and falling behind. We specialize in creating high-performance, scalable web applications that solve real business problems.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Our Approach',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Discovery Phase: Understanding your business goals
Architecture Planning: Designing scalable systems
Agile Development: Iterative development with feedback
Quality Assurance: Comprehensive testing
Deployment: Smooth launch with monitoring'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'What We Build',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'From customer portals and SaaS platforms to internal tools and enterprise systems, we have the expertise to bring your vision to life using cutting-edge technologies.'
                    ]
                ],
                'features' => [
                    'Responsive design',
                    'Real-time capabilities',
                    'Third-party integrations',
                    'Cloud infrastructure',
                    'Performance optimization',
                    'Security best practices',
                    'Automated testing',
                    'CI/CD pipelines'
                ],
                'pricing_info' => [
                    'starting_price' => '$20,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'Technical requirements',
                        'Full-stack development',
                        'Quality assurance',
                        'Deployment setup',
                        '2 months support'
                    ]
                ],
                'icon_image' => 8,
                'status' => 'active'
            ]
        );

        // SEO for Web Application Development
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $webAppService->id],
            [
                'meta_title' => 'Web Application Development Services | Custom Solutions',
                'meta_description' => 'Professional web application development services. Build scalable, high-performance applications with our expert development team.',
                'meta_keywords' => 'web application development, custom web apps, saas development, enterprise applications',
                'canonical_url' => '/services/web-application-development',
                'og_title' => 'Expert Web Application Development',
                'og_description' => 'Transform your business with custom web applications built to scale.',
            ]
        );

        // E-Commerce Solutions Service
        $ecommerceService = Service::updateOrCreate(
            ['slug' => 'e-commerce-solutions'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'E-Commerce Solutions',
                'slug' => 'e-commerce-solutions',
                'short_description' => 'Complete e-commerce platforms that drive sales and enhance customer experience. From product catalogs to payment integration, we build it all.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Grow Your Online Business',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'E-commerce is more than just a shopping cart. It\'s about creating an experience that converts visitors into customers and keeps them coming back. Our e-commerce solutions are designed with both user experience and conversion optimization in mind.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Features We Deliver',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Product Management: Flexible catalog and inventory
Payment Integration: Secure payment gateways
Shopping Cart: Intuitive checkout process
Order Management: Complete order workflow
Customer Accounts: Profiles and order history
Analytics: Sales tracking and insights'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Platform Expertise',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Whether you need a custom solution or prefer platforms like WooCommerce or Shopify with custom extensions, we have you covered.'
                    ]
                ],
                'features' => [
                    'Product catalog management',
                    'Shopping cart & checkout',
                    'Payment gateway integration',
                    'Inventory management',
                    'Order processing',
                    'Customer accounts',
                    'Discount & coupon system',
                    'Sales analytics'
                ],
                'pricing_info' => [
                    'starting_price' => '$25,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'Store setup',
                        'Payment integration',
                        'Product migration',
                        'Testing',
                        '3 months support'
                    ]
                ],
                'icon_image' => 9,
                'status' => 'active'
            ]
        );

        // SEO for E-Commerce Solutions
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $ecommerceService->id],
            [
                'meta_title' => 'E-Commerce Solutions | Online Store Development Services',
                'meta_description' => 'Build a complete e-commerce platform with payment integration, inventory management, and customer analytics. Boost online sales with custom solutions.',
                'meta_keywords' => 'e-commerce solutions, online store, shopping cart, payment integration',
                'canonical_url' => '/services/e-commerce-solutions',
                'og_title' => 'Professional E-Commerce Solutions',
                'og_description' => 'Complete e-commerce platforms for online business success.',
            ]
        );

        // Mobile App Development Service
        $mobileService = Service::updateOrCreate(
            ['slug' => 'mobile-app-development'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'Mobile App Development',
                'slug' => 'mobile-app-development',
                'short_description' => 'Native and cross-platform mobile applications for iOS and Android. Reach your customers wherever they are with professional mobile apps.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Professional Mobile App Development',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'In a mobile-first world, having a great mobile app is essential for business success. Our mobile development team creates native and cross-platform applications that provide exceptional user experiences.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Native vs Cross-Platform',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'We offer both native development for optimal performance and cross-platform solutions for cost-effective development across multiple platforms. Choose the approach that best fits your requirements and budget.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'What We Build',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Consumer Mobile Apps
Enterprise Mobile Solutions
E-Commerce Mobile Apps
Social Networking Apps
On-Demand Service Apps
Healthcare & Fitness Apps'
                    ]
                ],
                'features' => [
                    'iOS development (Swift/Objective-C)',
                    'Android development (Kotlin/Java)',
                    'Cross-platform (React Native/Flutter)',
                    'Push notifications',
                    'Offline functionality',
                    'App store optimization',
                    'Analytics integration',
                    'Backend API development'
                ],
                'pricing_info' => [
                    'starting_price' => '$30,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'UI/UX design',
                        'Mobile development',
                        'Backend integration',
                        'App store submission',
                        '2 months support'
                    ]
                ],
                'icon_image' => 10,
                'status' => 'active'
            ]
        );

        // SEO for Mobile App Development
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $mobileService->id],
            [
                'meta_title' => 'Mobile App Development | iOS & Android Apps',
                'meta_description' => 'Professional mobile app development for iOS and Android. Native and cross-platform apps that deliver exceptional user experiences.',
                'meta_keywords' => 'mobile app development, iOS apps, Android apps, React Native, Flutter',
                'canonical_url' => '/services/mobile-app-development',
                'og_title' => 'Expert Mobile App Development',
                'og_description' => 'Native and cross-platform mobile applications for iOS and Android.',
            ]
        );

        // Digital Transformation Service
        $digitalService = Service::updateOrCreate(
            ['slug' => 'digital-transformation'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'Digital Transformation',
                'slug' => 'digital-transformation',
                'short_description' => 'Comprehensive digital transformation services to modernize your business processes, improve efficiency, and drive innovation.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Transform Your Business Digitally',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Digital transformation is about fundamentally changing how your business operates to meet the demands of the digital age. Our services help you modernize processes, improve efficiency, and stay competitive.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Our Digital Transformation Services',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Legacy System Modernization: Migrate from outdated systems
Cloud Migration & Adoption: Leverage cloud scalability
Process Automation: Automate repetitive tasks
Data Analytics & BI: Transform data into insights
Change Management: Support organizational change'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Why Choose Us?',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'We combine proven methodology with deep technology expertise to deliver digital transformation solutions that provide measurable ROI and lasting business value.'
                    ]
                ],
                'features' => [
                    'Legacy system modernization',
                    'Cloud migration strategy',
                    'Process automation',
                    'Data analytics & BI',
                    'Change management',
                    'Technology assessment',
                    'Roadmap development',
                    'ROI measurement'
                ],
                'pricing_info' => [
                    'starting_price' => '$50,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'Assessment & strategy',
                        'Implementation',
                        'Change management',
                        'Training',
                        '6 months support'
                    ]
                ],
                'icon_image' => 11,
                'status' => 'active'
            ]
        );

        // SEO for Digital Transformation
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $digitalService->id],
            [
                'meta_title' => 'Digital Transformation Services | Modernize Your Business',
                'meta_description' => 'Comprehensive digital transformation services to modernize business processes, improve efficiency, and drive innovation. Legacy migration and cloud adoption.',
                'meta_keywords' => 'digital transformation, legacy migration, cloud adoption, business automation',
                'canonical_url' => '/services/digital-transformation',
                'og_title' => 'Digital Transformation Services',
                'og_description' => 'Transform your business with modern technology solutions.',
            ]
        );

        // API Development & Integration Service
        $apiService = Service::updateOrCreate(
            ['slug' => 'api-development-integration'],
            [
                'service_category_id' => $developmentCategory->id,
                'name' => 'API Development & Integration',
                'slug' => 'api-development-integration',
                'short_description' => 'RESTful and GraphQL API development with comprehensive documentation. Seamlessly integrate your systems and connect with third-party services.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'Powerful API Development & Integration',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'APIs are the backbone of modern software systems, enabling seamless communication between different applications and services. Our API development services ensure your systems can connect efficiently and securely.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'API Types We Develop',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'RESTful APIs: Industry-standard REST APIs
GraphQL APIs: Flexible query language
Webhook Integration: Real-time data sync
Third-party Integrations: Connect with popular services'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'API Security & Documentation',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Every API we develop includes comprehensive security measures (OAuth 2.0, JWT) and detailed documentation (Swagger/OpenAPI) to ensure smooth integration and maintenance.'
                    ]
                ],
                'features' => [
                    'RESTful API development',
                    'GraphQL API development',
                    'OAuth 2.0 & JWT authentication',
                    'Rate limiting',
                    'API versioning',
                    'Swagger/OpenAPI documentation',
                    'Webhook integration',
                    'Third-party API integration'
                ],
                'pricing_info' => [
                    'starting_price' => '$12,000',
                    'billing_type' => 'project',
                    'includes' => [
                        'API design',
                        'Development',
                        'Documentation',
                        'Testing',
                        '1 month support'
                    ]
                ],
                'icon_image' => 7,
                'status' => 'active'
            ]
        );

        // SEO for API Development & Integration
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Service::class, 'seoable_id' => $apiService->id],
            [
                'meta_title' => 'API Development & Integration Services',
                'meta_description' => 'Professional RESTful and GraphQL API development with comprehensive documentation. Seamlessly integrate systems and connect with third-party services.',
                'meta_keywords' => 'API development, REST API, GraphQL, integration, webhooks',
                'canonical_url' => '/services/api-development-integration',
                'og_title' => 'API Development & Integration',
                'og_description' => 'Powerful API development and integration services.',
            ]
        );
    }
}