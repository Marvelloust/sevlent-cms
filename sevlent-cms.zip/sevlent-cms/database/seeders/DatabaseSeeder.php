<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            // Core seeders - order is important!
            RoleSeeder::class,              // 1. Roles first
            UserSeeder::class,               // 2. Users (references roles)
            MediaSeeder::class,              // 3. Media (uploaded by users)
            SettingsSeeder::class,           // 4. Settings
            
            // Content structure
            PageSeeder::class,               // 5. Pages and sections
            MenuSeeder::class,               // 6. Menus (references pages)
            
            // Services
            ServiceCategorySeeder::class,    // 7. Service categories first
            ServiceSeeder::class,            // 8. Services (references categories)
            
            // Blog
            BlogCategorySeeder::class,       // 9. Blog categories
            BlogTagSeeder::class,            // 10. Blog tags
            BlogSeeder::class,               // 11. Blogs (references categories, tags, users, media)
            
            // Projects
            ProjectSeeder::class,            // 12. Projects
            
            // Careers
            CareerSeeder::class,             // 13. Careers
            JobApplicationSeeder::class,     // 14. Job Applications (references careers)
            
            // Contact
            ContactSeeder::class,            // 15. Contact submissions
            
            // FAQ
            FaqSeeder::class,                // 16. FAQs
        ]);
    }
}
