<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\Page;
use App\Models\Service;
use App\Models\Blog;
use App\Models\Project;
use App\Models\Career;
use App\Models\Contact;
use App\Models\User;
use App\Services\ActivityLogger;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ActivitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create activities for existing records
        $this->createActivitiesForModel(Page::class, 'Page');
        $this->createActivitiesForModel(Service::class, 'Service');
        $this->createActivitiesForModel(Blog::class, 'Blog');
        $this->createActivitiesForModel(Project::class, 'Project');
        $this->createActivitiesForModel(Career::class, 'Career');
        $this->createActivitiesForModel(Contact::class, 'Contact');
        $this->createActivitiesForModel(User::class, 'User');
    }

    private function createActivitiesForModel($modelClass, $modelName)
    {
        $records = $modelClass::all();

        foreach ($records as $record) {
            // Create a "created" activity for each existing record
            ActivityLogger::log('created', $record);

            // Randomly create some "updated" activities
            if (rand(1, 3) === 1) {
                ActivityLogger::log('updated', $record);
            }
        }
    }
}
