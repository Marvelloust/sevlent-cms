<?php

namespace Database\Seeders;

use App\Models\ServiceCategory;
use Illuminate\Database\Seeder;

class ServiceCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Development Services',
                'slug' => 'development-services',
                'description' => 'Professional software development services including web, mobile, and custom applications',
                'status' => 'active'
            ],
            [
                'name' => 'Consulting Services',
                'slug' => 'consulting-services',
                'description' => 'Expert consulting services for digital transformation and technology strategy',
                'status' => 'active'
            ],
            [
                'name' => 'Design Services',
                'slug' => 'design-services',
                'description' => 'UI/UX design services for web and mobile applications',
                'status' => 'active'
            ],
            [
                'name' => 'Cloud Services',
                'slug' => 'cloud-services',
                'description' => 'Cloud migration, deployment, and management services',
                'status' => 'active'
            ],
            [
                'name' => 'Maintenance & Support',
                'slug' => 'maintenance-support',
                'description' => 'Ongoing maintenance and support services for applications and systems',
                'status' => 'active'
            ]
        ];

        foreach ($categories as $category) {
            ServiceCategory::updateOrCreate(
                ['slug' => $category['slug']],
                $category
            );
        }
    }
}
