<?php

namespace Database\Seeders;

use App\Models\BlogCategory;
use Illuminate\Database\Seeder;

class BlogCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            ['name' => 'Web Development', 'slug' => 'web-development'],
            ['name' => 'CMS', 'slug' => 'cms'],
            ['name' => 'Digital Marketing', 'slug' => 'digital-marketing'],
            ['name' => 'Technology', 'slug' => 'technology'],
            ['name' => 'Business', 'slug' => 'business'],
            ['name' => 'Mobile Development', 'slug' => 'mobile-development'],
            ['name' => 'Cloud Computing', 'slug' => 'cloud-computing'],
            ['name' => 'DevOps', 'slug' => 'devops'],
            ['name' => 'Security', 'slug' => 'security'],
            ['name' => 'Design', 'slug' => 'design'],
            ['name' => 'E-commerce', 'slug' => 'e-commerce'],
            ['name' => 'API Development', 'slug' => 'api-development'],
        ];

        foreach ($categories as $category) {
            BlogCategory::updateOrCreate(
                ['slug' => $category['slug']],
                $category
            );
        }
    }
}
