<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Faq;

class FaqSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faqs = [
            [
                'question' => 'What is your response time for inquiries?',
                'answer' => 'We typically respond to all inquiries within 24 hours during business days. For urgent matters, please call us directly at (555) 123-4567.',
                'icon' => 'clock',
                'color' => 'blue',
                'order' => 1,
                'is_active' => true,
            ],
            [
                'question' => 'Do you offer custom development services?',
                'answer' => 'Yes! We specialize in custom development solutions tailored to your specific needs. Contact our team to discuss your project requirements and get a personalized quote.',
                'icon' => 'settings',
                'color' => 'purple',
                'order' => 2,
                'is_active' => true,
            ],
            [
                'question' => 'What technologies do you work with?',
                'answer' => 'We have expertise in modern web technologies including Laravel, Vue.js, React, Node.js, and cloud platforms. We\'re always learning new technologies to stay current with industry trends.',
                'icon' => 'lightbulb',
                'color' => 'indigo',
                'order' => 3,
                'is_active' => true,
            ],
            [
                'question' => 'Do you provide ongoing support and maintenance?',
                'answer' => 'Absolutely! We offer comprehensive support and maintenance packages to ensure your project runs smoothly long after launch. We\'ll work with you to define the right support level for your needs.',
                'icon' => 'check',
                'color' => 'green',
                'order' => 4,
                'is_active' => true,
            ],
            [
                'question' => 'What is your project timeline?',
                'answer' => 'Project timelines vary depending on complexity and scope. We provide detailed estimates during the initial consultation. Small projects can be completed in weeks, while larger initiatives may take several months. We\'ll keep you updated every step of the way.',
                'icon' => 'calendar',
                'color' => 'orange',
                'order' => 5,
                'is_active' => true,
            ],
        ];

        foreach ($faqs as $faq) {
            Faq::updateOrCreate(
                ['question' => $faq['question']],
                $faq
            );
        }
    }
}
