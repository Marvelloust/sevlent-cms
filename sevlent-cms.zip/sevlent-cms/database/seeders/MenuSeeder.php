<?php

namespace Database\Seeders;

use App\Models\Menu;
use App\Models\MenuItem;
use App\Models\Page;
use Illuminate\Database\Seeder;

class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Main Navigation Menu
        $mainMenu = Menu::updateOrCreate(
            ['name' => 'Main Navigation'],
            ['name' => 'Main Navigation']
        );

        // Get some sample pages
        $homePage = Page::where('slug', 'home')->first();
        $aboutPage = Page::where('slug', 'about')->first();
        $servicesPage = Page::where('slug', 'services')->first();
        $contactPage = Page::where('slug', 'contact')->first();

        // Create menu items
        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Home', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Home',
                'url' => '/',
                'page_id' => $homePage?->id,
                'target' => '_self',
                'order_index' => 1,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Services', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Services',
                'url' => '/services',
                'page_id' => $servicesPage?->id,
                'target' => '_self',
                'order_index' => 2,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Blog', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Blog',
                'url' => '/blogs',
                'page_id' => null,
                'target' => '_self',
                'order_index' => 3,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Projects', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Projects',
                'url' => '/projects',
                'page_id' => null,
                'target' => '_self',
                'order_index' => 4,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Careers', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Careers',
                'url' => '/careers',
                'page_id' => null,
                'target' => '_self',
                'order_index' => 5,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $mainMenu->id, 'title' => 'Contact', 'depth' => 0],
            [
                'menu_id' => $mainMenu->id,
                'title' => 'Contact',
                'url' => '/contact',
                'page_id' => $contactPage?->id,
                'target' => '_self',
                'order_index' => 6,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        // Create Footer Menu
        $footerMenu = Menu::updateOrCreate(
            ['name' => 'Footer Menu'],
            ['name' => 'Footer Menu']
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $footerMenu->id, 'title' => 'Privacy Policy', 'depth' => 0],
            [
                'menu_id' => $footerMenu->id,
                'title' => 'Privacy Policy',
                'url' => '/privacy-policy',
                'page_id' => null,
                'target' => '_self',
                'order_index' => 1,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $footerMenu->id, 'title' => 'Terms of Service', 'depth' => 0],
            [
                'menu_id' => $footerMenu->id,
                'title' => 'Terms of Service',
                'url' => '/terms-of-service',
                'page_id' => null,
                'target' => '_self',
                'order_index' => 2,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $footerMenu->id, 'title' => 'About Us', 'depth' => 0],
            [
                'menu_id' => $footerMenu->id,
                'title' => 'About Us',
                'url' => '/about',
                'page_id' => $aboutPage?->id,
                'target' => '_self',
                'order_index' => 3,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );

        MenuItem::updateOrCreate(
            ['menu_id' => $footerMenu->id, 'title' => 'Contact', 'depth' => 0],
            [
                'menu_id' => $footerMenu->id,
                'title' => 'Contact',
                'url' => '/contact',
                'page_id' => $contactPage?->id,
                'target' => '_self',
                'order_index' => 4,
                'depth' => 0,
                'parent_id' => null,
                'is_active' => true,
            ]
        );
    }
}
