<?php

namespace Database\Seeders;

use App\Models\Page;
use App\Models\Section;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AboutPageSectionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $page = Page::where('slug', 'about')->first();

        if (!$page) {
            return;
        }

        // Update existing sections order and add new comprehensive sections
        $sections = [
            [
                'type' => 'hero',
                'title' => 'About SEVLENT Software Solutions',
                'content' => '',
                'data' => [
                    'headline' => 'Empowering Businesses Through Innovative Technology',
                    'subheadline' => 'We are a leading enterprise software development company committed to delivering exceptional digital solutions that drive growth and success.',
                    'description' => 'Founded in 2020, SEVLENT has rapidly become a trusted partner for businesses seeking cutting-edge software solutions. Our team of expert developers, designers, and strategists work collaboratively to transform ideas into powerful digital experiences.',
                    'primary_button_text' => 'Our Services',
                    'primary_button_url' => '/services',
                    'secondary_button_text' => 'Contact Us',
                    'secondary_button_url' => '/contact'
                ],
                'order_index' => 1,
                'is_active' => true
            ],
            [
                'type' => 'content',
                'title' => 'Our Story & Mission',
                'content' => '<h2>Our Story</h2><p>SEVLENT Software Solutions was founded in 2020 with a clear vision: to bridge the gap between innovative technology and business success. What started as a small team of passionate developers has grown into a full-service enterprise software company serving clients across multiple industries.</p><p>Our journey began during the global pandemic when we recognized the urgent need for businesses to accelerate their digital transformation. We saw an opportunity to not just build software, but to create solutions that truly make a difference in how businesses operate and serve their customers.</p><h2>Our Mission</h2><p>At SEVLENT, our mission is to empower businesses with cutting-edge technology solutions that drive growth, efficiency, and innovation. We believe that great software can transform how businesses operate and serve their customers in the modern digital landscape.</p><h2>Our Vision</h2><p>To be the leading provider of enterprise software solutions, recognized globally for our commitment to quality, innovation, and customer success. We envision a world where businesses of all sizes can leverage technology to achieve their full potential and compete effectively in the digital economy.</p>',
                'data' => [],
                'order_index' => 2,
                'is_active' => true
            ],
            [
                'type' => 'content',
                'title' => 'Our Core Values',
                'content' => '<div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8"><div class="text-center"><div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4"><svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg></div><h3 class="text-xl font-bold text-gray-900 mb-2">Innovation</h3><p class="text-gray-600">We constantly explore new technologies and methodologies to deliver cutting-edge solutions that keep our clients ahead of the curve.</p></div><div class="text-center"><div class="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4"><svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div><h3 class="text-xl font-bold text-gray-900 mb-2">Quality</h3><p class="text-gray-600">We maintain the highest standards in everything we do, from code quality to project delivery and customer service.</p></div><div class="text-center"><div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4"><svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg></div><h3 class="text-xl font-bold text-gray-900 mb-2">Collaboration</h3><p class="text-gray-600">We believe in transparent communication and collaborative partnerships with our clients throughout the development process.</p></div><div class="text-center"><div class="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4"><svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg></div><h3 class="text-xl font-bold text-gray-900 mb-2">Growth</h3><p class="text-gray-600">We are committed to continuous learning and improvement, both for our team and our clients\' businesses.</p></div></div>',
                'data' => [],
                'order_index' => 3,
                'is_active' => true
            ],
            [
                'type' => 'content',
                'title' => 'Company Milestones',
                'content' => '<div class="space-y-8"><div class="flex items-start space-x-4"><div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center"><span class="text-white font-bold">2020</span></div><div><h3 class="text-lg font-bold text-gray-900">Company Founded</h3><p class="text-gray-600">SEVLENT Software Solutions was established with a mission to deliver exceptional software development services.</p></div></div><div class="flex items-start space-x-4"><div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center"><span class="text-white font-bold">2021</span></div><div><h3 class="text-lg font-bold text-gray-900">First Major Client</h3><p class="text-gray-600">Successfully delivered our first enterprise-level custom CMS solution, establishing our reputation for quality and reliability.</p></div></div><div class="flex items-start space-x-4"><div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center"><span class="text-white font-bold">2022</span></div><div><h3 class="text-lg font-bold text-gray-900">Team Expansion</h3><p class="text-gray-600">Grew our team to 15+ skilled professionals and expanded our service offerings to include mobile app development.</p></div></div><div class="flex items-start space-x-4"><div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center"><span class="text-white font-bold">2023</span></div><div><h3 class="text-lg font-bold text-gray-900">Industry Recognition</h3><p class="text-gray-600">Received multiple industry awards for innovation and client satisfaction, solidifying our position as a leading software development company.</p></div></div><div class="flex items-start space-x-4"><div class="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-full flex items-center justify-center"><span class="text-white font-bold">2024</span></div><div><h3 class="text-lg font-bold text-gray-900">Global Expansion</h3><p class="text-gray-600">Expanded our services internationally and launched our AI-powered development tools, serving clients across 15+ countries.</p></div></div></div>',
                'data' => [],+
                'order_index' => 4,
                'is_active' => true
            ],
            [
                'type' => 'content',
                'title' => 'Why Choose SEVLENT',
                'content' => '<div class="grid md:grid-cols-2 gap-12 items-center"><div><h2 class="text-3xl font-bold text-gray-900 mb-6">Expertise You Can Trust</h2><p class="text-gray-600 mb-6">With over 4 years of experience in enterprise software development, we have successfully delivered 150+ projects across various industries. Our team combines technical excellence with deep industry knowledge to deliver solutions that drive real business value.</p><ul class="space-y-3"><li class="flex items-start"><svg class="w-5 h-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg><strong>Proven Track Record:</strong> 95% client satisfaction rate with successful project delivery</li><li class="flex items-start"><svg class="w-5 h-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg><strong>Modern Technology Stack:</strong> Latest frameworks, cloud-native solutions, and AI integration</li><li class="flex items-start"><svg class="w-5 h-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg><strong>Agile Methodology:</strong> Flexible development approach with regular client communication</li></ul></div><div class="space-y-6"><div class="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl"><h3 class="text-xl font-bold text-gray-900 mb-3">Technical Excellence</h3><p class="text-gray-600">Our developers stay at the forefront of technology trends, ensuring your solution uses the most appropriate and future-proof technologies.</p></div><div class="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl"><h3 class="text-xl font-bold text-gray-900 mb-3">Dedicated Support</h3><p class="text-gray-600">Beyond development, we provide ongoing maintenance, updates, and technical support to ensure your solution continues to perform optimally.</p></div><div class="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl"><h3 class="text-xl font-bold text-gray-900 mb-3">Scalable Solutions</h3><p class="text-gray-600">We build applications that grow with your business, designed to handle increased traffic, users, and feature requirements.</p></div></div></div>',
                'data' => [],
                'order_index' => 5,
                'is_active' => true
            ],
            [
                'type' => 'cta',
                'title' => 'Ready to Start Your Project?',
                'content' => '',
                'data' => [
                    'badge_text' => 'Let\'s Work Together',
                    'headline' => 'Transform Your Business with SEVLENT',
                    'subheadline' => 'Ready to take your business to the next level? Let\'s discuss how we can help you achieve your goals with our expert software development services.',
                    'button_text' => 'Start Your Project',
                    'button_url' => '/contact',
                    'trust_indicators' => [
                        ['text' => 'Free Consultation', 'icon' => 'chat'],
                        ['text' => 'No Obligation', 'icon' => 'shield'],
                        ['text' => 'Expert Team', 'icon' => 'users']
                    ]
                ],
                'order_index' => 6,
                'is_active' => true
            ],
            [
                'type' => 'team',
                'title' => 'Meet Our Team',
                'content' => '',
                'data' => [
                    'members' => [
                        [
                            'name' => 'John Smith',
                            'position' => 'CEO & Founder',
                            'bio' => 'With over 15 years in software development, John leads our vision and strategy.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/johnsmith',
                                'twitter' => 'https://twitter.com/johnsmith'
                            ]
                        ],
                        [
                            'name' => 'Sarah Davis',
                            'position' => 'CTO',
                            'bio' => 'Sarah oversees our technical architecture and ensures we use the best technologies.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/sarahdavis',
                                'github' => 'https://github.com/sarahdavis'
                            ]
                        ],
                        [
                            'name' => 'Mike Johnson',
                            'position' => 'Lead Developer',
                            'bio' => 'Mike specializes in full-stack development and leads our development team.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/mikejohnson',
                                'github' => 'https://github.com/mikejohnson'
                            ]
                        ],
                        [
                            'name' => 'Lisa Chen',
                            'position' => 'UI/UX Designer',
                            'bio' => 'Lisa creates beautiful, user-friendly interfaces that delight our users.',
                            'image' => null,
                            'social' => [
                                'linkedin' => 'https://linkedin.com/in/lisachen',
                                'dribbble' => 'https://dribbble.com/lisachen'
                            ]
                        ]
                    ]
                ],
                'order_index' => 7,
                'is_active' => true
            ]
        ];

        foreach($sections as $sectionData) {
            Section::updateOrCreate(
                ['page_id' => $page->id, 'type' => $sectionData['type'], 'order_index' => $sectionData['order_index']],
                array_merge($sectionData, ['page_id' => $page->id])
            );
        }
    }
}
