<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Get roles
        $superAdminRole = Role::where('name', 'super_admin')->first();
        $adminRole = Role::where('name', 'admin')->first();
        $editorRole = Role::where('name', 'editor')->first();
        $authorRole = Role::where('name', 'author')->first();
        $viewerRole = Role::where('name', 'viewer')->first();

        // Create super admin user (ID: 1)
        $superAdmin = User::updateOrCreate(
            ['email' => 'superadmin@sevlent.com'],
            [
                'name' => 'Super Admin',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
        if ($superAdminRole) {
            $superAdmin->roles()->sync([$superAdminRole->id]);
        }

        // Create admin user (ID: 2)
        $adminUser = User::updateOrCreate(
            ['email' => 'admin@sevlent.com'],
            [
                'name' => 'Admin User',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
        if ($adminRole) {
            $adminUser->roles()->sync([$adminRole->id]);
        }

        // Create editor user (ID: 3)
        $editor = User::updateOrCreate(
            ['email' => 'editor@sevlent.com'],
            [
                'name' => 'Content Editor',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
        if ($editorRole) {
            $editor->roles()->sync([$editorRole->id]);
        }

        // Create author user (ID: 4)
        $author = User::updateOrCreate(
            ['email' => 'author@sevlent.com'],
            [
                'name' => 'Content Author',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
        if ($authorRole) {
            $author->roles()->sync([$authorRole->id]);
        }

        // Create viewer user (ID: 5)
        $viewer = User::updateOrCreate(
            ['email' => 'viewer@sevlent.com'],
            [
                'name' => 'Content Viewer',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
        if ($viewerRole) {
            $viewer->roles()->sync([$viewerRole->id]);
        }

        // Create inactive user
        User::updateOrCreate(
            ['email' => 'inactive@sevlent.com'],
            [
                'name' => 'Inactive User',
                'password' => Hash::make('password'),
                'status' => 'inactive',
            ]
        );

        // Create test users
        User::updateOrCreate(
            ['email' => 'john.doe@sevlent.com'],
            [
                'name' => 'John Doe',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );

        User::updateOrCreate(
            ['email' => 'jane.smith@sevlent.com'],
            [
                'name' => 'Jane Smith',
                'password' => Hash::make('password'),
                'status' => 'active',
                'email_verified_at' => now(),
            ]
        );
    }
}
