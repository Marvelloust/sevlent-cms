<?php

namespace Database\Seeders;

use App\Models\Blog;
use App\Models\BlogCategory;
use App\Models\BlogTag;
use App\Models\SeoMetadata;
use Illuminate\Database\Seeder;

class BlogSeeder extends Seeder
{
    public function run(): void
    {
        // Get existing blog categories (created by BlogCategorySeeder)
        $webDevCategory = BlogCategory::where('slug', 'web-development')->first();
        $cmsCategory = BlogCategory::where('slug', 'cms')->first();
        $digitalMarketingCategory = BlogCategory::where('slug', 'digital-marketing')->first();
        $technologyCategory = BlogCategory::where('slug', 'technology')->first();
        $businessCategory = BlogCategory::where('slug', 'business')->first();

        // Get existing blog tags (created by BlogTagSeeder)
        $laravelTag = BlogTag::where('slug', 'laravel')->first();
        $reactTag = BlogTag::where('slug', 'react')->first();
        $vueTag = BlogTag::where('slug', 'vue-js')->first();
        $jsTag = BlogTag::where('slug', 'javascript')->first();
        $phpTag = BlogTag::where('slug', 'php')->first();
        $seoTag = BlogTag::where('slug', 'seo')->first();
        $performanceTag = BlogTag::where('slug', 'performance')->first();
        $securityTag = BlogTag::where('slug', 'security')->first();
        $apiTag = BlogTag::where('slug', 'api')->first();
        $databaseTag = BlogTag::where('slug', 'database')->first();
        $uiuxTag = BlogTag::where('slug', 'ui-ux')->first();
        $mobileTag = BlogTag::where('slug', 'mobile')->first();
        $ecommerceTag = BlogTag::where('slug', 'e-commerce')->first();
        $cloudTag = BlogTag::where('slug', 'cloud')->first();
        $devopsTag = BlogTag::where('slug', 'devops')->first();

        $blog1 = Blog::updateOrCreate(
            ['slug' => 'modern-web-development-trends-2024'],
            [
                'title' => 'Modern Web Development Trends for 2024',
                'slug' => 'modern-web-development-trends-2024',
                'content' => '<h2>The Evolution of Web Development</h2><p>Web development continues to evolve at a rapid pace, with new technologies and methodologies emerging regularly. In 2024, we\'re seeing several key trends that are reshaping how we build and deploy web applications.</p><h2>Key Trends for 2024</h2><h3>1. AI-Powered Development</h3><p>Artificial intelligence is revolutionizing web development. From AI-assisted coding tools to intelligent content management systems, AI is helping developers work more efficiently and create better user experiences.</p><h3>2. Edge Computing</h3><p>Edge computing is becoming increasingly important for web applications. By processing data closer to users, applications can deliver faster response times and better performance.</p><h3>3. Progressive Web Apps (PWAs)</h3><p>PWAs continue to gain traction, offering app-like experiences in web browsers. They provide offline functionality, push notifications, and can be installed on users\' devices.</p><h3>4. Serverless Architecture</h3><p>Serverless computing allows developers to focus on code rather than infrastructure management. This approach offers scalability, cost efficiency, and faster development cycles.</p><h2>The Future of Web Development</h2><p>As we look ahead, the web development landscape will continue to evolve. Staying current with these trends will be crucial for developers and businesses alike. The key is to adopt new technologies thoughtfully, ensuring they align with business goals and user needs.</p>',
                'excerpt' => 'Explore the latest trends shaping web development in 2024, from AI integration to edge computing and beyond.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'The Evolution of Web Development',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Web development continues to evolve at a rapid pace, with new technologies and methodologies emerging regularly. In 2024, we\'re seeing several key trends that are reshaping how we build and deploy web applications.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Key Trends for 2024',
                        'level' => 2
                    ],
                    [
                        'type' => 'heading',
                        'content' => '1. AI-Powered Development',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Artificial intelligence is revolutionizing web development. From AI-assisted coding tools to intelligent content management systems, AI is helping developers work more efficiently and create better user experiences.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => '2. Edge Computing',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Edge computing is becoming increasingly important for web applications. By processing data closer to users, applications can deliver faster response times and better performance.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => '3. Progressive Web Apps (PWAs)',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'PWAs continue to gain traction, offering app-like experiences in web browsers. They provide offline functionality, push notifications, and can be installed on users\' devices.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => '4. Serverless Architecture',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Serverless computing allows developers to focus on code rather than infrastructure management. This approach offers scalability, cost efficiency, and faster development cycles.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'The Future of Web Development',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'As we look ahead, the web development landscape will continue to evolve. Staying current with these trends will be crucial for developers and businesses alike. The key is to adopt new technologies thoughtfully, ensuring they align with business goals and user needs.'
                    ]
                ],
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(5),
                'author_id' => 1,
                'category_id' => $webDevCategory->id
            ]
        );

        // Create SEO for Blog 1
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog1->id],
            [
                'meta_title' => 'Modern Web Development Trends for 2024 - SEVLENT Blog',
                'meta_description' => 'Explore the latest trends shaping web development in 2024, from AI integration to edge computing and beyond.',
                'meta_keywords' => 'web development trends, AI, edge computing, PWAs, serverless',
                'canonical_url' => '/blog/modern-web-development-trends-2024',
                'og_title' => 'Modern Web Development Trends for 2024',
                'og_description' => 'Explore the latest trends shaping web development in 2024.',
                'og_image' => null
            ]
        );

        $blog2 = Blog::updateOrCreate(
            ['slug' => 'building-scalable-cms-solutions'],
            [
                'title' => 'Building Scalable CMS Solutions: Best Practices',
                'slug' => 'building-scalable-cms-solutions',
                'content' => '<h2>The Importance of Scalable CMS Architecture</h2><p>In today\'s digital landscape, content management systems need to handle increasing amounts of content and traffic. Building a scalable CMS requires careful planning and the right architectural decisions from the start.</p><h2>Key Principles for Scalable CMS Design</h2><h3>1. Modular Architecture</h3><p>A modular architecture allows you to add features and functionality as needed without affecting the core system. This approach makes it easier to maintain and scale your CMS over time.</p><h3>2. Database Optimization</h3><p>Efficient database design is crucial for scalability. Consider using read replicas, caching strategies, and optimized queries to handle increased loads.</p><h3>3. Content Delivery Networks (CDNs)</h3><p>CDNs help distribute content globally, reducing latency and improving performance for users worldwide. They\'re essential for CMS solutions serving international audiences.</p><h3>4. Caching Strategies</h3><p>Implementing proper caching at multiple levels (browser, server, database) can significantly improve performance and reduce server load.</p><h2>Performance Optimization Techniques</h2><ul><li><strong>Image Optimization:</strong> Compress and serve images in modern formats</li><li><strong>Code Splitting:</strong> Load only the JavaScript and CSS you need</li><li><strong>Database Indexing:</strong> Ensure proper indexing for fast queries</li><li><strong>CDN Integration:</strong> Distribute static assets globally</li></ul><h2>Monitoring and Maintenance</h2><p>Regular monitoring and maintenance are essential for keeping your CMS performing well. Implement logging, error tracking, and performance monitoring to identify and address issues before they impact users.</p>',
                'excerpt' => 'Learn how to build content management systems that can grow with your business, from architecture decisions to performance optimization.',
                'content_blocks' => [
                    [
                        'type' => 'heading',
                        'content' => 'The Importance of Scalable CMS Architecture',
                        'level' => 2
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'In today\'s digital landscape, content management systems need to handle increasing amounts of content and traffic. Building a scalable CMS requires careful planning and the right architectural decisions from the start.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Key Principles for Scalable CMS Design',
                        'level' => 2
                    ],
                    [
                        'type' => 'heading',
                        'content' => '1. Modular Architecture',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'A modular architecture allows you to add features and functionality as needed without affecting the core system. This approach makes it easier to maintain and scale your CMS over time.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => '2. Database Optimization',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'Efficient database design is crucial for scalability. Consider using read replicas, caching strategies, and optimized queries to handle increased loads.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => '3. Content Delivery Networks (CDNs)',
                        'level' => 3
                    ],
                    [
                        'type' => 'paragraph',
                        'content' => 'CDNs help distribute content globally, reducing latency and improving performance for users worldwide. They\'re essential for CMS solutions serving international audiences.'
                    ],
                    [
                        'type' => 'heading',
                        'content' => 'Performance Optimization Techniques',
                        'level' => 2
                    ],
                    [
                        'type' => 'list',
                        'content' => 'Image Optimization: Compress and serve images in modern formats\nCode Splitting: Load only the JavaScript and CSS you need\nDatabase Indexing: Ensure proper indexing for fast queries\nCDN Integration: Distribute static assets globally',
                        'ordered' => false
                    ]
                ],
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(12),
                'author_id' => 1,
                'category_id' => $cmsCategory->id
            ]
        );

        $blog2->tags()->sync([$laravelTag->id, $phpTag->id, $performanceTag->id, $databaseTag->id]); // Laravel, PHP, Performance, Database

        // Create SEO for Blog 2
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog2->id],
            [
                'meta_title' => 'Building Scalable CMS Solutions: Best Practices',
                'meta_description' => 'Learn how to build content management systems that can grow with your business, from architecture decisions to performance optimization.',
                'meta_keywords' => 'CMS, scalability, architecture, performance, database optimization',
                'canonical_url' => '/blog/building-scalable-cms-solutions',
                'og_title' => 'Building Scalable CMS Solutions: Best Practices',
                'og_description' => 'Learn how to build scalable CMS solutions.',
                'og_image' => null
            ]
        );

        $blog3 = Blog::updateOrCreate(
            ['slug' => 'seo-strategies-for-modern-websites'],
            [
                'title' => 'SEO Strategies for Modern Websites in 2024',
                'slug' => 'seo-strategies-for-modern-websites',
                'content' => '<h2>The Evolving SEO Landscape</h2><p>Search engine optimization continues to evolve as search engines become more sophisticated. In 2024, SEO is about more than just keywords – it\'s about providing value and creating great user experiences.</p><h2>Core SEO Strategies</h2><h3>1. Technical SEO Fundamentals</h3><p>Technical SEO forms the foundation of any successful SEO strategy. This includes site speed optimization, mobile-friendliness, secure connections (HTTPS), and proper site structure.</p><h3>2. Content Optimization</h3><p>High-quality, relevant content remains king. Focus on creating comprehensive content that answers users\' questions and provides real value. Use natural language and semantic HTML.</p><h3>3. User Experience (UX) Signals</h3><p>Search engines now consider user experience as a ranking factor. This includes page load speed, mobile usability, and overall site usability.</p><h3>4. Local SEO</h3><p>For businesses serving local markets, local SEO is crucial. Optimize your Google My Business profile, get local citations, and create location-specific content.</p><h2>Advanced SEO Techniques</h2><ul><li><strong>Schema Markup:</strong> Help search engines understand your content</li><li><strong>Voice Search Optimization:</strong> Optimize for conversational queries</li><li><strong>Core Web Vitals:</strong> Meet Google\'s performance standards</li><li><strong>E-A-T Signals:</strong> Build expertise, authoritativeness, and trustworthiness</li></ul><h2>Measuring SEO Success</h2><p>Use tools like Google Analytics, Google Search Console, and SEO-specific tools to track your progress. Monitor key metrics like organic traffic, keyword rankings, and conversion rates.</p>',
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(18),
                'author_id' => 1,
                'category_id' => $digitalMarketingCategory->id
            ]
        );

        $blog3->tags()->sync([$seoTag->id, $performanceTag->id, $uiuxTag->id]); // SEO, Performance, UI/UX

        // Create SEO for Blog 3
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog3->id],
            [
                'meta_title' => 'SEO Strategies for Modern Websites in 2024',
                'meta_description' => 'Master the latest SEO techniques and strategies to improve your website\'s search engine rankings and drive more organic traffic.',
                'meta_keywords' => 'SEO, search engine optimization, website ranking, organic traffic',
                'canonical_url' => '/blog/seo-strategies-for-modern-websites',
                'og_title' => 'SEO Strategies for Modern Websites in 2024',
                'og_description' => 'Master the latest SEO techniques for better search rankings.',
                'og_image' => null
            ]
        );

        $blog4 = Blog::updateOrCreate(
            ['slug' => 'importance-of-mobile-first-design'],
            [
                'title' => 'The Importance of Mobile-First Design in 2024',
                'slug' => 'importance-of-mobile-first-design',
                'content' => '<h2>Mobile Dominance in Digital Usage</h2><p>Mobile devices now account for more than 60% of all internet usage worldwide. With this shift, designing for mobile first has become essential for any successful digital strategy.</p><h2>Why Mobile-First Design Matters</h2><h3>1. User Behavior</h3><p>Most users now access the internet primarily through mobile devices. Your website needs to work perfectly on these smaller screens to capture and retain users.</p><h3>2. SEO Benefits</h3><p>Google\'s mobile-first indexing means that your mobile version is now the primary version used for ranking. A mobile-optimized site is essential for good search rankings.</p><h3>3. Performance Considerations</h3><p>Mobile-first design forces you to prioritize performance from the start. This results in faster, more efficient websites that work better across all devices.</p><h2>Implementing Mobile-First Design</h2><h3>Progressive Enhancement</h3><p>Start with the mobile experience and progressively enhance for larger screens. This ensures your core functionality works on all devices.</p><h3>Responsive Design Principles</h3><p>Use flexible layouts, scalable images, and media queries to create designs that adapt to different screen sizes.</p><h3>Touch-Friendly Interfaces</h3><p>Design for touch interactions with appropriately sized buttons, swipe gestures, and intuitive navigation patterns.</p><h2>Tools and Technologies</h2><p>Modern frameworks like Bootstrap, Tailwind CSS, and CSS Grid make implementing mobile-first designs easier than ever. Combine these with testing tools to ensure your designs work across all devices.</p>',
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(25),
                'author_id' => 1,
                'category_id' => $webDevCategory->id
            ]
        );

        $blog4->tags()->sync([$jsTag->id, $performanceTag->id, $uiuxTag->id, $mobileTag->id]); // JavaScript, Performance, UI/UX, Mobile

        // Create SEO for Blog 4
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog4->id],
            [
                'meta_title' => 'The Importance of Mobile-First Design in 2024',
                'meta_description' => 'Why mobile-first design is essential for modern websites and how to implement it effectively in your development process.',
                'meta_keywords' => 'mobile-first design, responsive design, mobile optimization',
                'canonical_url' => '/blog/importance-of-mobile-first-design',
                'og_title' => 'The Importance of Mobile-First Design in 2024',
                'og_description' => 'Why mobile-first design matters for modern websites.',
                'og_image' => null
            ]
        );

        $blog5 = Blog::updateOrCreate(
            ['slug' => 'digital-transformation-success-stories'],
            [
                'title' => 'Digital Transformation Success Stories: Real Results',
                'slug' => 'digital-transformation-success-stories',
                'content' => '<h2>The Power of Digital Transformation</h2><p>Digital transformation isn\'t just about adopting new technology – it\'s about fundamentally changing how businesses operate. Here are some real success stories that demonstrate the impact of successful digital transformation initiatives.</p><h2>Case Study: Retail Chain Modernization</h2><p>A traditional retail chain was struggling with outdated inventory systems and manual processes. After implementing a comprehensive digital transformation:</p><ul><li><strong>Inventory accuracy improved by 95%</strong></li><li><strong>Order processing time reduced by 60%</strong></li><li><strong>Customer satisfaction scores increased by 40%</strong></li><li><strong>Annual savings of $2.3 million</strong></li></ul><h2>Case Study: Manufacturing Process Optimization</h2><p>A manufacturing company digitized their production processes with IoT sensors and AI-powered analytics:</p><ul><li><strong>Production efficiency increased by 35%</strong></li><li><strong>Downtime reduced by 50%</strong></li><li><strong>Quality control improved by 25%</strong></li><li><strong>Energy costs reduced by 20%</strong></li></ul><h2>Key Success Factors</h2><h3>1. Leadership Commitment</h3><p>Successful transformations require strong leadership commitment and clear vision from the top.</p><h3>2. Employee Engagement</h3><p>Involving employees throughout the transformation process ensures buy-in and successful adoption.</p><h3>3. Phased Implementation</h3><p>Breaking the transformation into manageable phases reduces risk and allows for course corrections.</p><h3>4. Technology Selection</h3><p>Choosing the right technologies that align with business goals and existing infrastructure.</p><h2>Measuring Success</h2><p>Track both quantitative metrics (ROI, efficiency gains) and qualitative measures (employee satisfaction, customer feedback) to get a complete picture of transformation success.</p>',
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(30),
                'author_id' => 1,
                'category_id' => $businessCategory->id
            ]
        );

        $blog5->tags()->sync([$cloudTag->id, $devopsTag->id, $performanceTag->id]); // Cloud, DevOps, Performance

        // Create SEO for Blog 5
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog5->id],
            [
                'meta_title' => 'Digital Transformation Success Stories: Real Results',
                'meta_description' => 'Explore real-world examples of successful digital transformations and learn from businesses that have successfully modernized their operations.',
                'meta_keywords' => 'digital transformation, case studies, business success, technology adoption',
                'canonical_url' => '/blog/digital-transformation-success-stories',
                'og_title' => 'Digital Transformation Success Stories',
                'og_description' => 'Real results from successful digital transformation initiatives.',
                'og_image' => null
            ]
        );

        $blog6 = Blog::updateOrCreate(
            ['slug' => 'api-security-best-practices'],
            [
                'title' => 'API Security Best Practices for Modern Applications',
                'slug' => 'api-security-best-practices',
                'content' => '<h2>The Importance of API Security</h2><p>As APIs become the backbone of modern applications, securing them is more critical than ever. A single security vulnerability can compromise entire systems and expose sensitive data.</p><h2>Authentication and Authorization</h2><h3>OAuth 2.0 Implementation</h3><p>OAuth 2.0 provides a secure framework for API authentication. Use it to delegate access without sharing credentials.</p><h3>JWT Tokens</h3><p>JSON Web Tokens provide a stateless authentication mechanism. Always validate tokens on the server side and implement proper expiration.</p><h3>API Keys</h3><p>For simpler use cases, API keys can provide basic authentication. Never transmit them in plain text and implement proper key management.</p><h2>Data Protection</h2><h3>Input Validation</h3><p>Always validate and sanitize input data to prevent injection attacks. Use parameterized queries and input validation libraries.</p><h3>Rate Limiting</h3><p>Implement rate limiting to prevent abuse and DoS attacks. Different endpoints may require different limits based on their sensitivity.</p><h3>Encryption</h3><p>Use HTTPS for all API communications. Encrypt sensitive data at rest and in transit.</p><h2>Monitoring and Logging</h2><h3>Security Monitoring</h3><p>Implement comprehensive logging and monitoring to detect suspicious activities. Set up alerts for unusual patterns.</p><h3>Regular Audits</h3><p>Conduct regular security audits and penetration testing to identify vulnerabilities before they can be exploited.</p><h2>Common Security Pitfalls to Avoid</h2><ul><li>Storing sensitive data in logs</li><li>Using outdated encryption methods</li><li>Exposing internal API endpoints</li><li>Insufficient error handling that leaks information</li><li>Weak password policies</li></ul><h2>Security Tools and Technologies</h2><p>Leverage security tools like OWASP ZAP, API gateways with built-in security features, and automated security testing tools to maintain robust API security.</p>',
                'featured_image' => null,
                'status' => 'published',
                'published_at' => now()->subDays(35),
                'author_id' => 1,
                'category_id' => $technologyCategory->id
            ]
        );

        $blog6->tags()->sync([$apiTag->id, $securityTag->id, $performanceTag->id]); // API, Security, Performance

        // Create SEO for Blog 6
        SeoMetadata::updateOrCreate(
            ['seoable_type' => Blog::class, 'seoable_id' => $blog6->id],
            [
                'meta_title' => 'API Security Best Practices for Modern Applications',
                'meta_description' => 'Learn essential security practices for protecting your APIs from common threats and ensuring data integrity in your applications.',
                'meta_keywords' => 'API security, authentication, encryption, rate limiting',
                'canonical_url' => '/blog/api-security-best-practices',
                'og_title' => 'API Security Best Practices',
                'og_description' => 'Essential security practices for protecting modern APIs.',
                'og_image' => null
            ]
        );
    }
}