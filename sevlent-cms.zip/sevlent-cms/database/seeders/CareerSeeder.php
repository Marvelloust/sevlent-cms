<?php

namespace Database\Seeders;

use App\Models\Career;
use Illuminate\Database\Seeder;

class CareerSeeder extends Seeder
{
    public function run(): void
    {
        // Senior Laravel Developer
        Career::updateOrCreate(
            ['slug' => 'senior-laravel-developer'],
            [
                'job_title' => 'Senior Laravel Developer',
                'slug' => 'senior-laravel-developer',
                'job_description' => '<p>We are seeking an experienced Senior Laravel Developer to join our dynamic team. In this role, you will be responsible for developing and maintaining complex web applications using the Laravel framework.</p><p>You will work closely with product managers, designers, and other developers to create scalable solutions that meet our clients\' needs. The ideal candidate has a deep understanding of PHP, Laravel best practices, and modern web development technologies.</p>',
                'requirements' => '<ul><li>4+ years of professional Laravel development experience</li><li>Expert knowledge of PHP 8+ and Laravel framework</li><li>Strong understanding of MySQL and database design</li><li>Experience building RESTful APIs</li><li>Proficiency with Git version control</li><li>Strong problem-solving and debugging skills</li><li>Excellent communication and teamwork abilities</li><li>Experience with Vue.js or React is a plus</li></ul>',
                'location' => 'Remote / Hybrid',
                'employment_type' => 'full-time',
                'department' => 'Engineering',
                'experience_level' => 'senior',
                'skills' => ['Laravel', 'PHP', 'MySQL', 'REST API', 'Vue.js', 'Git', 'Docker', 'AWS'],
                'benefits' => [
                    'Competitive salary and performance bonuses',
                    'Health, dental, and vision insurance',
                    'Flexible working hours',
                    'Remote work options',
                    'Professional development budget',
                    'Annual company retreats',
                    '401(k) matching',
                    'Unlimited PTO'
                ],
                'work_type' => 'remote',
                'number_of_openings' => 2,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>SEVLENT Software Solutions is a leading enterprise software development company specializing in custom CMS, web applications, and digital transformation solutions. We pride ourselves on delivering high-quality software that drives business value.</p>',
                'salary_range' => '$90,000 - $130,000',
                'application_deadline' => now()->addDays(30),
                'expiry_date' => now()->addDays(45),
                'status' => 'open'
            ]
        );

        // React Frontend Developer
        Career::updateOrCreate(
            ['slug' => 'react-frontend-developer'],
            [
                'job_title' => 'React Frontend Developer',
                'slug' => 'react-frontend-developer',
                'job_description' => '<p>Join our frontend team to build modern, responsive user interfaces using React and TypeScript. You will work on exciting projects that push the boundaries of web development.</p><p>We are looking for a passionate developer who stays current with the latest frontend trends and is committed to writing clean, maintainable code.</p>',
                'requirements' => '<ul><li>3+ years of professional React development experience</li><li>Strong knowledge of JavaScript ES6+ and TypeScript</li><li>Experience with state management (Redux, Context API)</li><li>Proficiency in HTML5, CSS3, and responsive design</li><li>Familiarity with RESTful APIs and GraphQL</li><li>Experience with modern build tools (Webpack, Vite)</li><li>Understanding of web performance optimization</li><li>Experience with Next.js is a plus</li></ul>',
                'location' => 'Remote',
                'employment_type' => 'full-time',
                'department' => 'Engineering',
                'experience_level' => 'mid-level',
                'skills' => ['React', 'TypeScript', 'JavaScript', 'HTML/CSS', 'Redux', 'Next.js', 'GraphQL'],
                'benefits' => [
                    'Competitive salary',
                    'Comprehensive health insurance',
                    'Work from anywhere',
                    'Learning and development stipend',
                    'Modern tech stack',
                    'Collaborative team environment',
                    'Flexible hours',
                    'Stock options'
                ],
                'work_type' => 'remote',
                'number_of_openings' => 1,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>At SEVLENT, we build software that makes a difference. Join a team of talented developers committed to excellence and innovation.</p>',
                'salary_range' => '$75,000 - $110,000',
                'application_deadline' => now()->addDays(45),
                'expiry_date' => now()->addDays(60),
                'status' => 'open'
            ]
        );

        // DevOps Engineer
        Career::updateOrCreate(
            ['slug' => 'devops-engineer'],
            [
                'job_title' => 'DevOps Engineer',
                'slug' => 'devops-engineer',
                'job_description' => '<p>We need a skilled DevOps Engineer to manage our cloud infrastructure and streamline our deployment processes. You will work with AWS, Docker, Kubernetes, and modern CI/CD tools.</p><p>The ideal candidate has a strong background in cloud infrastructure, automation, and loves solving complex technical challenges.</p>',
                'requirements' => '<ul><li>3+ years of DevOps or Cloud Infrastructure experience</li><li>Strong experience with AWS (EC2, S3, RDS, Lambda)</li><li>Proficiency with Docker and container orchestration</li><li>Experience with CI/CD pipelines (Jenkins, GitLab CI, GitHub Actions)</li><li>Knowledge of infrastructure as code (Terraform, CloudFormation)</li><li>Strong Linux/Unix administration skills</li><li>Experience with monitoring tools (Prometheus, Grafana, CloudWatch)</li><li>Kubernetes experience preferred</li></ul>',
                'location' => 'Hybrid',
                'employment_type' => 'full-time',
                'department' => 'Infrastructure',
                'experience_level' => 'mid-level',
                'skills' => ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'CI/CD', 'Linux', 'Python', 'Monitoring'],
                'benefits' => [
                    'Competitive salary with bonuses',
                    'Full health benefits',
                    'Hybrid work model',
                    'Certification reimbursement',
                    'Latest tools and technologies',
                    'Team building events',
                    'Career growth opportunities',
                    'Generous PTO'
                ],
                'work_type' => 'hybrid',
                'number_of_openings' => 1,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>SEVLENT is at the forefront of cloud technology and software innovation. Be part of a team that values continuous improvement and technical excellence.</p>',
                'salary_range' => '$85,000 - $120,000',
                'application_deadline' => now()->addDays(60),
                'expiry_date' => now()->addDays(75),
                'status' => 'open'
            ]
        );

        // UI/UX Designer
        Career::updateOrCreate(
            ['slug' => 'ui-ux-designer'],
            [
                'job_title' => 'UI/UX Designer',
                'slug' => 'ui-ux-designer',
                'job_description' => '<p>Create beautiful and intuitive user experiences for our web and mobile applications. You will work closely with developers and product managers to bring designs to life.</p><p>We are looking for a designer who is passionate about user-centered design and has a strong portfolio showcasing their work.</p>',
                'requirements' => '<ul><li>3+ years of UI/UX design experience</li><li>Strong portfolio demonstrating web and mobile design work</li><li>Proficiency with Figma or Sketch</li><li>Experience with prototyping tools</li><li>Understanding of user research methodologies</li><li>Knowledge of responsive and accessible design principles</li><li>Excellent communication and collaboration skills</li><li>Basic understanding of HTML/CSS is a plus</li></ul>',
                'location' => 'On-site',
                'employment_type' => 'full-time',
                'department' => 'Design',
                'experience_level' => 'mid-level',
                'skills' => ['UI Design', 'UX Design', 'Figma', 'Prototyping', 'User Research', 'Wireframing', 'Accessibility'],
                'benefits' => [
                    'Competitive salary',
                    'Health and wellness benefits',
                    'Creative work environment',
                    'Design conference attendance',
                    'Learning budget for courses',
                    'Modern design tools',
                    'Collaborative culture',
                    'Flexible scheduling'
                ],
                'work_type' => 'onsite',
                'number_of_openings' => 1,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>Join SEVLENT\'s design team and help shape the future of our products. We value creativity, user empathy, and attention to detail.</p>',
                'salary_range' => '$70,000 - $100,000',
                'application_deadline' => now()->addDays(30),
                'expiry_date' => now()->addDays(45),
                'status' => 'open'
            ]
        );

        // Project Manager
        Career::updateOrCreate(
            ['slug' => 'project-manager'],
            [
                'job_title' => 'Project Manager',
                'slug' => 'project-manager',
                'job_description' => '<p>Lead software development projects from planning to delivery. You will coordinate between clients, developers, and stakeholders to ensure successful project outcomes.</p><p>The ideal candidate has a technical background, strong organizational skills, and experience managing agile development teams.</p>',
                'requirements' => '<ul><li>4+ years of project management experience in software development</li><li>Strong understanding of Agile/Scrum methodologies</li><li>Excellent stakeholder management skills</li><li>Experience with project management tools (Jira, Asana, Trello)</li><li>Strong communication and leadership abilities</li><li>Technical background or CS degree preferred</li><li>PMP or CSM certification is a plus</li><li>Experience managing remote teams preferred</li></ul>',
                'location' => 'Hybrid',
                'employment_type' => 'full-time', 
                'department' => 'Project Management',
                'experience_level' => 'senior',
                'skills' => ['Project Management', 'Agile', 'Scrum', 'Stakeholder Management', 'Jira', 'Communication', 'Leadership'],
                'benefits' => [
                    'Competitive salary and bonuses',
                    'Comprehensive benefits package',
                    'Hybrid work flexibility',
                    'Professional certification support',
                    'Leadership development programs',
                    'Team events and outings',
                    'Growth opportunities',
                    'Work-life balance'
                ],
                'work_type' => 'hybrid',
                'number_of_openings' => 1,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>SEVLENT delivers complex software projects on time and within budget. Join our PM team and help drive project success.</p>',
                'salary_range' => '$85,000 - $115,000',
                'application_deadline' => now()->addDays(45),
                'expiry_date' => now()->addDays(60),
                'status' => 'open'
            ]
        );

        // Junior Full Stack Developer
        Career::updateOrCreate(
            ['slug' => 'junior-full-stack-developer'],
            [
                'job_title' => 'Junior Full Stack Developer',
                'slug' => 'junior-full-stack-developer',
                'job_description' => '<p>Start your career as a Full Stack Developer at SEVLENT. You will work on both frontend and backend technologies, learning from experienced developers while contributing to real projects.</p><p>This is a great opportunity for recent graduates or developers with 1-2 years of experience looking to grow their skills.</p>',
                'requirements' => '<ul><li>1-2 years of web development experience or relevant degree</li><li>Basic knowledge of JavaScript and a backend language (PHP, Node.js, or Python)</li><li>Understanding of HTML, CSS, and responsive design</li><li>Familiarity with Git version control</li><li>Basic understanding of databases (MySQL or PostgreSQL)</li><li>Eagerness to learn and grow</li><li>Good problem-solving skills</li><li>Team player with good communication</li></ul>',
                'location' => 'Remote',
                'employment_type' => 'full-time',
                'department' => 'Engineering',
                'experience_level' => 'entry-level',
                'skills' => ['JavaScript', 'HTML/CSS', 'PHP or Node.js', 'MySQL', 'Git'],
                'benefits' => [
                    'Competitive entry-level salary',
                    'Mentorship program',
                    'Health insurance',
                    'Remote work',
                    'Learning resources and courses',
                    'Career development path',
                    'Supportive team culture',
                    'Paid time off'
                ],
                'work_type' => 'remote',
                'number_of_openings' => 2,
                'contact_email' => 'careers@sevlent.com',
                'company_overview' => '<p>SEVLENT invests in developing talent. Join us and grow your career in a supportive, learning-focused environment.</p>',
                'salary_range' => '$55,000 - $75,000',
                'application_deadline' => now()->addDays(60),
                'expiry_date' => now()->addDays(75),
                'status' => 'open'
            ]
        );
    }
}