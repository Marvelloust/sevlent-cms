<?php

namespace Database\Seeders;

use App\Models\Page;
use App\Models\Section;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class HomepageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create homepage if it doesn't exist
        $page = Page::where('slug', 'home')->first();
        if (!$page) {
            $page = Page::create([
                'title' => 'Home',
                'slug' => 'home',
                'content' => 'Welcome to SEVLENT Software Solutions',
                'status' => 'published',
                'order_index' => 1,
                'created_by' => 1
            ]);
        }

        // Create default sections if none exist
        if ($page->sections()->count() === 0) {
            $sections = [
                [
                    'type' => 'hero',
                    'title' => 'Welcome Hero Section',
                    'content' => '',
                    'data' => [
                        'section_title' => 'Professional Software Solutions',
                        'headline' => 'Transform Your Digital Vision',
                        'subheadline' => 'Innovative technology solutions tailored for your success',
                        'description' => 'We deliver cutting-edge software solutions that empower businesses to scale, innovate, and succeed in the digital age.',
                        'primary_button_text' => 'Get Started',
                        'primary_button_url' => '/contact',
                        'secondary_button_text' => 'Learn More',
                        'secondary_button_url' => '/about',
                        'background_image' => null,
                        'stats' => [
                            ['number' => '500+', 'label' => 'Projects Delivered'],
                            ['number' => '98%', 'label' => 'Client Satisfaction'],
                            ['number' => '24/7', 'label' => 'Support Available']
                        ]
                    ],
                    'order_index' => 0,
                    'is_active' => true
                ],
                [
                    'type' => 'about',
                    'title' => 'About Us Section',
                    'content' => 'SEVLENT Software Solutions is a leading provider of innovative technology solutions. We specialize in web development, mobile applications, and enterprise software systems.',
                    'data' => [
                        'image' => null
                    ],
                    'order_index' => 1,
                    'is_active' => true
                ],
                [
                    'type' => 'services',
                    'title' => 'Our Services',
                    'content' => '',
                    'data' => [],
                    'order_index' => 2,
                    'is_active' => true
                ],
                [
                    'type' => 'content',
                    'title' => 'Why Choose Us',
                    'content' => '<h2>Why Choose SEVLENT?</h2><p>We deliver cutting-edge solutions with a focus on quality, innovation, and customer satisfaction. Our team of experts ensures that every project meets the highest standards.</p><ul><li>Expert Team</li><li>Latest Technologies</li><li>24/7 Support</li><li>Custom Solutions</li></ul>',
                    'data' => [],
                    'order_index' => 3,
                    'is_active' => true
                ],
                [
                    'type' => 'cta',
                    'title' => 'Contact Us Today',
                    'content' => '',
                    'data' => [
                        'headline' => 'Ready to Start Your Project?',
                        'subheadline' => 'Contact us today to discuss your requirements and get a free consultation.',
                        'button_text' => 'Contact Us',
                        'button_url' => '/contact'
                    ],
                    'order_index' => 4,
                    'is_active' => true
                ]
            ];

            foreach ($sections as $sectionData) {
                Section::create(array_merge($sectionData, ['page_id' => $page->id]));
            }
        }
    }
}
