<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('careers', function (Blueprint $table) {
            $table->string('department')->nullable()->after('employment_type');
            $table->string('experience_level')->nullable()->after('department');
            $table->json('skills')->nullable()->after('experience_level');
            $table->json('benefits')->nullable()->after('skills');
            $table->enum('work_type', ['remote', 'hybrid', 'onsite'])->default('onsite')->after('benefits');
            $table->integer('number_of_openings')->nullable()->after('work_type');
            $table->string('contact_email')->nullable()->after('number_of_openings');
            $table->text('company_overview')->nullable()->after('contact_email');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('careers', function (Blueprint $table) {
            $table->dropColumn([
                'department',
                'experience_level',
                'skills',
                'benefits',
                'work_type',
                'number_of_openings',
                'contact_email',
                'company_overview'
            ]);
        });
    }
};
