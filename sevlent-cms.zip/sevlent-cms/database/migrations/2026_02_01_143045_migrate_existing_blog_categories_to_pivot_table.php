<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Migrate existing category_id data to the pivot table
        $blogs = DB::table('blogs')->whereNotNull('category_id')->get();

        foreach ($blogs as $blog) {
            DB::table('blog_category')->insert([
                'blog_id' => $blog->id,
                'category_id' => $blog->category_id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Remove the migrated data from pivot table
        DB::table('blog_category')->delete();
    }
};
