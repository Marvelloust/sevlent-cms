<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('activities', function (Blueprint $table) {
            $table->id();
            $table->string('action'); // created, updated, deleted
            $table->string('model_type'); // App\Models\Page, App\Models\Blog, etc.
            $table->unsignedBigInteger('model_id');
            $table->string('model_name'); // Page, Blog, Service, etc.
            $table->string('title')->nullable(); // Title of the item
            $table->text('description')->nullable(); // Description of the activity
            $table->json('changes')->nullable(); // Store what changed (for updates)
            $table->unsignedBigInteger('user_id')->nullable(); // Who performed the action
            $table->string('user_name')->nullable(); // User's name
            $table->string('ip_address')->nullable(); // IP address
            $table->timestamps();

            $table->index(['model_type', 'model_id']);
            $table->index(['user_id']);
            $table->index(['created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('activities');
    }
};
