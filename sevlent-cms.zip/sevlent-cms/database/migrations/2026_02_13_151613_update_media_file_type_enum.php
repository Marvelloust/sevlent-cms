<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('media', function (Blueprint $table) {
            // Update the enum to include more file types
            DB::statement("ALTER TABLE media MODIFY COLUMN file_type ENUM('image', 'video', 'audio', 'document', 'archive', 'other')");
        });
    }

    public function down(): void
    {
        Schema::table('media', function (Blueprint $table) {
            // Revert back to original enum values
            DB::statement("ALTER TABLE media MODIFY COLUMN file_type ENUM('image', 'pdf', 'doc')");
        });
    }
};
