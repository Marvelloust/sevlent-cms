<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // For SQLite, we need to recreate the table since SQLite doesn't support MODIFY COLUMN with ENUM
        Schema::table('careers', function (Blueprint $table) {
            // Update existing data to new values
            DB::statement("UPDATE careers SET status = 'active' WHERE status = 'open'");
            DB::statement("UPDATE careers SET status = 'inactive' WHERE status = 'closed'");

            // Update employment_type casing to match validation rules
            DB::statement("UPDATE careers SET employment_type = LOWER(employment_type)");
        });

        // Note: In a production environment, you'd need to handle the enum change differently
        // For now, we'll just update the data and rely on application-level validation
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('careers', function (Blueprint $table) {
            // First expand enum to allow both old and new values
            DB::statement("ALTER TABLE careers MODIFY COLUMN status ENUM('open', 'closed', 'active', 'inactive') NOT NULL");

            // Then revert data back to original values
            DB::statement("UPDATE careers SET status = 'open' WHERE status = 'active'");
            DB::statement("UPDATE careers SET status = 'closed' WHERE status = 'inactive'");

            // Finally restrict enum to only original values
            DB::statement("ALTER TABLE careers MODIFY COLUMN status ENUM('open', 'closed') NOT NULL");
        });
    }
};
