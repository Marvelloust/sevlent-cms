<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('careers', function (Blueprint $table) {
            $table->longText('requirements')->nullable()->after('job_description');
            $table->string('salary_range')->nullable()->after('requirements');
            $table->date('application_deadline')->nullable()->after('salary_range');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('careers', function (Blueprint $table) {
            $table->dropColumn(['requirements', 'salary_range', 'application_deadline']);
        });
    }
};
