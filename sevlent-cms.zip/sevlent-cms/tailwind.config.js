import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    darkMode: 'class',
    
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        "./resources/**/*.js",
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', ...defaultTheme.fontFamily.sans],
            },
            fontSize: {
                // Display sizes - for large headlines
                'display-xs': ['2rem', { lineHeight: '2.5rem', letterSpacing: '-0.025em' }],
                'display-sm': ['2.25rem', { lineHeight: '2.75rem', letterSpacing: '-0.025em' }],
                'display-md': ['2.5rem', { lineHeight: '3rem', letterSpacing: '-0.025em' }],
                'display-lg': ['3rem', { lineHeight: '3.5rem', letterSpacing: '-0.025em' }],
                'display-xl': ['3.5rem', { lineHeight: '4rem', letterSpacing: '-0.025em' }],
                
                // Heading sizes - responsive
                'heading-xs': ['1.25rem', { lineHeight: '1.75rem', letterSpacing: '-0.01em' }],
                'heading-sm': ['1.5rem', { lineHeight: '2rem', letterSpacing: '-0.01em' }],
                'heading-md': ['1.75rem', { lineHeight: '2.25rem', letterSpacing: '-0.01em' }],
                'heading-lg': ['2rem', { lineHeight: '2.5rem', letterSpacing: '-0.01em' }],
                'heading-xl': ['2.25rem', { lineHeight: '2.75rem', letterSpacing: '-0.01em' }],
                'heading-2xl': ['2.5rem', { lineHeight: '3rem', letterSpacing: '-0.01em' }],
                'heading-3xl': ['2.75rem', { lineHeight: '3.25rem', letterSpacing: '-0.01em' }],
                
                // Body text sizes
                'body-xs': ['0.875rem', { lineHeight: '1.25rem' }],
                'body-sm': ['0.9375rem', { lineHeight: '1.375rem' }],
                'body-md': ['1rem', { lineHeight: '1.5rem' }],
                'body-lg': ['1.125rem', { lineHeight: '1.75rem' }],
                'body-xl': ['1.25rem', { lineHeight: '1.875rem' }],
                
                // Metric/Number sizes
                'metric-sm': ['1.875rem', { lineHeight: '2.25rem', letterSpacing: '-0.025em' }],
                'metric-md': ['2.25rem', { lineHeight: '2.75rem', letterSpacing: '-0.025em' }],
                'metric-lg': ['3rem', { lineHeight: '3.5rem', letterSpacing: '-0.025em' }],
                'metric-xl': ['3.75rem', { lineHeight: '4.25rem', letterSpacing: '-0.025em' }],
            },
            colors: {
                primary: {
                    50: '#eff6ff',
                    100: '#dbeafe',
                    200: '#bfdbfe',
                    300: '#93c5fd',
                    400: '#60a5fa',
                    500: '#3b82f6',
                    600: '#2563eb',
                    700: '#1d4ed8',
                    800: '#1e40af',
                    900: '#1e3a8a',
                },
                secondary: {
                    50: '#f8fafc',
                    100: '#f1f5f9',
                    200: '#e2e8f0',
                    300: '#cbd5e1',
                    400: '#94a3b8',
                    500: '#64748b',
                    600: '#475569',
                    700: '#334155',
                    800: '#1e293b',
                    900: '#0f172a',
                }
            },
            spacing: {
                '18': '4.5rem',
                '88': '22rem',
            },
            boxShadow: {
                'soft': '0 2px 15px -3px rgba(0, 0, 0, 0.07), 0 10px 20px -2px rgba(0, 0, 0, 0.04)',
                'medium': '0 4px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
            }
        },
    },

    plugins: [forms],
};
