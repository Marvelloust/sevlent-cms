<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

// Development login route (remove in production)
Route::get('/dev-login', function () {
    $user = \App\Models\User::where('email', 'admin@sevlent.com')->first();
    if ($user) {
        \Illuminate\Support\Facades\Auth::login($user);
        return redirect('/admin');
    }
    return 'Admin user not found';
});

// Development route to list admin users (remove in production)
Route::get('/admin-users', function () {
    $admins = \App\Models\User::with('roles')->whereHas('roles', function($q) {
        $q->whereIn('name', ['admin', 'super_admin']);
    })->get();

    return view('admin-users-list', compact('admins'));
});

// Admin Routes (must come before frontend routes)
Route::prefix('admin')->middleware(['auth', 'admin'])->group(function () {
    // Dashboard
    Route::get('/', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('admin.dashboard');

    // Analytics
    Route::get('analytics', [\App\Http\Controllers\Admin\AnalyticsController::class, 'index'])->name('admin.analytics.index');
    Route::get('analytics/export', [\App\Http\Controllers\Admin\AnalyticsController::class, 'export'])->name('admin.analytics.export');

    // Pages Management
    Route::resource('pages', \App\Http\Controllers\Admin\PageController::class)->names('admin.pages');
    Route::get('pages/{page}/sections', [\App\Http\Controllers\Admin\PageController::class, 'sections'])->name('admin.pages.sections.index');
    Route::get('pages/{page}/sections/{section}', [\App\Http\Controllers\Admin\PageController::class, 'showSection'])->name('admin.pages.sections.show');
    Route::post('pages/{page}/sections', [\App\Http\Controllers\Admin\PageController::class, 'storeSection'])->name('admin.pages.sections.store');
    Route::put('pages/{page}/sections/{section}', [\App\Http\Controllers\Admin\PageController::class, 'updateSection'])->name('admin.pages.sections.update');
    Route::patch('pages/{page}/sections/{section}/toggle', [\App\Http\Controllers\Admin\PageController::class, 'toggleSection'])->name('admin.pages.sections.toggle');
    Route::delete('pages/{page}/sections/{section}', [\App\Http\Controllers\Admin\PageController::class, 'destroySection'])->name('admin.pages.sections.destroy');
    Route::post('pages/{page}/sections/reorder', [\App\Http\Controllers\Admin\PageController::class, 'reorderSections'])->name('admin.pages.sections.reorder');

    // Services Management
    Route::resource('services', \App\Http\Controllers\Admin\ServiceController::class)->names('admin.services');

    // Blogs Management
    Route::resource('blogs', \App\Http\Controllers\Admin\BlogController::class)->names('admin.blogs');
    Route::resource('blog-categories', \App\Http\Controllers\Admin\BlogCategoryController::class)->names('admin.blog-categories');
    Route::resource('blog-tags', \App\Http\Controllers\Admin\BlogTagController::class)->names('admin.blog-tags');

    // Service Categories Management
    Route::resource('service-categories', \App\Http\Controllers\Admin\ServiceCategoryController::class)->names('admin.service-categories');

    // Media Management
    Route::resource('media', \App\Http\Controllers\Admin\MediaController::class)->names('admin.media');
    Route::delete('media-bulk-delete', [\App\Http\Controllers\Admin\MediaController::class, 'bulkDelete'])->name('admin.media.bulk-delete');
    Route::get('media-selector', [\App\Http\Controllers\Admin\MediaController::class, 'selector'])->name('admin.media.selector')->withoutMiddleware(['auth', 'admin']);
    Route::get('media-test', function () {
        return view('admin.media.test');
    })->name('admin.media.test');

    // Settings Management
    Route::get('settings', [\App\Http\Controllers\Admin\SettingsController::class, 'index'])->name('admin.settings.index');
    Route::put('settings', [\App\Http\Controllers\Admin\SettingsController::class, 'update'])->name('admin.settings.update');

    // Careers Management
    Route::resource('careers', \App\Http\Controllers\Admin\CareerController::class)->names('admin.careers');
    
    // Job Applications Management
    Route::resource('job-applications', \App\Http\Controllers\Admin\JobApplicationController::class)->names('admin.job-applications')->except(['create', 'store', 'edit']);

    // Contacts Management
    Route::resource('contacts', \App\Http\Controllers\Admin\ContactController::class)->names('admin.contacts')->only(['index', 'show', 'destroy']);
    Route::patch('contacts/{contact}/mark-read', [\App\Http\Controllers\Admin\ContactController::class, 'markRead'])->name('admin.contacts.mark-read');
    Route::get('contacts-export', [\App\Http\Controllers\Admin\ContactController::class, 'export'])->name('admin.contacts.export');

    // Contact Settings Management
    Route::get('contact-settings', [\App\Http\Controllers\Admin\ContactSettingController::class, 'index'])->name('admin.contact-settings.index');
    Route::put('contact-settings', [\App\Http\Controllers\Admin\ContactSettingController::class, 'update'])->name('admin.contact-settings.update');

    // Notifications Management
    Route::get('notifications', [\App\Http\Controllers\Admin\NotificationController::class, 'index'])->name('admin.notifications.index');
    Route::get('notifications/recent', [\App\Http\Controllers\Admin\NotificationController::class, 'getRecent'])->name('admin.notifications.recent');
    Route::post('notifications/{id}/mark-as-read', [\App\Http\Controllers\Admin\NotificationController::class, 'markAsRead'])->name('admin.notifications.mark-as-read');
    Route::post('notifications/mark-all-as-read', [\App\Http\Controllers\Admin\NotificationController::class, 'markAllAsRead'])->name('admin.notifications.mark-all-as-read');
    Route::delete('notifications/{id}', [\App\Http\Controllers\Admin\NotificationController::class, 'destroy'])->name('admin.notifications.destroy');
    Route::post('notifications/clear-read', [\App\Http\Controllers\Admin\NotificationController::class, 'clearRead'])->name('admin.notifications.clear-read');

    // FAQs Management
    Route::resource('faqs', \App\Http\Controllers\Admin\FaqController::class)->names('admin.faqs');

    // Projects Management
    Route::resource('projects', \App\Http\Controllers\Admin\ProjectController::class)->names('admin.projects');

    // Activities Management
    Route::get('activities', [\App\Http\Controllers\Admin\ActivityController::class, 'index'])->name('admin.activities.index');

    // Menus Management
    Route::resource('menus', \App\Http\Controllers\Admin\MenuController::class)->names('admin.menus');
    Route::post('menus/{menu}/items', [\App\Http\Controllers\Admin\MenuController::class, 'storeItem'])->name('admin.menus.items.store');
    Route::put('menus/{menu}/items/{item}', [\App\Http\Controllers\Admin\MenuController::class, 'updateItem'])->name('admin.menus.items.update');
    Route::delete('menus/{menu}/items/{item}', [\App\Http\Controllers\Admin\MenuController::class, 'destroyItem'])->name('admin.menus.items.destroy');
    Route::post('menus/{menu}/reorder', [\App\Http\Controllers\Admin\MenuController::class, 'reorder'])->name('admin.menus.reorder');

    // Users Management (Super Admin Only)
    Route::middleware('super_admin')->group(function () {
        Route::resource('users', \App\Http\Controllers\Admin\UserController::class)->names('admin.users');
        Route::patch('users/{user}/toggle-status', [\App\Http\Controllers\Admin\UserController::class, 'toggleStatus'])->name('admin.users.toggle-status');
        Route::post('users/{user}/assign-roles', [\App\Http\Controllers\Admin\UserController::class, 'assignRoles'])->name('admin.users.assign-roles');
    });

    // Homepage Builder
    Route::get('homepage', [\App\Http\Controllers\Admin\HomepageController::class, 'index'])->name('admin.homepage.index');
    Route::get('homepage/sections/{section}', [\App\Http\Controllers\Admin\HomepageController::class, 'show'])->name('admin.homepage.sections.show');
    Route::post('homepage/sections', [\App\Http\Controllers\Admin\HomepageController::class, 'store'])->name('admin.homepage.sections.store');
    Route::put('homepage/sections/{section}', [\App\Http\Controllers\Admin\HomepageController::class, 'update'])->name('admin.homepage.sections.update');
    Route::patch('homepage/sections/{section}/toggle', [\App\Http\Controllers\Admin\HomepageController::class, 'toggle'])->name('admin.homepage.sections.toggle');
    Route::delete('homepage/sections/{section}', [\App\Http\Controllers\Admin\HomepageController::class, 'destroy'])->name('admin.homepage.sections.destroy');
    Route::post('homepage/sections/reorder', [\App\Http\Controllers\Admin\HomepageController::class, 'reorder'])->name('admin.homepage.sections.reorder');
    Route::get('homepage/section-types', [\App\Http\Controllers\Admin\HomepageController::class, 'getSectionTypes'])->name('admin.homepage.section-types');
});

// Frontend Routes
Route::get('/', [App\Http\Controllers\Frontend\PageController::class, 'home'])->name('home');

// Services Routes
Route::get('/services', [App\Http\Controllers\Frontend\ServiceController::class, 'index'])->name('services.index');
Route::get('/services/{service}', [App\Http\Controllers\Frontend\ServiceController::class, 'show'])->name('services.show');

// Blogs Routes
Route::get('/blogs', [App\Http\Controllers\Frontend\BlogController::class, 'index'])->name('blogs.index');
Route::get('/blogs/{blog}', [App\Http\Controllers\Frontend\BlogController::class, 'show'])->name('blogs.show');

// Projects Routes
Route::get('/projects', [App\Http\Controllers\Frontend\ProjectController::class, 'index'])->name('projects.index');
Route::get('/projects/{project}', [App\Http\Controllers\Frontend\ProjectController::class, 'show'])->name('projects.show');

// Careers Routes
Route::get('/careers', [App\Http\Controllers\Frontend\CareerController::class, 'index'])->name('careers.index');
Route::get('/careers/{career}', [App\Http\Controllers\Frontend\CareerController::class, 'show'])->name('careers.show');
Route::post('/careers/{career}/apply', [App\Http\Controllers\Frontend\JobApplicationController::class, 'store'])->name('careers.apply');

// Contact Routes
Route::get('/contact', [App\Http\Controllers\Frontend\ContactController::class, 'index'])->name('contact.index');
Route::post('/contact', [App\Http\Controllers\Frontend\ContactController::class, 'store'])->name('contact.store');

Route::get('/{slug}', [App\Http\Controllers\Frontend\PageController::class, 'show'])->name('page');
