<?php

namespace App\Console\Commands;

use App\Services\NotificationService;
use Illuminate\Console\Command;

class TestNotificationEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:notification-email {--type=contact : Type of notification to test (contact, job_application, user)}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Test notification email system by creating a test notification';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $notificationService = app(NotificationService::class);
        $type = $this->option('type');

        $this->info("Testing {$type} notification email...");

        switch ($type) {
            case 'contact':
                // Create a mock contact object
                $contact = (object) [
                    'id' => 999,
                    'name' => 'Test User',
                    'email' => 'test@example.com',
                ];
                $notification = $notificationService->notifyNewContact($contact);
                break;

            case 'job_application':
                // Create a mock job application object
                $application = (object) [
                    'id' => 999,
                    'name' => 'Test Applicant',
                    'email' => 'applicant@example.com',
                    'career' => (object) [
                        'title' => 'Test Position'
                    ]
                ];
                $notification = $notificationService->notifyNewJobApplication($application);
                break;

            case 'user':
                // Create a mock user object
                $user = (object) [
                    'id' => 999,
                    'name' => 'Test User',
                    'email' => 'newuser@example.com',
                ];
                $notification = $notificationService->notifyNewUser($user);
                break;

            default:
                $this->error("Invalid notification type. Use: contact, job_application, or user");
                return 1;
        }

        $this->info("✅ Test notification created: {$notification->title}");
        $this->info("📧 Email sent to super admins");
        $this->info("🔍 Check your email inbox for the notification");

        return 0;
    }
}
