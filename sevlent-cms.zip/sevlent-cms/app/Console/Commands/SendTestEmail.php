<?php

namespace App\Console\Commands;

use App\Mail\TestEmail;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class SendTestEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'mail:test {email? : The email address to send test to}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send a test email to verify SMTP configuration';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $email = $this->argument('email') ?? 'marvellous@neegles.com';

        $this->info("Sending test email to: {$email}");

        try {
            Mail::to($email)->send(new TestEmail());
            $this->info('✅ Test email sent successfully!');
            $this->info('Check your inbox for the test email.');
        } catch (\Exception $e) {
            $this->error('❌ Failed to send test email:');
            $this->error($e->getMessage());
            $this->info('Possible issues:');
            $this->info('1. Gmail App Password is incorrect');
            $this->info('2. 2-Factor Authentication not enabled');
            $this->info('3. Gmail security settings blocking the connection');
            $this->info('4. Firewall/antivirus blocking SMTP connection');
        }

        return 0;
    }
}
