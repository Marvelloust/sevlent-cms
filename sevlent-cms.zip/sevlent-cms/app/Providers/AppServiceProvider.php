<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\Setting;

// Import models and observers
use App\Models\Page;
use App\Models\Service;
use App\Models\ServiceCategory;
use App\Models\Blog;
use App\Models\BlogCategory;
use App\Models\BlogTag;
use App\Models\Project;
use App\Models\Career;
use App\Models\Contact;
use App\Models\User;
use App\Models\JobApplication;
use App\Models\Media;
use App\Models\Menu;
use App\Models\MenuItem;
use App\Models\Faq;
use App\Models\Section;
use App\Models\SeoMetadata;
use App\Models\Role;
use App\Observers\PageObserver;
use App\Observers\ServiceObserver;
use App\Observers\ServiceCategoryObserver;
use App\Observers\BlogObserver;
use App\Observers\BlogCategoryObserver;
use App\Observers\BlogTagObserver;
use App\Observers\ProjectObserver;
use App\Observers\CareerObserver;
use App\Observers\ContactObserver;
use App\Observers\UserObserver;
use App\Observers\JobApplicationObserver;
use App\Observers\MediaObserver;
use App\Observers\MenuObserver;
use App\Observers\MenuItemObserver;
use App\Observers\FaqObserver;
use App\Observers\SettingObserver;
use App\Observers\SectionObserver;
use App\Observers\SeoMetadataObserver;
use App\Observers\RoleObserver;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Prevent caching to ensure theme changes apply immediately
        if (app()->environment('production')) {
            \Illuminate\Support\Facades\Response::macro('preventCache', function ($response) {
                return $response->header('Cache-Control', 'no-cache, no-store, must-revalidate')
                               ->header('Pragma', 'no-cache')
                               ->header('Expires', '0');
            });
        }
        
        // Make settings globally available to all views
        View::composer('*', function ($view) {
            $settings = Setting::pluck('value', 'key')->toArray();
            $view->with('settings', $settings);
        });

        // Register model observers for activity logging
        Page::observe(PageObserver::class);
        Service::observe(ServiceObserver::class);
        ServiceCategory::observe(ServiceCategoryObserver::class);
        Blog::observe(BlogObserver::class);
        BlogCategory::observe(BlogCategoryObserver::class);
        BlogTag::observe(BlogTagObserver::class);
        Project::observe(ProjectObserver::class);
        Career::observe(CareerObserver::class);
        Contact::observe(ContactObserver::class);
        User::observe(UserObserver::class);
        JobApplication::observe(JobApplicationObserver::class);
        Media::observe(MediaObserver::class);
        Menu::observe(MenuObserver::class);
        MenuItem::observe(MenuItemObserver::class);
        Faq::observe(FaqObserver::class);
        Setting::observe(SettingObserver::class);
        Section::observe(SectionObserver::class);
        SeoMetadata::observe(SeoMetadataObserver::class);
        Role::observe(RoleObserver::class);
    }
}
