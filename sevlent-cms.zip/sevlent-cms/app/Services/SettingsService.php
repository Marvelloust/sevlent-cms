<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Support\Facades\Cache;

class SettingsService
{
    /**
     * Get a setting value by key
     */
    public static function get(string $key, $default = null)
    {
        return Cache::rememberForever("setting_{$key}", function () use ($key, $default) {
            return Setting::where('key', $key)->value('value') ?? $default;
        });
    }

    /**
     * Set a setting value
     */
    public static function set(string $key, string $value, string $group = 'general'): void
    {
        Setting::updateOrCreate(
            ['key' => $key],
            ['value' => $value, 'group_name' => $group]
        );

        // Clear cache
        Cache::forget("setting_{$key}");
    }

    /**
     * Get all settings by group
     */
    public static function getGroup(string $group): array
    {
        return Cache::rememberForever("settings_group_{$group}", function () use ($group) {
            return Setting::where('group_name', $group)->pluck('value', 'key')->toArray();
        });
    }

    /**
     * Get all settings
     */
    public static function all(): array
    {
        return Cache::rememberForever('all_settings', function () {
            return Setting::all()->pluck('value', 'key')->toArray();
        });
    }

    /**
     * Clear all settings cache
     */
    public static function clearCache(): void
    {
        Cache::flush();
    }

    /**
     * Get company settings
     */
    public static function company(): array
    {
        return self::getGroup('branding');
    }

    /**
     * Get contact settings
     */
    public static function contact(): array
    {
        return self::getGroup('contact');
    }

    /**
     * Get SEO settings
     */
    public static function seo(): array
    {
        return self::getGroup('seo');
    }
}