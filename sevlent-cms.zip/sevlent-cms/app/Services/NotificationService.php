<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\User;
use App\Mail\AdminNotificationMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class NotificationService
{
    /**
     * Create a notification for new contact form submission
     */
    public function notifyNewContact($contact)
    {
        $notification = Notification::create([
            'type' => 'contact',
            'title' => 'New Contact Form Submission',
            'message' => "New message from {$contact->name} ({$contact->email})",
            'data' => [
                'contact_id' => $contact->id,
                'name' => $contact->name,
                'email' => $contact->email,
            ],
            'link' => route('admin.contacts.show', $contact->id),
            'icon' => 'envelope',
            'color' => 'blue',
        ]);

        $this->sendEmailNotification($notification);

        return $notification;
    }

    /**
     * Create a notification for new job application
     */
    public function notifyNewJobApplication($application)
    {
        $careerTitle = $application->career->job_title ?? ($application->career?->title ?? null);
        if (empty($careerTitle)) {
            $careerTitle = 'N/A';
        }

        $notification = Notification::create([
            'type' => 'job_application',
            'title' => 'New Job Application Received',
            'message' => "{$application->name} applied for {$careerTitle}",
            'data' => [
                'application_id' => $application->id,
                'name' => $application->name,
                'email' => $application->email,
                'position' => $careerTitle,
            ],
            'link' => route('admin.job-applications.show', $application->id),
            'icon' => 'briefcase',
            'color' => 'green',
        ]);

        $this->sendEmailNotification($notification);

        return $notification;
    }

    /**
     * Create a notification for new user registration
     */
    public function notifyNewUser($user)
    {
        $notification = Notification::create([
            'type' => 'user',
            'title' => 'New User Registered',
            'message' => "New user {$user->name} has registered",
            'data' => [
                'user_id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
            'link' => route('admin.users.show', $user->id),
            'icon' => 'user-plus',
            'color' => 'purple',
        ]);

        $this->sendEmailNotification($notification);

        return $notification;
    }

    /**
     * Create a custom notification
     */
    public function createNotification(array $data)
    {
        $notification = Notification::create([
            'type' => $data['type'] ?? 'general',
            'title' => $data['title'],
            'message' => $data['message'],
            'data' => $data['data'] ?? null,
            'link' => $data['link'] ?? null,
            'icon' => $data['icon'] ?? 'bell',
            'color' => $data['color'] ?? 'blue',
        ]);

        if ($data['send_email'] ?? true) {
            $this->sendEmailNotification($notification);
        }

        return $notification;
    }

    /**
     * Send email notification to all admin users
     */
    protected function sendEmailNotification($notification)
    {
        try {
            // Get all super admin users
            $admins = User::whereHas('roles', function ($query) {
                $query->where('name', 'super_admin');
            })->where('status', 'active')->get();

            foreach ($admins as $admin) {
                Mail::to($admin->email)->send(new AdminNotificationMail($notification, $admin));
            }
        } catch (\Exception $e) {
            Log::error('Failed to send notification email: ' . $e->getMessage());
        }
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($notificationId)
    {
        $notification = Notification::find($notificationId);
        if ($notification) {
            $notification->markAsRead();
        }
        return $notification;
    }

    /**
     * Mark all notifications as read
     */
    public function markAllAsRead()
    {
        return Notification::unread()->update([
            'is_read' => true,
            'read_at' => now(),
        ]);
    }

    /**
     * Delete old read notifications
     */
    public function deleteOldNotifications($days = 30)
    {
        return Notification::read()
            ->where('read_at', '<', now()->subDays($days))
            ->delete();
    }

    /**
     * Get unread notification count
     */
    public function getUnreadCount()
    {
        return Notification::unread()->count();
    }

    /**
     * Get recent notifications
     */
    public function getRecentNotifications($limit = 10)
    {
        return Notification::recent($limit)->get();
    }
}
