<?php

namespace App\Services;

use App\Models\Activity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

class ActivityLogger
{
    /**
     * Log an activity.
     */
    public static function log(string $action, Model $model, ?string $description = null, ?array $changes = null): Activity
    {
        $user = Auth::user();

        return Activity::create([
            'action' => $action,
            'model_type' => get_class($model),
            'model_id' => $model->getKey(),
            'model_name' => class_basename($model),
            'title' => self::getModelTitle($model),
            'description' => $description ?: self::generateDescription($action, $model),
            'changes' => $changes,
            'user_id' => $user?->id,
            'user_name' => $user?->name,
            'ip_address' => Request::ip(),
        ]);
    }

    /**
     * Get a readable title for the model.
     */
    protected static function getModelTitle(Model $model): string
    {
        $titleFields = [
            'Page' => 'title',
            'Service' => 'title',
            'Blog' => 'title',
            'BlogCategory' => 'name',
            'BlogTag' => 'name',
            'ServiceCategory' => 'name',
            'Project' => 'title',
            'Career' => 'title',
            'JobApplication' => 'name',
            'Contact' => 'subject',
            'User' => 'name',
            'Media' => 'name',
            'Menu' => 'name',
            'MenuItem' => 'label',
            'Faq' => 'question',
            'Setting' => 'key',
            'Section' => 'type',
            'SeoMetadata' => 'meta_title',
            'Role' => 'name',
        ];

        $modelName = class_basename($model);
        $titleField = $titleFields[$modelName] ?? 'id';

        return $model->$titleField ?? "ID: {$model->getKey()}";
    }

    /**
     * Generate a default description for the activity.
     */
    protected static function generateDescription(string $action, Model $model): string
    {
        $modelName = class_basename($model);
        $title = self::getModelTitle($model);

        return match($action) {
            'created' => "Created new {$modelName}: {$title}",
            'updated' => "Updated {$modelName}: {$title}",
            'deleted' => "Deleted {$modelName}: {$title}",
            default => "{$action} {$modelName}: {$title}",
        };
    }

    /**
     * Log model creation.
     */
    public static function created(Model $model): Activity
    {
        return self::log('created', $model);
    }

    /**
     * Log model update.
     */
    public static function updated(Model $model, ?array $changes = null): Activity
    {
        return self::log('updated', $model, null, $changes);
    }

    /**
     * Log model deletion.
     */
    public static function deleted(Model $model): Activity
    {
        return self::log('deleted', $model);
    }

    /**
     * Get recent activities for dashboard.
     */
    public static function getRecentActivities(int $limit = 5)
    {
        return Activity::with('user')->latest()->limit($limit)->get();
    }

    /**
     * Get all activities with pagination.
     */
    public static function getAllActivities(int $perPage = 50)
    {
        return Activity::with('user')->latest()->paginate($perPage);
    }
}