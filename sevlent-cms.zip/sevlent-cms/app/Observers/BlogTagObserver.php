<?php

namespace App\Observers;

use App\Models\BlogTag;
use App\Services\ActivityLogger;

class BlogTagObserver
{
    /**
     * Handle the BlogTag "created" event.
     */
    public function created(BlogTag $blogTag): void
    {
        ActivityLogger::created($blogTag);
    }

    /**
     * Handle the BlogTag "updated" event.
     */
    public function updated(BlogTag $blogTag): void
    {
        ActivityLogger::updated($blogTag);
    }

    /**
     * Handle the BlogTag "deleted" event.
     */
    public function deleted(BlogTag $blogTag): void
    {
        ActivityLogger::deleted($blogTag);
    }

    /**
     * Handle the BlogTag "restored" event.
     */
    public function restored(BlogTag $blogTag): void
    {
        ActivityLogger::log('restored', $blogTag, "Restored blog tag: {$blogTag->name}");
    }

    /**
     * Handle the BlogTag "force deleted" event.
     */
    public function forceDeleted(BlogTag $blogTag): void
    {
        ActivityLogger::log('force_deleted', $blogTag, "Permanently deleted blog tag: {$blogTag->name}");
    }
}
