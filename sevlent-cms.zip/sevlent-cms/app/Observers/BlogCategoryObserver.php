<?php

namespace App\Observers;

use App\Models\BlogCategory;
use App\Services\ActivityLogger;

class BlogCategoryObserver
{
    /**
     * Handle the BlogCategory "created" event.
     */
    public function created(BlogCategory $blogCategory): void
    {
        ActivityLogger::created($blogCategory);
    }

    /**
     * Handle the BlogCategory "updated" event.
     */
    public function updated(BlogCategory $blogCategory): void
    {
        ActivityLogger::updated($blogCategory);
    }

    /**
     * Handle the BlogCategory "deleted" event.
     */
    public function deleted(BlogCategory $blogCategory): void
    {
        ActivityLogger::deleted($blogCategory);
    }

    /**
     * Handle the BlogCategory "restored" event.
     */
    public function restored(BlogCategory $blogCategory): void
    {
        ActivityLogger::log('restored', $blogCategory, "Restored blog category: {$blogCategory->name}");
    }

    /**
     * Handle the BlogCategory "force deleted" event.
     */
    public function forceDeleted(BlogCategory $blogCategory): void
    {
        ActivityLogger::log('force_deleted', $blogCategory, "Permanently deleted blog category: {$blogCategory->name}");
    }
}
