<?php

namespace App\Observers;

use App\Models\SeoMetadata;
use App\Services\ActivityLogger;

class SeoMetadataObserver
{
    /**
     * Handle the SeoMetadata "created" event.
     */
    public function created(SeoMetadata $seoMetadata): void
    {
        ActivityLogger::created($seoMetadata);
    }

    /**
     * Handle the SeoMetadata "updated" event.
     */
    public function updated(SeoMetadata $seoMetadata): void
    {
        ActivityLogger::updated($seoMetadata);
    }

    /**
     * Handle the SeoMetadata "deleted" event.
     */
    public function deleted(SeoMetadata $seoMetadata): void
    {
        ActivityLogger::deleted($seoMetadata);
    }

    /**
     * Handle the SeoMetadata "restored" event.
     */
    public function restored(SeoMetadata $seoMetadata): void
    {
        ActivityLogger::log('restored', $seoMetadata, "Restored SEO metadata");
    }

    /**
     * Handle the SeoMetadata "force deleted" event.
     */
    public function forceDeleted(SeoMetadata $seoMetadata): void
    {
        ActivityLogger::log('force_deleted', $seoMetadata, "Permanently deleted SEO metadata");
    }
}
