<?php

namespace App\Observers;

use App\Models\Menu;
use App\Services\ActivityLogger;

class MenuObserver
{
    /**
     * Handle the Menu "created" event.
     */
    public function created(Menu $menu): void
    {
        ActivityLogger::created($menu);
    }

    /**
     * Handle the Menu "updated" event.
     */
    public function updated(Menu $menu): void
    {
        ActivityLogger::updated($menu);
    }

    /**
     * Handle the Menu "deleted" event.
     */
    public function deleted(Menu $menu): void
    {
        ActivityLogger::deleted($menu);
    }

    /**
     * Handle the Menu "restored" event.
     */
    public function restored(Menu $menu): void
    {
        ActivityLogger::log('restored', $menu, "Restored menu: {$menu->name}");
    }

    /**
     * Handle the Menu "force deleted" event.
     */
    public function forceDeleted(Menu $menu): void
    {
        ActivityLogger::log('force_deleted', $menu, "Permanently deleted menu: {$menu->name}");
    }
}
