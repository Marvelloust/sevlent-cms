<?php

namespace App\Observers;

use App\Models\Section;
use App\Services\ActivityLogger;

class SectionObserver
{
    /**
     * Handle the Section "created" event.
     */
    public function created(Section $section): void
    {
        ActivityLogger::created($section);
    }

    /**
     * Handle the Section "updated" event.
     */
    public function updated(Section $section): void
    {
        ActivityLogger::updated($section);
    }

    /**
     * Handle the Section "deleted" event.
     */
    public function deleted(Section $section): void
    {
        ActivityLogger::deleted($section);
    }

    /**
     * Handle the Section "restored" event.
     */
    public function restored(Section $section): void
    {
        ActivityLogger::log('restored', $section, "Restored section: {$section->type}");
    }

    /**
     * Handle the Section "force deleted" event.
     */
    public function forceDeleted(Section $section): void
    {
        ActivityLogger::log('force_deleted', $section, "Permanently deleted section: {$section->type}");
    }
}
