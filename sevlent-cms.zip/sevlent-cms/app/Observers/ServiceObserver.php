<?php

namespace App\Observers;

use App\Models\Service;
use App\Services\ActivityLogger;

class ServiceObserver
{
    /**
     * Handle the Service "created" event.
     */
    public function created(Service $service): void
    {
        ActivityLogger::created($service);
    }

    /**
     * Handle the Service "updated" event.
     */
    public function updated(Service $service): void
    {
        ActivityLogger::updated($service);
    }

    /**
     * Handle the Service "deleted" event.
     */
    public function deleted(Service $service): void
    {
        ActivityLogger::deleted($service);
    }

    /**
     * Handle the Service "restored" event.
     */
    public function restored(Service $service): void
    {
        ActivityLogger::log('restored', $service, "Restored service: {$service->title}");
    }

    /**
     * Handle the Service "force deleted" event.
     */
    public function forceDeleted(Service $service): void
    {
        ActivityLogger::log('force_deleted', $service, "Permanently deleted service: {$service->title}");
    }
}
