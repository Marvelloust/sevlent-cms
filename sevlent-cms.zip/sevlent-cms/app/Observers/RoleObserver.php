<?php

namespace App\Observers;

use App\Models\Role;
use App\Services\ActivityLogger;

class RoleObserver
{
    /**
     * Handle the Role "created" event.
     */
    public function created(Role $role): void
    {
        ActivityLogger::created($role);
    }

    /**
     * Handle the Role "updated" event.
     */
    public function updated(Role $role): void
    {
        ActivityLogger::updated($role);
    }

    /**
     * Handle the Role "deleted" event.
     */
    public function deleted(Role $role): void
    {
        ActivityLogger::deleted($role);
    }

    /**
     * Handle the Role "restored" event.
     */
    public function restored(Role $role): void
    {
        ActivityLogger::log('restored', $role, "Restored role: {$role->name}");
    }

    /**
     * Handle the Role "force deleted" event.
     */
    public function forceDeleted(Role $role): void
    {
        ActivityLogger::log('force_deleted', $role, "Permanently deleted role: {$role->name}");
    }
}
