<?php

namespace App\Observers;

use App\Models\Setting;
use App\Services\ActivityLogger;

class SettingObserver
{
    /**
     * Handle the Setting "created" event.
     */
    public function created(Setting $setting): void
    {
        ActivityLogger::created($setting);
    }

    /**
     * Handle the Setting "updated" event.
     */
    public function updated(Setting $setting): void
    {
        ActivityLogger::updated($setting);
        
        // Clear view cache when theme colors are updated
        if (in_array($setting->key, ['primary_color', 'secondary_color', 'accent_color'])) {
            \Illuminate\Support\Facades\Artisan::call('view:clear');
            \Illuminate\Support\Facades\Cache::forget('theme_colors');
        }
    }

    /**
     * Handle the Setting "deleted" event.
     */
    public function deleted(Setting $setting): void
    {
        ActivityLogger::deleted($setting);
    }

    /**
     * Handle the Setting "restored" event.
     */
    public function restored(Setting $setting): void
    {
        ActivityLogger::log('restored', $setting, "Restored setting: {$setting->key}");
    }

    /**
     * Handle the Setting "force deleted" event.
     */
    public function forceDeleted(Setting $setting): void
    {
        ActivityLogger::log('force_deleted', $setting, "Permanently deleted setting: {$setting->key}");
    }
}
