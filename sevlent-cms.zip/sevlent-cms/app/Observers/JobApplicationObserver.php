<?php

namespace App\Observers;

use App\Models\JobApplication;
use App\Services\ActivityLogger;

class JobApplicationObserver
{
    /**
     * Handle the JobApplication "created" event.
     */
    public function created(JobApplication $jobApplication): void
    {
        ActivityLogger::created($jobApplication);
    }

    /**
     * Handle the JobApplication "updated" event.
     */
    public function updated(JobApplication $jobApplication): void
    {
        ActivityLogger::updated($jobApplication);
    }

    /**
     * Handle the JobApplication "deleted" event.
     */
    public function deleted(JobApplication $jobApplication): void
    {
        ActivityLogger::deleted($jobApplication);
    }

    /**
     * Handle the JobApplication "restored" event.
     */
    public function restored(JobApplication $jobApplication): void
    {
        ActivityLogger::log('restored', $jobApplication, "Restored job application: {$jobApplication->name}");
    }

    /**
     * Handle the JobApplication "force deleted" event.
     */
    public function forceDeleted(JobApplication $jobApplication): void
    {
        ActivityLogger::log('force_deleted', $jobApplication, "Permanently deleted job application: {$jobApplication->name}");
    }
}
