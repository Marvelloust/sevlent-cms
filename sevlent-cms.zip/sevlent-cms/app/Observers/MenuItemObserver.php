<?php

namespace App\Observers;

use App\Models\MenuItem;
use App\Services\ActivityLogger;

class MenuItemObserver
{
    /**
     * Handle the MenuItem "created" event.
     */
    public function created(MenuItem $menuItem): void
    {
        ActivityLogger::created($menuItem);
    }

    /**
     * Handle the MenuItem "updated" event.
     */
    public function updated(MenuItem $menuItem): void
    {
        ActivityLogger::updated($menuItem);
    }

    /**
     * Handle the MenuItem "deleted" event.
     */
    public function deleted(MenuItem $menuItem): void
    {
        ActivityLogger::deleted($menuItem);
    }

    /**
     * Handle the MenuItem "restored" event.
     */
    public function restored(MenuItem $menuItem): void
    {
        ActivityLogger::log('restored', $menuItem, "Restored menu item: {$menuItem->label}");
    }

    /**
     * Handle the MenuItem "force deleted" event.
     */
    public function forceDeleted(MenuItem $menuItem): void
    {
        ActivityLogger::log('force_deleted', $menuItem, "Permanently deleted menu item: {$menuItem->label}");
    }
}
