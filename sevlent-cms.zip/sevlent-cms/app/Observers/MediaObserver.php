<?php

namespace App\Observers;

use App\Models\Media;
use App\Services\ActivityLogger;

class MediaObserver
{
    /**
     * Handle the Media "created" event.
     */
    public function created(Media $media): void
    {
        ActivityLogger::created($media);
    }

    /**
     * Handle the Media "updated" event.
     */
    public function updated(Media $media): void
    {
        ActivityLogger::updated($media);
    }

    /**
     * Handle the Media "deleted" event.
     */
    public function deleted(Media $media): void
    {
        ActivityLogger::deleted($media);
    }

    /**
     * Handle the Media "restored" event.
     */
    public function restored(Media $media): void
    {
        ActivityLogger::log('restored', $media, "Restored media: {$media->name}");
    }

    /**
     * Handle the Media "force deleted" event.
     */
    public function forceDeleted(Media $media): void
    {
        ActivityLogger::log('force_deleted', $media, "Permanently deleted media: {$media->name}");
    }
}
