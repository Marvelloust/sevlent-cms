<?php

namespace App\Observers;

use App\Models\Career;
use App\Services\ActivityLogger;

class CareerObserver
{
    /**
     * Handle the Career "created" event.
     */
    public function created(Career $career): void
    {
        ActivityLogger::created($career);
    }

    /**
     * Handle the Career "updated" event.
     */
    public function updated(Career $career): void
    {
        ActivityLogger::updated($career);
    }

    /**
     * Handle the Career "deleted" event.
     */
    public function deleted(Career $career): void
    {
        ActivityLogger::deleted($career);
    }

    /**
     * Handle the Career "restored" event.
     */
    public function restored(Career $career): void
    {
        ActivityLogger::log('restored', $career, "Restored career: {$career->title}");
    }

    /**
     * Handle the Career "force deleted" event.
     */
    public function forceDeleted(Career $career): void
    {
        ActivityLogger::log('force_deleted', $career, "Permanently deleted career: {$career->title}");
    }
}
