<?php

namespace App\Observers;

use App\Models\Page;
use App\Services\ActivityLogger;

class PageObserver
{
    /**
     * Handle the Page "created" event.
     */
    public function created(Page $page): void
    {
        ActivityLogger::created($page);
    }

    /**
     * Handle the Page "updated" event.
     */
    public function updated(Page $page): void
    {
        ActivityLogger::updated($page);
    }

    /**
     * Handle the Page "deleted" event.
     */
    public function deleted(Page $page): void
    {
        ActivityLogger::deleted($page);
    }

    /**
     * Handle the Page "restored" event.
     */
    public function restored(Page $page): void
    {
        ActivityLogger::log('restored', $page, "Restored page: {$page->title}");
    }

    /**
     * Handle the Page "force deleted" event.
     */
    public function forceDeleted(Page $page): void
    {
        ActivityLogger::log('force_deleted', $page, "Permanently deleted page: {$page->title}");
    }
}
