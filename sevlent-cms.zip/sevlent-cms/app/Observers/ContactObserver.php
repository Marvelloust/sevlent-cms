<?php

namespace App\Observers;

use App\Models\Contact;
use App\Services\ActivityLogger;

class ContactObserver
{
    /**
     * Handle the Contact "created" event.
     */
    public function created(Contact $contact): void
    {
        ActivityLogger::created($contact);
    }

    /**
     * Handle the Contact "updated" event.
     */
    public function updated(Contact $contact): void
    {
        ActivityLogger::updated($contact);
    }

    /**
     * Handle the Contact "deleted" event.
     */
    public function deleted(Contact $contact): void
    {
        ActivityLogger::deleted($contact);
    }

    /**
     * Handle the Contact "restored" event.
     */
    public function restored(Contact $contact): void
    {
        ActivityLogger::log('restored', $contact, "Restored contact: {$contact->subject}");
    }

    /**
     * Handle the Contact "force deleted" event.
     */
    public function forceDeleted(Contact $contact): void
    {
        ActivityLogger::log('force_deleted', $contact, "Permanently deleted contact: {$contact->subject}");
    }
}
