<?php

namespace App\Observers;

use App\Models\Faq;
use App\Services\ActivityLogger;

class FaqObserver
{
    /**
     * Handle the Faq "created" event.
     */
    public function created(Faq $faq): void
    {
        ActivityLogger::created($faq);
    }

    /**
     * Handle the Faq "updated" event.
     */
    public function updated(Faq $faq): void
    {
        ActivityLogger::updated($faq);
    }

    /**
     * Handle the Faq "deleted" event.
     */
    public function deleted(Faq $faq): void
    {
        ActivityLogger::deleted($faq);
    }

    /**
     * Handle the Faq "restored" event.
     */
    public function restored(Faq $faq): void
    {
        ActivityLogger::log('restored', $faq, "Restored FAQ: {$faq->question}");
    }

    /**
     * Handle the Faq "force deleted" event.
     */
    public function forceDeleted(Faq $faq): void
    {
        ActivityLogger::log('force_deleted', $faq, "Permanently deleted FAQ: {$faq->question}");
    }
}
