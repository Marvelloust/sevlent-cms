<?php

namespace App\Observers;

use App\Models\Project;
use App\Services\ActivityLogger;

class ProjectObserver
{
    /**
     * Handle the Project "created" event.
     */
    public function created(Project $project): void
    {
        ActivityLogger::created($project);
    }

    /**
     * Handle the Project "updated" event.
     */
    public function updated(Project $project): void
    {
        ActivityLogger::updated($project);
    }

    /**
     * Handle the Project "deleted" event.
     */
    public function deleted(Project $project): void
    {
        ActivityLogger::deleted($project);
    }

    /**
     * Handle the Project "restored" event.
     */
    public function restored(Project $project): void
    {
        ActivityLogger::log('restored', $project, "Restored project: {$project->title}");
    }

    /**
     * Handle the Project "force deleted" event.
     */
    public function forceDeleted(Project $project): void
    {
        ActivityLogger::log('force_deleted', $project, "Permanently deleted project: {$project->title}");
    }
}
