<?php

namespace App\Observers;

use App\Models\ServiceCategory;
use App\Services\ActivityLogger;

class ServiceCategoryObserver
{
    /**
     * Handle the ServiceCategory "created" event.
     */
    public function created(ServiceCategory $serviceCategory): void
    {
        ActivityLogger::created($serviceCategory);
    }

    /**
     * Handle the ServiceCategory "updated" event.
     */
    public function updated(ServiceCategory $serviceCategory): void
    {
        ActivityLogger::updated($serviceCategory);
    }

    /**
     * Handle the ServiceCategory "deleted" event.
     */
    public function deleted(ServiceCategory $serviceCategory): void
    {
        ActivityLogger::deleted($serviceCategory);
    }

    /**
     * Handle the ServiceCategory "restored" event.
     */
    public function restored(ServiceCategory $serviceCategory): void
    {
        ActivityLogger::log('restored', $serviceCategory, "Restored service category: {$serviceCategory->name}");
    }

    /**
     * Handle the ServiceCategory "force deleted" event.
     */
    public function forceDeleted(ServiceCategory $serviceCategory): void
    {
        ActivityLogger::log('force_deleted', $serviceCategory, "Permanently deleted service category: {$serviceCategory->name}");
    }
}
