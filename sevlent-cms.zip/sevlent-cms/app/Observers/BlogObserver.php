<?php

namespace App\Observers;

use App\Models\Blog;
use App\Services\ActivityLogger;

class BlogObserver
{
    /**
     * Handle the Blog "created" event.
     */
    public function created(Blog $blog): void
    {
        ActivityLogger::created($blog);
    }

    /**
     * Handle the Blog "updated" event.
     */
    public function updated(Blog $blog): void
    {
        ActivityLogger::updated($blog);
    }

    /**
     * Handle the Blog "deleted" event.
     */
    public function deleted(Blog $blog): void
    {
        ActivityLogger::deleted($blog);
    }

    /**
     * Handle the Blog "restored" event.
     */
    public function restored(Blog $blog): void
    {
        ActivityLogger::log('restored', $blog, "Restored blog: {$blog->title}");
    }

    /**
     * Handle the Blog "force deleted" event.
     */
    public function forceDeleted(Blog $blog): void
    {
        ActivityLogger::log('force_deleted', $blog, "Permanently deleted blog: {$blog->title}");
    }
}
