<?php

use App\Services\SettingsService;

if (!function_exists('setting')) {
    /**
     * Get a setting value
     */
    function setting(string $key, $default = null)
    {
        return SettingsService::get($key, $default);
    }
}

if (!function_exists('setting_set')) {
    /**
     * Set a setting value
     */
    function setting_set(string $key, string $value, string $group = 'general'): void
    {
        SettingsService::set($key, $value, $group);
    }
}

if (!function_exists('settings_group')) {
    /**
     * Get settings by group
     */
    function settings_group(string $group): array
    {
        return SettingsService::getGroup($group);
    }
}

if (!function_exists('company_setting')) {
    /**
     * Get company settings
     */
    function company_setting(string $key = null)
    {
        $settings = SettingsService::company();
        return $key ? ($settings[$key] ?? null) : $settings;
    }
}

if (!function_exists('contact_setting')) {
    /**
     * Get contact settings
     */
    function contact_setting(string $key = null)
    {
        $settings = SettingsService::contact();
        return $key ? ($settings[$key] ?? null) : $settings;
    }
}

if (!function_exists('seo_setting')) {
    /**
     * Get SEO settings
     */
    function seo_setting(string $key = null)
    {
        $settings = SettingsService::seo();
        return $key ? ($settings[$key] ?? null) : $settings;
    }
}