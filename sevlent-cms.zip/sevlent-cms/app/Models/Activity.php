<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Activity extends Model
{
    protected $fillable = [
        'action',
        'model_type',
        'model_id',
        'model_name',
        'title',
        'description',
        'changes',
        'user_id',
        'user_name',
        'ip_address',
    ];

    protected $casts = [
        'changes' => 'array',
    ];

    /**
     * Get the user that performed this activity.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the model that was affected by this activity.
     */
    public function model()
    {
        return $this->model_type::find($this->model_id);
    }

    /**
     * Get the URL for the affected model in admin.
     */
    public function getModelUrl(): string
    {
        $routes = [
            'Page' => 'admin.pages.show',
            'Service' => 'admin.services.show',
            'ServiceCategory' => 'admin.service-categories.show',
            'Blog' => 'admin.blogs.show',
            'BlogCategory' => 'admin.blog-categories.show',
            'BlogTag' => 'admin.blog-tags.show',
            'Project' => 'admin.projects.show',
            'Career' => 'admin.careers.show',
            'JobApplication' => 'admin.job-applications.show',
            'Contact' => 'admin.contacts.show',
            'User' => 'admin.users.show',
            'Media' => 'admin.media.show',
            'Menu' => 'admin.menus.show',
            'MenuItem' => 'admin.menus.show',
            'Faq' => 'admin.faqs.show',
            'Setting' => 'admin.settings.index',
            'Section' => '#',
            'SeoMetadata' => '#',
            'Role' => '#',
        ];

        if (isset($routes[$this->model_name])) {
            try {
                return route($routes[$this->model_name], $this->model_id);
            } catch (\Exception $e) {
                return '#';
            }
        }

        return '#';
    }

    /**
     * Get the icon class for this activity type.
     */
    public function icon(): string
    {
        $icons = [
            'Page' => 'fas fa-file-alt',
            'Service' => 'fas fa-cog',
            'ServiceCategory' => 'fas fa-tags',
            'Blog' => 'fas fa-blog',
            'BlogCategory' => 'fas fa-folder',
            'BlogTag' => 'fas fa-tag',
            'Project' => 'fas fa-project-diagram',
            'Career' => 'fas fa-briefcase',
            'JobApplication' => 'fas fa-user-tie',
            'Contact' => 'fas fa-envelope',
            'User' => 'fas fa-user',
            'Media' => 'fas fa-image',
            'Menu' => 'fas fa-bars',
            'MenuItem' => 'fas fa-list',
            'Faq' => 'fas fa-question-circle',
            'Setting' => 'fas fa-cog',
            'Section' => 'fas fa-th-large',
            'SeoMetadata' => 'fas fa-search',
            'Role' => 'fas fa-user-shield',
        ];

        return $icons[$this->model_name] ?? 'fas fa-circle';
    }

    /**
     * Get the color class for this activity action.
     */
    public function color(): string
    {
        return match($this->action) {
            'created' => 'green',
            'updated' => 'blue',
            'deleted' => 'red',
            default => 'gray',
        };
    }

    /**
     * Scope to get recent activities.
     */
    public function scopeRecent($query, $limit = 50)
    {
        return $query->latest()->limit($limit);
    }

    /**
     * Scope to filter by model type.
     */
    public function scopeForModel($query, $model)
    {
        return $query->where('model_type', get_class($model));
    }

    /**
     * Scope to filter by user.
     */
    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }
}
