<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Project extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'title',
        'slug',
        'description',
        'content_blocks',
        'technologies',
        'status'
    ];

    protected $casts = [
        'technologies' => 'array',
        'content_blocks' => 'array'
    ];

    public function media()
    {
        return $this->belongsToMany(Media::class, 'project_media');
    }

    public function seo()
    {
        return $this->morphOne(SeoMetadata::class, 'seoable');
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}