<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SeoMetadata extends Model
{
    protected $fillable = [
        'meta_title',
        'meta_description',
        'meta_keywords',
        'canonical_url',
        'og_title',
        'og_description',
        'og_image'
    ];

    public function seoable()
    {
        return $this->morphTo();
    }

    public function ogImage()
    {
        return $this->belongsTo(Media::class, 'og_image');
    }
}