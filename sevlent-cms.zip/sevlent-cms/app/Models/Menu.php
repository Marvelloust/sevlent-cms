<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    protected $fillable = ['name'];

    public function items()
    {
        return $this->hasMany(MenuItem::class)->orderBy('order_index');
    }

    public function topLevelItems()
    {
        return $this->hasMany(MenuItem::class)->whereNull('parent_id')->orderBy('order_index');
    }
}