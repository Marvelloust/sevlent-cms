<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobApplication extends Model
{
    protected $fillable = [
        'career_id',
        'name',
        'email',
        'phone',
        'linkedin',
        'cover_letter',
        'resume_path',
        'status',
        'notes'
    ];

    public function career()
    {
        return $this->belongsTo(Career::class);
    }
}
