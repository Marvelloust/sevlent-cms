<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    protected $fillable = [
        'page_id',
        'type',
        'title',
        'content',
        'data',
        'order_index',
        'is_active'
    ];

    protected $casts = [
        'data' => 'array',
        'is_active' => 'boolean'
    ];

    public function page()
    {
        return $this->belongsTo(Page::class);
    }
}