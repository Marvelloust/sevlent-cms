<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    protected $fillable = [
        'file_name',
        'file_path',
        'file_type',
        'mime_type',
        'file_size',
        'alt_text',
        'uploaded_by'
    ];

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function projects()
    {
        return $this->belongsToMany(\App\Models\Project::class, 'project_media');
    }

    public function services()
    {
        return $this->hasMany(\App\Models\Service::class, 'icon_image');
    }

    public function seoMetadata()
    {
        return $this->hasMany(\App\Models\SeoMetadata::class, 'og_image');
    }

    public function getUrlAttribute()
    {
        return asset('storage/' . $this->file_path);
    }
}