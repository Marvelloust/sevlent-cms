<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Service extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'service_category_id',
        'name',
        'slug',
        'short_description',
        'content_blocks',
        'features',
        'pricing_info',
        'icon_image',
        'status'
    ];

    protected $casts = [
        'content_blocks' => 'array',
        'features' => 'array',
        'pricing_info' => 'array',
    ];

    public function category()
    {
        return $this->belongsTo(ServiceCategory::class, 'service_category_id');
    }

    public function icon()
    {
        return $this->belongsTo(Media::class, 'icon_image');
    }

    public function seo()
    {
        return $this->morphOne(SeoMetadata::class, 'seoable');
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}