<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Page extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'title',
        'slug',
        'content',
        'banner_image',
        'status',
        'order_index',
        'created_by'
    ];

    public function sections()
    {
        return $this->hasMany(Section::class)->orderBy('order_index');
    }

    public function banner()
    {
        return $this->belongsTo(Media::class, 'banner_image');
    }

    public function seo()
    {
        return $this->morphOne(SeoMetadata::class, 'seoable');
    }
}