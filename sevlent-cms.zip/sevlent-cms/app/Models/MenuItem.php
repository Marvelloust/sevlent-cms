<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MenuItem extends Model
{
    protected $fillable = [
        'menu_id',
        'parent_id',
        'title',
        'url',
        'page_id',
        'target',
        'css_class',
        'icon',
        'order_index',
        'depth',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function menu()
    {
        return $this->belongsTo(Menu::class);
    }

    public function page()
    {
        return $this->belongsTo(Page::class);
    }

    public function parent()
    {
        return $this->belongsTo(MenuItem::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(MenuItem::class, 'parent_id')->orderBy('order_index');
    }

    public function allChildren()
    {
        return $this->children()->with('allChildren');
    }

    public function getUrlAttribute($value)
    {
        // If we have a page_id, return the page's slug
        if ($this->page_id && $this->page) {
            return '/' . $this->page->slug;
        }

        // Otherwise return the stored URL
        return $value;
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeTopLevel($query)
    {
        return $query->whereNull('parent_id');
    }
}