<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Career extends Model
{
    protected $fillable = [
        'job_title',
        'slug',
        'job_description',
        'requirements',
        'location',
        'employment_type',
        'department',
        'experience_level',
        'skills',
        'benefits',
        'work_type',
        'number_of_openings',
        'contact_email',
        'company_overview',
        'salary_range',
        'application_deadline',
        'expiry_date',
        'status'
    ];

    protected $casts = [
        'expiry_date' => 'date',
        'application_deadline' => 'date',
        'skills' => 'array',
        'benefits' => 'array'
    ];

    public function applications()
    {
        return $this->hasMany(JobApplication::class);
    }
}