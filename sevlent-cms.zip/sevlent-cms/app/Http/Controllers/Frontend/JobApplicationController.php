<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Career;
use App\Models\JobApplication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use App\Services\NotificationService;

class JobApplicationController extends Controller
{
    public function store(Request $request, $slug, NotificationService $notificationService)
    {
        $career = Career::where('slug', $slug)
            ->where('status', 'open')
            ->firstOrFail();

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:20',
            'linkedin' => 'nullable|url|max:255',
            'cover_letter' => 'nullable|string',
            'resume' => 'required|file|mimes:pdf,doc,docx|max:5120', // 5MB max
        ]);

        // Upload resume
        $resumePath = $request->file('resume')->store('resumes', 'public');

        // Create application
        $application = JobApplication::create([
            'career_id' => $career->id,
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'linkedin' => $request->linkedin,
            'cover_letter' => $request->cover_letter,
            'resume_path' => $resumePath,
            'status' => 'pending',
        ]);

        // Send notification to admins
        try {
            $notificationService->notifyNewJobApplication($application, $career);
        } catch (\Exception $e) {
            Log::error('Failed to send job application notification: ' . $e->getMessage());
        }

        return redirect()
            ->route('careers.show', $slug)
            ->with('success', 'Your application has been submitted successfully! We will review it and get back to you soon.');
    }
}
