<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Page;

class PageController extends Controller
{
    public function home()
    {
        $page = Page::where('slug', 'home')
            ->where('status', 'published')
            ->with(['sections' => function ($q) {
                $q->where('is_active', true)->orderBy('order_index');
            }, 'seo'])
            ->firstOrFail();

        return view('frontend.page', compact('page'));
    }

    public function services()
    {
        $page = Page::where('slug', 'services')
            ->where('status', 'published')
            ->with(['sections' => function ($q) {
                $q->where('is_active', true)->orderBy('order_index');
            }, 'seo'])
            ->firstOrFail();

        return view('frontend.page', compact('page'));
    }

    public function show($slug)
    {
        $page = Page::where('slug', $slug)
            ->where('status', 'published')
            ->with(['sections' => function ($q) {
                $q->where('is_active', true)->orderBy('order_index');
            }, 'seo'])
            ->firstOrFail();

        return view('frontend.page', compact('page'));
    }
}
