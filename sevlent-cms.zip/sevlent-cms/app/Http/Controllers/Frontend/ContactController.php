<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Setting;
use App\Models\Faq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use App\Mail\ContactFormSubmitted;
use App\Services\NotificationService;

class ContactController extends Controller
{
    public function index()
    {
        // Fetch contact settings
        $settingKeys = [
            'contact_address',
            'contact_phone',
            'contact_email',
            'contact_business_hours',
            'contact_map_url',
            'faq_section_title',
            'faq_section_subtitle',
            'faq_help_title',
            'faq_help_description',
            'faq_help_button_text',
        ];

        $contactSettings = Setting::whereIn('key', $settingKeys)
            ->pluck('value', 'key')
            ->toArray();

        // Provide defaults for missing settings
        $defaults = [
            'contact_address' => '123 Business Street\nSuite 100\nCity, State 12345',
            'contact_phone' => '(555) 123-4567',
            'contact_email' => 'info@sevlentcms.com',
            'contact_business_hours' => "Mon - Fri: 9:00 AM - 6:00 PM\nSaturday: 10:00 AM - 4:00 PM\nSunday: Closed",
            'contact_map_url' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.1234567890!2d-74.0059!3d40.7128!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDM4Ii44Ik4gNzTCsDMnMjEuMSJX!5e0!3m2!1sen!2sus!4v1234567890',
            'faq_section_title' => 'Frequently Asked Questions',
            'faq_section_subtitle' => 'Find answers to common questions about our services and get the information you need',
            'faq_help_title' => 'Didn\'t find what you were looking for?',
            'faq_help_description' => 'Feel free to contact us directly and we\'ll be happy to answer your questions.',
            'faq_help_button_text' => 'Get in Touch',
        ];

        // Merge defaults with actual settings
        $contactSettings = array_merge($defaults, $contactSettings);

        // Fetch active FAQs ordered by order field
        $faqs = Faq::active()->ordered()->get();

        return view('frontend.contact', compact('contactSettings', 'faqs'));
    }

    public function store(Request $request, NotificationService $notificationService)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:20',
            'subject' => 'required|string|max:255',
            'message' => 'required|string|max:2000',
        ]);

        // Create contact record
        $contact = Contact::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'] ?? null,
            'subject' => $validated['subject'],
            'message' => $validated['message'],
            'is_read' => false,
        ]);

        // Send email notification
        try {
            Mail::to(config('mail.admin_email', 'admin@example.com'))->send(new ContactFormSubmitted($contact));
        } catch (\Exception $e) {
            // Log the error but don't fail the request
            Log::error('Failed to send contact form email: ' . $e->getMessage());
        }

        // Send notification to admins
        try {
            $notificationService->notifyNewContact($contact);
        } catch (\Exception $e) {
            Log::error('Failed to send contact notification: ' . $e->getMessage());
        }

        return redirect()->back()->with('success', 'Thank you for your message! We\'ll get back to you soon.');
    }
}
