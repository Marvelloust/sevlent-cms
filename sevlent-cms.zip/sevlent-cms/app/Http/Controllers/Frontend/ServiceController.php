<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\ServiceCategory;

class ServiceController extends Controller
{
    public function index()
    {
        $query = Service::where('status', 'active')
            ->with(['category', 'icon']);

        // Filter by category if provided
        if (request('category')) {
            $query->whereHas('category', function($q) {
                $q->where('slug', request('category'))
                  ->where('status', 'active');
            });
        }

        $services = $query->orderBy('created_at', 'desc')->paginate(12);

        $categories = ServiceCategory::where('status', 'active')
            ->whereHas('services', function($q) {
                $q->where('status', 'active');
            })->get();

        return view('frontend.services.index', compact('services', 'categories'));
    }

    public function show($slug)
    {
        $service = Service::where('slug', $slug)
            ->where('status', 'active')
            ->with(['category', 'icon', 'seo'])
            ->firstOrFail();

        $relatedServices = Service::where('status', 'active')
            ->where('service_category_id', $service->service_category_id)
            ->where('id', '!=', $service->id)
            ->limit(3)
            ->get();

        return view('frontend.services.show', compact('service', 'relatedServices'));
    }
}
