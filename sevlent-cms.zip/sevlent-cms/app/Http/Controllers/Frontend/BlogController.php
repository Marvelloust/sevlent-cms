<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\BlogCategory;

class BlogController extends Controller
{
    public function index()
    {
        $query = Blog::where('status', 'published')
            ->with(['category', 'author', 'image']);

        // Filter by category if provided
        if (request('category')) {
            $query->whereHas('categories', function($q) {
                $q->where('slug', request('category'));
            });
        }

        $blogs = $query->orderBy('published_at', 'desc')->paginate(12);

        $categories = BlogCategory::whereHas('blogs', function($q) {
            $q->where('status', 'published');
        })->get();

        return view('frontend.blogs.index', compact('blogs', 'categories'));
    }

    public function show($slug)
    {
        $blog = Blog::where('slug', $slug)
            ->where('status', 'published')
            ->with(['category', 'author', 'image', 'seo'])
            ->firstOrFail();

        $relatedBlogs = Blog::where('status', 'published')
            ->where('category_id', $blog->category_id)
            ->where('id', '!=', $blog->id)
            ->orderBy('published_at', 'desc')
            ->limit(3)
            ->get();

        return view('frontend.blogs.show', compact('blog', 'relatedBlogs'));
    }
}
