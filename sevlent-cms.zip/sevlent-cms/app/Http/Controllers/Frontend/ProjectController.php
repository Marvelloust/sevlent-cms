<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Project;

class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::where('status', 'active')
            ->with(['media', 'seo'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        return view('frontend.projects.index', compact('projects'));
    }

    public function show($slug)
    {
        $project = Project::where('slug', $slug)
            ->where('status', 'active')
            ->with(['media', 'seo'])
            ->firstOrFail();

        $relatedProjects = Project::where('status', 'active')
            ->where('id', '!=', $project->id)
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();

        return view('frontend.projects.show', compact('project', 'relatedProjects'));
    }
}
