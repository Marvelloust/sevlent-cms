<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Career;

class CareerController extends Controller
{
    public function index()
    {
        $careers = Career::where('status', 'open')
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        return view('frontend.careers.index', compact('careers'));
    }

    public function show($slug)
    {
        $career = Career::where('slug', $slug)
            ->where('status', 'open')
            ->firstOrFail();

        $relatedCareers = Career::where('status', 'open')
            ->where('id', '!=', $career->id)
            ->orderBy('created_at', 'desc')
            ->limit(3)
            ->get();

        return view('frontend.careers.show', compact('career', 'relatedCareers'));
    }
}
