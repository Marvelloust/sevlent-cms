<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BlogController extends Controller
{
    public function index(Request $request)
    {
        $query = Blog::with(['author', 'categories', 'image']);

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%")
                  ->orWhere('excerpt', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Category filter
        if ($request->filled('category') && $request->category !== 'all') {
            $query->whereHas('categories', function ($q) use ($request) {
                $q->where('blog_categories.id', $request->category);
            });
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');

        // Validate sort parameters
        $allowedSorts = ['title', 'slug', 'status', 'created_at', 'updated_at', 'published_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'created_at';
        }

        $query->orderBy($sortBy, $sortDirection);

        $blogs = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalBlogs = Blog::count();
        $publishedBlogs = Blog::where('status', 'published')->count();
        $draftBlogs = Blog::where('status', 'draft')->count();

        // Get categories for filter dropdown
        $categories = \App\Models\BlogCategory::orderBy('name')->get();

        return view('admin.blogs.index', compact('blogs', 'totalBlogs', 'publishedBlogs', 'draftBlogs', 'categories'));
    }

    public function create()
    {
        $categories = \App\Models\BlogCategory::all();
        $tags = \App\Models\BlogTag::all();
        return view('admin.blogs.create', compact('categories', 'tags'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:blogs',
            'excerpt' => 'nullable|string|max:500',
            'content_blocks' => 'nullable|array',
            'content_blocks.*.type' => 'required|in:heading,paragraph,image,list,link',
            'content_blocks.*.content' => 'nullable|string',
            'content_blocks.*.image' => 'nullable|string',
            'content_blocks.*.link_text' => 'nullable|string',
            'featured_image' => 'nullable|exists:media,id',
            'categories' => 'nullable|array',
            'categories.*' => 'exists:blog_categories,id',
            'tags' => 'nullable|array',
            'tags.*' => 'exists:blog_tags,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:draft,published',
            'published_at' => 'nullable|date',
        ]);

        // Process content blocks
        $contentBlocks = [];
        if ($request->has('content_blocks')) {
            foreach ($request->content_blocks as $block) {
                if ($block['type'] === 'link' && isset($block['link_text'])) {
                    $contentBlocks[] = [
                        'type' => $block['type'],
                        'content' => $block['link_text'] . '|' . ($block['content'] ?? ''),
                        'image' => $block['image'] ?? null,
                    ];
                } else {
                    $contentBlocks[] = [
                        'type' => $block['type'],
                        'content' => $block['content'] ?? '',
                        'image' => $block['image'] ?? null,
                    ];
                }
            }
        }

        $blog = Blog::create([
            'title' => $request->title,
            'slug' => $request->slug,
            'excerpt' => $request->excerpt,
            'content' => '', // Keep for backward compatibility
            'content_blocks' => $contentBlocks,
            'featured_image' => $request->featured_image,
            'author_id' => auth()->id(),
            'status' => $request->status,
            'published_at' => $request->published_at,
        ]);

        if ($request->categories) {
            $blog->categories()->attach($request->categories);
        }

        if ($request->tags) {
            $blog->tags()->attach($request->tags);
        }

        // Create SEO metadata
        if ($request->filled(['meta_title', 'meta_description', 'meta_keywords', 'canonical_url', 'og_title', 'og_description', 'og_image'])) {
            $blog->seo()->create([
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'meta_keywords' => $request->meta_keywords,
                'canonical_url' => $request->canonical_url,
                'og_title' => $request->og_title,
                'og_description' => $request->og_description,
                'og_image' => $request->og_image,
            ]);
        }

        return redirect()->route('admin.blogs.index')->with('success', 'Blog created successfully.');
    }

    public function show(Blog $blog)
    {
        $blog->load(['categories', 'tags', 'author', 'seo.ogImage']);
        return view('admin.blogs.show', compact('blog'));
    }

    public function edit(Blog $blog)
    {
        $categories = \App\Models\BlogCategory::all();
        $tags = \App\Models\BlogTag::all();
        $blog->load(['categories', 'tags', 'author', 'seo.ogImage']);
        return view('admin.blogs.edit', compact('blog', 'categories', 'tags'));
    }

    public function update(Request $request, Blog $blog)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:blogs,slug,' . $blog->id,
            'excerpt' => 'nullable|string|max:500',
            'content_blocks' => 'nullable|array',
            'content_blocks.*.type' => 'required|in:heading,paragraph,image,list,link',
            'content_blocks.*.content' => 'nullable|string',
            'content_blocks.*.image' => 'nullable|string',
            'content_blocks.*.link_text' => 'nullable|string',
            'featured_image' => 'nullable|exists:media,id',
            'categories' => 'nullable|array',
            'categories.*' => 'exists:blog_categories,id',
            'tags' => 'nullable|array',
            'tags.*' => 'exists:blog_tags,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:draft,published',
            'published_at' => 'nullable|date',
        ]);

        // Process content blocks
        $contentBlocks = [];
        if ($request->has('content_blocks')) {
            foreach ($request->content_blocks as $block) {
                if ($block['type'] === 'link' && isset($block['link_text'])) {
                    $contentBlocks[] = [
                        'type' => $block['type'],
                        'content' => $block['link_text'] . '|' . ($block['content'] ?? ''),
                        'image' => $block['image'] ?? null,
                    ];
                } else {
                    $contentBlocks[] = [
                        'type' => $block['type'],
                        'content' => $block['content'] ?? '',
                        'image' => $block['image'] ?? null,
                    ];
                }
            }
        }

        $blog->update([
            'title' => $request->title,
            'slug' => $request->slug,
            'excerpt' => $request->excerpt,
            'content' => '', // Keep for backward compatibility
            'content_blocks' => $contentBlocks,
            'featured_image' => $request->featured_image,
            'status' => $request->status,
            'published_at' => $request->published_at,
        ]);

        $blog->categories()->sync($request->categories ?? []);
        $blog->tags()->sync($request->tags ?? []);

        // Update or create SEO metadata
        $seoData = [
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
            'meta_keywords' => $request->meta_keywords,
            'canonical_url' => $request->canonical_url,
            'og_title' => $request->og_title,
            'og_description' => $request->og_description,
            'og_image' => $request->og_image,
        ];

        if ($blog->seo) {
            $blog->seo->update($seoData);
        } else {
            $blog->seo()->create($seoData);
        }

        return redirect()->route('admin.blogs.index')->with('success', 'Blog updated successfully.');
    }

    public function destroy(Blog $blog)
    {
        if ($blog->featured_image) {
            Storage::disk('public')->delete($blog->featured_image);
        }
        $blog->delete();

        return redirect()->route('admin.blogs.index')->with('success', 'Blog deleted successfully.');
    }
}
