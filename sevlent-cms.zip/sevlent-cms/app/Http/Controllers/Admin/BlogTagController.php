<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BlogTag;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BlogTagController extends Controller
{
    public function index(Request $request)
    {
        $query = BlogTag::withCount('blogs');

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%");
            });
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'name');
        $sortDirection = $request->get('sort_direction', 'asc');

        // Validate sort parameters
        $allowedSorts = ['name', 'slug', 'blogs_count', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'name';
        }

        $query->orderBy($sortBy, $sortDirection);

        $tags = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalTags = BlogTag::count();
        $tagsWithBlogs = BlogTag::has('blogs')->count();
        $emptyTags = BlogTag::doesntHave('blogs')->count();

        return view('admin.blog-tags.index', compact('tags', 'totalTags', 'tagsWithBlogs', 'emptyTags'));
    }

    public function create()
    {
        return view('admin.blog-tags.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:blog_tags,name',
            'slug' => 'nullable|string|max:255|unique:blog_tags,slug',
        ]);

        $validated['slug'] = $validated['slug'] ?? Str::slug($validated['name']);

        BlogTag::create($validated);

        return redirect()->route('admin.blog-tags.index')
            ->with('success', 'Blog tag created successfully.');
    }

    public function edit(BlogTag $blogTag)
    {
        return view('admin.blog-tags.edit', compact('blogTag'));
    }

    public function update(Request $request, BlogTag $blogTag)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:blog_tags,name,' . $blogTag->id,
            'slug' => 'nullable|string|max:255|unique:blog_tags,slug,' . $blogTag->id,
        ]);

        $validated['slug'] = $validated['slug'] ?? Str::slug($validated['name']);

        $blogTag->update($validated);

        return redirect()->route('admin.blog-tags.index')
            ->with('success', 'Blog tag updated successfully.');
    }

    public function destroy(BlogTag $blogTag)
    {
        if ($blogTag->blogs()->count() > 0) {
            return back()->with('error', 'Cannot delete tag with associated blogs.');
        }

        $blogTag->delete();

        return redirect()->route('admin.blog-tags.index')
            ->with('success', 'Blog tag deleted successfully.');
    }
}
