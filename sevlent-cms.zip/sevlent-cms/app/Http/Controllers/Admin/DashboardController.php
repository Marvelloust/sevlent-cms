<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ActivityLogger;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        try {
            // Get recent activities using the ActivityLogger service
            $recentActivities = ActivityLogger::getRecentActivities(5);

            return view('admin.dashboard', compact('recentActivities'));
        } catch (\Exception $e) {
            // Fallback to empty activities if there's an error
            $recentActivities = collect();
            return view('admin.dashboard', compact('recentActivities'));
        }
    }
}