<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Career;
use Illuminate\Http\Request;

class CareerController extends Controller
{
    public function index(Request $request)
    {
        $query = Career::query();

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('job_title', 'like', "%{$search}%")
                  ->orWhere('location', 'like', "%{$search}%")
                  ->orWhere('department', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Employment type filter
        if ($request->filled('employment_type') && $request->employment_type !== 'all') {
            $query->where('employment_type', $request->employment_type);
        }

        // Work type filter
        if ($request->filled('work_type') && $request->work_type !== 'all') {
            $query->where('work_type', $request->work_type);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');

        // Validate sort parameters
        $allowedSorts = ['job_title', 'location', 'employment_type', 'work_type', 'status', 'expiry_date', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'created_at';
        }

        $query->orderBy($sortBy, $sortDirection);

        $careers = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalCareers = Career::count();
        $openCareers = Career::where('status', 'open')->count();
        $closedCareers = Career::where('status', 'closed')->count();
        $expiringSoon = Career::where('status', 'open')
            ->where('expiry_date', '>=', now())
            ->where('expiry_date', '<=', now()->addDays(7))
            ->count();

        return view('admin.careers.index', compact('careers', 'totalCareers', 'openCareers', 'closedCareers', 'expiringSoon'));
    }

    public function create()
    {
        return view('admin.careers.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'job_title' => 'required|string|max:255',
            'job_description' => 'nullable|string',
            'requirements' => 'nullable|string',
            'location' => 'nullable|string|max:255',
            'employment_type' => 'required|in:full-time,part-time,contract,freelance',
            'department' => 'nullable|string|max:255',
            'experience_level' => 'nullable|in:entry-level,mid-level,senior-level,executive',
            'skills' => 'nullable|string',
            'benefits' => 'nullable|string',
            'work_type' => 'required|in:remote,hybrid,onsite',
            'number_of_openings' => 'nullable|integer|min:1',
            'contact_email' => 'nullable|email|max:255',
            'company_overview' => 'nullable|string',
            'salary_range' => 'nullable|string|max:255',
            'application_deadline' => 'nullable|date|after:today',
            'expiry_date' => 'nullable|date|after:today',
            'status' => 'required|in:open,closed',
        ]);

        $data = $request->all();
        $data['slug'] = \Str::slug($request->job_title);

        // Handle JSON fields
        if ($request->filled('skills')) {
            $data['skills'] = array_filter(array_map('trim', explode(',', $request->skills)), function($skill) {
                return !empty($skill);
            });
        }
        if ($request->filled('benefits')) {
            $data['benefits'] = array_filter(array_map('trim', explode(',', $request->benefits)), function($benefit) {
                return !empty($benefit);
            });
        }

        Career::create($data);

        return redirect()->route('admin.careers.index')->with('success', 'Career created successfully.');
    }

    public function show(Career $career)
    {
        return view('admin.careers.show', compact('career'));
    }

    public function edit(Career $career)
    {
        return view('admin.careers.edit', compact('career'));
    }

    public function update(Request $request, Career $career)
    {
        $request->validate([
            'job_title' => 'required|string|max:255',
            'job_description' => 'nullable|string',
            'requirements' => 'nullable|string',
            'location' => 'nullable|string|max:255',
            'employment_type' => 'required|in:full-time,part-time,contract,freelance',
            'department' => 'nullable|string|max:255',
            'experience_level' => 'nullable|in:entry-level,mid-level,senior-level,executive',
            'skills' => 'nullable|string',
            'benefits' => 'nullable|string',
            'work_type' => 'required|in:remote,hybrid,onsite',
            'number_of_openings' => 'nullable|integer|min:1',
            'contact_email' => 'nullable|email|max:255',
            'company_overview' => 'nullable|string',
            'salary_range' => 'nullable|string|max:255',
            'application_deadline' => 'nullable|date',
            'expiry_date' => 'nullable|date',
            'status' => 'required|in:open,closed',
        ]);

        $data = $request->all();
        $data['slug'] = \Str::slug($request->job_title);

        // Handle JSON fields
        if ($request->filled('skills')) {
            $data['skills'] = array_filter(array_map('trim', explode(',', $request->skills)), function($skill) {
                return !empty($skill);
            });
        } else {
            $data['skills'] = [];
        }
        if ($request->filled('benefits')) {
            $data['benefits'] = array_filter(array_map('trim', explode(',', $request->benefits)), function($benefit) {
                return !empty($benefit);
            });
        } else {
            $data['benefits'] = [];
        }

        $career->update($data);

        return redirect()->route('admin.careers.index')->with('success', 'Career updated successfully.');
    }

    public function destroy(Career $career)
    {
        $career->delete();

        return redirect()->route('admin.careers.index')->with('success', 'Career deleted successfully.');
    }
}
