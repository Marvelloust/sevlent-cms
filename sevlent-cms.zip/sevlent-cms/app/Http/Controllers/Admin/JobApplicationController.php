<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\JobApplication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class JobApplicationController extends Controller
{
    public function index(Request $request)
    {
        $query = JobApplication::with('career');

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhereHas('career', function ($careerQuery) use ($search) {
                      $careerQuery->where('job_title', 'like', "%{$search}%");
                  });
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Career filter
        if ($request->filled('career_id')) {
            $query->where('career_id', $request->career_id);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');

        // Validate sort parameters
        $allowedSorts = ['name', 'email', 'status', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'created_at';
        }

        $query->orderBy($sortBy, $sortDirection);

        $applications = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalApplications = JobApplication::count();
        $pendingApplications = JobApplication::where('status', 'pending')->count();
        $reviewedApplications = JobApplication::where('status', 'reviewed')->count();
        $shortlistedApplications = JobApplication::where('status', 'shortlisted')->count();
        $hiredApplications = JobApplication::where('status', 'hired')->count();

        return view('admin.job-applications.index', compact(
            'applications',
            'totalApplications',
            'pendingApplications',
            'reviewedApplications',
            'shortlistedApplications',
            'hiredApplications'
        ));
    }

    public function show(JobApplication $jobApplication)
    {
        $jobApplication->load('career');
        return view('admin.job-applications.show', compact('jobApplication'));
    }

    public function update(Request $request, JobApplication $jobApplication)
    {
        $request->validate([
            'status' => 'required|in:pending,reviewed,shortlisted,rejected,hired',
            'notes' => 'nullable|string',
        ]);

        $jobApplication->update($request->only(['status', 'notes']));

        return redirect()
            ->route('admin.job-applications.show', $jobApplication)
            ->with('success', 'Application status updated successfully.');
    }

    public function destroy(JobApplication $jobApplication)
    {
        // Delete resume file
        if ($jobApplication->resume_path) {
            Storage::disk('public')->delete($jobApplication->resume_path);
        }

        $jobApplication->delete();

        return redirect()
            ->route('admin.job-applications.index')
            ->with('success', 'Application deleted successfully.');
    }
}
