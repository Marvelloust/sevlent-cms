<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class MediaController extends Controller
{
    public function index(Request $request)
    {
        $query = Media::with('uploader');

        // Filter by file type
        if ($request->has('type') && $request->type !== '') {
            $query->where('file_type', $request->type);
        }

        // Search by file name or alt text
        if ($request->has('search') && $request->search !== '') {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('file_name', 'like', "%{$search}%")
                  ->orWhere('alt_text', 'like', "%{$search}%");
            });
        }

        $media = $query->orderBy('created_at', 'desc')->paginate(24);

        $types = Media::select('file_type')->distinct()->pluck('file_type');

        return view('admin.media.index', compact('media', 'types'));
    }

    public function create()
    {
        return view('admin.media.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'files' => 'required|array|max:10',
            'files.*' => 'required|file|mimes:jpeg,png,jpg,gif,svg,webp,mp4,avi,mov,wmv,flv,webm,mp3,wav,ogg,pdf,doc,docx,xls,xlsx,ppt,pptx,txt,zip,rar|max:51200', // 50MB max
        ]);

        $uploadedFiles = [];

        foreach ($request->file('files') as $file) {
            $originalName = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $mimeType = $file->getMimeType();
            $size = $file->getSize();

            // Generate unique filename
            $filename = Str::uuid() . '.' . $extension;

            // Determine file type
            $fileType = $this->getFileType($mimeType);

            // Store file
            $path = $file->storeAs('media', $filename, 'public');

            // Create media record
            $media = Media::create([
                'file_name' => $originalName,
                'file_path' => $path,
                'file_type' => $fileType,
                'mime_type' => $mimeType,
                'file_size' => $size,
                'alt_text' => pathinfo($originalName, PATHINFO_FILENAME),
                'uploaded_by' => auth()->id(),
            ]);

            $uploadedFiles[] = $media;
        }

        $count = count($uploadedFiles);
        return redirect()->route('admin.media.index')->with('success', "{$count} file(s) uploaded successfully.");
    }

    public function show(Media $medium)
    {
        return view('admin.media.show', compact('medium'));
    }

    public function edit(Media $medium)
    {
        return view('admin.media.edit', compact('medium'));
    }

    public function update(Request $request, Media $medium)
    {
        $request->validate([
            'alt_text' => 'nullable|string|max:255',
            'file' => 'nullable|file|mimes:jpeg,png,jpg,gif,svg,webp,mp4,avi,mov,wmv,flv,webm,mp3,wav,ogg,pdf,doc,docx,xls,xlsx,ppt,pptx,txt,zip,rar|max:51200',
        ]);

        $data = $request->only(['alt_text']);

        // Handle file replacement
        if ($request->hasFile('file')) {
            // Delete old file
            Storage::disk('public')->delete($medium->file_path);

            $file = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            $filename = Str::uuid() . '.' . $extension;
            $mimeType = $file->getMimeType();
            $size = $file->getSize();
            $fileType = $this->getFileType($mimeType);

            // Store new file
            $path = $file->storeAs('media', $filename, 'public');

            $data = array_merge($data, [
                'file_name' => $file->getClientOriginalName(),
                'file_path' => $path,
                'file_type' => $fileType,
                'mime_type' => $mimeType,
                'file_size' => $size,
            ]);
        }

        $medium->update($data);

        return redirect()->route('admin.media.show', $medium)->with('success', 'Media updated successfully.');
    }

    public function destroy(Media $medium)
    {
        // Check if media is referenced by services
        $serviceReferences = $medium->services()->count();

        // Check if media is referenced by projects
        $projectReferences = $medium->projects()->count();

        if ($serviceReferences > 0 || $projectReferences > 0) {
            $references = [];
            if ($serviceReferences > 0) {
                $references[] = "{$serviceReferences} service(s)";
            }
            if ($projectReferences > 0) {
                $references[] = "{$projectReferences} project(s)";
            }

            return redirect()->back()->with('error', "Cannot delete '{$medium->file_name}' because it is still referenced by " . implode(', ', $references) . ". Please remove these references first.");
        }

        // Delete file from storage
        Storage::disk('public')->delete($medium->file_path);

        // Delete record
        $medium->delete();

        return redirect()->route('admin.media.index')->with('success', 'Media deleted successfully.');
    }

    public function bulkDelete(Request $request)
    {
        $request->validate([
            'media_ids' => 'required|array',
            'media_ids.*' => 'exists:media,id',
        ]);

        $media = Media::whereIn('id', $request->media_ids)->get();
        $deletedCount = 0;
        $skippedCount = 0;
        $skippedItems = [];

        foreach ($media as $item) {
            // Check if media is referenced by services
            $serviceReferences = \App\Models\Service::where('icon_image', $item->id)->count();

            // Check if media is referenced by projects through pivot table
            $projectReferences = $item->projects()->count();

            // Check if media is referenced by SEO metadata
            $seoReferences = \App\Models\SeoMetadata::where('og_image', $item->id)->count();

            if ($serviceReferences > 0 || $projectReferences > 0) {
                // Cannot delete - still referenced
                $skippedCount++;
                $references = [];
                if ($serviceReferences > 0) {
                    $references[] = "{$serviceReferences} service(s)";
                }
                if ($projectReferences > 0) {
                    $references[] = "{$projectReferences} project(s)";
                }
                $skippedItems[] = "{$item->file_name} (referenced by " . implode(', ', $references) . ")";
                continue;
            }

            // For SEO references, they will be set to null automatically due to onDelete('set null')

            // Delete file from storage
            Storage::disk('public')->delete($item->file_path);

            // Delete record
            $item->delete();
            $deletedCount++;
        }

        $message = "{$deletedCount} media file(s) deleted successfully.";
        if ($skippedCount > 0) {
            $message .= " {$skippedCount} file(s) were skipped because they are still referenced: " . implode(', ', $skippedItems);
        }

        return redirect()->route('admin.media.index')->with('success', $message);
    }

    /**
     * Get file type based on MIME type
     */
    private function getFileType($mimeType)
    {
        if (str_starts_with($mimeType, 'image/')) {
            return 'image';
        } elseif (str_starts_with($mimeType, 'video/')) {
            return 'video';
        } elseif (str_starts_with($mimeType, 'audio/')) {
            return 'audio';
        } elseif (in_array($mimeType, ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'])) {
            return 'document';
        } elseif (str_starts_with($mimeType, 'application/') && str_contains($mimeType, 'zip')) {
            return 'archive';
        } else {
            return 'other';
        }
    }

    public function selector(Request $request)
    {
        $query = Media::query();

        // Filter by file types (can be single type or array)
        if ($request->has('types') && $request->types !== '') {
            $types = json_decode($request->types, true);
            if (is_array($types) && !empty($types)) {
                $query->whereIn('file_type', $types);
            }
        } elseif ($request->has('type') && $request->type !== '') {
            // Fallback for single type parameter
            $query->where('file_type', $request->type);
        }

        // Search by file name or alt text
        if ($request->has('search') && $request->search !== '') {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('file_name', 'like', "%{$search}%")
                  ->orWhere('alt_text', 'like', "%{$search}%");
            });
        }

        $media = $query->orderBy('created_at', 'desc')->paginate(24);

        return view('admin.media.selector', compact('media'));
    }
}
