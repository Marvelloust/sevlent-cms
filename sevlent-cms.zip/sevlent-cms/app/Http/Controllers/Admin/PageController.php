<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class PageController extends Controller
{
    public function index(Request $request)
    {
        $query = Page::with('banner');

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'order_index');
        $sortDirection = $request->get('sort_direction', 'asc');

        // Validate sort parameters
        $allowedSorts = ['title', 'slug', 'status', 'created_at', 'updated_at', 'order_index'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'order_index';
        }

        $query->orderBy($sortBy, $sortDirection);

        $pages = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalPages = Page::count();
        $publishedPages = Page::where('status', 'published')->count();
        $draftPages = Page::where('status', 'draft')->count();

        return view('admin.pages.index', compact('pages', 'totalPages', 'publishedPages', 'draftPages'));
    }

    public function create()
    {
        return view('admin.pages.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:pages',
            'content' => 'required|string',
            'banner_image_id' => 'nullable|exists:media,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:draft,published',
        ]);

        $page = Page::create([
            'title' => $request->title,
            'slug' => $request->slug,
            'content' => $request->input('content'),
            'banner_image' => $request->banner_image_id,
            'status' => $request->status,
            'order_index' => Page::max('order_index') + 1,
            'created_by' => auth()->id(),
        ]);

        // Create SEO metadata
        if ($request->filled(['meta_title', 'meta_description', 'meta_keywords', 'canonical_url', 'og_title', 'og_description', 'og_image'])) {
            $page->seo()->create([
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'meta_keywords' => $request->meta_keywords,
                'canonical_url' => $request->canonical_url,
                'og_title' => $request->og_title,
                'og_description' => $request->og_description,
                'og_image' => $request->og_image,
            ]);
        }

        return redirect()->route('admin.pages.index')->with('success', 'Page created successfully.');
    }

    public function show(Page $page)
    {
        return view('admin.pages.show', compact('page'));
    }

    public function edit(Page $page)
    {
        return view('admin.pages.edit', compact('page'));
    }

    public function update(Request $request, Page $page)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:pages,slug,' . $page->id,
            'content' => 'required|string',
            'banner_image_id' => 'nullable|exists:media,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:draft,published',
        ]);

        $page->update([
            'title' => $request->title,
            'slug' => $request->slug,
            'content' => $request->input('content'),
            'banner_image' => $request->banner_image_id,
            'status' => $request->status,
        ]);

        // Update or create SEO metadata
        $seoData = [
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
            'meta_keywords' => $request->meta_keywords,
            'canonical_url' => $request->canonical_url,
            'og_title' => $request->og_title,
            'og_description' => $request->og_description,
            'og_image' => $request->og_image,
        ];

        if ($page->seo) {
            $page->seo->update($seoData);
        } else {
            $page->seo()->create($seoData);
        }

        return redirect()->route('admin.pages.index')->with('success', 'Page updated successfully.');
    }

    public function destroy(Page $page)
    {
        $page->delete();

        return redirect()->route('admin.pages.index')->with('success', 'Page deleted successfully.');
    }

    // Section management methods
    public function sections(Page $page)
    {
        $page->load(['sections' => function ($q) {
            $q->orderBy('order_index');
        }]);

        $sectionTypes = config('sections') ?: [
            'hero' => [
                'name' => 'Hero Section',
                'description' => 'Full-width hero section with headline, subheadline, and call-to-action button',
                'fields' => [
                    'section_title' => ['type' => 'text', 'label' => 'Section Title (Badge)', 'required' => false, 'placeholder' => 'e.g., Professional Software Solutions'],
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true, 'placeholder' => 'Enter your main headline'],
                    'subheadline' => ['type' => 'text', 'label' => 'Subheadline', 'required' => false, 'placeholder' => 'Enter your subheadline text'],
                    'description' => ['type' => 'textarea', 'label' => 'Description', 'required' => false, 'placeholder' => 'Enter a detailed description'],
                    'primary_button_text' => ['type' => 'text', 'label' => 'Primary Button Text', 'required' => false, 'placeholder' => 'e.g., Get Started'],
                    'primary_button_url' => ['type' => 'text', 'label' => 'Primary Button URL', 'required' => false, 'placeholder' => 'e.g., /contact'],
                    'secondary_button_text' => ['type' => 'text', 'label' => 'Secondary Button Text', 'required' => false, 'placeholder' => 'e.g., Learn More'],
                    'secondary_button_url' => ['type' => 'text', 'label' => 'Secondary Button URL', 'required' => false, 'placeholder' => 'e.g., /about'],
                    'background_image' => ['type' => 'media', 'label' => 'Background Image', 'required' => false],
                    'stats_json' => ['type' => 'stats', 'label' => 'Statistics', 'required' => false]
                ]
            ],
            'content' => [
                'name' => 'Content Section',
                'description' => 'Rich content section with customizable layout',
                'fields' => [
                    'layout' => ['type' => 'select', 'label' => 'Layout', 'required' => false, 'options' => ['full-width' => 'Full Width', 'two-column' => 'Two Column', 'centered' => 'Centered'], 'default' => 'full-width'],
                    'image' => ['type' => 'media', 'label' => 'Image', 'required' => false],
                    'image_position' => ['type' => 'select', 'label' => 'Image Position', 'required' => false, 'options' => ['left' => 'Left', 'right' => 'Right'], 'default' => 'right']
                ]
            ],
            'team' => [
                'name' => 'Team Section',
                'description' => 'Display team members with photos and information',
                'fields' => [
                    'members' => ['type' => 'team_members', 'label' => 'Team Members', 'required' => false]
                ]
            ],
            'cta' => [
                'name' => 'Call to Action',
                'description' => 'Call-to-action section with button',
                'fields' => [
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true, 'placeholder' => 'Ready to get started?'],
                    'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false, 'placeholder' => 'Join thousands of satisfied customers'],
                    'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false, 'placeholder' => 'Get Started'],
                    'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false, 'placeholder' => '/contact'],
                    'background_color' => ['type' => 'select', 'label' => 'Background Color', 'required' => false, 'options' => ['primary' => 'Primary', 'secondary' => 'Secondary', 'accent' => 'Accent', 'gray' => 'Gray'], 'default' => 'primary']
                ]
            ]
        ];

        return view('admin.pages.sections', compact('page', 'sectionTypes'));
    }

    public function storeSection(Request $request, Page $page)
    {
        try {
            $sectionTypes = config('sections') ?: [
                'hero' => [
                    'name' => 'Hero Section',
                    'fields' => [
                        'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                        'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                        'description' => ['type' => 'textarea', 'label' => 'Description', 'required' => false],
                        'primary_button_text' => ['type' => 'text', 'label' => 'Primary Button Text', 'required' => false],
                        'primary_button_url' => ['type' => 'text', 'label' => 'Primary Button URL', 'required' => false],
                        'secondary_button_text' => ['type' => 'text', 'label' => 'Secondary Button Text', 'required' => false],
                        'secondary_button_url' => ['type' => 'text', 'label' => 'Secondary Button URL', 'required' => false],
                        'background_image' => ['type' => 'media', 'label' => 'Background Image', 'required' => false],
                        'stats_json' => ['type' => 'stats', 'label' => 'Statistics', 'required' => false]
                    ]
                ],
                'content' => [
                    'name' => 'Content Section',
                    'fields' => [
                        'layout' => ['type' => 'select', 'label' => 'Layout', 'required' => false, 'options' => ['full-width' => 'Full Width', 'two-column' => 'Two Column', 'centered' => 'Centered'], 'default' => 'full-width'],
                        'image' => ['type' => 'media', 'label' => 'Image', 'required' => false],
                        'image_position' => ['type' => 'select', 'label' => 'Image Position', 'required' => false, 'options' => ['left' => 'Left', 'right' => 'Right'], 'default' => 'right']
                    ]
                ],
                'team' => [
                    'name' => 'Team Section',
                    'fields' => [
                        'members' => ['type' => 'team_members', 'label' => 'Team Members', 'required' => false]
                    ]
                ],
                'cta' => [
                    'name' => 'Call to Action',
                    'fields' => [
                        'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                        'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                        'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false],
                        'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false],
                        'background_color' => ['type' => 'select', 'label' => 'Background Color', 'required' => false, 'options' => ['primary' => 'Primary', 'secondary' => 'Secondary', 'accent' => 'Accent', 'gray' => 'Gray'], 'default' => 'primary']
                    ]
                ]
            ];
            $validTypes = implode(',', array_keys($sectionTypes));

            $validator = Validator::make($request->all(), [
                'type' => ['required', 'string', Rule::in(array_keys($sectionTypes))],
                'title' => 'required|string|max:255',
                'order_index' => 'required|integer|min:0'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $sectionType = $sectionTypes[$request->type] ?? null;
            if (!$sectionType) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid section type: ' . $request->type
                ], 400);
            }
        $data = [];

        // Process section-specific fields
        if (isset($sectionType['fields'])) {
            foreach ($sectionType['fields'] as $fieldKey => $fieldConfig) {
                if ($request->has($fieldKey)) {
                    $value = $request->input($fieldKey);

                    // Handle stats_json - convert to stats array
                    if ($fieldKey === 'stats_json' && !empty($value)) {
                        try {
                            if (is_array($value)) {
                                $data['stats'] = $value;
                            } else {
                                $data['stats'] = json_decode($value, true);
                            }
                        } catch (\Exception $e) {
                            \Log::error('Invalid JSON in stats_json field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle members - convert to members array with proper social links structure
                    elseif ($fieldKey === 'members' && !empty($value)) {
                        // The form sends team member data as an array directly
                        if (is_array($value)) {
                            // Process each member to structure social links properly
                            $processedMembers = [];
                            foreach ($value as $member) {
                                $socialLinks = [];
                                
                                // Collect social links from flat structure
                                if (!empty($member['linkedin'])) {
                                    $socialLinks['linkedin'] = $member['linkedin'];
                                }
                                if (!empty($member['twitter'])) {
                                    $socialLinks['twitter'] = $member['twitter'];
                                }
                                if (!empty($member['github'])) {
                                    $socialLinks['github'] = $member['github'];
                                }
                                if (!empty($member['dribbble'])) {
                                    $socialLinks['dribbble'] = $member['dribbble'];
                                }
                                
                                // Build member data with nested social array
                                $processedMember = [
                                    'name' => $member['name'] ?? '',
                                    'position' => $member['position'] ?? '',
                                    'bio' => $member['bio'] ?? '',
                                    'image' => $member['image'] ?? '',
                                ];
                                
                                if (!empty($socialLinks)) {
                                    $processedMember['social'] = $socialLinks;
                                }
                                
                                $processedMembers[] = $processedMember;
                            }
                            $data['members'] = $processedMembers;
                        } else {
                            // Fallback for JSON string (legacy support)
                            try {
                                $decodedValue = json_decode($value, true);
                                $data['members'] = is_array($decodedValue) ? $decodedValue : [];
                            } catch (\Exception $e) {
                                \Log::error('Invalid JSON in members field', ['error' => $e->getMessage()]);
                                $data['members'] = [];
                            }
                        }
                    }
                    // Handle content_blocks - ensure proper structure
                    elseif ($fieldKey === 'content_blocks' && !empty($value)) {
                        if (is_array($value)) {
                            $processedBlocks = [];
                            foreach ($value as $block) {
                                if (isset($block['type']) && $block['type'] === 'image') {
                                    $processedBlocks[] = [
                                        'type' => 'image',
                                        'content' => $block['content'] ?? '',
                                        'alt' => $block['alt'] ?? '',
                                        'caption' => $block['caption'] ?? ''
                                    ];
                                } else {
                                    $processedBlocks[] = $block;
                                }
                            }
                            $data['content_blocks'] = $processedBlocks;
                        }
                    } else {
                        $data[$fieldKey] = $value;
                    }
                }
            }
        }

        $section = Section::create([
            'page_id' => $page->id,
            'type' => $request->type,
            'title' => $request->title,
            'content' => $request->input('content') ?? $request->input('title') ?? 'Section content',
            'data' => $data,
            'order_index' => $request->order_index,
            'is_active' => $request->boolean('is_active', true)
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->load('page'),
            'message' => 'Section created successfully'
        ]);
        } catch (\Exception $e) {
            \Log::error('Error creating section: ' . $e->getMessage(), [
                'page_id' => $page->id,
                'request_data' => $request->all(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'An error occurred while creating the section: ' . $e->getMessage()
            ], 500);
        }
    }

    public function updateSection(Request $request, Page $page, Section $section)
    {
        try {
            $sectionTypes = config('sections') ?: [
                'hero' => [
                    'name' => 'Hero Section',
                    'fields' => [
                        'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                        'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                        'description' => ['type' => 'textarea', 'label' => 'Description', 'required' => false],
                        'primary_button_text' => ['type' => 'text', 'label' => 'Primary Button Text', 'required' => false],
                        'primary_button_url' => ['type' => 'text', 'label' => 'Primary Button URL', 'required' => false],
                        'secondary_button_text' => ['type' => 'text', 'label' => 'Secondary Button Text', 'required' => false],
                        'secondary_button_url' => ['type' => 'text', 'label' => 'Secondary Button URL', 'required' => false],
                        'background_image' => ['type' => 'media', 'label' => 'Background Image', 'required' => false],
                        'stats_json' => ['type' => 'stats', 'label' => 'Statistics', 'required' => false]
                    ]
                ],
                'content' => [
                    'name' => 'Content Section',
                    'fields' => [
                        'layout' => ['type' => 'select', 'label' => 'Layout', 'required' => false, 'options' => ['full-width' => 'Full Width', 'two-column' => 'Two Column', 'centered' => 'Centered'], 'default' => 'full-width'],
                        'image' => ['type' => 'media', 'label' => 'Image', 'required' => false],
                        'image_position' => ['type' => 'select', 'label' => 'Image Position', 'required' => false, 'options' => ['left' => 'Left', 'right' => 'Right'], 'default' => 'right']
                    ]
                ],
                'team' => [
                    'name' => 'Team Section',
                    'fields' => [
                        'members' => ['type' => 'team_members', 'label' => 'Team Members', 'required' => false]
                    ]
                ],
                'cta' => [
                    'name' => 'Call to Action',
                    'fields' => [
                        'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                        'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                        'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false],
                        'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false],
                        'background_color' => ['type' => 'select', 'label' => 'Background Color', 'required' => false, 'options' => ['primary' => 'Primary', 'secondary' => 'Secondary', 'accent' => 'Accent', 'gray' => 'Gray'], 'default' => 'primary']
                    ]
                ]
            ];
            $validTypes = implode(',', array_keys($sectionTypes));

            $validator = Validator::make($request->all(), [
                'type' => ['required', 'string', Rule::in(array_keys($sectionTypes))],
                'title' => 'required|string|max:255',
                'order_index' => 'required|integer|min:0'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $sectionType = $sectionTypes[$request->type] ?? null;
            if (!$sectionType) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid section type: ' . $request->type
                ], 400);
            }
        $data = [];

        // Process section-specific fields
        if (isset($sectionType['fields'])) {
            foreach ($sectionType['fields'] as $fieldKey => $fieldConfig) {
                if ($request->has($fieldKey)) {
                    $value = $request->input($fieldKey);

                    // Handle stats_json - convert to stats array
                    if ($fieldKey === 'stats_json' && !empty($value)) {
                        try {
                            if (is_array($value)) {
                                $data['stats'] = $value;
                            } else {
                                $data['stats'] = json_decode($value, true);
                            }
                        } catch (\Exception $e) {
                            \Log::error('Invalid JSON in stats_json field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle members - convert to members array
                    elseif ($fieldKey === 'members' && !empty($value)) {
                        // The form sends team member data as an array directly
                        if (is_array($value)) {
                            $data['members'] = $value;
                        } else {
                            // Fallback for JSON string (legacy support)
                            try {
                                $data['members'] = json_decode($value, true);
                            } catch (\Exception $e) {
                                \Log::error('Invalid JSON in members field', ['error' => $e->getMessage()]);
                            }
                        }
                    } else {
                        $data[$fieldKey] = $value;
                    }
                }
            }
        }

        $section->update([
            'type' => $request->type,
            'title' => $request->title,
            'content' => $request->input('content') ?? $request->input('title') ?? $section->content ?? 'Section content',
            'data' => $data,
            'order_index' => $request->order_index,
            'is_active' => $request->boolean('is_active', true)
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->fresh(),
            'message' => 'Section updated successfully'
        ]);
        } catch (\Exception $e) {
            \Log::error('Error updating section: ' . $e->getMessage(), [
                'section_id' => $section->id,
                'request_data' => $request->all(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating the section: ' . $e->getMessage()
            ], 500);
        }
    }

    public function toggleSection(Request $request, Page $page, Section $section)
    {
        $section->update([
            'is_active' => !$section->is_active
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->fresh(),
            'message' => 'Section ' . ($section->is_active ? 'enabled' : 'disabled') . ' successfully'
        ]);
    }

    public function destroySection(Page $page, Section $section)
    {
        $section->delete();

        return response()->json([
            'success' => true,
            'message' => 'Section deleted successfully'
        ]);
    }

    public function reorderSections(Request $request, Page $page)
    {
        $validator = Validator::make($request->all(), [
            'sections' => 'required|array',
            'sections.*.id' => 'required|integer|exists:sections,id',
            'sections.*.order_index' => 'required|integer|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        DB::transaction(function () use ($request) {
            foreach ($request->sections as $sectionData) {
                Section::where('id', $sectionData['id'])->update([
                    'order_index' => $sectionData['order_index']
                ]);
            }
        });

        return response()->json([
            'success' => true,
            'message' => 'Sections reordered successfully'
        ]);
    }

    public function showSection(Page $page, Section $section)
    {
        // Load media information for media fields
        $sectionData = $section->data ?? [];
        $sectionTypes = config('sections') ?: [
            'hero' => ['fields' => ['background_image' => ['type' => 'media']]],
            'content' => ['fields' => ['image' => ['type' => 'media']]],
            'team' => ['fields' => []],
            'cta' => ['fields' => []]
        ];

        if (isset($sectionTypes[$section->type]['fields'])) {
            foreach ($sectionTypes[$section->type]['fields'] as $fieldKey => $fieldConfig) {
                if ($fieldConfig['type'] === 'media' && isset($sectionData[$fieldKey]) && $sectionData[$fieldKey]) {
                    $media = \App\Models\Media::find($sectionData[$fieldKey]);
                    if ($media) {
                        $sectionData[$fieldKey . '_media'] = [
                            'id' => $media->id,
                            'name' => $media->file_name,
                            'url' => $media->url,
                            'type' => $media->file_type,
                            'size' => $media->file_size
                        ];
                    }
                }
            }
        }

        // Convert stats array back to JSON for form editing
        if (isset($sectionData['stats']) && is_array($sectionData['stats'])) {
            $sectionData['stats_json'] = json_encode($sectionData['stats']);
        }

        // Convert members array back to JSON for form editing
        if (isset($sectionData['members']) && is_array($sectionData['members'])) {
            $sectionData['members_json'] = json_encode($sectionData['members']);
        }

        $sectionArray = $section->toArray();
        $sectionArray['data'] = $sectionData;

        return response()->json([
            'success' => true,
            'section' => $sectionArray
        ]);
    }
}
