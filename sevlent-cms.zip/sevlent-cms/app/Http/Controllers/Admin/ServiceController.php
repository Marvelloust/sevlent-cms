<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ServiceController extends Controller
{
    public function index(Request $request)
    {
        $query = Service::with(['category', 'icon']);

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Category filter
        if ($request->filled('category') && $request->category !== 'all') {
            $query->where('service_category_id', $request->category);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');

        // Validate sort parameters
        $allowedSorts = ['name', 'slug', 'status', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'created_at';
        }

        $query->orderBy($sortBy, $sortDirection);

        $services = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalServices = Service::count();
        $activeServices = Service::where('status', 'active')->count();
        $inactiveServices = Service::where('status', 'inactive')->count();
        $categories = \App\Models\ServiceCategory::all();

        return view('admin.services.index', compact('services', 'totalServices', 'activeServices', 'inactiveServices', 'categories'));
    }

    public function create()
    {
        $categories = \App\Models\ServiceCategory::all();
        return view('admin.services.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'service_category_id' => 'required|exists:service_categories,id',
            'short_description' => 'nullable|string|max:500',
            'content_blocks' => 'nullable|array',
            'features' => 'nullable|array',
            'pricing_info' => 'nullable|array',
            'icon_image' => 'nullable|exists:media,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:active,inactive',
        ]);

        // Generate slug from name
        $slug = \Str::slug($request->name);
        $originalSlug = $slug;
        $counter = 1;
        while (Service::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        $service = Service::create([
            'name' => $request->name,
            'slug' => $slug,
            'service_category_id' => $request->service_category_id,
            'short_description' => $request->short_description,
            'content_blocks' => $request->content_blocks,
            'features' => $request->features,
            'pricing_info' => $request->pricing_info,
            'icon_image' => $request->icon_image,
            'status' => $request->status,
        ]);

        // Create SEO metadata
        if ($request->filled(['meta_title', 'meta_description', 'meta_keywords', 'canonical_url', 'og_title', 'og_description', 'og_image'])) {
            $service->seo()->create([
                'meta_title' => $request->meta_title,
                'meta_description' => $request->meta_description,
                'meta_keywords' => $request->meta_keywords,
                'canonical_url' => $request->canonical_url,
                'og_title' => $request->og_title,
                'og_description' => $request->og_description,
                'og_image' => $request->og_image,
            ]);
        }

        return redirect()->route('admin.services.index')->with('success', 'Service created successfully.');
    }

    public function show(Service $service)
    {
        $service->load(['category', 'icon', 'seo.ogImage']);
        return view('admin.services.show', compact('service'));
    }

    public function edit(Service $service)
    {
        $categories = \App\Models\ServiceCategory::all();
        $service->load(['category', 'icon', 'seo.ogImage']);
        return view('admin.services.edit', compact('service', 'categories'));
    }

    public function update(Request $request, Service $service)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'service_category_id' => 'required|exists:service_categories,id',
            'short_description' => 'nullable|string|max:500',
            'content_blocks' => 'nullable|array',
            'features' => 'nullable|array',
            'pricing_info' => 'nullable|array',
            'icon_image' => 'nullable|exists:media,id',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:500',
            'meta_keywords' => 'nullable|string|max:255',
            'canonical_url' => 'nullable|url',
            'og_title' => 'nullable|string|max:255',
            'og_description' => 'nullable|string|max:500',
            'og_image' => 'nullable|exists:media,id',
            'status' => 'required|in:active,inactive',
        ]);

        $service->update([
            'name' => $request->name,
            'service_category_id' => $request->service_category_id,
            'short_description' => $request->short_description,
            'content_blocks' => $request->content_blocks,
            'features' => $request->features,
            'pricing_info' => $request->pricing_info,
            'icon_image' => $request->icon_image,
            'status' => $request->status,
        ]);

        // Update or create SEO metadata
        $seoData = [
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
            'meta_keywords' => $request->meta_keywords,
            'canonical_url' => $request->canonical_url,
            'og_title' => $request->og_title,
            'og_description' => $request->og_description,
            'og_image' => $request->og_image,
        ];

        if ($service->seo) {
            $service->seo->update($seoData);
        } else {
            $service->seo()->create($seoData);
        }

        return redirect()->route('admin.services.index')->with('success', 'Service updated successfully.');
    }

    public function destroy(Service $service)
    {
        if ($service->icon) {
            Storage::disk('public')->delete($service->icon);
        }
        $service->delete();

        return redirect()->route('admin.services.index')->with('success', 'Service deleted successfully.');
    }
}
