<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    public function index(Request $request)
    {
        $query = Faq::query();

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('question', 'like', "%{$search}%")
                  ->orWhere('answer', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            if ($request->status === 'active') {
                $query->where('is_active', true);
            } elseif ($request->status === 'inactive') {
                $query->where('is_active', false);
            }
        }

        // Icon filter
        if ($request->filled('icon') && $request->icon !== 'all') {
            $query->where('icon', $request->icon);
        }

        // Color filter
        if ($request->filled('color') && $request->color !== 'all') {
            $query->where('color', $request->color);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'order');
        $sortDirection = $request->get('sort_direction', 'asc');

        // Validate sort parameters
        $allowedSorts = ['question', 'icon', 'color', 'is_active', 'order', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'order';
        }

        $query->orderBy($sortBy, $sortDirection);

        $faqs = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalFaqs = Faq::count();
        $activeFaqs = Faq::where('is_active', true)->count();
        $inactiveFaqs = Faq::where('is_active', false)->count();

        return view('admin.faqs.index', compact('faqs', 'totalFaqs', 'activeFaqs', 'inactiveFaqs'));
    }

    public function create()
    {
        return view('admin.faqs.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'question' => 'required|string|max:255',
            'answer' => 'required|string',
            'icon' => 'required|string|in:clock,settings,lightbulb,check,calendar',
            'color' => 'required|string|in:blue,purple,indigo,green,orange',
            'order' => 'nullable|integer',
            'is_active' => 'boolean',
        ]);

        $validated['is_active'] = $request->has('is_active');
        $validated['order'] = $validated['order'] ?? Faq::max('order') + 1;

        Faq::create($validated);

        return redirect()->route('admin.faqs.index')->with('success', 'FAQ created successfully.');
    }

    public function edit(Faq $faq)
    {
        return view('admin.faqs.edit', compact('faq'));
    }

    public function show(Faq $faq)
    {
        return view('admin.faqs.show', compact('faq'));
    }

    public function update(Request $request, Faq $faq)
    {
        $validated = $request->validate([
            'question' => 'required|string|max:255',
            'answer' => 'required|string',
            'icon' => 'required|string|in:clock,settings,lightbulb,check,calendar',
            'color' => 'required|string|in:blue,purple,indigo,green,orange',
            'order' => 'nullable|integer',
            'is_active' => 'boolean',
        ]);

        $validated['is_active'] = $request->has('is_active');

        $faq->update($validated);

        return redirect()->route('admin.faqs.index')->with('success', 'FAQ updated successfully.');
    }

    public function destroy(Faq $faq)
    {
        $faq->delete();
        return redirect()->route('admin.faqs.index')->with('success', 'FAQ deleted successfully.');
    }
}
