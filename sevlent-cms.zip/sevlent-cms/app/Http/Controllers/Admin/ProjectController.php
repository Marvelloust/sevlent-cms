<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        $query = Project::with(['media']);

        // Search filter
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Status filter
        if ($request->filled('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        // Sort options
        $sortBy = $request->get('sort_by', 'created_at');
        $sortDirection = $request->get('sort_direction', 'desc');

        // Validate sort parameters
        $allowedSorts = ['title', 'status', 'created_at', 'updated_at'];
        if (!in_array($sortBy, $allowedSorts)) {
            $sortBy = 'created_at';
        }

        $query->orderBy($sortBy, $sortDirection);

        $projects = $query->paginate(15)->withQueryString();

        // Get total counts for stats (not affected by filters)
        $totalProjects = Project::count();
        $activeProjects = Project::where('status', 'active')->count();
        $inactiveProjects = Project::where('status', 'inactive')->count();

        return view('admin.projects.index', compact('projects', 'totalProjects', 'activeProjects', 'inactiveProjects'));
    }

    public function create()
    {
        return view('admin.projects.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'technologies' => 'nullable|string|max:500',
            'media_ids' => 'nullable|array',
            'media_ids.*' => 'exists:media,id',
            'content_blocks' => 'nullable|array',
            'content_blocks.*.type' => 'required|in:heading,paragraph,image,list,link',
            'content_blocks.*.content' => 'nullable|string',
            'status' => 'required|in:active,inactive',
        ]);

        $data = $request->all();

        // Convert technologies string to array
        if (isset($data['technologies']) && is_string($data['technologies'])) {
            $data['technologies'] = array_map('trim', explode(',', $data['technologies']));
        }

        // Process content blocks
        if (isset($data['content_blocks']) && is_array($data['content_blocks'])) {
            $processedBlocks = [];
            foreach ($data['content_blocks'] as $block) {
                $processedBlock = [
                    'type' => $block['type'],
                    'content' => $block['content'] ?? '',
                ];
                
                // For link blocks, combine text and URL
                if ($block['type'] === 'link' && isset($block['link_text'])) {
                    $processedBlock['content'] = $block['link_text'] . '|' . ($block['content'] ?? '');
                }
                
                // For image blocks, store the image path
                if ($block['type'] === 'image' && isset($block['image'])) {
                    $processedBlock['image'] = $block['image'];
                }
                
                $processedBlocks[] = $processedBlock;
            }
            $data['content_blocks'] = $processedBlocks;
        }

        $project = Project::create($data);

        // Sync media relationships
        if ($request->has('media_ids')) {
            $project->media()->sync($request->media_ids);
        }

        return redirect()->route('admin.projects.index')->with('success', 'Project created successfully.');
    }

    public function show(Project $project)
    {
        $project->load(['media']);
        return view('admin.projects.show', compact('project'));
    }

    public function edit(Project $project)
    {
        $project->load(['media']);
        return view('admin.projects.edit', compact('project'));
    }

    public function update(Request $request, Project $project)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'technologies' => 'nullable|string|max:500',
            'media_ids' => 'nullable|array',
            'media_ids.*' => 'exists:media,id',
            'content_blocks' => 'nullable|array',
            'content_blocks.*.type' => 'required|in:heading,paragraph,image,list,link',
            'content_blocks.*.content' => 'nullable|string',
            'status' => 'required|in:active,inactive',
        ]);

        $data = $request->all();

        // Convert technologies string to array
        if (isset($data['technologies']) && is_string($data['technologies'])) {
            $data['technologies'] = array_map('trim', explode(',', $data['technologies']));
        }

        // Process content blocks
        if (isset($data['content_blocks']) && is_array($data['content_blocks'])) {
            $processedBlocks = [];
            foreach ($data['content_blocks'] as $block) {
                $processedBlock = [
                    'type' => $block['type'],
                    'content' => $block['content'] ?? '',
                ];
                
                // For link blocks, combine text and URL
                if ($block['type'] === 'link' && isset($block['link_text'])) {
                    $processedBlock['content'] = $block['link_text'] . '|' . ($block['content'] ?? '');
                }
                
                // For image blocks, store the image path
                if ($block['type'] === 'image' && isset($block['image'])) {
                    $processedBlock['image'] = $block['image'];
                }
                
                $processedBlocks[] = $processedBlock;
            }
            $data['content_blocks'] = $processedBlocks;
        }

        $project->update($data);

        // Sync media relationships
        if ($request->has('media_ids')) {
            $project->media()->sync($request->media_ids);
        } else {
            $project->media()->detach();
        }

        return redirect()->route('admin.projects.index')->with('success', 'Project updated successfully.');
    }

    public function destroy(Project $project)
    {
        foreach ($project->media as $media) {
            Storage::disk('public')->delete($media->path);
            $media->delete();
        }
        $project->delete();

        return redirect()->route('admin.projects.index')->with('success', 'Project deleted successfully.');
    }
}
