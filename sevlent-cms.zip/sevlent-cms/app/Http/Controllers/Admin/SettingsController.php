<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index()
    {
        $settings = Setting::pluck('value', 'key')->toArray();
        return view('admin.settings.index', compact('settings'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'company_name' => 'nullable|string|max:255',
            'tagline' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'favicon' => 'nullable|image|mimes:jpeg,png,jpg,gif,ico|max:1024',
            'primary_color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'secondary_color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'accent_color' => 'nullable|string|regex:/^#[0-9A-Fa-f]{6}$/',
            'facebook' => 'nullable|url',
            'twitter' => 'nullable|url',
            'linkedin' => 'nullable|url',
            'instagram' => 'nullable|url',
            'footer_content' => 'nullable|string',
            'default_meta_title' => 'nullable|string|max:255',
            'default_meta_description' => 'nullable|string|max:500',
        ]);

        foreach ($validated as $key => $value) {
            // Skip if value is null or empty (except for specific fields that can be empty)
            if (is_null($value) || (is_string($value) && trim($value) === '')) {
                continue;
            }

            // Determine the group based on the setting key
            $group = match($key) {
                'company_name', 'tagline', 'logo', 'favicon', 'primary_color', 'secondary_color', 'accent_color' => 'branding',
                'email', 'phone', 'address', 'facebook', 'twitter', 'linkedin', 'instagram' => 'contact',
                'default_meta_title', 'default_meta_description', 'default_meta_keywords' => 'seo',
                'footer_content' => 'footer',
                default => 'general'
            };

            if ($request->hasFile($key)) {
                $file = $request->file($key);
                $path = $file->store('settings', 'public');
                Setting::updateOrCreate(
                    ['key' => $key],
                    ['value' => $path, 'group_name' => $group]
                );
            } else {
                Setting::updateOrCreate(
                    ['key' => $key],
                    ['value' => $value, 'group_name' => $group]
                );
            }
        }

        // Check if theme colors were updated
        $themeColorsUpdated = isset($validated['primary_color']) || 
                              isset($validated['secondary_color']) || 
                              isset($validated['accent_color']);

        $message = 'Settings updated successfully.';
        if ($themeColorsUpdated) {
            $message .= ' Theme colors will update automatically across the site.';
        }

        return redirect()->route('admin.settings.index')->with('success', $message);
    }
}
