<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Blog;
use App\Models\BlogCategory;
use App\Models\Contact;
use App\Models\JobApplication;
use App\Models\Media;
use App\Models\Page;
use App\Models\Project;
use App\Models\Service;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;

class AnalyticsController extends Controller
{
    /**
     * Display the analytics dashboard
     */
    public function index(Request $request)
    {
        $dateFrom = $request->filled('date_from') 
            ? Carbon::parse($request->date_from)->startOfDay()
            : Carbon::now()->subDays(30)->startOfDay();
        
        $dateTo = $request->filled('date_to')
            ? Carbon::parse($request->date_to)->endOfDay()
            : Carbon::now()->endOfDay();

        $comparison = $request->get('comparison', 'previous_period');

        // Calculate comparison period
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $comparisonFrom = $dateFrom->copy()->subDays($daysDiff + 1);
        $comparisonTo = $dateFrom->copy()->subDay();

        // Overview Statistics
        $stats = $this->getOverviewStats($dateFrom, $dateTo, $comparisonFrom, $comparisonTo);

        // Chart Data
        $chartData = [
            'content' => $this->getContentTrendsData($dateFrom, $dateTo),
            'contacts' => $this->getContactsData($dateFrom, $dateTo),
            'jobApplications' => $this->getJobApplicationsData($dateFrom, $dateTo),
            'activities' => $this->getActivitiesData($dateFrom, $dateTo),
            'users' => $this->getUsersData($dateFrom, $dateTo),
            'mediaDistribution' => $this->getMediaDistribution(),
            'topPages' => $this->getTopPages(),
            'categoryDistribution' => $this->getCategoryDistribution(),
        ];

        return view('admin.analytics.index', compact(
            'stats',
            'chartData',
            'dateFrom',
            'dateTo',
            'comparison'
        ));
    }

    /**
     * Get overview statistics
     */
    private function getOverviewStats($dateFrom, $dateTo, $comparisonFrom, $comparisonTo)
    {
        $stats = [
            'total_content' => [
                'current' => $this->getTotalContent($dateFrom, $dateTo),
                'previous' => $this->getTotalContent($comparisonFrom, $comparisonTo),
                'label' => 'Total Content',
                'icon' => 'fas fa-file-alt',
                'color' => 'blue',
            ],
            'new_contacts' => [
                'current' => Contact::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => Contact::whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'New Contacts',
                'icon' => 'fas fa-envelope',
                'color' => 'green',
            ],
            'job_applications' => [
                'current' => JobApplication::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => JobApplication::whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'Job Applications',
                'icon' => 'fas fa-user-tie',
                'color' => 'purple',
            ],
            'total_users' => [
                'current' => User::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => User::whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'New Users',
                'icon' => 'fas fa-users',
                'color' => 'indigo',
            ],
            'active_projects' => [
                'current' => Project::where('status', 'published')->whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => Project::where('status', 'published')->whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'Active Projects',
                'icon' => 'fas fa-project-diagram',
                'color' => 'yellow',
            ],
            'published_blogs' => [
                'current' => Blog::where('status', 'published')->whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => Blog::where('status', 'published')->whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'Published Blogs',
                'icon' => 'fas fa-blog',
                'color' => 'pink',
            ],
            'media_uploads' => [
                'current' => Media::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => Media::whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'Media Uploads',
                'icon' => 'fas fa-image',
                'color' => 'red',
            ],
            'total_activities' => [
                'current' => Activity::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
                'previous' => Activity::whereBetween('created_at', [$comparisonFrom, $comparisonTo])->count(),
                'label' => 'Total Activities',
                'icon' => 'fas fa-chart-line',
                'color' => 'teal',
            ],
        ];

        // Calculate percentage changes
        foreach ($stats as $key => &$stat) {
            $stat['change'] = $stat['previous'] > 0 
                ? round((($stat['current'] - $stat['previous']) / $stat['previous']) * 100, 1)
                : ($stat['current'] > 0 ? 100 : 0);
        }

        return $stats;
    }

    /**
     * Get total content count
     */
    private function getTotalContent($dateFrom, $dateTo)
    {
        $blogs = Blog::whereBetween('created_at', [$dateFrom, $dateTo])->count();
        $pages = Page::whereBetween('created_at', [$dateFrom, $dateTo])->count();
        $projects = Project::whereBetween('created_at', [$dateFrom, $dateTo])->count();
        $services = Service::whereBetween('created_at', [$dateFrom, $dateTo])->count();

        return $blogs + $pages + $projects + $services;
    }

    /**
     * Get content trends data over time
     */
    private function getContentTrendsData($dateFrom, $dateTo)
    {
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $groupBy = $daysDiff > 60 ? 'week' : 'day';

        $dates = [];
        $currentDate = $dateFrom->copy();
        
        while ($currentDate <= $dateTo) {
            if ($groupBy === 'week') {
                $dates[] = $currentDate->copy()->startOfWeek()->format('Y-m-d');
                $currentDate->addWeek();
            } else {
                $dates[] = $currentDate->format('Y-m-d');
                $currentDate->addDay();
            }
        }

        $dates = array_unique($dates);
        sort($dates);

        $blogs = $this->getCountsByDate(Blog::class, $dateFrom, $dateTo, $groupBy);
        $projects = $this->getCountsByDate(Project::class, $dateFrom, $dateTo, $groupBy);
        $services = $this->getCountsByDate(Service::class, $dateFrom, $dateTo, $groupBy);
        $pages = $this->getCountsByDate(Page::class, $dateFrom, $dateTo, $groupBy);

        // Get theme colors
        $colors = $this->getThemeColors();

        return [
            'labels' => array_map(function($date) use ($groupBy) {
                return $groupBy === 'week' 
                    ? 'Week of ' . Carbon::parse($date)->format('M d')
                    : Carbon::parse($date)->format('M d');
            }, $dates),
            'datasets' => [
                [
                    'label' => 'Blogs',
                    'data' => array_map(fn($date) => $blogs[$date] ?? 0, $dates),
                    'borderColor' => $colors['primary']['solid'],
                    'backgroundColor' => $colors['primary']['light'],
                ],
                [
                    'label' => 'Projects',
                    'data' => array_map(fn($date) => $projects[$date] ?? 0, $dates),
                    'borderColor' => $colors['secondary']['solid'],
                    'backgroundColor' => $colors['secondary']['light'],
                ],
                [
                    'label' => 'Services',
                    'data' => array_map(fn($date) => $services[$date] ?? 0, $dates),
                    'borderColor' => $colors['accent']['solid'],
                    'backgroundColor' => $colors['accent']['light'],
                ],
                [
                    'label' => 'Pages',
                    'data' => array_map(fn($date) => $pages[$date] ?? 0, $dates),
                    'borderColor' => $colors['primary']['solid'],
                    'backgroundColor' => $colors['primary']['light'],
                ],
            ],
        ];
    }

    /**
     * Get contacts data over time
     */
    private function getContactsData($dateFrom, $dateTo)
    {
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $groupBy = $daysDiff > 60 ? 'week' : 'day';

        $dates = [];
        $currentDate = $dateFrom->copy();
        
        while ($currentDate <= $dateTo) {
            if ($groupBy === 'week') {
                $dates[] = $currentDate->copy()->startOfWeek()->format('Y-m-d');
                $currentDate->addWeek();
            } else {
                $dates[] = $currentDate->format('Y-m-d');
                $currentDate->addDay();
            }
        }

        $dates = array_unique($dates);
        sort($dates);

        $contacts = $this->getCountsByDate(Contact::class, $dateFrom, $dateTo, $groupBy);

        return [
            'labels' => array_map(function($date) use ($groupBy) {
                return $groupBy === 'week' 
                    ? 'Week of ' . Carbon::parse($date)->format('M d')
                    : Carbon::parse($date)->format('M d');
            }, $dates),
            'data' => array_map(fn($date) => $contacts[$date] ?? 0, $dates),
        ];
    }

    /**
     * Get job applications data over time
     */
    private function getJobApplicationsData($dateFrom, $dateTo)
    {
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $groupBy = $daysDiff > 60 ? 'week' : 'day';

        $dates = [];
        $currentDate = $dateFrom->copy();
        
        while ($currentDate <= $dateTo) {
            if ($groupBy === 'week') {
                $dates[] = $currentDate->copy()->startOfWeek()->format('Y-m-d');
                $currentDate->addWeek();
            } else {
                $dates[] = $currentDate->format('Y-m-d');
                $currentDate->addDay();
            }
        }

        $dates = array_unique($dates);
        sort($dates);

        $applications = $this->getCountsByDate(JobApplication::class, $dateFrom, $dateTo, $groupBy);

        return [
            'labels' => array_map(function($date) use ($groupBy) {
                return $groupBy === 'week' 
                    ? 'Week of ' . Carbon::parse($date)->format('M d')
                    : Carbon::parse($date)->format('M d');
            }, $dates),
            'data' => array_map(fn($date) => $applications[$date] ?? 0, $dates),
        ];
    }

    /**
     * Get activities data over time
     */
    private function getActivitiesData($dateFrom, $dateTo)
    {
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $groupBy = $daysDiff > 60 ? 'week' : 'day';

        $dates = [];
        $currentDate = $dateFrom->copy();
        
        while ($currentDate <= $dateTo) {
            if ($groupBy === 'week') {
                $dates[] = $currentDate->copy()->startOfWeek()->format('Y-m-d');
                $currentDate->addWeek();
            } else {
                $dates[] = $currentDate->format('Y-m-d');
                $currentDate->addDay();
            }
        }

        $dates = array_unique($dates);
        sort($dates);

        $activities = $this->getCountsByDate(Activity::class, $dateFrom, $dateTo, $groupBy);

        return [
            'labels' => array_map(function($date) use ($groupBy) {
                return $groupBy === 'week' 
                    ? 'Week of ' . Carbon::parse($date)->format('M d')
                    : Carbon::parse($date)->format('M d');
            }, $dates),
            'data' => array_map(fn($date) => $activities[$date] ?? 0, $dates),
        ];
    }

    /**
     * Get users data over time
     */
    private function getUsersData($dateFrom, $dateTo)
    {
        $daysDiff = $dateFrom->diffInDays($dateTo);
        $groupBy = $daysDiff > 60 ? 'week' : 'day';

        $dates = [];
        $currentDate = $dateFrom->copy();
        
        while ($currentDate <= $dateTo) {
            if ($groupBy === 'week') {
                $dates[] = $currentDate->copy()->startOfWeek()->format('Y-m-d');
                $currentDate->addWeek();
            } else {
                $dates[] = $currentDate->format('Y-m-d');
                $currentDate->addDay();
            }
        }

        $dates = array_unique($dates);
        sort($dates);

        $users = $this->getCountsByDate(User::class, $dateFrom, $dateTo, $groupBy);

        return [
            'labels' => array_map(function($date) use ($groupBy) {
                return $groupBy === 'week' 
                    ? 'Week of ' . Carbon::parse($date)->format('M d')
                    : Carbon::parse($date)->format('M d');
            }, $dates),
            'data' => array_map(fn($date) => $users[$date] ?? 0, $dates),
        ];
    }

    /**
     * Get media distribution by file type
     */
    private function getMediaDistribution()
    {
        $mediaByType = Media::selectRaw('file_type, COUNT(*) as count')
            ->groupBy('file_type')
            ->orderBy('count', 'desc')
            ->get();

        $labels = [];
        $data = [];

        foreach ($mediaByType as $item) {
            $labels[] = ucfirst($item->file_type);
            $data[] = $item->count;
        }

        return [
            'labels' => $labels,
            'data' => $data,
        ];
    }

    /**
     * Get category distribution for blogs
     */
    private function getCategoryDistribution()
    {
        $categories = BlogCategory::withCount('blogs')
            ->orderBy('blogs_count', 'desc')
            ->limit(10)
            ->get();

        return [
            'labels' => $categories->pluck('name')->toArray(),
            'data' => $categories->pluck('blogs_count')->toArray(),
        ];
    }

    /**
     * Get top pages by sections count
     */
    private function getTopPages()
    {
        $pages = Page::withCount('sections')
            ->orderBy('sections_count', 'desc')
            ->limit(10)
            ->get();

        return [
            'labels' => $pages->pluck('title')->toArray(),
            'data' => $pages->pluck('sections_count')->toArray(),
        ];
    }

    /**
     * Helper method to get counts by date
     */
    private function getCountsByDate($model, $dateFrom, $dateTo, $groupBy = 'day')
    {
        $dateFormat = $groupBy === 'week' ? 'YYYY-MM-DD' : 'YYYY-MM-DD';
        
        if (config('database.default') === 'mysql') {
            $formatString = $groupBy === 'week' 
                ? "DATE_FORMAT(DATE_SUB(created_at, INTERVAL WEEKDAY(created_at) DAY), '%Y-%m-%d')"
                : "DATE_FORMAT(created_at, '%Y-%m-%d')";
        } else {
            $formatString = $groupBy === 'week'
                ? "strftime('%Y-%m-%d', created_at, 'weekday 0', '-7 days')"
                : "strftime('%Y-%m-%d', created_at)";
        }

        $results = $model::whereBetween('created_at', [$dateFrom, $dateTo])
            ->selectRaw("$formatString as date, COUNT(*) as count")
            ->groupBy('date')
            ->orderBy('date')
            ->pluck('count', 'date')
            ->toArray();

        return $results;
    }

    /**
     * Export analytics data
     */
    public function export(Request $request)
    {
        $dateFrom = $request->filled('date_from') 
            ? Carbon::parse($request->date_from)->startOfDay()
            : Carbon::now()->subDays(30)->startOfDay();
        
        $dateTo = $request->filled('date_to')
            ? Carbon::parse($request->date_to)->endOfDay()
            : Carbon::now()->endOfDay();

        $data = [
            'period' => $dateFrom->format('Y-m-d') . ' to ' . $dateTo->format('Y-m-d'),
            'blogs' => Blog::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'projects' => Project::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'services' => Service::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'pages' => Page::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'contacts' => Contact::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'job_applications' => JobApplication::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'users' => User::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
            'activities' => Activity::whereBetween('created_at', [$dateFrom, $dateTo])->count(),
        ];

        return response()->json($data);
    }

    /**
     * Convert hex color to RGB string
     */
    private function hexToRgb($hex, $alpha = null)
    {
        $hex = str_replace('#', '', $hex);
        
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        return $alpha !== null 
            ? "rgba($r, $g, $b, $alpha)"
            : "rgb($r, $g, $b)";
    }

    /**
     * Get theme colors from settings
     */
    private function getThemeColors()
    {
        $primaryColor = setting('primary_color', '#3b82f6');
        $secondaryColor = setting('secondary_color', '#8b5cf6');
        $accentColor = setting('accent_color', '#10b981');
        
        return [
            'primary' => [
                'solid' => $this->hexToRgb($primaryColor),
                'light' => $this->hexToRgb($primaryColor, 0.1),
            ],
            'secondary' => [
                'solid' => $this->hexToRgb($secondaryColor),
                'light' => $this->hexToRgb($secondaryColor, 0.1),
            ],
            'accent' => [
                'solid' => $this->hexToRgb($accentColor),
                'light' => $this->hexToRgb($accentColor, 0.1),
            ],
        ];
    }
}
