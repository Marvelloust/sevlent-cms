<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class ContactSettingController extends Controller
{
    public function index()
    {
        $contactSettings = [
            'contact_address' => Setting::where('key', 'contact_address')->first()?->value ?? '',
            'contact_phone' => Setting::where('key', 'contact_phone')->first()?->value ?? '',
            'contact_email' => Setting::where('key', 'contact_email')->first()?->value ?? '',
            'contact_business_hours' => Setting::where('key', 'contact_business_hours')->first()?->value ?? '',
            'contact_map_url' => Setting::where('key', 'contact_map_url')->first()?->value ?? '',
            'faq_section_title' => Setting::where('key', 'faq_section_title')->first()?->value ?? 'Frequently Asked Questions',
            'faq_section_subtitle' => Setting::where('key', 'faq_section_subtitle')->first()?->value ?? 'Find answers to common questions about our services and get the information you need',
            'faq_help_title' => Setting::where('key', 'faq_help_title')->first()?->value ?? 'Didn\'t find what you were looking for?',
            'faq_help_description' => Setting::where('key', 'faq_help_description')->first()?->value ?? 'Feel free to contact us directly and we\'ll be happy to answer your questions.',
            'faq_help_button_text' => Setting::where('key', 'faq_help_button_text')->first()?->value ?? 'Get in Touch',
        ];

        return view('admin.contact-settings.index', compact('contactSettings'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'contact_address' => 'nullable|string',
            'contact_phone' => 'nullable|string',
            'contact_email' => 'nullable|email',
            'contact_business_hours' => 'nullable|string',
            'contact_map_url' => 'nullable|url',
            'faq_section_title' => 'nullable|string',
            'faq_section_subtitle' => 'nullable|string',
            'faq_help_title' => 'nullable|string',
            'faq_help_description' => 'nullable|string',
            'faq_help_button_text' => 'nullable|string',
        ]);

        // Map keys to their group names
        $groupMap = [
            'contact_address' => 'contact',
            'contact_phone' => 'contact',
            'contact_email' => 'contact',
            'contact_business_hours' => 'contact',
            'contact_map_url' => 'contact',
            'faq_section_title' => 'faq',
            'faq_section_subtitle' => 'faq',
            'faq_help_title' => 'faq',
            'faq_help_description' => 'faq',
            'faq_help_button_text' => 'faq',
        ];

        foreach ($validated as $key => $value) {
            Setting::updateOrCreate(
                ['key' => $key],
                [
                    'value' => $value ?? '',
                    'group_name' => $groupMap[$key] ?? 'general'
                ]
            );
        }

        return redirect()->route('admin.contact-settings.index')->with('success', 'Contact settings updated successfully.');
    }
}
