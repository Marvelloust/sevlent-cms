<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Display a listing of notifications
     */
    public function index(Request $request)
    {
        $query = Notification::query();

        // Apply filters
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        if ($request->filled('read_status')) {
            if ($request->read_status === 'read') {
                $query->where('is_read', true);
            } elseif ($request->read_status === 'unread') {
                $query->where('is_read', false);
            }
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $notifications = $query->orderBy('created_at', 'desc')->paginate(20);
        $unreadCount = Notification::unread()->count();

        // Get available types for filter dropdown
        $availableTypes = Notification::distinct('type')->pluck('type')->filter()->values();

        return view('admin.notifications.index', compact('notifications', 'unreadCount', 'availableTypes'));
    }

    /**
     * Get recent notifications for dropdown (AJAX)
     */
    public function getRecent()
    {
        $notifications = Notification::recent(10)->get();
        $unreadCount = Notification::unread()->count();

        // Map notifications to include human readable timestamps
        $payload = $notifications->map(function ($n) {
            return [
                'id' => $n->id,
                'type' => $n->type,
                'title' => $n->title,
                'message' => $n->message,
                'data' => $n->data,
                'link' => $n->link,
                'icon_class' => $n->icon_class ?? null,
                'color_class' => $n->color_class ?? null,
                'is_read' => (bool) $n->is_read,
                'created_at' => $n->created_at,
                'created_at_human' => $n->created_at->diffForHumans(),
                'created_at_formatted' => $n->created_at->format('M j, Y H:i'),
            ];
        });

        return response()->json([
            'notifications' => $payload,
            'unread_count' => $unreadCount,
        ]);
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id)
    {
        $notification = Notification::findOrFail($id);
        $notification->markAsRead();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Notification marked as read',
            ]);
        }

        return redirect()->back()->with('success', 'Notification marked as read');
    }

    /**
     * Mark all notifications as read
     */
    public function markAllAsRead()
    {
        $this->notificationService->markAllAsRead();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'All notifications marked as read',
            ]);
        }

        return redirect()->back()->with('success', 'All notifications marked as read');
    }

    /**
     * Delete a notification
     */
    public function destroy($id)
    {
        $notification = Notification::findOrFail($id);
        $notification->delete();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Notification deleted',
            ]);
        }

        return redirect()->back()->with('success', 'Notification deleted');
    }

    /**
     * Delete all read notifications
     */
    public function clearRead()
    {
        Notification::read()->delete();

        if (request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'All read notifications cleared',
            ]);
        }

        return redirect()->back()->with('success', 'All read notifications cleared');
    }
}
