<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;use Illuminate\Support\Facades\Log;use Illuminate\Support\Facades\Validator;

class HomepageController extends Controller
{
    public function index()
    {
        $page = Page::where('slug', 'home')->with(['sections' => function ($q) {
            $q->orderBy('order_index');
        }])->first();

        Log::info('Homepage controller - Page found:', $page ? $page->toArray() : 'null');

        if (!$page) {
            Log::info('Creating homepage');
            $page = Page::create([
                'title' => 'Home',
                'slug' => 'home',
                'content' => 'Welcome to our homepage',
                'status' => 'published',
                'order_index' => 1,
                'created_by' => auth()->id()
            ]);
        }

        Log::info('Page sections count: ' . $page->sections->count());
        Log::info('Page sections', ['sections' => $page->sections->toArray()]);

        $sectionTypes = config('sections') ?: [
            'hero' => [
                'name' => 'Hero Section',
                'description' => 'Full-width hero section with headline, subheadline, and call-to-action button',
                'fields' => [
                    'section_title' => ['type' => 'text', 'label' => 'Section Title (Badge)', 'required' => false, 'placeholder' => 'e.g., Professional Software Solutions'],
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true, 'placeholder' => 'Enter your main headline'],
                    'subheadline' => ['type' => 'text', 'label' => 'Subheadline', 'required' => false, 'placeholder' => 'Enter your subheadline text'],
                    'description' => ['type' => 'textarea', 'label' => 'Description', 'required' => false, 'placeholder' => 'Enter a detailed description'],
                    'primary_button_text' => ['type' => 'text', 'label' => 'Primary Button Text', 'required' => false, 'placeholder' => 'e.g., Get Started'],
                    'primary_button_url' => ['type' => 'text', 'label' => 'Primary Button URL', 'required' => false, 'placeholder' => 'e.g., /contact'],
                    'secondary_button_text' => ['type' => 'text', 'label' => 'Secondary Button Text', 'required' => false, 'placeholder' => 'e.g., Learn More'],
                    'secondary_button_url' => ['type' => 'text', 'label' => 'Secondary Button URL', 'required' => false, 'placeholder' => 'e.g., /about'],
                    'background_image' => ['type' => 'media', 'label' => 'Background Image', 'required' => false],
                    'stats_json' => ['type' => 'stats', 'label' => 'Statistics', 'required' => false]
                ]
            ],
            'about' => [
                'name' => 'About Section',
                'description' => 'Two-column section with text content and optional image',
                'fields' => [
                    'image' => ['type' => 'media', 'label' => 'Image', 'required' => false]
                ]
            ],
            'services' => [
                'name' => 'Services Preview',
                'description' => 'Display featured services in a grid layout',
                'fields' => [
                    'number_to_display' => ['type' => 'number', 'label' => 'Number of Services to Display', 'required' => false, 'placeholder' => 'e.g., 6'],
                    'show_view_all' => ['type' => 'checkbox', 'label' => 'Show "View All" Button', 'required' => false]
                ]
            ],
            'content' => [
                'name' => 'Content Section',
                'description' => 'Simple content section with rich text editor',
                'fields' => []
            ],
            'cta' => [
                'name' => 'Call to Action',
                'description' => 'Centered call-to-action section',
                'fields' => [
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                    'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                    'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false],
                    'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false]
                ]
            ]
        ];
        Log::info('Section types config:', $sectionTypes);

        return view('admin.homepage.index', compact('page', 'sectionTypes'));
    }

    public function store(Request $request)
    {
        $sectionTypes = config('sections') ?: [
            'hero' => ['name' => 'Hero Section', 'fields' => ['headline' => [], 'subheadline' => [], 'description' => [], 'primary_button_text' => [], 'primary_button_url' => [], 'secondary_button_text' => [], 'secondary_button_url' => [], 'background_image' => []]],
            'about' => ['name' => 'About Section', 'fields' => ['image' => []]],
            'services' => ['name' => 'Services Preview', 'fields' => ['number_to_display' => ['type' => 'number'], 'show_view_all' => ['type' => 'checkbox']]],
            'content' => ['name' => 'Content Section', 'fields' => []],
            'cta' => ['name' => 'Call to Action', 'fields' => ['headline' => [], 'subheadline' => [], 'button_text' => [], 'button_url' => []]]
        ];
        $validTypes = implode(',', array_keys($sectionTypes));

        Log::info('Section types config', ['sectionTypes' => $sectionTypes]);
        Log::info('Valid types string: ' . $validTypes);
        Log::info('Request data', ['request' => $request->all()]);

        $validator = Validator::make($request->all(), [
            'type' => 'required|string|in:' . $validTypes,
            'title' => 'required|string|max:255',
            'order_index' => 'required|integer|min:0'
        ]);

        if ($validator->fails()) {
            Log::info('Validation failed', ['errors' => $validator->errors()->toArray()]);
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $page = Page::where('slug', 'home')->first();
        if (!$page) {
            $page = Page::create([
                'title' => 'Home',
                'slug' => 'home',
                'content' => 'Welcome to our homepage',
                'status' => 'published',
                'order_index' => 1,
                'created_by' => auth()->id()
            ]);
        }

        $sectionType = config('sections')[$request->type];
        $data = [];

        // Process section-specific fields
        if (isset($sectionType['fields'])) {
            foreach ($sectionType['fields'] as $fieldKey => $fieldConfig) {
                if ($request->has($fieldKey)) {
                    $value = $request->input($fieldKey);
                    
                    // Handle stats_json - convert to stats array
                    if ($fieldKey === 'stats_json' && !empty($value)) {
                        try {
                            $data['stats'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in stats_json field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle features - convert to features array
                    elseif ($fieldKey === 'features' && !empty($value)) {
                        try {
                            $data['features'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in features field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle trust_indicators - convert to trust_indicators array
                    elseif ($fieldKey === 'trust_indicators' && !empty($value)) {
                        try {
                            $data['trust_indicators'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in trust_indicators field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle testimonials - convert to testimonials array
                    elseif ($fieldKey === 'testimonials' && !empty($value)) {
                        try {
                            $data['testimonials'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in testimonials field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle services - convert to services array
                    elseif ($fieldKey === 'services' && !empty($value)) {
                        try {
                            $data['services'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in services field', ['error' => $e->getMessage()]);
                        }
                    } else {
                        $data[$fieldKey] = $value;
                    }
                }
            }
        }

        $section = Section::create([
            'page_id' => $page->id,
            'type' => $request->type,
            'title' => $request->title,
            'content' => $request->input('content', ''),
            'data' => $data,
            'order_index' => $request->order_index,
            'is_active' => $request->boolean('is_active', true)
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->load('page'),
            'message' => 'Section created successfully'
        ]);
    }

    public function update(Request $request, Section $section)
    {
        $sectionTypes = config('sections');
        $validTypes = implode(',', array_keys($sectionTypes));

        Log::info('Update - Section types config', ['sectionTypes' => $sectionTypes]);
        Log::info('Update - Valid types string: ' . $validTypes);
        Log::info('Update - Request data', ['request' => $request->all()]);
        Log::info('Update - Section', ['section' => $section->toArray()]);

        $validator = Validator::make($request->all(), [
            'type' => 'required|string|in:' . $validTypes,
            'title' => 'required|string|max:255',
            'order_index' => 'required|integer|min:0'
        ]);

        if ($validator->fails()) {
            Log::info('Update validation failed', ['errors' => $validator->errors()->toArray()]);
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $sectionType = config('sections')[$request->type];
        $data = [];

        // Process section-specific fields
        if (isset($sectionType['fields'])) {
            foreach ($sectionType['fields'] as $fieldKey => $fieldConfig) {
                if ($request->has($fieldKey)) {
                    $value = $request->input($fieldKey);
                    
                    // Handle stats_json - convert to stats array
                    if ($fieldKey === 'stats_json' && !empty($value)) {
                        try {
                            $data['stats'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in stats_json field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle features - convert to features array
                    elseif ($fieldKey === 'features' && !empty($value)) {
                        try {
                            $data['features'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in features field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle trust_indicators - convert to trust_indicators array
                    elseif ($fieldKey === 'trust_indicators' && !empty($value)) {
                        try {
                            $data['trust_indicators'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in trust_indicators field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle testimonials - convert to testimonials array
                    elseif ($fieldKey === 'testimonials' && !empty($value)) {
                        try {
                            $data['testimonials'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in testimonials field', ['error' => $e->getMessage()]);
                        }
                    }
                    // Handle services - convert to services array
                    elseif ($fieldKey === 'services' && !empty($value)) {
                        try {
                            $data['services'] = json_decode($value, true);
                        } catch (\Exception $e) {
                            Log::error('Invalid JSON in services field', ['error' => $e->getMessage()]);
                        }
                    } else {
                        $data[$fieldKey] = $value;
                    }
                }
            }
        }

        $section->update([
            'type' => $request->type,
            'title' => $request->title,
            'content' => $request->input('content', ''),
            'data' => $data,
            'order_index' => $request->order_index,
            'is_active' => $request->boolean('is_active', true)
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->fresh(),
            'message' => 'Section updated successfully'
        ]);
    }

    public function reorder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'sections' => 'required|array',
            'sections.*.id' => 'required|integer|exists:sections,id',
            'sections.*.order_index' => 'required|integer|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        DB::transaction(function () use ($request) {
            foreach ($request->sections as $sectionData) {
                Section::where('id', $sectionData['id'])->update([
                    'order_index' => $sectionData['order_index']
                ]);
            }
        });

        return response()->json([
            'success' => true,
            'message' => 'Sections reordered successfully'
        ]);
    }

    public function toggle(Request $request, Section $section)
    {
        $section->update([
            'is_active' => !$section->is_active
        ]);

        return response()->json([
            'success' => true,
            'section' => $section->fresh(),
            'message' => 'Section ' . ($section->is_active ? 'enabled' : 'disabled') . ' successfully'
        ]);
    }

    public function destroy(Section $section)
    {
        $section->delete();

        return response()->json([
            'success' => true,
            'message' => 'Section deleted successfully'
        ]);
    }

    public function show(Section $section)
    {
        // Load media information for media fields
        $sectionData = $section->data ?? [];
        $sectionTypes = config('sections') ?: [
            'hero' => ['fields' => ['background_image' => ['type' => 'media']]],
            'about' => ['fields' => ['image' => ['type' => 'media']]],
            'services' => ['fields' => []],
            'content' => ['fields' => []],
            'cta' => ['fields' => []]
        ];

        if (isset($sectionTypes[$section->type]['fields'])) {
            foreach ($sectionTypes[$section->type]['fields'] as $fieldKey => $fieldConfig) {
                if ($fieldConfig['type'] === 'media' && isset($sectionData[$fieldKey]) && $sectionData[$fieldKey]) {
                    $media = \App\Models\Media::find($sectionData[$fieldKey]);
                    if ($media) {
                        $sectionData[$fieldKey . '_media'] = [
                            'id' => $media->id,
                            'name' => $media->file_name,
                            'url' => $media->url,
                            'type' => $media->file_type,
                            'size' => $media->file_size
                        ];
                    }
                }
            }
        }

        // Convert stats array back to JSON for form editing
        if (isset($sectionData['stats']) && is_array($sectionData['stats'])) {
            $sectionData['stats_json'] = json_encode($sectionData['stats']);
        }

        $sectionArray = $section->toArray();
        $sectionArray['data'] = $sectionData;

        return response()->json([
            'success' => true,
            'section' => $sectionArray
        ]);
    }

    public function getSectionTypes()
    {
        $sectionTypes = config('sections') ?: [
            'hero' => [
                'name' => 'Hero Section',
                'description' => 'Full-width hero section with headline, subheadline, and call-to-action button',
                'fields' => [
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true, 'placeholder' => 'Enter your main headline'],
                    'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false, 'placeholder' => 'Enter your subheadline text'],
                    'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false, 'placeholder' => 'e.g., Get Started'],
                    'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false, 'placeholder' => 'e.g., /contact'],
                    'background_image' => ['type' => 'media', 'label' => 'Background Image', 'required' => false]
                ]
            ],
            'about' => [
                'name' => 'About Section',
                'description' => 'Two-column section with text content and optional image',
                'fields' => [
                    'image' => ['type' => 'media', 'label' => 'Image', 'required' => false]
                ]
            ],
            'services' => [
                'name' => 'Services Preview',
                'description' => 'Display featured services in a grid layout',
                'fields' => [
                    'number_to_display' => ['type' => 'number', 'label' => 'Number of Services to Display', 'required' => false, 'placeholder' => 'e.g., 6'],
                    'show_view_all' => ['type' => 'checkbox', 'label' => 'Show "View All" Button', 'required' => false]
                ]
            ],
            'content' => [
                'name' => 'Content Section',
                'description' => 'Simple content section with rich text editor',
                'fields' => []
            ],
            'cta' => [
                'name' => 'Call to Action',
                'description' => 'Centered call-to-action section',
                'fields' => [
                    'headline' => ['type' => 'text', 'label' => 'Headline', 'required' => true],
                    'subheadline' => ['type' => 'textarea', 'label' => 'Subheadline', 'required' => false],
                    'button_text' => ['type' => 'text', 'label' => 'Button Text', 'required' => false],
                    'button_url' => ['type' => 'text', 'label' => 'Button URL', 'required' => false]
                ]
            ]
        ];

        return response()->json([
            'success' => true,
            'sectionTypes' => $sectionTypes
        ]);
    }
}
