<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\MenuItem;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $menus = Menu::with('items')->get();
        return view('admin.menus.index', compact('menus'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.menus.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        Menu::create($request->only(['name']));

        return redirect()->route('admin.menus.index')->with('success', 'Menu created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Menu $menu)
    {
        $menu->load([
            'items' => function($query) {
                $query->with('children')->orderBy('order_index');
            },
            'topLevelItems' => function($query) {
                $query->with('children')->orderBy('order_index');
            }
        ]);

        $pages = Page::select('id', 'title', 'slug')->get();

        return view('admin.menus.show', compact('menu', 'pages'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Menu $menu)
    {
        return view('admin.menus.edit', compact('menu'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Menu $menu)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $menu->update($request->only(['name']));

        return redirect()->route('admin.menus.index')->with('success', 'Menu updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Menu $menu)
    {
        $menu->delete();

        return redirect()->route('admin.menus.index')->with('success', 'Menu deleted successfully.');
    }

    /**
     * Store a new menu item.
     */
    public function storeItem(Request $request, Menu $menu)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'url' => 'nullable|string|max:255',
            'page_id' => 'nullable|exists:pages,id',
            'parent_id' => 'nullable|exists:menu_items,id',
            'target' => 'required|in:_self,_blank,_parent,_top',
            'css_class' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'is_active' => 'boolean',
        ]);

        // Generate URL based on page_id or use provided URL
        $url = null;
        if ($request->page_id) {
            $page = \App\Models\Page::find($request->page_id);
            $url = $page ? '/' . $page->slug : $request->url;
        } else {
            $url = $request->url;
        }

        $maxOrder = MenuItem::where('menu_id', $menu->id)
            ->where('parent_id', $request->parent_id)
            ->max('order_index') ?? 0;

        $depth = 0;
        if ($request->parent_id) {
            $parent = MenuItem::find($request->parent_id);
            $depth = $parent->depth + 1;
        }

        MenuItem::create([
            'menu_id' => $menu->id,
            'parent_id' => $request->parent_id,
            'title' => $request->title,
            'url' => $url,
            'page_id' => $request->page_id,
            'target' => $request->target,
            'css_class' => $request->css_class,
            'icon' => $request->icon,
            'order_index' => $maxOrder + 1,
            'depth' => $depth,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->back()->with('success', 'Menu item added successfully.');
    }

    /**
     * Update a menu item.
     */
    public function updateItem(Request $request, Menu $menu, MenuItem $item)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'url' => 'nullable|string|max:255',
            'page_id' => 'nullable|exists:pages,id',
            'parent_id' => 'nullable|exists:menu_items,id',
            'target' => 'required|in:_self,_blank,_parent,_top',
            'css_class' => 'nullable|string|max:255',
            'icon' => 'nullable|string|max:255',
            'is_active' => 'boolean',
        ]);

        // Generate URL based on page_id or use provided URL
        $url = null;
        if ($request->page_id) {
            $page = \App\Models\Page::find($request->page_id);
            $url = $page ? '/' . $page->slug : $request->url;
        } else {
            $url = $request->url;
        }

        $depth = 0;
        if ($request->parent_id) {
            $parent = MenuItem::find($request->parent_id);
            $depth = $parent->depth + 1;
        }

        $item->update([
            'parent_id' => $request->parent_id,
            'title' => $request->title,
            'url' => $url,
            'page_id' => $request->page_id,
            'target' => $request->target,
            'css_class' => $request->css_class,
            'icon' => $request->icon,
            'depth' => $depth,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return redirect()->back()->with('success', 'Menu item updated successfully.');
    }

    /**
     * Delete a menu item.
     */
    public function destroyItem(Menu $menu, MenuItem $item)
    {
        // Delete all children recursively
        $this->deleteItemAndChildren($item);

        return redirect()->back()->with('success', 'Menu item deleted successfully.');
    }

    /**
     * Reorder menu items.
     */
    public function reorder(Request $request, Menu $menu)
    {
        $request->validate([
            'items' => 'required|array',
            'items.*.id' => 'required|integer|exists:menu_items,id',
            'items.*.order_index' => 'required|integer',
            'items.*.parent_id' => 'nullable|integer|exists:menu_items,id',
        ]);

        DB::transaction(function () use ($request) {
            foreach ($request->items as $itemData) {
                $item = MenuItem::find($itemData['id']);

                $depth = 0;
                if ($itemData['parent_id']) {
                    $parent = MenuItem::find($itemData['parent_id']);
                    $depth = $parent->depth + 1;
                }

                $item->update([
                    'order_index' => $itemData['order_index'],
                    'parent_id' => $itemData['parent_id'],
                    'depth' => $depth,
                ]);
            }
        });

        return response()->json(['success' => true]);
    }

    /**
     * Recursively delete menu item and its children.
     */
    private function deleteItemAndChildren(MenuItem $item)
    {
        foreach ($item->children as $child) {
            $this->deleteItemAndChildren($child);
        }

        $item->delete();
    }
}
