<?php

return [
    'hero' => [
        'name' => 'Hero Section',
        'description' => 'Full-width hero section with headline, subheadline, and call-to-action buttons',
        'fields' => [
            'section_title' => [
                'type' => 'text',
                'label' => 'Section Title (Badge)',
                'required' => false,
                'placeholder' => 'e.g., Professional Software Solutions'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Enter your main headline'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Enter your subheadline text'
            ],
            'description' => [
                'type' => 'textarea',
                'label' => 'Description',
                'required' => false,
                'placeholder' => 'Enter a detailed description'
            ],
            'primary_button_text' => [
                'type' => 'text',
                'label' => 'Primary Button Text',
                'required' => false,
                'placeholder' => 'e.g., Get Started'
            ],
            'primary_button_url' => [
                'type' => 'text',
                'label' => 'Primary Button URL',
                'required' => false,
                'placeholder' => 'e.g., /contact'
            ],
            'secondary_button_text' => [
                'type' => 'text',
                'label' => 'Secondary Button Text',
                'required' => false,
                'placeholder' => 'e.g., Learn More'
            ],
            'secondary_button_url' => [
                'type' => 'text',
                'label' => 'Secondary Button URL',
                'required' => false,
                'placeholder' => 'e.g., /about'
            ],
            'background_image' => [
                'type' => 'media',
                'label' => 'Background Image',
                'required' => false
            ],
            'stats_json' => [
                'type' => 'stats',
                'label' => 'Statistics',
                'required' => false
            ]
        ]
    ],

    'about' => [
        'name' => 'About Section',
        'description' => 'Two-column section with text content and optional image',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., About Us'
            ],
            'image' => [
                'type' => 'media',
                'label' => 'Image',
                'required' => false
            ],
            'floating_stat_number' => [
                'type' => 'text',
                'label' => 'Floating Stat Number',
                'required' => false,
                'placeholder' => 'e.g., 10+'
            ],
            'floating_stat_label' => [
                'type' => 'text',
                'label' => 'Floating Stat Label',
                'required' => false,
                'placeholder' => 'e.g., Years Experience'
            ],
            'features' => [
                'type' => 'features',
                'label' => 'Features',
                'required' => false
            ],
            'cta_button_text' => [
                'type' => 'text',
                'label' => 'CTA Button Text',
                'required' => false,
                'placeholder' => 'e.g., Learn More About Us'
            ],
            'cta_button_url' => [
                'type' => 'text',
                'label' => 'CTA Button URL',
                'required' => false,
                'placeholder' => 'e.g., /about'
            ]
        ]
    ],

    'services' => [
        'name' => 'Services Preview',
        'description' => 'Display all active services from the database in a grid layout',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Services'
            ],
            'display_limit' => [
                'type' => 'number',
                'label' => 'Number of Services to Display',
                'required' => false,
                'placeholder' => 'Leave empty to show all',
                'min' => 1,
                'max' => 50
            ],
            'show_view_all' => [
                'type' => 'checkbox',
                'label' => 'Show "View All" Button',
                'required' => false,
                'default' => true
            ]
        ]
    ],

    'content' => [
        'name' => 'Content Section',
        'description' => 'Structured content section with badge, headline, and multiple content blocks',
        'fields' => [
            'section_badge' => [
                'type' => 'text',
                'label' => 'Section Badge/Label',
                'required' => false,
                'placeholder' => 'e.g., Our Story, About Us'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Main Headline',
                'required' => false,
                'placeholder' => 'Enter the main heading'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Optional subheading or introductory text'
            ],
            'content_blocks' => [
                'type' => 'content_blocks',
                'label' => 'Content Blocks',
                'required' => false,
                'description' => 'Add multiple content blocks with headings and paragraphs'
            ],
            'background_color' => [
                'type' => 'select',
                'label' => 'Background Color',
                'required' => false,
                'options' => [
                    'white' => 'White',
                    'gray' => 'Light Gray',
                    'blue' => 'Light Blue',
                    'gradient' => 'Gradient'
                ],
                'default' => 'white'
            ]
        ]
    ],

    'cta' => [
        'name' => 'Call to Action',
        'description' => 'Centered call-to-action section with badge, headline, subheadline, button, and trust indicators',
        'fields' => [
            'badge_text' => [
                'type' => 'text',
                'label' => 'Badge Text',
                'required' => false,
                'placeholder' => 'e.g., Let\'s Work Together'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Enter your main headline'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Enter your subheadline text'
            ],
            'button_text' => [
                'type' => 'text',
                'label' => 'Button Text',
                'required' => false,
                'placeholder' => 'e.g., Get Free Consultation'
            ],
            'button_url' => [
                'type' => 'text',
                'label' => 'Button URL',
                'required' => false,
                'placeholder' => 'e.g., /contact'
            ],
            'trust_indicators' => [
                'type' => 'features',
                'label' => 'Trust Indicators',
                'required' => false,
                'description' => 'Add trust indicators like "Free Consultation", "Quick Response", etc.'
            ]
        ]
    ],

    'testimonials' => [
        'name' => 'Testimonials',
        'description' => 'Customer testimonials and reviews section with ratings and client information',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Testimonials'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'What Our Clients Say'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Hear from our satisfied clients'
            ],
            'testimonials' => [
                'type' => 'testimonials',
                'label' => 'Testimonials',
                'required' => false,
                'description' => 'Add customer testimonials with ratings, names, positions, and content'
            ],
            'cta_button_text' => [
                'type' => 'text',
                'label' => 'CTA Button Text',
                'required' => false,
                'placeholder' => 'Get in Touch'
            ],
            'cta_button_url' => [
                'type' => 'text',
                'label' => 'CTA Button URL',
                'required' => false,
                'placeholder' => '/contact'
            ]
        ]
    ],

    'team' => [
        'name' => 'Team Section',
        'description' => 'Display team members with photos, bios, and social links',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Team'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Meet Our Team'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Get to know the people behind our success'
            ],
            'members' => [
                'type' => 'team_members',
                'label' => 'Team Members',
                'required' => false,
                'description' => 'Add team members with their photos, positions, bios, and social links'
            ],
            'cta_button_text' => [
                'type' => 'text',
                'label' => 'CTA Button Text',
                'required' => false,
                'placeholder' => 'Join Our Team'
            ],
            'cta_button_url' => [
                'type' => 'text',
                'label' => 'CTA Button URL',
                'required' => false,
                'placeholder' => '/careers'
            ]
        ]
    ],

    'mission' => [
        'name' => 'Mission Statement',
        'description' => 'Company mission statement with icon and description',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Mission'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Mission'
            ],
            'mission_statement' => [
                'type' => 'textarea',
                'label' => 'Mission Statement',
                'required' => true,
                'placeholder' => 'Enter your company mission statement'
            ],
            'description' => [
                'type' => 'textarea',
                'label' => 'Additional Description',
                'required' => false,
                'placeholder' => 'Provide additional context or details'
            ],
            'icon_image' => [
                'type' => 'media',
                'label' => 'Icon/Image',
                'required' => false
            ]
        ]
    ],

    'vision' => [
        'name' => 'Vision Statement',
        'description' => 'Company vision statement with future goals',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Vision'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Vision'
            ],
            'vision_statement' => [
                'type' => 'textarea',
                'label' => 'Vision Statement',
                'required' => true,
                'placeholder' => 'Enter your company vision statement'
            ],
            'description' => [
                'type' => 'textarea',
                'label' => 'Additional Description',
                'required' => false,
                'placeholder' => 'Describe your future goals and aspirations'
            ],
            'background_image' => [
                'type' => 'media',
                'label' => 'Background Image',
                'required' => false
            ]
        ]
    ],

    'story' => [
        'name' => 'Origin Story',
        'description' => 'Company origin story with timeline milestones',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Story'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Journey'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'A brief introduction to your story'
            ],
            'timeline_items' => [
                'type' => 'features',
                'label' => 'Timeline Milestones',
                'required' => true,
                'description' => 'Add key milestones in your company journey. Use the Icon field for the year (e.g., "2020")'
            ]
        ]
    ],

    'values' => [
        'name' => 'Core Values',
        'description' => 'Display company core values with icons and descriptions',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Values'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'What We Stand For'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Introduction to your core values'
            ],
            'values_list' => [
                'type' => 'features',
                'label' => 'Core Values',
                'required' => true,
                'description' => 'Add your core values with titles and descriptions'
            ]
        ]
    ],

    'purpose' => [
        'name' => 'Purpose Statement',
        'description' => 'Why your company exists and what drives you',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Purpose'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Why We Exist'
            ],
            'purpose_statement' => [
                'type' => 'textarea',
                'label' => 'Purpose Statement',
                'required' => true,
                'placeholder' => 'Describe your company\'s core purpose'
            ],
            'description' => [
                'type' => 'textarea',
                'label' => 'Additional Description',
                'required' => false,
                'placeholder' => 'Elaborate on what drives your organization'
            ],
            'background_color' => [
                'type' => 'select',
                'label' => 'Background Color',
                'required' => false,
                'options' => [
                    'white' => 'White',
                    'gray' => 'Light Gray',
                    'blue' => 'Light Blue',
                    'gradient' => 'Gradient'
                ],
                'default' => 'gradient'
            ]
        ]
    ],

    'philosophy' => [
        'name' => 'Philosophy & Beliefs',
        'description' => 'Company philosophy and guiding principles',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Philosophy'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Beliefs'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Introduction to your philosophy'
            ],
            'philosophy_content' => [
                'type' => 'textarea',
                'label' => 'Philosophy Statement',
                'required' => true,
                'placeholder' => 'Describe your company\'s philosophy and beliefs'
            ],
            'principles' => [
                'type' => 'features',
                'label' => 'Guiding Principles',
                'required' => false,
                'description' => 'Add your guiding principles'
            ]
        ]
    ],

    'approach' => [
        'name' => 'Approach & Methodology',
        'description' => 'How you work and your methodology',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Approach'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'How We Work'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Brief description of your methodology'
            ],
            'approach_description' => [
                'type' => 'textarea',
                'label' => 'Approach Description',
                'required' => true,
                'placeholder' => 'Describe your working methodology'
            ],
            'steps' => [
                'type' => 'features',
                'label' => 'Process Steps',
                'required' => false,
                'description' => 'Add your process steps or methodology stages'
            ],
            'methodology_image' => [
                'type' => 'media',
                'label' => 'Methodology Diagram/Image',
                'required' => false
            ]
        ]
    ],

    'commitment' => [
        'name' => 'Commitment & Promise',
        'description' => 'Your commitment to customers and stakeholders',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Commitment'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Promise to You'
            ],
            'commitment_statement' => [
                'type' => 'textarea',
                'label' => 'Commitment Statement',
                'required' => true,
                'placeholder' => 'State your commitment to customers'
            ],
            'promises' => [
                'type' => 'features',
                'label' => 'Our Promises',
                'required' => false,
                'description' => 'Add specific promises or commitments'
            ],
            'cta_button_text' => [
                'type' => 'text',
                'label' => 'CTA Button Text',
                'required' => false,
                'placeholder' => 'Get Started'
            ],
            'cta_button_url' => [
                'type' => 'text',
                'label' => 'CTA Button URL',
                'required' => false,
                'placeholder' => '/contact'
            ]
        ]
    ],

    'impact' => [
        'name' => 'Impact & Results',
        'description' => 'Showcase your impact with statistics',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Impact'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Making a Difference'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Describe your impact'
            ],
            'stats_json' => [
                'type' => 'stats',
                'label' => 'Impact Statistics',
                'required' => false,
                'description' => 'Add metrics and statistics'
            ]
        ]
    ],

    'community' => [
        'name' => 'Community & Culture',
        'description' => 'Company culture and community involvement',
        'fields' => [
            'section_label' => [
                'type' => 'text',
                'label' => 'Section Label',
                'required' => false,
                'placeholder' => 'e.g., Our Culture'
            ],
            'headline' => [
                'type' => 'text',
                'label' => 'Headline',
                'required' => true,
                'placeholder' => 'Our Community'
            ],
            'subheadline' => [
                'type' => 'textarea',
                'label' => 'Subheadline',
                'required' => false,
                'placeholder' => 'Introduction to your culture'
            ],
            'culture_description' => [
                'type' => 'textarea',
                'label' => 'Culture Description',
                'required' => true,
                'placeholder' => 'Describe your company culture and values'
            ],
            'culture_highlights' => [
                'type' => 'features',
                'label' => 'Culture Highlights',
                'required' => false,
                'description' => 'Add key aspects of your culture'
            ],
            'culture_image' => [
                'type' => 'media',
                'label' => 'Culture Image',
                'required' => false
            ],
            'cta_button_text' => [
                'type' => 'text',
                'label' => 'CTA Button Text',
                'required' => false,
                'placeholder' => 'Join Our Team'
            ],
            'cta_button_url' => [
                'type' => 'text',
                'label' => 'CTA Button URL',
                'required' => false,
                'placeholder' => '/careers'
            ]
        ]
    ]
];